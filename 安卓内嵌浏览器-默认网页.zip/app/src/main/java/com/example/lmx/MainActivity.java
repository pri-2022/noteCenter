package com.example.lmx;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        WebView webView = (WebView) findViewById(R.id.web_view);

        // 设置本地存储
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAppCacheEnabled(true);
        String appCachepath = getApplication().getCacheDir().getAbsolutePath();
        webView.getSettings().setAppCachePath(appCachepath);
        webView.getSettings().setDatabaseEnabled(true);


        // 设置 url 地址
        webView.loadUrl("http://192.168.0.178:80");
        webView.setWebViewClient(new WebViewClient());


//        webView.loadUrl("http://192.168.0.178:80");
//        webView.loadUrl("http://192.168.0.100:9527");
//        webView.setWebViewClient(new WebViewClient(){
//          @Override
//          public void onPageFinished(WebView view,String url){
//              super.onPageFinished(view,url);
//              String userAgent = "shixinzhang";
//              String js = "window.localStorage.setItem('userAgent','" + userAgent +"');";
//              String jsUrl = "javascript:(function({var localStorage = window.localStorage ;" +
//                      "localStorage.setItem('userAgent','"+userAgent+"')})()";
//              if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT){
//                  view.evaluateJavascript(js,null);
//              }else {
//                  view.loadUrl(jsUrl);
//                  view.reload();
//              }
//          }
//        });
    }
}