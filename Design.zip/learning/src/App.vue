<template>
  <div class="BOX">
    <div class="left">
      <div class="mode">
        <div class="moder mg" @click="handleNewTree()">新二叉树</div>
        <!-- 演示 or 检测 -->
        <div
          v-for="(item, index) in modeList"
          class="moder"
          @click="handleModer(index)"
          :class="[
            isModeActive == index ? 'Active' : '',
            isZhongxu && index == 2 ? 'dead' : '',
          ]"
        >
          {{ item }}
        </div>
      </div>
      <!-- 遍历模式 -->
      <div class="genre">
        <div
          v-for="(item, index) in genres"
          class="moder"
          @click="handleGenre(index)"
          :class="[
            isGenreActive == index ? 'Active' : '',
            isJiance && index == 2 ? 'dead' : '',
          ]"
        >
          {{ item }}
        </div>
      </div>
      <div class="mode">
        <div
          class="moder"
          @click="isThread = !isThread"
          :class="isThread === true ? 'Active' : ''"
        >
          搜索化
        </div>
      </div>
    </div>
    <!-- 演示模式的树 -->
    <div class="right" v-if="!isJiance">
      <div class="top">
        <div
          v-for="(node, index) in TreeNodeArr"
          class="topNode"
          v-if="index < showCount"
        >
          {{ node.value }}
        </div>

        <div class="topShow" @click="handleTopshow()">演示</div>
      </div>
      <div class="main">
        <div class="TreeBox">
          <div class="TreeCase">
            <div class="f1" v-for="(item, index) in list">
              <div
                :ref="it"
                class="circle"
                v-for="it in item"
                :class="[
                  it == 0 ? 'bg1' : '',
                  getIt(it) == currentNode ? 'zoom-in-out-box' : '',
                ]"
              >
                {{ getIt(it) }}
                <div class="childL" v-if="isThread && isLeftNull(it)">
                  {{ toFront(it) }}
                </div>
                <div class="childR" v-if="isThread && isRightNull(it)">
                  {{ toBehind(it) }}
                </div>
              </div>
            </div>
            <svg>
              <g style="stroke: #000; stroke-width: 5">
                <line
                  v-for="(line, index) in lines"
                  :id="index"
                  :key="index"
                  :x1="lines.get(index).x1"
                  :y1="lines.get(index).y1"
                  :x2="lines.get(index).x2"
                  :y2="lines.get(index).y2"
                />
              </g>
            </svg>
          </div>
        </div>
      </div>
    </div>
    <!-- 检测模式的树 -->
    <div class="right" v-else="isJiance">
      <div class="top top2">
        <div class="topL">
          <div>{{ isGenreActive == 1 ? "前序" : "后序" }}</div>
          <div
            class="quan"
            v-for="(node, index) in TreeNodeArr"
            draggable="true"
            @dragstart="drag($event, index)"
            :id="node.key"
          >
            {{ node.value }}
          </div>
        </div>
        <div class="topR">
          <div>中序</div>
          <div class="quan dead" v-for="node in zxTreeNodeArr">
            {{ node.value }}
          </div>
        </div>
        <div class="topShow" @click="handleTopCommit()">确定</div>
      </div>
      <div class="main">
        <div class="TreeBox">
          <div class="TreeCase">
            <div class="f1" v-for="(item, index) in listJC">
              <div
                class="circle"
                v-for="it in item"
                @drop="drop($event, it)"
                @dragover="dragover($event)"
              >
                {{ getJC(it) }}
              </div>
            </div>
            <svg>
              <g style="stroke: #000; stroke-width: 5">
                <line
                  v-for="(line, index) in linesJC"
                  :id="index"
                  :key="index"
                  :x1="linesJC.get(index).x1"
                  :y1="linesJC.get(index).y1"
                  :x2="linesJC.get(index).x2"
                  :y2="linesJC.get(index).y2"
                />
              </g>
            </svg>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import BT from "./components/BT";
export default {
  name: "App",
  data() {
    let lines = new Map();
    let linesJC = new Map();
    let TreeObj = [..."ABCDEFGHIJKLMNO"];
    let list = [[1], [2, 3], [4, 5, 6, 7], [8, 9, 10, 11, 12, 13, 14, 15]];
    let listJC = [[1], [2, 3], [4, 5, 6, 7], [8, 9, 10, 11, 12, 13, 14, 15]];
    let jianCeArr = new Map();
    return {
      // left-data
      modeList: {
        1: "演示模式",
        2: "检测模式",
      },
      genres: {
        1: "前序遍历",
        2: "中序遍历",
        3: "后序遍历",
      },
      isModeActive: 1,
      isGenreActive: 1,
      isJiance: false,
      isZhongxu: false,
      // right-bottom-data
      TreeObj, // 字母
      list,
      listJC,
      lines,
      linesJC,
      Tree: null,
      TreeJC: null,
      // right-top-data
      TreeNodeArr: [], //遍历后的序列
      showCount: 1, // 遍历点
      currentNode: "",
      // 线索化
      isThread: false,
      // 检测模式
      zxTreeNodeArr: [],
      jianCeArr,
    };
  },
  mounted() {
    this.changeDom(this.list[2], this.list[3]);
    this.beLine();
    this.beLineJC();
    this.beTree();
    this.TreeNodeArr = this.getPre();
    this.zxTreeNodeArr = this.getIn();
    this.currentNode = this.TreeNodeArr[0].value;
  },
  methods: {
    // 拖放系列函数
    drag(e, index) {
      e.dataTransfer.setData("text", index);
    },

    // 拖放系列函数
    drop(e, it) {
      e.preventDefault();
      let index = parseInt(e.dataTransfer.getData("text"));
      this.jianCeArr.set(it, this.TreeNodeArr[index].value);
      this.listJC.reverse().reverse();
    },

    // 拖放系列函数
    dragover(e) {
      e.preventDefault();
    },

    // 拖放后的字母
    getJC(it) {
      let i = "";
      this.jianCeArr.forEach((value, index) => {
        if (it == index) {
          i = value;
        }
      });
      return i;
    },

    // 检测
    handleTopCommit() {
      if (this.jianCeArr.size != 10) {
        alert("结点个数不正确！");
        return false;
      } else if (this.filterMap(this.jianCeArr)) {
        alert("存在重复结点！");
        return false;
      } else if (!this.isConnect(this.jianCeArr)) {
        alert("不具有连通性！");
        return false;
      } else {
        let arrJC = Array.from(this.sortMap(this.jianCeArr));

        this.TreeJC = new BT(arrJC[0][0], arrJC[0][1], null);

        arrJC.unshift();
        arrJC.forEach((item) => {
          this.TreeJC.insert(Math.floor(item[0] / 2), item[0], item[1], {
            left: item[0] % 2 == 0,
            right: item[0] % 2 != 0,
          });
        });

        let jcPre = [];
        for (let node of this.TreeJC.preOrderTraversal()) {
          jcPre.push(node.value);
        }
        jcPre = jcPre.join("");

        let jcIn = [];
        for (let node of this.TreeJC.inOrderTraversal()) {
          jcIn.push(node.value);
        }
        jcIn = jcIn.join("");

        let Pre = [];
        for (let node of this.Tree.preOrderTraversal()) {
          Pre.push(node.value);
        }
        Pre = Pre.join("");

        let In = [];
        for (let node of this.Tree.inOrderTraversal()) {
          In.push(node.value);
        }
        In = In.join("");

        if(jcPre == Pre && jcIn==In){
          alert("答对啦！")
        }else{
          alert("您的答案是错误的！")
        }
      }
    },

    // 验证连通性
    isConnect(map) {
      let Connect = 1;
      map.forEach((value, index) => {
        if (!map.has(Math.floor(index / 2)) && index != 1) {
          Connect = 0;
        }
      });
      return Connect;
    },

    // map过滤
    filterMap(map) {
      let arr = [];
      Array.from(map).forEach((item) => {
        arr.push(item[1]);
      });
      let set = new Set(arr);
      return set.size < 10;
    },

    // map排序
    sortMap(map) {
      let arrayObj = Array.from(map);
      arrayObj.sort(function (a, b) {
        return a[0] - b[0];
      });
      let result = new Map(arrayObj.map((i) => [i[0], i[1]]));
      return result;
    },

    // 根据数组长度生成随机数
    randomArr(arr) {
      let index = Math.floor(Math.random() * arr.length);
      return index;
    },

    // 消除节点
    changeDom(listArr1, listArr2) {
      // 消除第三行的一个节点及其子节点
      let index = this.randomArr(listArr1);
      listArr1.splice(index, 1, 0);
      listArr2.splice(index * 2, 2, 0, 0);

      // 消除第四行的随机两个节点（已经删除的不算）
      let a1 = index * 2;
      let a2 = index * 2 + 1;
      let count = 0;
      while (count < 2) {
        let i = this.randomArr(listArr2);
        if (!(i == a2 || i == a1 || listArr2[i] == 0)) {
          listArr2.splice(i, 1, 0);
          count = count + 1;
        }
      }
    },

    // 节点连线
    beLine() {
      let sum = 0;
      this.list.flat(2).forEach((item) => {
        if (item == 0 || item == 1) {
          return false;
        }
        let x1 = this.$refs[item][0].getBoundingClientRect().x;
        let y1 = this.$refs[item][0].getBoundingClientRect().y;
        // 父节点
        let x2 = this.$refs[Math.floor(item / 2)][0].getBoundingClientRect().x;
        let y2 = this.$refs[Math.floor(item / 2)][0].getBoundingClientRect().y;
        this.lines.set(sum, {
          x1,
          y1,
          x2,
          y2,
        });
        sum = sum + 1;
      });
    },

    // 检测模式的节点连线
    beLineJC() {
      let sum = 0;
      this.listJC.flat(2).forEach((item) => {
        if (item == 1) {
          return false;
        }
        let x1 = this.$refs[item][0].getBoundingClientRect().x;
        let y1 = this.$refs[item][0].getBoundingClientRect().y;
        // 父节点
        let x2 = this.$refs[Math.floor(item / 2)][0].getBoundingClientRect().x;
        let y2 = this.$refs[Math.floor(item / 2)][0].getBoundingClientRect().y;
        this.linesJC.set(sum, {
          x1,
          y1,
          x2,
          y2,
        });
        sum = sum + 1;
      });
    },

    // 生成二叉树
    beTree() {
      let nodes = this.list.flat(2);
      let i = 0;

      // 根结点
      this.Tree = new BT(nodes[0], this.TreeObj[i], null);

      // 添加结点
      nodes.forEach((item) => {
        if (item == 0 || item == 1) {
          return false;
        }
        i = i + 1;
        this.Tree.insert(Math.floor(item / 2), item, this.TreeObj[i], {
          left: item % 2 == 0,
          right: item % 2 != 0,
        });
      });
    },

    // 前序遍历
    getPre() {
      let tempArr = [];
      for (let node of this.Tree.preOrderTraversal()) {
        tempArr.push(node);
      }
      return tempArr;
    },

    // 中序遍历
    getIn() {
      let tempArr = [];
      for (let node of this.Tree.inOrderTraversal()) {
        tempArr.push(node);
      }
      return tempArr;
    },

    // 后序遍历
    getPost() {
      let tempArr = [];
      for (let node of this.Tree.postOrderTraversal()) {
        tempArr.push(node);
      }
      return tempArr;
    },

    // 选择前序 中序 后序
    handleGenre(i) {
      if (this.isJiance && i == 2) {
        return false;
      }
      this.isGenreActive = i;
      i == 2 ? (this.isZhongxu = true) : (this.isZhongxu = false);

      this.showCount = 1;

      if (i == 1) {
        this.TreeNodeArr = this.getPre();
      } else if (i == 2) {
        this.TreeNodeArr = this.getIn();
      } else {
        this.TreeNodeArr = this.getPost();
      }
      this.currentNode = this.TreeNodeArr[0].value;
      this.jianCeArr.clear();
    },

    // 选择演示 检测
    handleModer(i) {
      if (this.isZhongxu && i == 2) {
        return false;
      }
      this.isModeActive = i;
      i == 2 ? (this.isJiance = true) : (this.isJiance = false);

      this.jianCeArr.clear();
    },

    // 改变结点值
    getIt(it) {
      let i;
      this.TreeNodeArr.forEach((item) => {
        if (it == item.key) {
          i = item.value;
        }
      });
      return i;
    },

    // 判断左孩子是否为空
    isLeftNull(it) {
      return this.Tree && this.Tree.find(it) && this.Tree.find(it).isLeftNull;
    },

    // 判断右孩子是否为空
    isRightNull(it) {
      return this.Tree && this.Tree.find(it) && this.Tree.find(it).isRightNull;
    },

    //将左孩子改为前驱
    toFront(it) {
      let i = "空";
      this.TreeNodeArr.forEach((item, index) => {
        if (it == item.key && this.TreeNodeArr[index - 1]) {
          i = this.TreeNodeArr[index - 1].value;
        }
      });
      return i;
    },

    //将右孩子改为后继
    toBehind(it) {
      let i = "空";
      this.TreeNodeArr.forEach((item, index) => {
        if (it == item.key && this.TreeNodeArr[index + 1]) {
          i = this.TreeNodeArr[index + 1].value;
        }
      });
      return i;
    },

    // 遍历动画
    handleTopshow() {
      this.currentNode = this.TreeNodeArr[this.showCount].value;
      this.showCount++;
    },

    // 新的二叉树
    handleNewTree() {
      window.location.reload();
    },
  },
};
</script>

<style lang='less'>
html,
body {
  height: 100%;
  overflow: hidden;
  margin: 0;
  padding: 0;
}
.BOX {
  display: grid;
  grid-template-columns: 1fr 5fr;
  width: 100%;
  height: 100%;
  .left {
    display: grid;
    grid-template-rows: 1fr 1fr 1fr;
    background: linear-gradient(to bottom, #e5e5be, #b7ccaf);
    .moder {
      box-sizing: border-box;
      width: 80%;
      height: 40px;
      margin: 40px 20px;
      text-align: center;
      font-size: 25px;
      border: solid 2px #000;
      border-radius: 20px;
      background: #b7ccaf;
      cursor: pointer;
    }
    .mg {
      margin-bottom: 100px;
    }
  }
  .right {
    display: grid;
    grid-template-rows: 1fr 9fr;
    .top {
      background: #b7ccaf;
    }
    .main {
      background: #efe1cb;
    }
  }
}
.Active {
  background: green !important;
}
.dead {
  background: #666 !important;
  cursor: not-allowed !important;
}
.TreeBox {
  overflow: hidden;
  display: grid;
  position: relative;
  align-items: center;
  justify-items: center;
  .TreeCase {
    display: grid;
    grid-template-rows: 1fr 1fr 1fr 1fr;
    width: 900px;
    height: 600px;
    .f1 {
      display: flex;
      align-items: center;
      justify-content: space-around;
    }
  }
}
.circle {
  position: relative;
  z-index: 2;
  width: 80px;
  height: 80px;
  margin: 0 25px;
  text-align: center;
  font-size: 50px;
  line-height: 1.5;
  border-radius: 50%;
  background: linear-gradient(to right, #f1f2b5, #135058);
}
.childL {
  position: absolute;
  top: 60px;
  left: -20px;
  font-size: 35px;
  width: 50px;
  height: 50px;
  text-align: center;
  border-radius: 50%;
  background: linear-gradient(to right, #f1f2b5, #135058);
}
.childR {
  position: absolute;
  top: 60px;
  right: -20px;
  font-size: 35px;
  width: 50px;
  height: 50px;
  text-align: center;
  border-radius: 50%;
  background: linear-gradient(to right, #f1f2b5, #135058);
}
.bg1 {
  opacity: 0;
  overflow: hidden;
}
svg {
  position: absolute;
  top: -40px;
  left: -215px;
  width: 113%;
  height: 120%;
}
// right-top
.topNode {
  display: inline-block;
  margin: 10px 10px;
  width: 80px;
  height: 80px;
  line-height: 2;
  font-size: 40px;
  text-align: center;
  background: #dadfba;
  border-radius: 10px;
}
.topShow {
  display: inline-block;
  position: absolute;
  top: 0;
  right: 0;
  margin: 10px 50px;
  width: 100px;
  height: 80px;
  line-height: 2;
  font-size: 40px;
  text-align: center;
  border-radius: 10px;
  background: green;
  cursor: pointer;
}
.zoom-in-out-box {
  background: green;
  animation: zoom-in-zoom-out 1s ease infinite;
}

@keyframes zoom-in-zoom-out {
  0% {
    transform: scale(1, 1);
  }
  50% {
    transform: scale(1.25, 1.25);
  }
  100% {
    transform: scale(1, 1);
  }
}
// 检测模式
.top2 {
  display: grid;
  font-size: 25px;
  grid-template-columns: 7fr 7fr 2fr;
}
.quan {
  box-sizing: border-box;
  display: inline-block;
  width: 45px;
  height: 45px;
  margin: 20px 5px 0;
  text-align: center;
  font-size: 30px;
  background: green;
  cursor: pointer;
}
</style>
