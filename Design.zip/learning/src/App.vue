<template>
  <div class="BOX">
    <div class="left"></div>
    <div class="right">
      <div class="top"></div>
      <div class="main">
        <Tree/>
      </div>
    </div>
  </div>
</template>

<script>
import Tree from './components/Tree.vue'
export default {
  name: "App",
  components:{
    Tree
  }
};
</script>

<style lang='less'>
html,body{
  height: 100%;
  overflow: hidden;
  margin: 0;
  padding: 0;
}
.BOX {
  display: grid;
  grid-template-columns: 1fr 6fr;
  width: 100%;
  height: 100%;
  .left {
    background: linear-gradient(to bottom,  #e5e5be,#b7ccaf);
  }
  .right {
    display: grid;
    grid-template-rows: 1fr 9fr;
    .top{
      background: #b7ccaf;
    }
    .main{
      background: #efe1cb;
    }
  }
}
</style>
