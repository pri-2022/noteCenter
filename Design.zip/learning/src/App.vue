<template>
  <div class="BOX">
    <div class="left">
      <div class="mode">
        <div
          v-for="(item, index) in modeList"
          class="moder"
          @click="handleModer(index)"
          :class="[
            isModeActive == index ? 'Active' : '',
            isZhongxu && index == 2 ? 'dead' : '',
          ]"
        >
          {{ item }}
        </div>
      </div>
      <div class="genre">
        <div
          v-for="(item, index) in genres"
          class="moder"
          @click="handleGenre(index)"
          :class="[
            isGenreActive == index ? 'Active' : '',
            isJiance && index == 2 ? 'dead' : '',
          ]"
        >
          {{ item }}
        </div>
      </div>
    </div>
    <div class="right">
      <div class="top"></div>
      <div class="main">
        <Tree />
      </div>
    </div>
  </div>
</template>

<script>
import Tree from "./components/Tree.vue";
export default {
  name: "App",
  data() {
    return {
      modeList: {
        1: "演示模式",
        2: "检测模式",
      },
      genres: {
        1: "前序遍历",
        2: "中序遍历",
        3: "后序遍历",
        4: "搜索化",
      },
      isModeActive: 1,
      isGenreActive: 1,
      isJiance: false,
      isZhongxu: false,
    };
  },
  components: {
    Tree,
  },
  methods: {
    handleGenre(i) {
      if(this.isJiance&&i==2){
        return false;
      }
      this.isGenreActive = i;
      i == 2 ? this.isZhongxu = true : this.isZhongxu = false;
    },
    handleModer(i) {
      if(this.isZhongxu&&i==2){
        return false;
      }
      this.isModeActive = i;
      i == 2 ? (this.isJiance = true) : (this.isJiance = false);
    },
  },
};
</script>

<style lang='less'>
html,
body {
  height: 100%;
  overflow: hidden;
  margin: 0;
  padding: 0;
}
.BOX {
  display: grid;
  grid-template-columns: 1fr 5fr;
  width: 100%;
  height: 100%;
  .left {
    display: grid;
    grid-template-rows: 1fr 2fr;
    background: linear-gradient(to bottom, #e5e5be, #b7ccaf);
    .moder {
      box-sizing: border-box;
      width: 80%;
      height: 40px;
      margin: 50px 20px;
      text-align: center;
      font-size: 25px;
      border: solid 2px #000;
      border-radius: 20px;
      background: #b7ccaf;
      cursor: pointer;
    }
  }
  .right {
    display: grid;
    grid-template-rows: 1fr 9fr;
    .top {
      background: #b7ccaf;
    }
    .main {
      background: #efe1cb;
    }
  }
}
.Active {
  background: green !important;
}
.dead {
  background: #666 !important;
  cursor: not-allowed !important;
}
</style>
