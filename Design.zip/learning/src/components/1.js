/**
   * 实现两个元素中心点的连线
   * @param  {Object} startObj  jquery对象，起点元素
   * @param  {Object} endObj    jquery对象，终点元素
   * @return {String}           返回连线的dom
   */
export default {
    drawLine(startObj, endObj) {
        //起点元素中心坐标
        var y_start = Number(startObj.css("top").replace("px", "")) + startObj.height() / 2;
        var x_start = Number(startObj.css("left").replace("px", "")) + startObj.width() / 2;

        //终点元素中心坐标
        var y_end = Number(endObj.css("top").replace("px", "")) + endObj.height() / 2;
        var x_end = Number(endObj.css("left").replace("px", "")) + endObj.width() / 2;;

        //用勾股定律计算出斜边长度及其夹角（即连线的旋转角度）
        var lx = x_end - x_start;
        var ly = y_end - y_start;
        //计算连线长度
        var length = Math.sqrt(lx * lx + ly * ly);
        //弧度值转换为角度值
        var c = 360 * Math.atan2(ly, lx) / (2 * Math.PI);

        //连线中心坐标
        var midX = (x_end + x_start) / 2;
        var midY = (y_end + y_start) / 2
        var deg = c <= -90 ? (360 + c) : c;  //负角转换为正角

        return `<div class='line' 
                        style='top:${midY}px;left:${midX - length / 2}px;width:${length}px;transform:rotate(${deg}deg);'>
                    </div>`
    }
}