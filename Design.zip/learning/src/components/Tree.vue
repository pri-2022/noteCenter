<template>
  <div class="TreeBox">
    <div class="TreeCase">
      <div class="f1" v-for="(item, index) in list" :key="index">
        <div
          class="circle"
          v-for="it in item"
          :key="it"
          @click="add(it)"
          :class="it == 0 ? 'bg1' : ''"
        >
          {{ it }}
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import "./Tree";
export default {
  name: "Tree",
  data() {
    let TreeObj = [..."ABCDEFGHIJKLMNO"];
    let list = [[1], [2, 3], [4, 5, 6, 7], [8, 9, 10, 11, 12, 13, 14, 15]];
    return {
      TreeObj,
      list,
    };
  },
  mounted() {
    this.changeDom(this.list[2],this.list[3])
  },
  methods: {
    add(it) {
      alert(it);
    },
    randomArr(arr) {
      let index = Math.floor(Math.random() * arr.length);
      return index;
    },
    changeDom(listArr1,listArr2) {
      let index = this.randomArr(listArr1);
      listArr1.splice(index, 1, 0);
      listArr2.splice(index*2,2,0,0)

    },
  },
};
</script>

<style lang='less'>
.TreeBox {
  display: grid;
  align-items: center;
  justify-items: center;
  .TreeCase {
    display: grid;
    grid-template-rows: 1fr 1fr 1fr 1fr;
    width: 900px;
    height: 600px;
    margin-top: 50px;
    .f1 {
      display: flex;
      align-items: center;
      justify-content: space-around;
    }
  }
}
.circle {
  z-index: 2;
  width: 80px;
  height: 80px;
  text-align: center;
  font-size: 50px;
  line-height: 1.5;
  border-radius: 50%;
  background: linear-gradient(to right, #f1f2b5, #135058);
}
.bg1 {
  background: #000;
  overflow: hidden;
}
</style>