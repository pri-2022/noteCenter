<template>
  <div class="TreeBox">
    <div class="TreeCase">
      <svg>
        <g>
          <line
            v-for="index in lines"
            :key="index"
            :x1="lines.get(index).x1"
            :y1="lines.get(index).y1"
            :x2="lines.get(index).x2"
            :y2="lines.get(index).y2"
            style="stroke: rgb(255, 0, 0); stroke-width: 2"
          />
        </g>
      </svg>
      <div class="f1" v-for="(item, index) in list">
        <div
          :ref="it"
          class="circle"
          v-for="it in item"
          @click="add(it)"
          :class="it == 0 ? 'bg1' : ''"
        >
          {{ it }}
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import "./Tree";
export default {
  name: "Tree",
  data() {
    let lines = new Map();
    let TreeObj = [..."ABCDEFGHIJKLMNO"];
    let list = [[1], [2, 3], [4, 5, 6, 7], [8, 9, 10, 11, 12, 13, 14, 15]];
    return {
      TreeObj,
      list,
      lines,
    };
  },
  mounted() {
    this.changeDom(this.list[2], this.list[3]);
    this.beLine();
  },
  methods: {
    // 根据数组长度生成随机数
    randomArr(arr) {
      let index = Math.floor(Math.random() * arr.length);
      return index;
    },
    // 消除节点
    changeDom(listArr1, listArr2) {
      // 消除第三行的一个节点及其子节点
      let index = this.randomArr(listArr1);
      listArr1.splice(index, 1, 0);
      listArr2.splice(index * 2, 2, 0, 0);

      // 消除第四行的随机两个节点（已经删除的不算）
      let a1 = index * 2;
      let a2 = index * 2 + 1;
      let count = 0;
      while (count < 2) {
        let i = this.randomArr(listArr2);
        if (!(i == a2 || i == a1 || listArr2[i] == 0)) {
          listArr2.splice(i, 1, 0);
          count = count + 1;
        }
      }
    },

    // 节点连线
    beLine() {
      let count = 0;
      this.list.flat(2).forEach((item) => {
        if (item == 0 || item == 1) {
          return false;
        }
        let x1 = this.$refs[item][0].getBoundingClientRect().x;
        let y1 = this.$refs[item][0].getBoundingClientRect().y;
        // 父节点
        let x2 = this.$refs[Math.floor(item / 2)][0].getBoundingClientRect().x;
        let y2 = this.$refs[Math.floor(item / 2)][0].getBoundingClientRect().y;

        this.lines.set(count, {
          x1,
          y1,
          x2,
          y2,
        });
      });
    },
  },
};
</script>

<style lang='less'>
.TreeBox {
  display: grid;
  align-items: center;
  justify-items: center;
  .TreeCase {
    display: grid;
    grid-template-rows: 1fr 1fr 1fr 1fr;
    width: 900px;
    height: 600px;
    margin-top: 50px;
    .f1 {
      display: flex;
      align-items: center;
      justify-content: space-around;
    }
  }
}
.circle {
  z-index: 2;
  transform-origin: center;
  width: 80px;
  height: 80px;
  text-align: center;
  font-size: 50px;
  line-height: 1.5;
  border-radius: 50%;
  background: linear-gradient(to right, #f1f2b5, #135058);
}
.bg1 {
  background: #000;
  overflow: hidden;
}
svg {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
}
</style>