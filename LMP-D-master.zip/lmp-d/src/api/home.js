import request from "@/utils/request";
import { globalCallback, websocketsend } from "@/utils/ws";
// 获取板卡标识符列表
export function CardListApi(data) {
  return request({
    // url: '/api/v1',
    url: "/lmp_d/LinkInfo",
    method: "post",
    data
  });
}
// LMP-D 获取输入端口包含详情
export function getInputCardListApi(data) {
  return new Promise(resolve => {
    if (localStorage.getItem("incardListData")) {
      const incardListData = JSON.parse(localStorage.getItem("incardListData"));
      const a = setTimeout(function() {
        clearTimeout(a);
        resolve(incardListData);
      }, 500);
    } else {
      websocketsend(`(sync,incard)\r\n`, res => {
        const incard_info_sync = res.reduce((arr, item) => {
          if (item.incard_info_sync) {
            arr.push(...item.incard_info_sync);
          }
          return arr;
        }, []);
        localStorage.setItem(
          "incardListData",
          JSON.stringify(incard_info_sync)
        );
        resolve(incard_info_sync);
      });
    }
  });
  // return request({
  //   // url: '/lmp_d/incard_info_sync',
  //   url: "/api/v1",
  //   method: "post",
  //   data
  // });
}
// LMP-D 获取输出端口包含详情
export function getOutCardListApi(data) {
  return new Promise(resolve => {
    if (localStorage.getItem("outListData")) {
      const outListData = JSON.parse(localStorage.getItem("outListData"));
      const a = setTimeout(function() {
        clearTimeout(a);
        resolve(outListData);
      }, 500);
    } else {
      websocketsend("(sync,outcard)\r\n", res => {
        const outList = res.reduce((arr, item) => {
          if (item.outcard_info_sync) {
            arr.push(item.outcard_info_sync);
          }
          return arr.flat(Infinity);
        }, []);
        localStorage.setItem("outListData", JSON.stringify(outList));
        resolve(outList);
      });
    }
  });
  // return request({
  //   // url: '/lmp_d/outcard_info_sync', // mock
  //   url: "/api/v1", // mock
  //   method: "post",
  //   data
  // });
}
// 根据板卡ch获取板卡详情
export function CardDetailApi(data) {
  return request({
    url: "/api/v1",
    // url: '/lmp_d/cardDetail',
    method: "post",
    data
  });
}
// 拖动输入卡至输出卡位置时的动作指令
export function SendInOutSeatApi(data) {
  return request({
    url: "/api/v1",
    method: "post",
    data
  });
}
// 获取场景列表
export function SyncSceneApi(data) {
  return request({
    url: "/api/v1",
    // url: '/lmp_d/syncScene',
    method: "post",
    data
  });
}
// 获取单个场景的数据
export function getScenceDataApi(data) {
  return request({
    url: "/api/v1",
    method: "post",
    data
  });
}
// 保存场景
export function scene_saveApi(data) {
  const { Group, Id, Scene_name } = data;
  websocketsend(`(scene,save,${Group},${Id},${Scene_name})\r\n`, res => {
    console.log("保存场景的响应数据：", res);
  });
  return request({
    url: "/api/v1",
    method: "post",
    data
  });

  // const { Group, Id, Scene_name } = data;
  // return new Promise((resolve, reject) => {
  //   websocketsend(`(scene,save,${Group},${Id},${Scene_name})\r\n`, res => {
  //     console.log("保存场景的响应数据：", res);
  //     resolve(res);
  //   });
  // });
}
// 开窗
export function windowOpenApi(data) {
  const { Group, value, ID, Vsrc_CH, Vsrc_clip_style, x, y, w, h } = data;
  // return request({
  //   url: "/api/v1",
  //   method: "post",
  //   data
  // });
  const ow = w % 4 === 0 ? w : w - (w % 4);
  // const ox = x % 4 === 0 ? x : x - (x % 4);
  const ox = x % 2 === 0 ? x : x + 1;
  return new Promise((resolve, reject) => {
    websocketsend(
      `(wnd,open,${Group},${value},${ID},${Vsrc_CH},${Vsrc_clip_style},${ox},${y},${ow},${h})\r\n`,
      res => {
        console.log("开窗的响应数据：", res);
        resolve(res);
      }
    );
  });
}
// 清屏分组
export function windowClearApi(data) {
  const { Group } = data;
  // return request({
  //   url: "/api/v1",
  //   method: "post",
  //   data
  // });
  return new Promise((resolve, reject) => {
    websocketsend(`(wnd,clear,${Group})\r\n`, res => {
      console.log("清屏分组的响应数据：", res);
      resolve(res);
    });
  });
}
// 移动窗口
export function windowMoveApi(data) {
  const { gid, value, ID, x, y, w, h } = data;
  const ow = w % 8 === 0 ? w : w - (w % 8);
  // const ow = w % 2 === 0 ? w : w + 1;
  // const oh = h % 2 === 0 ? h : h + 1;
  // const ox = x % 4 === 0 ? x : x - (x % 4);
  const ox = x % 2 === 0 ? x : x + 1;
  // const oy = y % 2 === 0 ? y : y + 1;
  return new Promise((resolve, reject) => {
    websocketsend(
      `(wnd,move,${value},${ID},${ox},${y},${ow},${h})\r\n`,
      res => {
        console.log("移动窗口的响应数据：", res);
        if (res && res.indexOf(`\"ok\"`) !== -1) {
          resolve(res);
        } else {
          reject("err");
        }
      }
    );
  });
}
// 关闭单个窗口
export function windowCloseApi(data) {
  return request({
    url: "/api/v1",
    method: "post",
    data
  });
}
// 窗口变化 单个窗口的变化
export function windowChngApi(data) {
  const { value, ID, Group, Vsrc_CH, Vsrc_clip_style, x, y, w, h } = data;
  return new Promise(resolve => {
    websocketsend(
      `(wnd,chng,${Group},${value},${ID},${Vsrc_CH},${Vsrc_clip_style},${x},${y},${w},${h})\r\n`,
      res => {
        console.log("单个窗口变化的响应数据：", res);
        resolve(res);
      }
    );
  });
}
// 多个窗变化
export function windowNewChangeApi(data) {
  const { Group, value, ID } = data;
  return new Promise(resolve => {
    websocketsend(`(wnd,chng,${Group},${value},${ID.join(",")})\r\n`, res => {
      console.log("多个窗口变化的响应数据：", res);
      resolve(res);
    });
  });
}
// 图层控制
export function windowLayerControlApi(data) {
  const { ID, layer } = data;
  return new Promise(resolve => {
    websocketsend(`(wnd,lctrl,${ID},${layer})\r\n`, res => {
      resolve(res);
    });
  });
  // return request({
  //   url: "/api/v1",
  //   method: "post",
  //   data
  // });
}
// 窗口属性设置
export function windowAttriConfigApi(data) {
  const { gid, ID, type, en } = data;
  return new Promise(resolve => {
    websocketsend(`(wnd,attri,${ID},full,${en})\r\n`, res => {
      resolve(res);
    });
  });
  // return request({
  //   url: "/api/v1",
  //   method: "post",
  //   data
  // });
}
// 窗口同步
export function syncWindowApi(data) {
  // return request({
  //   url: "/api/v1",
  //   // url: '/lmp_d/syncWindow',
  //   method: "post",
  //   data
  // });
  return new Promise((resolve, reject) => {
    websocketsend(`(sync,wnd)\r\n`, res => {
      const dataArray = res.filter(item => item["winfo sync"]);
      try {
        // const { "winfo sync": winfo_sync } = dataArray[0];
        const winfo_sync = dataArray.reduce((arr, item) => {
          if (item["winfo sync"]) {
            arr.push(...item["winfo sync"]);
          }
          return arr;
        }, []);
        resolve(winfo_sync);
      } catch (e) {
        resolve([]);
      }
    });
  });
}
// 调用单个场景
export function scene_callApi(data) {
  // return request({
  //   url: "/api/v1",
  //   method: "post",
  //   data
  // });

  const { gid, Id } = data;
  return new Promise((resolve, reject) => {
    websocketsend(`(scene,call,${Id})\r\n`, res => {
      console.log("点击调用场景的响应数据：", res);
      resolve(res);
    });
  });
}
// 删除单个场景
export function scene_delApi(data) {
  const { Group, Id } = data;
  return new Promise((resolve, reject) => {
    websocketsend(`(scene,del,${Id})\r\n`, res => {
      console.log("删除场景的响应数据：", res);
      resolve(res);
    });
  });
}
// 删除当前组的所有场景
export function sceneDelAllApi(data) {
  const { Group, Id } = data;
  return new Promise((resolve, reject) => {
    websocketsend(`(scene,del,${Group},0)\r\n`, res => {
      console.log("删除场景的响应数据：", res);
      resolve(res);
    });
  });
}
// 场景轮询开关
export function scene_rotateApi(data) {
  const { Group, en } = data;
  return new Promise((resolve, reject) => {
    websocketsend(`(scene,rotate,${Group},${en})\r\n`, res => {
      console.log("场景轮询开关的响应数据：", res);
      resolve(res);
    });
  });
  // return request({
  //   url: "/api/v1",
  //   method: "post",
  //   data
  // });
}
// 轮巡参数设置
export function scene_rotate_argsApi(data) {
  const { Group, period, Id_group } = data;
  return new Promise((resolve, reject) => {
    websocketsend(
      `(args,rotate,${Group},${period},${Id_group.join(",")})\r\n`,
      res => {
        console.log("轮巡参数设置的响应数据：", res);
        resolve(res);
      }
    );
  });
}
// 串口调试接口
export function TerminalApi(data) {
  return request({
    url: "/api/v1",
    method: "post",
    data
  });
}
// 获取轮询参数设置
export function scene_pollingApi(data) {
  return request({
    url: "/api/v1",
    // url: '/lmp_d/scene_polling',
    method: "post",
    data
  });
}
// 切换输入源通道
export function windowInChangeApi(data) {
  const { ID, Vsrc_CH, Vsrc_clip_style } = data;
  return new Promise(resolve => {
    websocketsend(`(wnd,ichg,${ID},${Vsrc_CH},${Vsrc_clip_style})\r\n`, res => {
      resolve(res);
    });
  });
}
// 切换输入格式
export function set_insubcardApi(data) {
  return request({
    url: "/api/v1",
    method: "post",
    data
  });
}
// 选择EDID前五个
export function edidChooseApi(data) {
  return request({
    url: "/api/v1",
    method: "post",
    data
  });
}
// 选择EDID后五个
export function edidLearnInApi(data) {
  return request({
    url: "/api/v1",
    method: "post",
    data
  });
}
// 获取设备信息
export function DevInfoApi(data) {
  return new Promise(resolve => {
    websocketsend(`(info,dev)\r\n`, res => {
      console.log("查询设备的响应数据：", res);
      const devInfo = res.reduce((arr, item) => {
        if (item["dev info"]) {
          arr.push(item["dev info"]);
        }
        return arr;
      }, []);
      resolve(devInfo[0]);
    });
  });
  // return request({
  //   url: "/api/v1",
  //   method: "post",
  //   data
  // });
}
// 查询版本
export function verApi() {
  return new Promise(resolve => {
    websocketsend(`(ver)\r\n`, res => {
      const VersionInfo = res.reduce((arr, item) => {
        if (item["VersionInfo"]) {
          arr.push(item["VersionInfo"]);
        }
        return arr;
      }, []);
      console.log("查询版本的响应数据1：", VersionInfo);
      console.log("查询版本的响应数据2：", VersionInfo[0]);
      let obj = {};
      VersionInfo.forEach(item => {
        Object.assign(obj, item);
      });
      resolve(obj);
    });
  });
}
