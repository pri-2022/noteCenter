import request from '@/utils/request'
// 获取用户列表
export function userListApi(data) {
  return request({
    url: '/api/v1',
    method: 'post',
    data
  })
}
// 添加用户
export function newUserApi(data) {
  return request({
    url: '/api/v1',
    method: 'post',
    data
  })
}
// 编辑用户
export function editUserApi(data) {
  return request({
    url: '/api/v1',
    method: 'post',
    data
  })
}
// 删除用户
export function delUserApi(data) {
  return request({
    url: '/api/v1',
    method: 'post',
    data
  })
}
