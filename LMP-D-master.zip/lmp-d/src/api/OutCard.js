import request from "@/utils/request";
import { websocketsend } from "@/utils/ws";
// 设置输出卡分辨率
export function settingTimingApi(data) {
  // D: 111
  // Fps: 60
  // Group: 1
  // H_ACTIVE: 1920
  // H_BP: 80
  // H_FP: 48
  // H_POL: 1
  // H_SYNC: 32
  // H_TOTAL: 2080
  // M: 22
  // Name: "1920x1080 RB"
  // Rate: 138.5
  // V_ACTIVE: 1080
  // V_BP: 23
  // V_FP: 3
  // V_POL: 0
  // V_SYNC: 5
  // V_TOTAL: 1111
  // cmd: "settingTiming"

  const {
    Group,
    Name,
    H_ACTIVE,
    H_TOTAL,
    H_BP,
    H_FP,
    H_SYNC,
    H_POL,
    V_ACTIVE,
    V_TOTAL,
    V_BP,
    V_FP,
    V_SYNC,
    V_POL,
    Fps,
    M,
    D
  } = data;
  return new Promise(resolve => {
    websocketsend(
      `(setting,timing,${Group},${Name},${H_ACTIVE},${H_TOTAL},${H_BP},${H_FP},${H_SYNC},${H_POL},${V_ACTIVE},${V_TOTAL},${V_BP},${V_FP},${V_SYNC},${V_POL},${Fps},${D},${M})\r\n`,
      res => {
        resolve(res);
      }
    );
  });
  // return request({
  //   url: "/api/v1",
  //   // url: '/lmp_d/settingTiming',
  //   method: "post",
  //   data
  // });
}
// 设置输出卡亮度
export function outBrightnessConfigApi(data) {
  return request({
    url: "/api/v1",
    method: "post",
    data
  });
}
// 选择分辨率模式
export function settingResAutoApi(data) {
  return request({
    url: "/api/v1",
    method: "post",
    data
  });
}
// 选择信号格式
export function outModeConfigApi(data) {
  return request({
    url: "/api/v1",
    method: "post",
    data
  });
}
// 切换画面
export function outFreedConfigApi(data) {
  return request({
    url: "/api/v1",
    method: "post",
    data
  });
}
// 输出音频切换
export function outAudioControlApi(data) {
  return request({
    url: "/api/v1",
    method: "post",
    data
  });
}
// 输出卡重命名
export function outcardRenameApi(data) {
  const { ch, name } = data;
  return new Promise(resolve => {
    websocketsend(`(rename,outcard,${ch},${name})\r\n`, res => {
      resolve(res);
    });
  });
  // return request({
  //   url: "/api/v1",
  //   method: "post",
  //   data
  // });
}
// 添加自定义分辨率
export function newDefineTimingApi(data) {
  return request({
    url: "/api/v1",
    method: "post",
    data
  });
}
// 获取自定义分辨率
export function getDefineTimingListApi(data) {
  // return new Promise(resolve => {
  //   const a = setTimeout(function() {
  //     clearTimeout(a);
  //     resolve({
  //       list: [
  //         {
  //           Name: "自定义1536*1816",
  //           H_FP: 88,
  //           H_POL: 44,
  //           H_SYNC: 1,
  //           H_BP: 148,
  //           H_ACTIVE: 1536,
  //           H_TOTAL: 1816,
  //           V_FP: 4,
  //           V_POL: 5,
  //           V_SYNC: 0,
  //           V_BP: 36,
  //           V_ACTIVE: 1536,
  //           V_TOTAL: 1581,
  //           Fps: 60,
  //           M: 26,
  //           D: 111,
  //           Rate: 169.394664
  //         }
  //       ]
  //     });
  //   }, 1000);
  //   // websocketsend(`()\r\n`, res => {});
  // });

  return request({
    // url: '/lmp_d/getDefineTimingList',
    url: "/api/v1",
    method: "post",
    data
  });
}
