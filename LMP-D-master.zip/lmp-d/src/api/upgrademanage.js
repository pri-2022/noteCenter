import request from '@/utils/request'
// 控制卡MCU上传文件
export function upgrade_mcuApi(data) {
  return request({
    url: '/api/upgrade_mcu',
    "Content-Type": "multipart/form-data",
    method: 'post',
    data
  })
}
