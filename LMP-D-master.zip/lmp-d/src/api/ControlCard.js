import request from "@/utils/request";
import { websocketsend } from "@/utils/ws";
// 查询控制卡信息
export function GetIpInfoApi(data) {
  return request({
    url: "/api/v1",
    method: "post",
    data
  });
}
// 修改控制卡信息
export function modifyIpInfoApi(data) {
  const { ip, mac, mask, gateway, port } = data;
  return new Promise(resolve => {
    websocketsend(`(mip,${ip},${mac},${mask},${gateway},${port})\r\n`, res => {
      resolve(res);
    });
  });
  // return request({
  //   url:'/api/v1',
  //   method:'post',
  //   data
  // })
}
// 获取输入卡版本
export function GetVersionInfoApi(data) {
  return request({
    url: "/api/v1",
    method: "post",
    data
  });
}
// 恢复出厂设置
export function factoryDefaultApi(data) {
  return new Promise(resolve => {
    websocketsend(`(CLEAR)\r\n`, res => {
      resolve(res);
    });
  });
  // return request({
  //   url: "/api/v1",
  //   method: "post",
  //   data
  // });
}
// 控制风扇速度
export function settingFanApi(data) {
  return new Promise(resolve => {
    websocketsend(`(fan,${data.step})\r\n`, res => {
      resolve(res);
    });
  });
  // return request({
  //   url: "/api/v1",
  //   method: "post",
  //   data
  // });
}
