// 添加自定义分辨率
import request from '@/utils/request'

// 添加自定义分辨率
export function newDefineTimingApi(data) {
  return request({
    url: '/api/v1',
    method: 'post',
    data
  })
}
// 编辑自定义分辨率接口
export function editDefineTimingApi(data) {
  return request({
    url: '/api/v1',
    method: 'post',
    data
  })
}
// 获取自定义分辨率
export function getDefineTimingListApi(data) {
  return request({
    url: '/api/v1',
    method: 'post',
    data
  })
}
// 删除自定义分辨率
export function delDefineTimingApi(data) {
  return request({
    url: '/api/v1',
    method: 'post',
    data
  })
}
