import request from '@/utils/request'

export function login(data) {
  return request({
    // url: '/lmp_d/login',  // mock
    url: '/api/v1',
    method: 'post',
    data
  })
}

export function getInfo(token) {
  return request({
    url: '/vue-element-admin/user/info',
    method: 'post',
    data: { token }
  })
}

export function logout() {
  return request({
    url: '/vue-element-admin/user/logout',
    method: 'post'
  })
}
