import request from "@/utils/request";
import { websocketsend } from "@/utils/ws";

// 获取分组和屏幕映射数据 iSend是否重新发送请求不走缓存
export function ginfo_syncApi(data, iSend) {
  return new Promise(resolve => {
    if (localStorage.getItem("omapData") && !iSend) {
      const a = setTimeout(function() {
        clearTimeout(a);
        resolve(JSON.parse(localStorage.getItem("omapData")));
      }, 500);
    } else {
      websocketsend("(sync,omap)\r\n", res => {
        localStorage.setItem("omapData", JSON.stringify(res));
        resolve(res);
      });
    }

    // websocketsend("(sync,omap)\r\n", res => {
    //   resolve(res);
    // });
  });

  // return request({
  //   url: '/api/v1',
  //   // url: '/lmp_d/ginfo_sync',
  //   method: 'post',
  //   data
  // })
}
// 重命名分组名称
export function groupRenameApi(data) {
  // return request({
  //   url: "/api/v1",
  //   method: "post",
  //   data
  // });
  const { id, name } = data;
  return new Promise(resolve => {
    websocketsend(`(rename,group,${id},${name})\r\n`, res => {
      resolve(res);
    });
  });
}
// 设置分组模式
export function gmodApi(data) {
  const { Group, idx } = data;
  return new Promise(resolve => {
    websocketsend(`(setting,gmod,${Group},${idx})\r\n`, res => {
      resolve(res);
    });
  });
}
// 设置分组标志组号
export function gflagApi(data) {
  const { Group, en } = data;
  return new Promise(resolve => {
    websocketsend(`(setting,gflag,${Group},${en})\r\n`, res => {
      resolve(res);
    });
  });
}
// 设置分组参数
export function settingWmodApi(data) {
  const {
    Group,
    GroupType,
    Panel_Row,
    Panel_Col,
    Logic_Sub_Panel_Row,
    Logic_Sub_Panel_Col,
    Panel_Gap_V,
    Panel_Gap_H
  } = data;
  return new Promise(resolve => {
    websocketsend(
      `(setting,wmod,${Group},${Panel_Row},${Panel_Col},${Logic_Sub_Panel_Row},${Logic_Sub_Panel_Col},${Panel_Gap_V},${Panel_Gap_H},${GroupType})\r\n`,
      res => {
        resolve(res);
      }
    );
  });

  // return request({
  //   url: "/api/v1",
  //   // url: '/lmp_d/settingWmod',
  //   method: "post",
  //   data
  // });
}
// 切换分组
export function settingCgrpApi(data) {
  return new Promise(resolve => {
    websocketsend(`(setting,cgrp,${data.Group})\r\n`, res => {
      resolve(res);
    });
  });

  // return request({
  //   url: "/api/v1",
  //   // url: '/lmp_d/settingCgrp',
  //   method: "post",
  //   data
  // });
}
//查询拼接屏的详细分辨率
export function timingInfoApi(data) {
  const { Group } = data;
  return new Promise(resolve => {
    websocketsend(`(info,timing,${Group})\r\n`, res => {
      console.log("查询组分辨率的响应数据：", res);
      let itemData = res.filter(item => item.timing);

      resolve(
        (itemData[0] && itemData[0].timing) || {
          H_active: 1920,
          V_active: 1080,
          Name: "1920x1080@60"
        }
      );
    });
  });
  // return request({
  //   url: "/api/v1",
  //   // url: '/lmp_d/timingInfo',
  //   method: "post",
  //   data
  // });
}
// 设置屏幕映射关系
export function settingOmapApi(data) {
  // Logic_ch: 6
  // Phy_ch: 1
  // gap: 0
  // h: 1080
  // w: 1920
  // x: 1920
  // y: 1080

  const { Group, GroupType, map } = data;
  let omapStr = map.map(item => {
    return `${item.Logic_ch},${item.Phy_ch},${item.x},${item.y},${item.w},${
      item.h
    },100`;
  });
  console.log(map, "map");
  console.log(omapStr, "omapStr");
  return new Promise(resolve => {
    if (omapStr.length) {
      websocketsend(`(setting,omap,${Group},${omapStr.join(",")})\r\n`, res => {
        resolve(res);
      });
    } else {
      websocketsend(`(setting,omap,${Group},0,0,0,0,0,0)\r\n`, res => {
        resolve(res);
      });
    }
  });
  // return request({
  //   url: "/api/v1",
  //   // url: '/lmp_d/settingOmap',
  //   method: "post",
  //   data
  // });
}
export function cmapApi(data) {
  const { Group } = data;
  return new Promise(resolve => {
    websocketsend(`(setting,cmap,${Group})\r\n`, res => {
      console.log("cmap清除映射的响应数据：", res);
      resolve(res);
    });
  });
}
