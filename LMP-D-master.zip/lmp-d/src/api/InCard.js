import request from "@/utils/request";
import { websocketsend, WS } from "@/utils/ws";
import { chunk } from "lodash";
function sleep(duration) {
  return new Promise(function(resolve) {
    setTimeout(resolve, duration);
  });
}
export async function sendData(data, isBuffer, duration) {
  if (isBuffer) {
    WS.send(data);
  } else {
    websocketsend(data, () => {});
  }
  await sleep(duration);
}

// POE开关
export function poeControlApi(data) {
  return request({
    url: "/api/v1",
    method: "post",
    data
  });
}
// 输入音频选择
export function inAudioChooseApi(data) {
  return request({
    url: "/api/v1",
    method: "post",
    data
  });
}
// Edid恢复默认
export function edidInitApi(data) {
  return request({
    url: "/api/v1",
    method: "post",
    data
  });
}
// 输入卡上传EDID
export function updateEdidApi(data, ch) {
  return request({
    url: `/api/updateEdid?ch=${ch}`,
    method: "post",
    "Content-Type": "multipart/form-data",
    data
  });
}
// 字幕开关
export function inSubtitleApi(data) {
  const { ch, en } = data;
  return new Promise(resolve => {
    websocketsend(`(in,subtitle,${ch},${en})\r\n`, res => {
      resolve(res);
    });
  });
  // return request({
  //   url: "/api/v1",
  //   method: "post",
  //   data
  // });
}
// 输入板卡重命名
export function incardRenameApi(data) {
  const { ch, name } = data;
  return new Promise(resolve => {
    websocketsend(`(rename,incard,${ch},${name})\r\n`, res => {
      resolve(res);
    });
  });
  // return request({
  //   url: "/api/v1",
  //   method: "post",
  //   data
  // });
}
// 输入字幕显示参数设置
export function inSubtitleArgsApi(data) {
  const { ch, bc_transparent, Fc, Bc, X, Y, W, H } = data;
  return new Promise(resolve => {
    websocketsend(
      `(args,subtitle,${ch},${bc_transparent},${Fc.join()},${Bc.join()},${X},${Y},${W},${H})\r\n`,
      res => {
        resolve(res);
      }
    );
  });
  // return request({
  //   url: "/api/v1",
  //   method: "post",
  //   data
  // });
}

// 查询输入卡分辨率
export function InCardResInfoApi(data) {
  const { port_index, ch } = data;
  console.log("port_index:", port_index);
  console.log("ch:", ch);
  return new Promise(resolve => {
    websocketsend(`(info,res,${ch})\r\n`, res => {
      // { "input resolution": { "ch": 1, "h": 0, "v": 0 } } { "msg": "ok", "data": "(info,res,1)\r\n" }
      const infoRes = res.reduce((arr, item) => {
        if (item["input resolution"]) {
          arr.push(item["input resolution"]);
        }
        return arr;
      }, []);
      resolve(infoRes[0]);
    });
  });
  // return request({
  //   url: '/api/v1',
  //   // url: '/lmp_d/InCardResInfo',
  //   method: 'post',
  //   data
  // })
}
// 开关自动上报信息
export function infoReportConfigApi(data) {
  return new Promise(resolve => {
    websocketsend(`(info,report,${data.en})\r\n`, res => {
      resolve(res);
    });
  });
  // return request({
  //   url: "/api/v1",
  //   method: "post",
  //   data
  // });
}

// 上传字幕
export function inSubtitleTransApi(data) {
  const { ch, packsize, pic_w, pic_h } = data;
  return new Promise(resolve => {
    // var buffer = new ArrayBuffer(data.data.length);
    // var view = new DataView(buffer);
    // for (let i = 0; i < data.data.length; i++) {
    //   view.setUint8(i, parseInt(data.data[i], 16));
    // }

    // buffer总长度：view.byteLength

    const chunkArr = chunk(data.data, 1024);

    async function main() {
      await sendData(
        `(in,subtitle,trans,${ch},1,${data.data.length})\r\n`,
        false,
        1000
      );
      for (const item of chunkArr) {
        const index = chunkArr.indexOf(item);
        let b = new ArrayBuffer(item.length);
        let v = new DataView(b);
        for (let j = 0; j < item.length; j++) {
          v.setUint8(j, parseInt(item[j], 16));
        }
        await sendData(v, true, 1000);
      }

      await sendData(`(in,subtitle,trans,${ch},0,0)\r\n`, false, 1000);
    }
    main().then(r => {
      resolve(true);
    });

    // websocketsend(
    //   `(in,subtitle,trans,${ch},1,${data.data.length})\r\n`,
    //   res => {
    //     console.log(data.data.length, "data.data.length");
    //     const chunkArr = chunk(data.data, 1024);
    //     console.log(chunkArr, "chunkArr");
    //     console.log(chunkArr.length, "chunkArr.length");
    //     chunkArr.forEach((item, index) => {
    //       let b = new ArrayBuffer(item.length);
    //       let v = new DataView(b);
    //       for (let j = 0; j < item.length; j++) {
    //         v.setUint8(j, parseInt(item[j], 16));
    //       }
    //       WS.send(v);
    //     });
    //     const a = setTimeout(function() {
    //       websocketsend(`(in,subtitle,trans,${ch},0,0)\r\n`, res => {}, false);
    //       resolve(true);
    //       clearTimeout(a);
    //     }, 2000);
    //   }
    // );

    // const b = new Blob([view], { type: "text/plain" });
    // const r = new FileReader();
    // r.readAsArrayBuffer(b);
    // r.onload = function() {
    //   websocketsend(`(in,subtitle,trans,${ch},1,${b.size})\r\n`, res => {
    //     // WS.send(view);
    //     WS.send(r.result);
    //     const a = setTimeout(function() {
    //       resolve(res);
    //       clearTimeout(a);
    //     }, 3000);
    //
    //     // websocketsend(
    //     //   view,
    //     //   res => {
    //     //     resolve(res);
    //     //   },
    //     //   true
    //     // );
    //   });
    // };
  });
  // return request({
  //   url: "/api/v1",
  //   method: "post",
  //   data
  // });
}
// 字体字库参数
export function argsFontApi(data) {
  const { ch, FontAttri, Size, Text, FontName } = data;
  const { Blod, Italic, Strickout, Underline } = FontAttri;
  let str = `${Blod}${Italic}${Strickout}${Underline}`;
  return new Promise(resolve => {
    websocketsend(
      `(args,font,${ch},${parseInt(str, 2).toString(
        10
      )},${Size},${Text},${FontName})\r\n`,
      res => {
        resolve(res);
      }
    );
  });
  // return request({
  //   url: "/api/v1",
  //   method: "post",
  //   data
  // });
}
// 板卡恢复默认
export function subCardDefaultApi(data) {
  return request({
    url: "/api/v1",
    method: "post",
    data
  });
}
