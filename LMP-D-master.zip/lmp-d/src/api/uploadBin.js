import request from '@/utils/request'

export function updateApi(data,url) {
  return request({
    url,
    method: 'post',
    "Content-Type": "multipart/form-data",
    data
  })
}
