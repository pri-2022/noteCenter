import request from "@/utils/request";

export function articleApi(data) {
  return request({
    url: 'https://time.geekbang.org/serv/v1/article',
    method: 'post',
    data
  })
}
