<template>
  <div class="padding30">
    <el-container>
      <!--      <el-aside>-->
      <!--        <p>分组列表</p>-->
      <!--        <el-menu :default-active="activeIndex" class="el-menu-demo" mode="vertical" @select="handleSelect">-->
      <!--          <el-menu-item v-for="item of context" :index="`${item.gID}`" @click="handleClick(item)">{{item.name?item.name:`屏幕分组${item.gID}`}}</el-menu-item>-->
      <!--        </el-menu>-->
      <!--      </el-aside>-->
      <el-aside width="300px" style="margin-bottom: 2vw">
        <el-form ref="form" inline :model="form" :rules="rules" label-width="100px" label-position="left">
          <el-form-item :label="$t('spl.belongingToTheGroup')+'：'" >
            <div style="display: grid;grid-template-columns: 2fr 1fr;gap: 10px;">
              <el-select v-model="activeIndex" >
                <el-option v-for="item of context" :label="item.name?item.name:$t('home.group')+item.gID" :value="item.gID" @click.native="handleClick(item)"></el-option>
              </el-select>
              <el-button size="mini" @click="promptChangName">{{ $t('spl.Rename') }}</el-button>
            </div>
            <el-button size="mini" @click="promptAddName">{{ $t('spl.addGroup') }}</el-button>
            <el-button size="mini" @click="promptDel">{{ $t('spl.deleteGroup') }}</el-button>
          </el-form-item>
          <!--          <el-form-item label="分组名称："  prop="name">-->
          <!--            <el-input v-model="form.name"><div slot="append" @click="ChangName">确定</div></el-input>-->
          <!--          </el-form-item>-->
          <el-form-item :label="$t('spl.GroupType')+'：'" prop="GroupType">
            <el-radio-group v-model.number="form.GroupType" @change="GroupChange">
              <el-radio :label="1">LCD</el-radio>
              <el-radio :label="2">LED</el-radio>
            </el-radio-group>
          </el-form-item>
          <!--          <el-form-item label="屏幕类型:" v-show="form.GroupType===2">-->
          <!--            <el-radio-group v-model.number="form.SceneType">-->
          <!--              <el-radio :label="3">lcd</el-radio>-->
          <!--              <el-radio :label="4">led</el-radio>-->
          <!--            </el-radio-group>-->
          <!--          </el-form-item>-->
          <el-form-item :label="$t('spl.rowAndColumnSettings')+'：'" style="display: flex;flex-direction: column;">
            <div style="display: flex;flex-direction: column;">
              <el-input type="number" v-model.number="form.Panel_Row" @change="RowChange" :min="1" :max="16"><div slot="append">{{$t('spl.row') }}</div></el-input>
              <span style="width: 10px"></span>
              <el-input type="number" v-model.number="form.Panel_Col" @change="ColChange" :min="1" :max="16"><div slot="append">{{$t('spl.col') }}</div></el-input>
            </div>
          </el-form-item>
          <div v-if="form.GroupType!==2">
            <!--            <el-form-item label="逻辑子屏：">-->
            <!--              <div style="display: flex;flex-direction: column;">-->
            <!--                <el-input type="number" v-model.number="form.Logic_Sub_Panel_Row" :min="1" :max="3"><div slot="append">行</div></el-input>-->
            <!--                <span style="width: 10px"></span>-->
            <!--                <el-input type="number" v-model.number="form.Logic_Sub_Panel_Col" :min="1" :max="3"><div slot="append">列</div></el-input>-->
            <!--              </div>-->
            <!--            </el-form-item>-->
                        <el-form-item :label="$t('spl.PanelGap')+': '">
                          <div style="display: flex;flex-direction: column;">
                            <el-input type="number" v-model.number="form.Panel_Gap_V" :min="0" :max="99" @change="Panel_Gap_VChange"><div slot="prepend">
                              {{ $t('spl.HS') }}</div></el-input>
                            <span style="width: 10px"></span>
                            <el-input type="number" v-model.number="form.Panel_Gap_H" :min="0" :max="99" @change="Panel_Gap_HChange"><div slot="prepend">{{ $t('spl.VI') }}</div></el-input>
                          </div>
                        </el-form-item>
          </div>
          <el-form-item :label="$t('spl.outputFormat')+'：'" prop="timing">
            <el-select v-model="form.timing"  @change="timingChange">
              <!--          <el-option :label="item.Name" :value="index" v-for="(item,index) of OutFormatConfigs"></el-option>-->
              <el-option :label="item.Name" :value="item.Name" v-for="(item,index) in DefineTimingList"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" size="mini" @click="GroupEnter1">{{ $t('home.enter') }}</el-button>
          </el-form-item>
        </el-form>
      </el-aside>
      <el-main style="padding-top: 0;" v-if="activeIndex">

        <!--        <el-card class="box-card">-->
        <!--          <div slot="header" class="clearfix">-->
        <!--            <span class="fontsize16">分组参数设置</span>-->
        <!--            <el-button style="float: right;" type="primary" size="mini" @click="GroupEnter">确定</el-button>-->
        <!--          </div>-->

        <!--&lt;!&ndash;          <el-tabs v-model="activeIndex" type="card">&ndash;&gt;-->
        <!--&lt;!&ndash;            <el-tab-pane v-for="item of context" :label="item.name?item.name:`屏幕分组${item.gID}`" :name="`${item.gID}`" @click.native="handleClick(item)" ></el-tab-pane>&ndash;&gt;-->
        <!--&lt;!&ndash;          </el-tabs>&ndash;&gt;-->

        <!--          <el-form ref="form" :model="form" :rules="rules" label-width="120px" label-position="left">-->
        <!--            <el-form-item label="所属分组：">-->
        <!--              <el-select v-model="activeIndex" placeholder="请选择分组">-->
        <!--                <el-option v-for="item of context" :label="item.name?item.name:`屏幕分组${item.gID}`" :value="item.gID" @click.native="handleClick(item)"></el-option>-->
        <!--              </el-select>-->
        <!--            </el-form-item>-->
        <!--            <el-form-item label="分组名称：" style="width: 320px;" prop="name">-->
        <!--              <el-input v-model="form.name"><div slot="append" @click="ChangName">确定</div></el-input>-->
        <!--            </el-form-item>-->
        <!--            <el-form-item label="屏幕类型：">-->
        <!--              <el-radio-group v-model.number="form.GroupType">-->
        <!--                <el-radio :label="1">矩阵</el-radio>-->
        <!--                <el-radio :label="2">拼接</el-radio>-->
        <!--              </el-radio-group>-->
        <!--            </el-form-item>-->
        <!--            <div v-if="form.GroupType===2">-->
        <!--              <el-form-item label="行列设置：">-->
        <!--                <div style="width: 400px;display: flex;flex-direction: row;">-->
        <!--                  <el-input type="number" v-model.number="form.Panel_Row"  :min="1" :max="9"><div slot="prepend">行</div></el-input>-->
        <!--                  <span style="width: 10px"></span>-->
        <!--                  <el-input type="number" v-model.number="form.Panel_Col"  :min="1" :max="9"><div slot="prepend">列</div></el-input>-->
        <!--                </div>-->
        <!--              </el-form-item>-->
        <!--              <el-form-item label="逻辑子屏设置：">-->
        <!--                <div style="width: 400px;display: flex;flex-direction: row;">-->
        <!--                  <el-input type="number" v-model.number="form.Logic_Sub_Panel_Row" :min="1" :max="3"><div slot="prepend">行</div></el-input>-->
        <!--                  <span style="width: 10px"></span>-->
        <!--                  <el-input type="number" v-model.number="form.Logic_Sub_Panel_Col" :min="1" :max="3"><div slot="prepend">列</div></el-input>-->
        <!--                </div>-->
        <!--              </el-form-item>-->
        <!--              <el-form-item label="边缘宽度设置：">-->
        <!--                <div style="width: 400px;display: flex;flex-direction: row;">-->
        <!--                  <el-input type="number" v-model.number="form.Panel_Gap_V" :min="1" :max="99"><div slot="prepend">水平间距</div></el-input>-->
        <!--                  <span style="width: 10px"></span>-->
        <!--                  <el-input type="number" v-model.number="form.Panel_Gap_H" :min="1" :max="99"><div slot="prepend">垂直间距</div></el-input>-->
        <!--                </div>-->
        <!--              </el-form-item>-->
        <!--              <el-form-item label="输出格式：">-->
        <!--                <el-select v-model="form.timing" placeholder="请选择分辨率" @change="timingChange">-->
        <!--                  &lt;!&ndash;          <el-option :label="item.Name" :value="index" v-for="(item,index) of OutFormatConfigs"></el-option>&ndash;&gt;-->
        <!--                  <el-option :label="item.Name" :value="item.M" v-for="(item,index) in DefineTimingList"></el-option>-->
        <!--                </el-select>-->
        <!--              </el-form-item>-->
        <!--            </div>-->

        <!--&lt;!&ndash;            <el-form-item>&ndash;&gt;-->
        <!--&lt;!&ndash;              <el-button type="primary" size="mini" @click="GroupEnter">确定</el-button>&ndash;&gt;-->
        <!--&lt;!&ndash;            </el-form-item>&ndash;&gt;-->
        <!--          </el-form>-->
        <!--        </el-card>-->

        <el-card class="box-card" style="overflow: auto;height: 80vh;-webkit-overflow-scrolling: touch;">
          <div slot="header" class="clearfix">
            <span class="fontsize16">{{ $t('spl.screenSettings') }}</span>
            <!--            <el-button style="float: right;" size="mini" type="primary" @click="settingOmapEnter">确定</el-button>-->
          </div>

          <el-container>
            <el-main class="grid-main-wrapper">
              <el-row v-for="(i,index_i) in GridArray"  type="flex" justify="center" align="middle" class="grid-row-wrapper">


                <el-col  @touchstart.native="longTimeTouch($event,j,j.name,2)" @touchend.native="emptyTime()"  @dblclick.native="handleColClick($event,j,[j.X,j.Y])"  v-for="(j,index_j) in i" :draggable="j.outputCh!==''" :data-outputCh="j.outputCh" @dragstart.native="drag($event,j,j.name,2)"  @drop.native="drop($event,j,[j.X,j.Y])" @dragover.native="allowDrop($event,j)"  :span="4"  :class="['grid-col-wrapper',j.outputCh?'active':'']">
                  <el-popover
                    placement="top"
                    :title="$t('spl.Screen')+$t('spl.setUp')+j.sceneIndex"
                    width="200"
                    trigger="click"
                    :disabled="(!j.outputCh)"
                  >
                    <div slot="reference" style="width: 100%;height: 100%;">
                      <!--                 <span class="fontsize16">{{`(${index_j*W},${index_i*H})`}}</span>-->
                      <!--                   <span class="fontsize16">{{`(${j.X},${j.Y})`}}</span>-->
                      <!--                 <span class="fontsize16">关闭</span>-->
                      <span class="outSite">{{j.output}}</span>
                      <span class="scene_name">{{`${j.sceneIndex}`}}</span>
                    </div>
                    <div style="display: flex;justify-content:space-between;flex-direction: column;text-align: left;">
                      <div>{{ $t('spl.x') }}：<input :disabled="form.GroupType!==2||j.output===''" v-model.number="j.X" @blur="jxchange(j)"></input></div>
                      <div>{{ $t('spl.y') }}：<input :disabled="form.GroupType!==2||j.output===''" v-model.number="j.Y" @blur="jxchange(j)"></input></div>
                      <div>{{ $t('spl.w') }}：&nbsp;&nbsp;&nbsp;&nbsp;<input :disabled="form.GroupType!==2||j.output===''" v-model.number="j.W" @blur="jxchange(j)"></input></div>
                      <div>{{ $t('spl.h') }}：&nbsp;&nbsp;&nbsp;&nbsp;<input :disabled="form.GroupType!==2||j.output===''" v-model.number="j.H" @blur="jxchange(j)"></input></div>
<!--                      <div v-if="j.isCheckedOmap" style="margin-top: 5px;text-align: center;"> <el-button type="primary" size="mini" @click="omapOpenWindow(j)">开窗</el-button> </div>-->
                      <div  style="margin-top: 5px;text-align: center;"> <el-button type="primary" size="mini" @click="omapOpenWindow(j)">
                        {{ $t('spl.open') }}</el-button> </div>
                    </div>

                    <!--                   <el-form inline label-position="left" style="margin-bottom: 0;">-->
                    <!--                     <el-form-item label="水平起点：" style="margin-bottom: 0;">-->
                    <!--                       <el-input size="mini" v-model="j.X"></el-input>-->
                    <!--                     </el-form-item>-->
                    <!--                     <el-form-item label="垂直起点：" style="margin-bottom: 0;">-->
                    <!--                       <el-input size="mini" v-model="j.Y"></el-input>-->
                    <!--                     </el-form-item>-->
                    <!--                     <el-form-item label="屏幕宽：" style="margin-bottom: 0;">-->
                    <!--                       <el-input size="mini" v-model="j.k"></el-input>-->
                    <!--                     </el-form-item>-->
                    <!--                     <el-form-item label="屏幕高："  style="margin-bottom: 0;">-->
                    <!--                       <el-input size="mini" v-model="j.g"></el-input>-->
                    <!--                     </el-form-item>-->
                    <!--                   </el-form>-->
                  </el-popover>


                </el-col>

              </el-row>
              <el-button @click="quitSettingOmapEnter">{{ $t('spl.cancelCurrentMap') }}</el-button>
              <el-button @click="OmapEnter">{{ $t('spl.enterMap') }}</el-button>
            </el-main>

            <el-aside @drop.native="dropOutList($event)" @dragover.native="allowDropOutList($event)">
              <p>{{ $t('spl.outCardList') }}</p>
              <div class="scrollbar" style="height: 500px;overflow-y: scroll;">
                <el-menu :default-active="OutCardIndex" class="el-menu-demo" mode="vertical" @select="OutCardHandleSelect">
                  <el-menu-item
                    :draggable="!item.disabled"
                    @dragstart.native="drag($event,item,item.rename?item.rename:`${NameList[item.card_type]+item.ch}`,1)"
                    @click.native="clickOutCard($event,item,item.rename?item.rename:`${NameList[item.card_type]+item.ch}`,1)"
                    v-for="item of OutCardList"
                    :disabled="item.disabled"
                    :index="`${item.ch+(item.port_index===undefined?'_0':`_${item.port_index}`)}`"
                  >
                    <!--                  {{item.rename?item.rename:`${NameList[item.card_type]+item.ch+(item.port_index===undefined?'_0':`_${item.port_index}`)}`}}-->
                    {{item.rename?item.rename:`${NameList[item.card_type]+item.ch}`}}
                  </el-menu-item>
                </el-menu>
              </div>

            </el-aside>

          </el-container>

        </el-card>

      </el-main>
    </el-container>

  </div>
</template>

<script>
import {
  ginfo_syncApi,
  groupRenameApi,
  settingCgrpApi,
  settingWmodApi,
  timingInfoApi,
  settingOmapApi, cmapApi, gmodApi, gflagApi,
} from '@/api/SplicingSettings';
import {
  CardDetailApi,
  CardListApi, getInputCardListApi,
  getOutCardListApi,
  scene_delApi, sceneDelAllApi,
  windowClearApi,
  windowOpenApi,
} from '@/api/home';
import {getDefineTimingListApi, settingTimingApi} from "@/api/OutCard";
import {initWebSocket, WS, onOffer, websocketsend} from '@/utils/ws';
import i18n from '@/lang';
const inputValidatorGroupRename=value=>!!value  // 判断非空

export default {
  name: "index",
  data() {
    var validateGroupType = (rule, value, callback) => {
      if (value === 0) {
        callback(new Error(i18n.t('spl.PleaseGroupType')));
      } else {
        callback();
      }
    };
    return {
      Loop:null,
      abcd:null,
      dragstart_i:null,
      GridArray:[],
      activeIndex: '',// 当前选择的分组
      OutCardIndex: '', // 当前选择的输出卡
      context:[], // 分组列表
      OutFormatConfigs: {
        1: {
          Name: '1920x1080@60',
          H_ACTIVE: 1920,
          H_TOTAL: 2200,
          H_BP: 148,
          H_FP: 88,
          H_SYNC: 44,
          H_POL: 1,
          V_ACTIVE: 1080,
          V_TOTAL: 1125,
          V_BP: 36,
          V_FP: 4,
          V_SYNC: 5,
          V_POL: 1,
          Rate: 148.5,
          Fps: 60,
          M: 22,
          D: 4
        },
        2: {
          Name: '1920x1080@50',
          H_ACTIVE: 1920,
          H_TOTAL: 2640,
          H_BP: 148,
          H_FP: 528,
          H_SYNC: 44,
          H_POL: 1,
          V_ACTIVE: 1080,
          V_TOTAL: 1125,
          V_BP: 36,
          V_FP: 4,
          V_SYNC: 5,
          V_POL: 1,
          Rate: 148.5,
          Fps: 50,
          M: 22,
          D: 4
        },
        3: {
          Name: '1280x720@60',
          H_FP: 110,
          H_POL: 1,
          H_SYNC: 40,
          H_BP: 220,
          H_ACTIVE: 1280,
          H_TOTAL: 1650,
          V_FP: 5,
          V_POL: 1,
          V_SYNC: 5,
          V_BP: 20,
          V_ACTIVE: 720,
          V_TOTAL: 750,
          Fps: 60,
          M: 22,
          D: 8,
          Rate: 148.5
        },
        4: {
          Name: '1280x720@50',
          H_FP: 440,
          H_POL: 1,
          H_SYNC: 40,
          H_BP: 220,
          H_ACTIVE: 1280,
          H_TOTAL: 1980,
          V_FP: 5,
          V_POL: 1,
          V_SYNC: 5,
          V_BP: 20,
          V_ACTIVE: 720,
          V_TOTAL: 750,
          Fps: 50,
          M: 22,
          D: 8,
          Rate: 74.25
        },
        5: {
          Name: '800x600@60',
          H_FP: 40,
          H_POL: 1,
          H_SYNC: 128,
          H_BP: 88,
          H_ACTIVE: 800,
          H_TOTAL: 1056,
          V_FP: 1,
          V_POL: 1,
          V_SYNC: 4,
          V_BP: 23,
          V_ACTIVE: 600,
          V_TOTAL: 628,
          Fps: 60,
          M: 28,
          D: 19,
          Rate: 40
        },
        6: {
          Name: '1024x768@60',
          H_FP: 24,
          H_POL: 0,
          H_SYNC: 136,
          H_BP: 160,
          H_ACTIVE: 1024,
          H_TOTAL: 1344,
          V_FP: 3,
          V_POL: 0,
          V_SYNC: 6,
          V_BP: 29,
          V_ACTIVE: 768,
          V_TOTAL: 806,
          Fps: 60,
          M: 65,
          D: 27,
          Rate: 65
        },
        7: {
          Name: '1280x768@60',
          H_FP: 64,
          H_POL: 0,
          H_SYNC: 128,
          H_BP: 192,
          H_ACTIVE: 1280,
          H_TOTAL: 1664,
          V_FP: 3,
          V_POL: 1,
          V_SYNC: 7,
          V_BP: 20,
          V_ACTIVE: 768,
          V_TOTAL: 798,
          Fps: 60,
          M: 180,
          D: 61,
          Rate: 79.5
        },
        8: {
          Name: '1280x800@60',
          H_FP: 72,
          H_POL: 0,
          H_SYNC: 128,
          H_BP: 200,
          H_ACTIVE: 1280,
          H_TOTAL: 1680,
          V_FP: 3,
          V_POL: 1,
          V_SYNC: 6,
          V_BP: 22,
          V_ACTIVE: 800,
          V_TOTAL: 831,
          Fps: 60,
          M: 273,
          D: 88,
          Rate: 83.5
        },
        9: {
          Name: '1280x960@60',
          H_FP: 96,
          H_POL: 1,
          H_SYNC: 112,
          H_BP: 312,
          H_ACTIVE: 1280,
          H_TOTAL: 1800,
          V_FP: 1,
          V_POL: 1,
          V_SYNC: 3,
          V_BP: 36,
          V_ACTIVE: 960,
          V_TOTAL: 1000,
          Fps: 60,
          M: 12,
          D: 3,
          Rate: 108
        },
        10: {
          Name: '1280x1024@60',
          H_FP: 48,
          H_POL: 1,
          H_SYNC: 112,
          H_BP: 248,
          H_ACTIVE: 1280,
          H_TOTAL: 1688,
          V_FP: 1,
          V_POL: 1,
          V_SYNC: 3,
          V_BP: 38,
          V_ACTIVE: 1024,
          V_TOTAL: 1066,
          Fps: 60,
          M: 12,
          D: 3,
          Rate: 108
        },
        11: {
          Name: '1360x768@60',
          H_FP: 64,
          H_POL: 1,
          H_SYNC: 112,
          H_BP: 256,
          H_ACTIVE: 1360,
          H_TOTAL: 1792,
          V_FP: 3,
          V_POL: 1,
          V_SYNC: 6,
          V_BP: 18,
          V_ACTIVE: 768,
          V_TOTAL: 795,
          Fps: 60,
          M: 19,
          D: 6,
          Rate: 85.5
        },
        12: {
          Name: '1400x1050@60',
          H_FP: 88,
          H_POL: 0,
          H_SYNC: 144,
          H_BP: 232,
          H_ACTIVE: 1400,
          H_TOTAL: 1864,
          V_FP: 3,
          V_POL: 1,
          V_SYNC: 4,
          V_BP: 32,
          V_ACTIVE: 1050,
          V_TOTAL: 1089,
          Fps: 60,
          M: 415,
          D: 92,
          Rate: 121.75
        },
        13: {
          Name: '1440x900@60',
          H_FP: 80,
          H_POL: 0,
          H_SYNC: 152,
          H_BP: 232,
          H_ACTIVE: 1400,
          H_TOTAL: 1904,
          V_FP: 3,
          V_POL: 1,
          V_SYNC: 6,
          V_BP: 25,
          V_ACTIVE: 900,
          V_TOTAL: 934,
          Fps: 60,
          M: 71,
          D: 18,
          Rate: 106.5
        },
        14: {
          Name: '1600x900@60',
          H_FP: 88,
          H_POL: 0,
          H_SYNC: 168,
          H_BP: 256,
          H_ACTIVE: 1600,
          H_TOTAL: 2112,
          V_FP: 3,
          V_POL: 1,
          V_SYNC: 5,
          V_BP: 26,
          V_ACTIVE: 900,
          V_TOTAL: 934,
          Fps: 60,
          M: 320,
          D: 73,
          Rate: 118.25
        },
        15: {
          Name: '1680x1050@60',
          H_FP: 104,
          H_POL: 0,
          H_SYNC: 176,
          H_BP: 280,
          H_ACTIVE: 1680,
          H_TOTAL: 2240,
          V_FP: 3,
          V_POL: 1,
          V_SYNC: 6,
          V_BP: 30,
          V_ACTIVE: 1050,
          V_TOTAL: 1089,
          Fps: 60,
          M: 65,
          D: 12,
          Rate: 146.25
        },
        16: {
          Name: '1280x768 RB',
          H_FP: 48,
          H_POL: 1,
          H_SYNC: 32,
          H_BP: 80,
          H_ACTIVE: 1280,
          H_TOTAL: 1440,
          V_FP: 3,
          V_POL: 0,
          V_SYNC: 7,
          V_BP: 12,
          V_ACTIVE: 768,
          V_TOTAL: 790,
          Fps: 60,
          M: 91,
          D: 36,
          Rate: 68.25
        },
        17: {
          Name: '1280x800 RB',
          H_FP: 48,
          H_POL: 1,
          H_SYNC: 32,
          H_BP: 80,
          H_ACTIVE: 1280,
          H_TOTAL: 1440,
          V_FP: 3,
          V_POL: 0,
          V_SYNC: 6,
          V_BP: 14,
          V_ACTIVE: 800,
          V_TOTAL: 823,
          Fps: 60,
          M: 71,
          D: 27,
          Rate: 71
        },
        18: {
          Name: '1440x900 RB',
          H_FP: 48,
          H_POL: 1,
          H_SYNC: 32,
          H_BP: 80,
          H_ACTIVE: 1440,
          H_TOTAL: 1600,
          V_FP: 3,
          V_POL: 0,
          V_SYNC: 6,
          V_BP: 17,
          V_ACTIVE: 900,
          V_TOTAL: 926,
          Fps: 60,
          M: 135,
          D: 41,
          Rate: 88.75
        },
        19: {
          Name: '1400x1050 RB',
          H_FP: 48,
          H_POL: 1,
          H_SYNC: 32,
          H_BP: 80,
          H_ACTIVE: 1400,
          H_TOTAL: 1560,
          V_FP: 3,
          V_POL: 0,
          V_SYNC: 4,
          V_BP: 23,
          V_ACTIVE: 1050,
          V_TOTAL: 1080,
          Fps: 60,
          M: 101,
          D: 27,
          Rate: 101
        },
        20: {
          Name: '1600x900 RB',
          H_FP: 24,
          H_POL: 1,
          H_SYNC: 80,
          H_BP: 96,
          H_ACTIVE: 1600,
          H_TOTAL: 1800,
          V_FP: 1,
          V_POL: 1,
          V_SYNC: 3,
          V_BP: 96,
          V_ACTIVE: 900,
          V_TOTAL: 1000,
          Fps: 60,
          M: 12,
          D: 3,
          Rate: 108
        },
        21: {
          Name: '1680x1050 RB',
          H_FP: 48,
          H_POL: 1,
          H_SYNC: 32,
          H_BP: 80,
          H_ACTIVE: 1680,
          H_TOTAL: 1840,
          V_FP: 3,
          V_POL: 0,
          V_SYNC: 6,
          V_BP: 21,
          V_ACTIVE: 1050,
          V_TOTAL: 1080,
          Fps: 60,
          M: 119,
          D: 27,
          Rate: 119
        },
        22: {
          Name: '1920x1080 RB',
          H_FP: 48,
          H_POL: 1,
          H_SYNC: 32,
          H_BP: 80,
          H_ACTIVE: 1920,
          H_TOTAL: 2080,
          V_FP: 3,
          V_POL: 0,
          V_SYNC: 5,
          V_BP: 23,
          V_ACTIVE: 1080,
          V_TOTAL: 1111,
          Fps: 60,
          M: 277,
          D: 54,
          Rate: 138.5
        },
        23: {
          Name: '1920x1200 RB',
          H_FP: 48,
          H_POL: 1,
          H_SYNC: 32,
          H_BP: 80,
          H_ACTIVE: 1920,
          H_TOTAL: 2080,
          V_FP: 3,
          V_POL: 0,
          V_SYNC: 6,
          V_BP: 26,
          V_ACTIVE: 1200,
          V_TOTAL: 1235,
          Fps: 60,
          M: 137,
          D: 24,
          Rate: 154
        },
        24: {
          Name: '2560x920 RB',
          H_FP: 32,
          H_POL: 1,
          H_SYNC: 44,
          H_BP: 48,
          H_ACTIVE: 2560,
          H_TOTAL: 2684,
          V_FP: 4,
          V_POL: 0,
          V_SYNC: 5,
          V_BP: 36,
          V_ACTIVE: 920,
          V_TOTAL: 965,
          Fps: 60,
          M: 495,
          D: 86,
          Rate: 155.4036
        },
        25: {
          Name: '1080x1920 RB',
          H_FP: 88,
          H_POL: 1,
          H_SYNC: 44,
          H_BP: 148,
          H_ACTIVE: 1080,
          H_TOTAL: 1360,
          V_FP: 3,
          V_POL: 1,
          V_SYNC: 4,
          V_BP: 36,
          V_ACTIVE: 1920,
          V_TOTAL: 1963,
          Fps: 60,
          M: 528,
          D: 89,
          Rate: 157.51112
        },
        26: {
          Name: '1536x1536@60',
          H_FP: 32,
          H_POL: 1,
          H_SYNC: 24,
          H_BP: 48,
          H_ACTIVE: 1536,
          H_TOTAL: 1640,
          V_FP: 4,
          V_POL: 0,
          V_SYNC: 5,
          V_BP: 30,
          V_ACTIVE: 1536,
          V_TOTAL: 1575,
          Fps: 60,
          M: 781,
          D: 126,
          Rate: 154.98
        }
      },
      DefineTimingList:[],
      itemTiming:[],
      W:1920,
      H:1080,
      form:{
        name:'',
        GroupType: null,// 分组类型 1 矩阵 0拼控
        SceneType: 3, // 屏幕类型 3 lcd 4 led
        Panel_Row:'',
        Panel_Col:'',
        Logic_Sub_Panel_Row:'',
        Logic_Sub_Panel_Col:'',
        Panel_Gap_V:'',
        Panel_Gap_H:'',
        timing:'',
      },
      // 验证规则
      rules:{
        name: [
          { required: true, message: i18n.t('spl.PleaseName'), trigger: 'blur' },
          { min: 1, max: 6, message: i18n.t('spl.charactersLength'), trigger: 'blur' }
        ],
        GroupType:[
          {required:true,message: i18n.t('spl.PleaseGroupType'),trigger:'blur'},
          {validator:validateGroupType,trigger: 'blur'}
        ],
        timing:[{ required: true, message: i18n.t('spl.PleaseResolution'), trigger: 'change' }]
      },
      // 已插卡列表
      cardTAGList:[],
      // 卡板类型名字
      NameList:{
        1:'HDMI',
        4: "VGA",
        23: "DP4K",
        17: "HDMI4K",
        24: "HDMI4K60_",
        10:'HDMI',
        11: "DVI_VS",
        58:'HDMI',
        59: "DVI",
        49:'HDMI',
        100:'HDMI',
        101:'HDMI',
        102:'HDMI',
        3:'CVBS',
        51:'HDBT',
        2:'DVI',
        50:'DVI',
        81: "HDMI4_",
        82: "DVI4_",
        6:'SDI',
        53:'SDI',
      },
      // 输入卡cID列表
      inCardCIDList:[],
      // 输出卡列表
      OutCardList:[],
      OutCardListCopy:[],
      // 输出卡的ID列表
      OutCardIDList:[],
      // 输入卡的ID列表
      inCardChNameList:[],
      // 屏幕映射关系
      omap:[],
      // 当前的分组ID
      gid:null,
      // 输入输出卡映射关系表
      CardINOUTList: {
        1: '1_0',
        2: '1_1',
        3: '2_0',
        4: '2_1',
        5: '3_0',
        6: '3_1',
        7: '4_0',
        8: '4_1',
        9: '5_0',
        10: '5_1',
        11: '6_0',
        12: '6_1',
        13: '7_0',
        14: '7_1',
        15: '8_0',
        16: '8_1',
        17: '9_0',
        18: '9_1',
        19: '10_0',
        20: '10_1',
        21: '11_0',
        22: '11_1',
        23: '12_0',
        24: '12_1',
        25: '13_0',
        26: '13_1',
        27: '14_0',
        28: '14_1',
        29: '15_0',
        30: '15_1',
        31: '16_0',
        32: '16_1',
        33: '17_0',
        34: '17_1',
        35: '18_0',
        36: '18_1',
        37: '19_0',
        38: '19_1',
        39: '20_0',
        40: '20_1',
        41: '21_0',
        42: '21_1',
        43: '22_0',
        44: '22_1',
        45: '23_0',
        46: '23_1',
        47: '24_0',
        48: '24_1',
        49: '25_0',
        50: '25_1',
        51: '26_0',
        52: '26_1',
        53: '27_0',
        54: '27_1',
        55: '28_0',
        56: '28_1',
        57: '29_0',
        58: '29_1',
        59: '30_0',
        60: '30_1',
        61: '31_0',
        62: '31_1',
        63: '32_0',
        64: '32_1',
      },
    }
  },
  created() {
    if (!WS) {
      initWebSocket();
    }
  },
  mounted() {

    this.getDefineTimingList()
    // this.socketApi.sendSock({}, data => {
    //   console.log('拼接设置模块接收的长连接数据：SplicingSettings',data);
    // })
    onOffer(res=>{

    })

  },
  methods: {
   async omapOpenWindow(item){
      const _this=this
      console.log(item,'omapOpenWindow')
     const tempOmapData=JSON.parse(localStorage.getItem("tempOmapData"))
     const tempWindow=tempOmapData.find(i=>i.Phy_ch===item.outputCh)
     // console.log(tempOmapData,'tempOmapData')
     // console.log(tempWindow,'tempWindow')
     if (!tempWindow){
       _this.$message.error(i18n.t('spl.PleaseMapFirst'))
       return false
     }

     await websocketsend(`(wnd,clear,${_this.gid})\r\n`,res=>{})
     await windowOpenApi({
        cmd: 'windowOpen',
        Group: this.gid,
        value: 1, // 0 灰色 1正常 2wu无效
        ID: 999, // 窗口ID （0-65535）
        Vsrc_CH: this.inCardCIDList[0], //信号源通道
        Vsrc_clip_style: 0, // 信号源裁剪方案
        // x: tempWindow.x,// 起点x
        // y: tempWindow.y,// 起点y
        // w: tempWindow.w,// 结束x 或者 窗体宽
        // h: tempWindow.h // 结束y 或者 窗体高
       x: item.X,// 起点x
       y: item.Y,// 起点y
       w: item.W,// 结束x 或者 窗体宽
       h: item.H // 结束y 或者 窗体高
      }).then(res=>{
        this.$message.success(i18n.t('spl.WindowOpened'))
      })
    },
    jxchange(j){
      // console.log(j,'jjjjjjjjjjjj')
      // console.log(j.sceneIndex,'sceneIndex')
      if (j.W>this.W){
        j.W=this.W
      }
      if (j.W<64){
        j.W=64
      }
      if (j.H>this.H){
        j.H=this.H
      }
      if (j.H<64){
        j.H=64
      }
      this.omap.forEach(item=>{
        if (item.Logic_ch===j.sceneIndex){
          item.x=j.X
          item.y=j.Y
          item.w=j.W
          item.h=j.H
        }
      })


      console.log(this.omap,'this.omap')
    },
    // 获取板卡
    getCardList(){
      let port2Type=[81,82]; // 4图层输出卡
      this.OutCardList=[];
      this.OutCardListCopy=[];

      // TODO: LMP-D: 获取输出通道列表
      getOutCardListApi({
        cmd: 'outcard_info_sync',
      }).then(res=>{
        console.log('输出卡的数据： ',res)
        let outCardList=res.map(item=>{
          if (item.type){
            if (port2Type.includes(item.type)){
              if (item.cID%2!==0){
                return {
                  rename:item.name,
                  card_type:item.type,
                  ch:item.cID,
                  gID:item.gID,
                  disabled:null
                }
              }
            }else {
              return {
                rename:item.name,
                card_type:item.type,
                ch:item.cID,
                gID:item.gID,
                disabled:null
              }
            }

          }
        }).filter(Boolean)
        console.log('outCardList：',outCardList)
        this.OutCardList=[...outCardList]
        this.OutCardListCopy=[...outCardList]
        this.OutCardIDList=outCardList.reduce((arr,item)=>{
          if (item.ch){
            arr.push(parseInt(item.ch))
          }
          return arr
        },[])
        console.log("this.OutCardIDList: ",this.OutCardIDList)
      }).then(()=>{
        this.getGinfo_sync()
      }).then(()=>{
        this.inCardCIDList=[];
        getInputCardListApi({ cmd: "incard_info_sync" }).then(res=>{
          console.log('输入卡的数据：',res)
          res.forEach(i=>{
            if (i.type){
              this.inCardCIDList.push(i.cID);
            }
          })
        })
      })
    },
    // 获取分组列表
    getGinfo_sync() {
      const _this=this
      const loading1 = this.$loading({
        lock: true,
        text: i18n.t('spl.Processing'),
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.7)'
      })
      // 获取分组列表
      ginfo_syncApi({
        cmd:'ginfo_sync'
      },true).then(res=>{
        _this.context = res
        .map(item => {
          if (item["ginfo sync"]) {
            _this.gid = item["ginfo sync"]["curr grp"];
            return item["ginfo sync"].context;
          }
          // if (item["omap"]) {
          //   _this.omap = item["omap"];
          // }
        })
        .filter(Boolean);

        _this.omap = res.reduce((arr, item) => {
          if (item["omap"]) {
            arr.push(...item["omap"]);
          }
          return arr;
        }, []);
        localStorage.setItem("tempOmapData",JSON.stringify(_this.omap))
        // this.context=GroupContext  // 分组列表
        // let curr_grp=res.ginfo_sync.curr_grp // 当前的分组ID
        // this.gid=curr_grp
        // this.activeIndex=res.ginfo_sync.curr_grp.toString()
        this.activeIndex=_this.gid
        let activeItem=this.context.filter(item=>item.gID===_this.gid)
        console.log(activeItem,'activeItemactiveItemactiveItemactiveItem')
        this.handleClick(activeItem[0])
        let a=setTimeout(function () {
          loading1.close()
          clearTimeout(a)
        },1000)

      })
    },
    // 获取所有的映射关系
    getOmapInfo(){
      let _this=this
      ginfo_syncApi({
        cmd:'ginfo_sync'
      },true).then(res=>{

        const omapList=res.reduce((arr, item) => {
          if (item["omap"]) {
            arr.push(...item["omap"]);
          }
          return arr;
        }, []);
        // 映射关系
        if (omapList&&omapList.length){
          console.log(omapList,'res.omap映射关系')
          console.log(this.OutCardList,'this.OutCardList')
          console.log(_this.gid,'_this.gid')
          omapList.forEach(omap=>{
            this.OutCardList.forEach(itemm=>{
              let Phy_index=itemm.port_index===undefined?0:itemm.port_index;
              let Phy_ch_index=`${itemm.ch}_${Phy_index}`
              for (let j in this.CardINOUTList){
                if (this.CardINOUTList[j]===Phy_ch_index){
                  if (omap.Phy_ch==j){
                    itemm.gid=omap.gid
                  }
                }
              }
            })
          })
          let Gomap=omapList.filter(ii=>ii.gid===_this.gid)
          Gomap.forEach(item=>{
            // 标记已经映射
            item['isCheckedOmap']=true
          })
          this.omap=[...Gomap]
          console.log(Gomap,'Gomap')
          console.log(this.omap,'获取所有的映射关系this.omap')
          // 输出卡列表中不能含有 omap中含有的输出卡
          // 根据omap映射到屏幕
          // omap   Phy_ch
          // OutCardList ch


          // 映射了的输出卡
          let omapOutList=[]
          // 映射了的屏幕
          // let sceneIndexList=[]
          omapList.forEach(omap=> {
            omapOutList.push(omap.Phy_ch)
          })
          Gomap.forEach(omap=>{
            // omapOutList.push(omap.Phy_ch)
            // sceneIndexList.push(omap.Logic_ch)

            // 遍历二维数组  显示映射关系
            for (let i in this.GridArray){
              for (let j in this.GridArray[i]){
                if (this.GridArray[i][j].sceneIndex===omap.Logic_ch){
                  this.GridArray[i][j].W=omap.w
                  this.GridArray[i][j].H=omap.h
                  this.GridArray[i][j].X=omap.x
                  this.GridArray[i][j].Y=omap.y

                  // let ch=this.CardINOUTList[omap.Phy_ch].split('_')[0]
                  let ch=omap.Phy_ch
                  // let port=this.CardINOUTList[omap.Phy_ch].split('_')[1]

                  // Logic_ch: 1
                  // Phy_ch: 1
                  // gid: 1
                  // h: 1080
                  // isCheckedOmap: true
                  // pixel_space: 100
                  // w: 1920
                  // x: 0
                  // y: 0

                  console.log(omap,'omap')
                  console.log(ch,'ch')
                  const itemChFilter=this.OutCardList.filter(item=>item.ch==ch)
                  const itemCh=itemChFilter[0]
                  console.log(itemCh,"itemCh")
                  if (itemCh&&itemCh.card_type>0){
                    let outName=itemCh.rename?itemCh.rename:`${this.NameList[itemCh.card_type]}${omap.Phy_ch}`
                    this.GridArray[i][j].list={...itemCh,name:outName}
                    this.GridArray[i][j].output=outName
                    this.GridArray[i][j].outputCh=omap.Phy_ch
                    if (omap.isCheckedOmap){
                      this.GridArray[i][j]['isCheckedOmap']=true
                    }
                  }
                }
              }
            }
          })
          console.log(omapOutList,'omapOutListomapOutList')
          this.OutCardList.forEach(itemm=>{

            itemm.disabled = omapOutList.includes(itemm.ch);

            // let Phy_index=itemm.port_index===undefined?0:itemm.port_index;
            // let Phy_ch_index=`${itemm.ch}_${Phy_index}`
            // for (let j in this.CardINOUTList){
            //   if (this.CardINOUTList[j]===Phy_ch_index){
            //     console.log(j,'j')
            //     console.log(Phy_ch_index,'Phy_ch_index')
            //     console.log(this.CardINOUTList[j],'this.CardINOUTList[j]')
            //     console.log(omapOutList.includes(parseInt(j)),'omapOutList.includes(parseInt(j))')
            //
            //     // itemm.gid=omap.gid
            //   }
            // }
          })

          // console.log(this.GridArray,'this.GridArray')



        }else{
          console.log("omap为空的情况")
          console.log("this.OutCardList",this.OutCardList)
          // omap为空的情况
          this.OutCardList.forEach(item=> {
            console.log(item.gid,'omap为空的情况:item.gid')
            if (item.gid){
              if (this.gid==item.gid) {
                item.disabled=false
              }
            }else {
              item.disabled=false
            }

          })
        }

        let a=setTimeout(function(){
          _this.$forceUpdate();
          clearTimeout(a)
        },1000)
      })
    },
    // 更改分组名称的对话框
    promptChangName(){
      const _this=this
      this.$prompt(i18n.t('spl.PleaseGroupName'), i18n.t('home.deleteAllTip'), {
        confirmButtonText: i18n.t('home.enter'),
        cancelButtonText: i18n.t('home.cancel'),
        inputValue:_this.form.name,
        inputValidator:inputValidatorGroupRename,
        inputErrorMessage:i18n.t('spl.PleaseGroupName')
      }).then(({ value }) => {
        groupRenameApi({
          cmd: 'groupRename',
          id: parseInt(this.activeIndex),
          name: value
        }).then(res=>{
          this.getGinfo_sync()
          this.$message.success(i18n.t('set.SuccessModified'))
        }).catch(err=>{
          this.$message.error(i18n.t('set.failEdit'))
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: i18n.t('spl.CancelRename')
        });
      });
    },
    // 添加分组
    promptAddName(){
      const _this=this
      if (this.context.length===4){
        this.$message.error(i18n.t('spl.OnlyFourGroups'))
        return false;
      }
      const nameList={
        1:null,
        2:null,
        3:null,
        4:null
      }
      this.context.forEach(item=>{
        nameList[item.gID]=item
      })
      const noVal=[]
      for (let key in nameList){
        if (!nameList[key]){
          noVal.push(parseInt(key))
        }
      }
      this.$prompt(i18n.t('spl.PleaseGroupName'), i18n.t('home.deleteAllTip'), {
        confirmButtonText: i18n.t('home.enter'),
        cancelButtonText: i18n.t('home.cancel'),
        inputValue:i18n.t('spl.ScreenGrouping')+Math.min(...noVal),
        inputValidator:inputValidatorGroupRename,
        inputErrorMessage:i18n.t('spl.PleaseGroupName')
      }).then(({ value }) => {

        const loading3 = this.$loading({
          lock: true,
          text: i18n.t('spl.Processing'),
          spinner: 'el-icon-loading',
          background: 'rgba(0, 0, 0, 0.7)'
        })

        gmodApi({
          Group: Math.min(...noVal),
          idx: 3
        }).then(()=>{
          gflagApi({Group:Math.min(...noVal),en:1}).then(()=>{
            settingWmodApi({
              cmd:'settingWmod',
              Group: Math.min(...noVal),
              GroupType: _this.form.GroupType,
              Panel_Row: _this.form.Panel_Row,
              Panel_Col: _this.form.Panel_Col,
              Logic_Sub_Panel_Row: _this.form.Logic_Sub_Panel_Row,
              Logic_Sub_Panel_Col: _this.form.Logic_Sub_Panel_Col,
              Panel_Gap_V: _this.form.Panel_Gap_V,
              Panel_Gap_H: _this.form.Panel_Gap_H,
              // Panel_Gap_V: 0,
              // Panel_Gap_H: 0,
            }).then(()=>{
              cmapApi({cmd:'cmap',Group:Math.min(...noVal)}).then(()=>{
                groupRenameApi({
                  cmd: 'groupRename',
                  id: Math.min(...noVal),
                  name: value
                })
                websocketsend(`(setting,omap,${Math.min(...noVal)},0,0,0,0,0,0)\r\n`,res=>{
                  const timingData=_this.itemTiming.length?_this.itemTiming[0]:_this.DefineTimingList[0]
                  settingTimingApi({
                    cmd: 'settingTiming',
                    ...timingData,
                    // Ch:_this.ch,
                    Group: Math.min(...noVal)
                  }).then(()=>{
                    websocketsend(`(out,osdflag,${Math.min(...noVal)},0,0)\r\n`,(r)=>{
                      settingCgrpApi({
                        cmd:'settingCgrp',
                        Group: Math.min(...noVal)
                      }).then(()=>{
                        sceneDelAllApi({
                          cmd: 'scene_del',
                          Id: 0,
                          Group: Math.min(...noVal)
                        }).then(()=>{
                          websocketsend(
                            `(args,rotate,${Math.min(...noVal)},5})\r\n`,
                            res => {
                              loading3.close()
                              _this.getGinfo_sync()
                            }
                          );
                        })
                      })
                    })
                  })
                })
              })
            })
          })

          // this.$message.success('修改成功')
        }).catch(err=>{
          // this.$message.error('修改失败')
        })


      }).catch(() => {
        // this.$message({
        //   type: 'info',
        //   message: ''
        // });
      });
    },
    // 删除分组
    promptDel(){
      const _this=this;
      if (this.context.length===1){
        this.$message.error(i18n.t('spl.OnlyOneGroup'))
        return false
      }
      let notDelGroup=this.context.find(item=>item.gID!==parseInt(this.activeIndex))
      gflagApi({
        Group: parseInt(this.activeIndex),
        en:0
      }).then(()=>{
        cmapApi({
          Group:parseInt(this.activeIndex)
        }).then(()=>{
          websocketsend(`(setting,omap,${parseInt(this.activeIndex)},0,0,0,0,0,0)\r\n`,res=>{
            const timingData=_this.itemTiming.length?_this.itemTiming[0]:_this.DefineTimingList[0]
            settingTimingApi({
              cmd: 'settingTiming',
              ...timingData,
              Group: parseInt(this.activeIndex)
            }).then(()=>{
              // _this.$message.success('删除成功')
              settingCgrpApi({
                cmd:'settingCgrp',
                Group: notDelGroup.gID
              })
              _this.getGinfo_sync()
            })
          })
        })
      })
    },
    // 修改分组名称
    ChangName(){
      this.$refs.form.validateField('name');
      if (this.form.name.length>6||this.form.name.length===0){
        return false
      }
      groupRenameApi({
        cmd: 'groupRename',
        id: parseInt(this.activeIndex),
        name: this.form.name
      }).then(res=>{
        this.getGinfo_sync()
        this.$message.success(i18n.t('set.SuccessModified'))
      }).catch(err=>{
        this.$message.error(i18n.t('set.failEdit'))
      })


    },
    // 选择分组时触发的事件
    handleSelect(index) {
      this.activeIndex=index
      console.log(index,'分组gID值')
    },
    // 选择分组时的点击事件
    handleClick(item){
      let _this=this
      console.log(item,'item值');
      // 清空映射关系
      this.omap=[]
      this.gid=item.gID
      this.form.GroupType=item.panel_type||1
      this.form.name=item.name?item.name:(i18n.t('home.group')+item.gID)
      this.form.Panel_Row=item.Rows||3
      this.form.Panel_Col=item.Cols||3
      this.form.Logic_Sub_Panel_Row=item.subRows||1
      this.form.Logic_Sub_Panel_Col=item.subCols||1
      this.form.Panel_Gap_V=item.vgap||0 // 水平
      this.form.Panel_Gap_H=item.hgap||0 // 垂直
      // 根据分组获取拼接屏的详细分辨率
      timingInfoApi({
        cmd:'timingInfo',
        Group: parseInt(this.activeIndex)
      }).then(res=>{
        console.log(res,'handleClick此分组的分辨率信息')
        console.log(res.Name,'res.Name')
        let ite=this.DefineTimingList.filter(item=>item.Name===res.Name)
        console.log(ite,'ite')
        if (res.Name) {
          this.itemTiming=res.Name==="undefined"?[this.DefineTimingList[0]]:[...ite]
          this.form.timing=res.Name==="undefined"?'1920x1080@60':res.Name
        } else {
          this.itemTiming=[this.DefineTimingList[0]]
          this.form.timing='1920x1080@60'
        }
        console.log(this.DefineTimingList[0],'this.DefineTimingList[0]')
        console.log(this.itemTiming,'this.itemTiming')
        // TODO: 分组的默认分辨率是1920 1080
        this.W=res.Name?this.itemTiming[0].H_ACTIVE:1920
        this.H=res.Name?this.itemTiming[0].V_ACTIVE:1080

      })
      this.OutCardList=[...this.OutCardListCopy]
      // 计算屏幕
      this.computedGrid().then(res=>{
        // 获取分组 获取映射
        _this.getOmapInfo()
      })


    },
    // 屏幕设置映射关系确定按钮
    settingOmapEnter(){
      console.log(this.omap,'this.omap设置映射关系的时候')

      this.omap.forEach(item=>{
        item['gap']=0; // 映射新增间隙
        for(let i in this.GridArray){
          for (let j in this.GridArray[i]){
            if (item.Logic_ch===this.GridArray[i][j].sceneIndex){
              item.x=this.GridArray[i][j].X
              item.y=this.GridArray[i][j].Y
            }
          }
        }
      })

      console.log(this.OutCardIDList,'OutCardIDList')
      this.omap=this.omap.filter(item=>{
        // console.log("Phy_ch: ",item.Phy_ch)
        // let ch=this.CardINOUTList[item.Phy_ch].split('_')[0]
        return this.OutCardIDList.includes(parseInt(item.Phy_ch))
      })
      console.log(this.omap,'过滤之后的this.omap')

      settingOmapApi({
        cmd:'settingOmap',
        Group: parseInt(this.activeIndex), // 当前分组ID
        GroupType: parseInt(this.form.GroupType), // 分组类型
        // SceneType: parseInt(this.form.SceneType), // 屏幕类型
        map:[...this.omap], // 映射关系
      }).then(res=>{
        settingTimingApi({
          cmd: 'settingTiming',
          ...this.itemTiming[0],
          // Ch:this.ch,
          Group: parseInt(this.activeIndex)
        })
        // this.$message.success('设置成功')
      })
    },
    // 取消当前映射关系
    quitSettingOmapEnter(){
      cmapApi({cmd:'cmap',Group:parseInt(this.activeIndex)})
      windowClearApi({
        cmd:'windowClear',
        Group:this.gid
      }).then(res=>{
        settingCgrpApi({
          cmd:'settingCgrp',
          Group: parseInt(this.activeIndex)
        })
        this.getCardList()
      })
      // settingOmapApi({
      //   cmd:'settingOmap',
      //   Group: parseInt(this.activeIndex), // 当前分组ID
      //   GroupType: parseInt(this.form.GroupType), // 分组类型
      //   // SceneType: parseInt(this.form.SceneType), // 屏幕类型
      //   map:[], // 映射关系
      // }).then(res=>{
      //   this.$message.success('设置成功')
      //   settingCgrpApi({
      //     cmd:'settingCgrp',
      //     Group: parseInt(this.activeIndex)
      //   })
      //   this.getCardList()
      // }).catch(err=>{
      //   this.$message.error('清空当前映射失败')
      // })
    },
    // 提交当前映射
    OmapEnter(isOmapEnterOpenWindow){
      const _this=this
      return new Promise(resolve => {


        let loading1= _this.$loading({
            lock: true,
            text: i18n.t('spl.SettingUp'),
            spinner: "el-icon-loading",
            background: "rgba(0, 0, 0, 0.7)"
          });


        settingWmodApi({
          cmd:'settingWmod',
          Group: parseInt(_this.activeIndex),
          GroupType: _this.form.GroupType,
          Panel_Row: _this.form.Panel_Row,
          Panel_Col: _this.form.Panel_Col,
          Logic_Sub_Panel_Row: _this.form.Logic_Sub_Panel_Row,
          Logic_Sub_Panel_Col: _this.form.Logic_Sub_Panel_Col,
          Panel_Gap_V: _this.form.Panel_Gap_V,
          Panel_Gap_H: _this.form.Panel_Gap_H,
          // Panel_Gap_V: 0,
          // Panel_Gap_H: 0,
        }).then(()=>{
          cmapApi({cmd:'cmap',Group:parseInt(_this.activeIndex)}).then(()=>{
            _this.addGap()
            localStorage.setItem("tempOmapData",JSON.stringify(_this.omap))
            settingOmapApi({
              cmd:'settingOmap',
              Group: parseInt(_this.activeIndex), // 当前分组ID
              GroupType: parseInt(_this.form.GroupType), // 分组类型
              map:[..._this.omap], // 映射关系
            }).then(()=>{
              settingTimingApi({
                cmd: 'settingTiming',
                ..._this.itemTiming[0],
                // Ch:_this.ch,
                Group: parseInt(_this.activeIndex)
              }).then(()=>{
                sceneDelAllApi({
                  cmd: 'scene_del',
                  Id: 0,
                  Group: parseInt(_this.activeIndex)
                }).then(()=>{
                  localStorage.setItem("sceneData",JSON.stringify([]))
                })
                websocketsend(`(out,osdflag,${parseInt(_this.activeIndex)},0,0)\r\n`,(r)=>{
                  settingCgrpApi({
                    cmd:'settingCgrp',
                    Group: parseInt(_this.activeIndex)
                  }).then(()=>{
                    loading1.close()
                    resolve(true)
                  })
                })
              })

            })
          })
        })
      })


    },
    // 选择输出卡时触发的事件
    OutCardHandleSelect(index){
      console.log(index,'选择的输出卡')
    },
    longTimeTouch(ev,i,name,type){
     const _this=this
     clearTimeout(this.Loop)
      this.Loop=setTimeout(function() {

        let JsonEvData = {
          name,
          ...i
        }
        if (JsonEvData.list){
          let port=parseInt(JsonEvData.list.name.split('_')[1])
          let Phy_index=null
          if (JsonEvData.list.port){
            Phy_index=port; // 端口
          }else {
            Phy_index=JsonEvData.list.port_index===undefined?0:JsonEvData.list.port_index; // 端口
          }
          let ch_port=`${JsonEvData.list.ch}_${Phy_index}`

          let portAs
          for (let j in this.CardINOUTList){
            if (this.CardINOUTList[j]===ch_port){
              portAs=j
            }
          }

          this.OutCardList.forEach(item=>{
            let item_index=item.port_index===undefined?0:item.port_index; // 端口
            let item_port=`${item.ch}_${item_index}`
            for (let j in this.CardINOUTList){
              if (this.CardINOUTList[j]===item_port){
                if (portAs==j){
                  item.disabled=false
                  this.$forceUpdate()
                  this.GridArray.forEach(item=>{
                    item.forEach(it=>{
                      if (it.sceneIndex===JsonEvData.sceneIndex){
                        it.output=''
                        it.outputCh=''
                        it.list= {}
                      }
                    })
                  })
                  _.remove(this.omap,item=>item.Logic_ch===JsonEvData.sceneIndex)
                }
              }
            }
          })
        }
      }.bind(this),1000)
    },
    emptyTime(){
     clearTimeout(this.Loop)
    },
    // 单击COL时的事件
    handleColClick(ev,j,xy){
     const _this=this
     if (this.abcd&&this.dragstart_i){
       // 从右侧拖至宫格
       console.log('从右侧输出卡拖至宫格')
       let JsonEvData=this.abcd
       let Phy_index // 端口
       let card_type
       if (j.output&&j.outputCh&&j.list){
         console.log('已有映射')
         _.remove(this.omap,item=>item.Logic_ch===j.sceneIndex)

         let port=parseInt(j.list.name.split('_')[1])
         let Phy_index=null
         if (j.list.port){
           Phy_index=port; // 端口
         }else {
           Phy_index=j.list.port_index===undefined?0:j.list.port_index; // 端口
         }
         let ch_port=`${j.list.ch}_${Phy_index}`

         let portAs
         for (let j in this.CardINOUTList){
           if (this.CardINOUTList[j]===ch_port){
             portAs=j
           }
         }

         this.OutCardList.forEach(item=>{
           let item_index=item.port_index===undefined?0:item.port_index; // 端口
           let item_port=`${item.ch}_${item_index}`
           for (let j in this.CardINOUTList){
             if (this.CardINOUTList[j]===item_port){
               if (portAs==j){
                 console.log(`${portAs} ---> ${j}`)
                 item.disabled=false
               }
             }
           }

         })

       } else {
         console.log('没有映射')
       }

       card_type=JsonEvData.card_type
       j.output=JsonEvData.name
       j.outputCh=JsonEvData.ch
       j.list=JsonEvData
       Phy_index=JsonEvData.port_index===undefined?0:JsonEvData.port_index; // 端口

       // console.log(this.OutCardList,'this.OutCardList')
       // console.log(item.rename?item.rename:`${this.NameList[item.card_type]+item.ch+(item.port_index===undefined?'_0':`_${item.port_index}`)}`)
       console.log(JsonEvData.name)
       console.log(JsonEvData)
       // let outputChItem=this.OutCardList.filter(item=>(item.rename?item.rename:`${this.NameList[item.card_type]+item.ch}`)===JsonEvData.name)
       let outputChItem=this.OutCardList.filter(item=>item.ch===JsonEvData.ch)
       console.log(outputChItem,'outputChItem')
       // console.log(j,'j')
       // console.log(xy,'xyyyyy')
       if (outputChItem.length){
         outputChItem[0].disabled=true
         // 先注释掉 删除卡的逻辑
         // this.OutCardList.splice(this.OutCardList.indexOf(outputChItem[0]),1)
       }

       // ch_port
       let ch_port=`${j.outputCh}_${Phy_index}`
       // 扩大了两倍的输出卡ID
       let portAs
       for (let j in this.CardINOUTList){
         if (this.CardINOUTList[j]===ch_port){
           portAs=j
         }
       }

       console.log(Phy_index,'Phy_index')
       this.omap.push({
         Logic_ch: j.sceneIndex, // 屏幕索引
         Phy_ch: parseInt(j.outputCh), // 扩大了的输出卡ID
         // Phy_index:Phy_index, // 输出卡端口
         // card_type:card_type, // 输出卡类型
         x:xy[0],// 原点宽
         y:xy[1],// 原点高
         w:j.W||1920,  // 分辨率水平
         h:j.H||1080,  // 分辨率垂直
       })

       let s=setTimeout(function() {
         _this.abcd=null
         _this.dragstart_i=null
         clearTimeout(s)
       },500)
     }

    },
    // 双击COL时的事件
    handleColdbClick(item){
      console.log(item,'itemmmm')
    },
    // 点击输出卡
    clickOutCard(ev,i,name,type){
     this.abcd={
       name,
       ...i
     }
     this.dragstart_i={
       ...i
     }
    },
    // 拖拽输出卡的时候
    drag(ev,i,name,type){
      let _this=this
      console.log(ev,'拖拽输出卡drag时de ev')
      console.log(i,'拖拽输出卡drag时的i')
      let data={
        name,
        ...i
      }
      ev.dataTransfer.setData("abcd", JSON.stringify(data));
      ev.dataTransfer.setData("dragstart_i", JSON.stringify(i));
      if (type===2) {

        // i.output=''
        // i.outputCh=''
        // i.list= {}

        console.log(this.omap,'this.omap')
        // 把这一项加到右侧列表
        let items=this.omap.filter(item=>item.Logic_ch===i.sceneIndex)
        console.log(items,'items')
        // 在omap中删掉含有i.sceneIndex的项
        // _.remove(this.omap,item=>item.Logic_ch===i.sceneIndex)
        items.forEach(omap=>{
          this.OutCardList.forEach(itemm=>{
            let Phy_index=itemm.port_index===undefined?0:itemm.port_index;
            let Phy_ch_index=`${itemm.ch}_${Phy_index}`
            console.log(Phy_ch_index,'Phy_ch_index')
            for (let j in this.CardINOUTList) {
              if (this.CardINOUTList[j]===Phy_ch_index) {
                console.log(j,'j')
                console.log(omap.Phy_ch,'omap.Phy_ch')
                if (omap.Phy_ch==j) {
                  // itemm.disabled=false
                }
              }
            }

            // let port=parseInt(JsonEvData.list.name.split('_')[1])
            // let Phy_index=null
            // if (JsonEvData.list.port){
            //   Phy_index=port; // 端口
            // }else {
            //   Phy_index=JsonEvData.list.port_index===undefined?0:JsonEvData.list.port_index; // 端口
            // }
            // let ch_port=`${JsonEvData.list.ch}_${Phy_index}`
            //
            // let portAs
            // for (let j in this.CardINOUTList){
            //   if (this.CardINOUTList[j]===ch_port){
            //     portAs=j
            //   }
            // }

          })
        })

      }

    },
    drop(ev,j,xy) {
      // console.log(j,'jjjjjjjjjjjjjjjjj')
      // 拖拽至屏幕时
      console.log(ev,'拖拽至屏幕时drop')
      let evData = ev.dataTransfer.getData("abcd");
      let JsonEvData = JSON.parse(evData);
      let Phy_index // 端口
      let card_type
      console.log(JsonEvData,'JsonEvData')

      if (JsonEvData.list) { // 宫格内拖动
        let dragstart_i=JSON.parse(ev.dataTransfer.getData('dragstart_i'));
        console.log('宫格内拖动')

        console.log(dragstart_i,'dragstart_i')
        console.log(j,'j')
        this.GridArray.forEach(item=>{
          item.forEach(it=>{
            if (it.sceneIndex===dragstart_i.sceneIndex&&it.output===dragstart_i.output){
              if (j.output&&j.outputCh&&j.list) { // 交换映射位置
                console.log('有相交')
                console.log(dragstart_i,"dragstart_i")
                console.log(j,"j")
                _.remove(this.omap,item=>item.Logic_ch===dragstart_i.sceneIndex)
                _.remove(this.omap,item=>item.Logic_ch===j.sceneIndex)

                // A
                this.omap.push({
                  Logic_ch: j.sceneIndex, // 屏幕索引
                  Phy_ch: parseInt(JsonEvData.list.ch), // 扩大了的输出卡ID
                  // Phy_index:Phy_index, // 输出卡端口
                  // card_type:card_type, // 输出卡类型
                  x:j.X,// 原点宽
                  y:j.Y,// 原点高
                  w:dragstart_i.W||1920,  // 分辨率水平
                  h:dragstart_i.H||1080,  // 分辨率垂直
                })
                console.log({
                  Logic_ch: j.sceneIndex, // 屏幕索引
                  Phy_ch: parseInt(JsonEvData.list.ch), // 扩大了的输出卡ID
                  // Phy_index:Phy_index, // 输出卡端口
                  // card_type:card_type, // 输出卡类型
                  x:j.X,// 原点宽
                  y:j.Y,// 原点高
                  w:dragstart_i.W||1920,  // 分辨率水平
                  h:dragstart_i.H||1080,  // 分辨率垂直
                },"A")

                // B

                console.log(xy,"xy")
                // B
                this.omap.push({
                  Logic_ch: dragstart_i.sceneIndex, // 屏幕索引
                  Phy_ch: parseInt(j.list.ch), // 扩大了的输出卡ID
                  // Phy_index:Phy_index, // 输出卡端口
                  // card_type:card_type, // 输出卡类型
                  x:dragstart_i.X,// 原点宽
                  y:dragstart_i.Y,// 原点高
                  w:j.W||1920,  // 分辨率水平
                  h:j.H||1080,  // 分辨率垂直
                })
                console.log({
                  Logic_ch: dragstart_i.sceneIndex, // 屏幕索引
                  Phy_ch: parseInt(j.list.ch), // 扩大了的输出卡ID
                  // Phy_index:Phy_index, // 输出卡端口
                  // card_type:card_type, // 输出卡类型
                  x:xy[0],// 原点宽
                  y:xy[1],// 原点高
                  w:j.W||1920,  // 分辨率水平
                  h:j.H||1080,  // 分辨率垂直
                },"B")


                // B->A
                it.output=j.output
                it.outputCh=j.outputCh
                it.list= j.list

                // A->B
                card_type=JsonEvData.list.card_type
                j.output=JsonEvData.list.name
                j.outputCh=JsonEvData.list.ch
                j.list=JsonEvData.list



              }else {
                console.log('无效')
                _.remove(this.omap,item=>item.Logic_ch===dragstart_i.sceneIndex)

                // A
                let port=parseInt(JsonEvData.list.name.split('_')[1])
                let Phy_index=null
                if (JsonEvData.list.port){
                  Phy_index=port; // 端口
                }else {
                  Phy_index=JsonEvData.list.port_index===undefined?0:JsonEvData.list.port_index; // 端口
                }
                let ch_port=`${JsonEvData.list.ch}_${Phy_index}`

                let portAs
                for (let j in this.CardINOUTList){
                  if (this.CardINOUTList[j]===ch_port){
                    portAs=j
                  }
                }
                // A
                this.omap.push({
                  Logic_ch: j.sceneIndex, // 屏幕索引
                  Phy_ch: parseInt(JsonEvData.list.ch), // 扩大了的输出卡ID
                  // Phy_index:Phy_index, // 输出卡端口
                  // card_type:card_type, // 输出卡类型
                  x:j.X,// 原点宽
                  y:j.Y,// 原点高
                  w:j.W||1920,  // 分辨率水平
                  h:j.H||1080,  // 分辨率垂直
                })

                card_type=JsonEvData.list.card_type
                j.output=JsonEvData.list.name
                j.outputCh=JsonEvData.list.ch
                j.list=JsonEvData.list

                it.output=''
                it.outputCh=''
                it.list= {}

              }

            }
          })
        })


        // card_type=JsonEvData.list.card_type
        // j.output=JsonEvData.list.name
        // j.outputCh=JsonEvData.list.ch
        // j.list=JsonEvData.list
        // console.log(j,'j')
        console.log(JsonEvData.list,'JsonEvData.list')
        let port=parseInt(JsonEvData.list.name.split('_')[1])
        if (JsonEvData.list.port){
          Phy_index=port; // 端口
        }else {
          Phy_index=JsonEvData.list.port_index===undefined?0:JsonEvData.list.port_index; // 端口
        }


        // let outputChItem=this.omap.filter(item=>(item.Phy_ch+'_'+item.Phy_index)===(JsonEvData.list.ch+'_'+Phy_index))
        let ch_port=`${JsonEvData.list.ch}_${Phy_index}`
        // console.log(ch_port,'ch_port')
        let portAs
        for (let j in this.CardINOUTList){
          if (this.CardINOUTList[j]===ch_port){
            portAs=j
          }
        }

        this.OutCardList.forEach(itemm=>{
          let Phy_index=itemm.port_index===undefined?0:itemm.port_index;
          let Phy_ch_index=`${itemm.ch}_${Phy_index}`
          for (let j in this.CardINOUTList){
            if (this.CardINOUTList[j]===Phy_ch_index){
              console.log(portAs,'portAs')
              console.log(j,'j')
              if (portAs==j) {
                itemm.disabled=true
              }
            }
          }
        })


        let outputChItem=this.omap.filter(item=>item.Phy_ch===parseInt(JsonEvData.list.ch))
        console.log(portAs,'portAs')
        console.log(outputChItem,'outputChItem')
        if (outputChItem.length){
          // this.omap.splice(this.omap.indexOf(outputChItem[0]),1)
        }
      } else { // 从右侧拖至宫格
        console.log('从右侧输出卡拖至宫格')
        if (j.output&&j.outputCh&&j.list){
          console.log('已有映射')
          _.remove(this.omap,item=>item.Logic_ch===j.sceneIndex)

          let port=parseInt(j.list.name.split('_')[1])
          let Phy_index=null
          if (j.list.port){
            Phy_index=port; // 端口
          }else {
            Phy_index=j.list.port_index===undefined?0:j.list.port_index; // 端口
          }
          let ch_port=`${j.list.ch}_${Phy_index}`

          let portAs
          for (let j in this.CardINOUTList){
            if (this.CardINOUTList[j]===ch_port){
              portAs=j
            }
          }

          this.OutCardList.forEach(item=>{
            let item_index=item.port_index===undefined?0:item.port_index; // 端口
            let item_port=`${item.ch}_${item_index}`
            for (let j in this.CardINOUTList){
              if (this.CardINOUTList[j]===item_port){
                if (portAs==j){
                  console.log(`${portAs} ---> ${j}`)
                  item.disabled=false
                }
              }
            }

          })

        } else {
          console.log('没有映射')
        }

        card_type=JsonEvData.card_type
        j.output=JsonEvData.name
        j.outputCh=JsonEvData.ch
        j.list=JsonEvData
        Phy_index=JsonEvData.port_index===undefined?0:JsonEvData.port_index; // 端口

        // console.log(this.OutCardList,'this.OutCardList')
        // console.log(item.rename?item.rename:`${this.NameList[item.card_type]+item.ch+(item.port_index===undefined?'_0':`_${item.port_index}`)}`)
        console.log(JsonEvData.name)
        console.log(JsonEvData)
        // let outputChItem=this.OutCardList.filter(item=>(item.rename?item.rename:`${this.NameList[item.card_type]+item.ch}`)===JsonEvData.name)
        let outputChItem=this.OutCardList.filter(item=>item.ch===JsonEvData.ch)
        console.log(outputChItem,'outputChItem')
        // console.log(j,'j')
        // console.log(xy,'xyyyyy')
        if (outputChItem.length){
          outputChItem[0].disabled=true
          // 先注释掉 删除卡的逻辑
          // this.OutCardList.splice(this.OutCardList.indexOf(outputChItem[0]),1)
        }

        // ch_port
        let ch_port=`${j.outputCh}_${Phy_index}`
        // 扩大了两倍的输出卡ID
        let portAs
        for (let j in this.CardINOUTList){
          if (this.CardINOUTList[j]===ch_port){
            portAs=j
          }
        }

        console.log(Phy_index,'Phy_index')
        this.omap.push({
          Logic_ch: j.sceneIndex, // 屏幕索引
          Phy_ch: parseInt(j.outputCh), // 扩大了的输出卡ID
          // Phy_index:Phy_index, // 输出卡端口
          // card_type:card_type, // 输出卡类型
          x:xy[0],// 原点宽
          y:xy[1],// 原点高
          w:j.W||1920,  // 分辨率水平
          h:j.H||1080,  // 分辨率垂直
        })


      }


      // console.log(this.omap,'this.omap')
      console.log(this.GridArray,'this.GridArray')




    },
    dropOutList(ev){
      console.log(ev,'拖拽至输出卡列表时drop')
      let evData = ev.dataTransfer.getData("abcd");
      let JsonEvData = JSON.parse(evData);

      console.log(JsonEvData,'拖拽至输出卡列表时JsonEvData')
      if (JsonEvData.list){
        let port=parseInt(JsonEvData.list.name.split('_')[1])
        let Phy_index=null
        if (JsonEvData.list.port){
          Phy_index=port; // 端口
        }else {
          Phy_index=JsonEvData.list.port_index===undefined?0:JsonEvData.list.port_index; // 端口
        }
        let ch_port=`${JsonEvData.list.ch}_${Phy_index}`

        let portAs
        for (let j in this.CardINOUTList){
          if (this.CardINOUTList[j]===ch_port){
            portAs=j
          }
        }

        this.OutCardList.forEach(item=>{
          let item_index=item.port_index===undefined?0:item.port_index; // 端口
          let item_port=`${item.ch}_${item_index}`
          // if (ch_port===item_port){
          //   console.log(ch_port,'ch_portch_portch_port')
          //   this.OutCardList.splice(this.OutCardList.indexOf(item),1)
          // }

          for (let j in this.CardINOUTList){
            if (this.CardINOUTList[j]===item_port){
              // console.log(portAs,'portAs')
              // console.log(j,'j')
              if (portAs==j){
                console.log(`${portAs} ---> ${j}`)
                item.disabled=false
                this.$forceUpdate()

                this.GridArray.forEach(item=>{
                  item.forEach(it=>{
                    if (it.sceneIndex===JsonEvData.sceneIndex){
                      it.output=''
                      it.outputCh=''
                      it.list= {}
                    }
                  })
                })

                _.remove(this.omap,item=>item.Logic_ch===JsonEvData.sceneIndex)
              }
            }
          }

        })

        // this.OutCardList.push(JsonEvData.list)

      }

      console.log(this.OutCardList,'this.OutCardList')
    },
    allowDrop(ev,j){
      // console.log(ev,'拖拽至输出卡列表时allowDrop事件')
      // console.log(j,'j')

      ev.preventDefault()
    },
    allowDropOutList(ev){
      // console.log(ev,'allowDropOutList事件')
      ev.preventDefault()
    },
    GroupChange(val){
      this.form.Panel_Gap_V=0;
      this.form.Panel_Gap_H=0;
      this.cancelGap();
    },
    // 行改变时
    RowChange:_.throttle(function (val){
      console.log(val,'row')
      this.computedGrid(true)
      console.log(this.omap,'rowchange:this.omap')
      console.log(this.OutCardList,'rowchange:this.OutCardList')

      this.OutCardList.forEach(item=> {
        console.log(item.gid,'rowchange:item.gid')
        if (item.gID){
          if (this.gid==item.gID) {
            item.disabled=false
          }
        }else {
          item.disabled=false
        }
      })
      this.omap=[]


      // this.OutCardList=[...this.OutCardListCopy]
    }),
    // 列改变时
    ColChange:_.throttle(function (val){
      console.log(val,'col')
      this.computedGrid(true)
      this.OutCardList.forEach(item=> {
        console.log(item.gID,'ColChange:item.gid')
        if (item.gID){
          if (this.gid==item.gID) {
            item.disabled=false
          }
        }else {
          item.disabled=false
        }
      })
      this.omap=[]

      // this.OutCardList=[...this.OutCardListCopy]
    }),
    // 选择分辨率下拉框
    timingChange(val) {
      console.log(val, '分辨率')
      // console.log(this.DefineTimingList[val], '分辨率值item.Name')
      let ite=this.DefineTimingList.filter(item=>item.Name===val)
      console.log(ite,'ite')
      this.itemTiming=[...ite]
      // console.log(ite,'所选择的值')
      let W=this.itemTiming.length?this.itemTiming[0].H_ACTIVE:1920
      let H=this.itemTiming.length?this.itemTiming[0].V_ACTIVE:1080
      this.W=W;
      this.H=H;
      // console.log(this.omap,'this.omap')
      for (let i=0;i<this.GridArray.length;i++){
        for (let j=0;j<this.GridArray[i].length;j++){
          this.GridArray[i][j]['X']=j*W
          this.GridArray[i][j]['Y']=i*H
          this.GridArray[i][j]['W']=W
          this.GridArray[i][j]['H']=H

          this.omap.forEach(item=>{
            if (this.GridArray[i][j]['sceneIndex']===item.Logic_ch){
              item.w=W;
              item.h=H;
              item.x=j*W;
              item.y=i*H;
            }
          })
        }
      }
      this.$forceUpdate()
      // TODO: 把omap里的宽高修改成分辨率宽高

      // settingTimingApi({
      //   cmd: 'settingTiming',
      //   ...this.itemTiming[0],
      //   // Ch:this.ch,
      //   Group: parseInt(this.activeIndex)
      // })
      // console.log([...ite],'[...ite]')

    },
    // 分组参数提交事件
    GroupEnter(){
      let _this=this
      if(this.form.GroupType!==0){
        this.$refs.form.validateField('timing');
        if (!this.form.timing){
          return false
        }
      }
      cmapApi({cmd:'cmap',Group:parseInt(this.activeIndex)})
      // TODO: 假设LED为2
      if(this.form.GroupType===2){
        // 设置屏幕映射关系
        this.settingOmapEnter()
      }
      // 删除当前分组的所有场景
      sceneDelAllApi({
        cmd: 'scene_del',
        Id: 0,
        Group: parseInt(this.activeIndex)
      }).then(res=>{
        settingWmodApi({
          cmd:'settingWmod',
          Group: parseInt(this.activeIndex),
          GroupType: this.form.GroupType,
          Panel_Row: this.form.Panel_Row,
          Panel_Col: this.form.Panel_Col,
          Logic_Sub_Panel_Row: this.form.Logic_Sub_Panel_Row,
          Logic_Sub_Panel_Col: this.form.Logic_Sub_Panel_Col,
          Panel_Gap_V: this.form.Panel_Gap_V,
          Panel_Gap_H: this.form.Panel_Gap_H,
          // Panel_Gap_V: 0,
          // Panel_Gap_H: 0,
        }).then(res=>{
          if (this.form.GroupType!==0){ // 拼接模式lcd才要为这个分组选择分辨率 2 3
            this.W=this.itemTiming[0].H_ACTIVE
            this.H=this.itemTiming[0].V_ACTIVE
            settingCgrpApi({
              cmd:'settingCgrp',
              Group: parseInt(this.activeIndex)
            }).then(res=>{
              console.log('切换分组成功')
            }).then(_=>{
              this.getCardList()
            }).then(_=>{
              // 根据行列计算矩阵
              this.computedGrid()
            })

          }
          if (this.form.GroupType===1){  // 1
            settingCgrpApi({
              cmd:'settingCgrp',
              Group: parseInt(this.activeIndex)
            }).then(res=>{
              console.log('切换分组成功')
            }).then(_=>{
              this.getCardList()
            }).then(_=>{
              // 根据行列计算矩阵
              this.computedGrid()
            })
          }


          // TODO: 假设LED为2 后面要改成3
          if(this.form.GroupType==1){
            // 设置屏幕映射关系
            _this.settingOmapEnter()
          }

        }).then(_=>{
          // 清除当前分组的已开窗
          let a=setTimeout(function(){
            windowClearApi({
              cmd:'windowClear',
              Group:_this.gid
            })
            clearTimeout(a)
          },2000)
        })
      })





    },
    addGap(){
     const _this=this;
      if (_this.form.GroupType===1) {
        let w=parseInt(_this.form.Panel_Gap_V);
        let h=parseInt(_this.form.Panel_Gap_H);
        const ow = w % 2 === 0 ? w : w + 1;
        // const oh = h % 2 === 0 ? h : h + 1;
        for (let i = 0; i <_this.GridArray.length ; i++) {
          let I_item=_this.GridArray[i];
          for (let j = 0; j < I_item.length; j++) {
            let {X,Y,sceneIndex}=I_item[j];
            _this.omap.forEach(o=>{
              if (o.Logic_ch===sceneIndex){
                o.x=j*(_this.W+ow)
                o.y=i*(_this.H+h)
              }
            })
            _this.GridArray[i][j]["X"]=j*(_this.W+ow)
            _this.GridArray[i][j]["Y"]=i*(_this.H+h)
          }
        }
        console.log(_this.GridArray,'_this.GridArray')
        _this.$forceUpdate()
      }
    },
    cancelGap(){
      const _this=this;
        for (let i = 0; i <_this.GridArray.length ; i++) {
          let I_item=_this.GridArray[i];
          for (let j = 0; j < I_item.length; j++) {
            let {X,Y,sceneIndex}=I_item[j];
            _this.omap.forEach(o=>{
              if (o.Logic_ch===sceneIndex){
                o.x=j*(_this.W)
                o.y=i*(_this.H)
                o.w=_this.W
                o.h=_this.H
              }
            });
            _this.GridArray[i][j]["X"]=j*(_this.W)
            _this.GridArray[i][j]["Y"]=i*(_this.H)
            _this.GridArray[i][j]["W"]=_this.W
            _this.GridArray[i][j]["H"]=_this.H
          }
        }
        console.log(_this.GridArray,'_this.GridArray')
        _this.$forceUpdate()

    },
    Panel_Gap_VChange(val){
     if (val>99){
       this.form.Panel_Gap_V=99
     }
     if (val<0){
       this.form.Panel_Gap_V=0
     }
    },
    Panel_Gap_HChange(val){
      if (val>99){
        this.form.Panel_Gap_H=99
      }
      if (val<0){
        this.form.Panel_Gap_H=0
      }
    },
    GroupEnter1() {
      const _this=this
      let val=true
      this.$refs['form'].validate((valid) => {
        if (valid) {
          val=true
        } else {
          val=false
          console.log('error submit!!');
          return false;
        }
      });
      if (!val){return false}
      const loading1 = this.$loading({
        lock: true,
        text: i18n.t('spl.SettingUp'),
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      settingWmodApi({
        cmd:'settingWmod',
        Group: parseInt(_this.activeIndex),
        GroupType: _this.form.GroupType,
        Panel_Row: _this.form.Panel_Row,
        Panel_Col: _this.form.Panel_Col,
        Logic_Sub_Panel_Row: _this.form.Logic_Sub_Panel_Row,
        Logic_Sub_Panel_Col: _this.form.Logic_Sub_Panel_Col,
        Panel_Gap_V: _this.form.Panel_Gap_V,
        Panel_Gap_H: _this.form.Panel_Gap_H,
        // Panel_Gap_V: 0,
        // Panel_Gap_H: 0,
      }).then(()=>{
        cmapApi({cmd:'cmap',Group:parseInt(_this.activeIndex)}).then(()=>{
          // 这里先把水平间距和垂直间距加到Omap
          if (_this.form.GroupType===1) {
            _this.addGap()
          }
          settingOmapApi({
            cmd:'settingOmap',
            Group: parseInt(_this.activeIndex), // 当前分组ID
            GroupType: parseInt(_this.form.GroupType), // 分组类型
            // SceneType: parseInt(_this.form.SceneType), // 屏幕类型
            map:[..._this.omap], // 映射关系
          }).then(()=>{
            const timingData=_this.itemTiming.length?_this.itemTiming[0]:_this.DefineTimingList[0]
            settingTimingApi({
              cmd: 'settingTiming',
              ...timingData,
              // Ch:_this.ch,
              Group: parseInt(_this.activeIndex)
            }).then(()=>{
              websocketsend(`(out,osdflag,${parseInt(_this.activeIndex)},0,0)\r\n`,(r)=>{
                settingCgrpApi({
                  cmd:'settingCgrp',
                  Group: parseInt(_this.activeIndex)
                }).then(()=>{
                  sceneDelAllApi({
                    cmd: 'scene_del',
                    Id: 0,
                    Group: parseInt(_this.activeIndex)
                  }).then(()=>{
                    websocketsend(
                      `(args,rotate,${parseInt(_this.activeIndex)},5})\r\n`,
                      res => {

                        websocketsend("(sync,omap)\r\n", res => {
                          localStorage.setItem("omapData", JSON.stringify(res));
                        })

                        loading1.close()
                      }
                    );
                  })
                })
              })
            })
          })
        })
      })
    },
    // 根据行列计算矩阵
    computedGrid(isRowColChange){
      let _this=this
      return new Promise((resolve, reject) => {
        timingInfoApi({
          cmd:'timingInfo',
          Group: parseInt(_this.activeIndex)
        }).then(res=>{
          console.log(res,'此分组的分辨率信息Name')
          let M=isRowColChange?_this.form.timing:res.Name
          let ite=_this.DefineTimingList.filter(item=>item.Name===M)
          // TODO: 分组的默认分辨率是1920 1080
          _this.W=ite.length?ite[0].H_ACTIVE:1920
          _this.H=ite.length?ite[0].V_ACTIVE:1080

          _this.GridArray=[]
          let a=[]
          for (let i=1;i<_this.form.Panel_Row*_this.form.Panel_Col+1;i++){
            a.push({
              sceneIndex: i,
              output: '',
              outputCh: '',
              list: {}
            })
          }
          for (let i=0;i<a.length;i+=_this.form.Panel_Col){
            _this.GridArray.push(a.slice(i,i+_this.form.Panel_Col))
          }
          console.log(_this.GridArray,'_this.GridArray')
          console.log(_this.W,'_this.W')
          console.log(_this.H,'_this.H')
          // TODO: 这里需要重新获取分辨率宽高
          for (let i=0;i<_this.GridArray.length;i++){
            for (let j=0;j<_this.GridArray[i].length;j++){
              _this.GridArray[i][j]['X']=j*_this.W
              _this.GridArray[i][j]['Y']=i*_this.H
              _this.GridArray[i][j]['W']=_this.W
              _this.GridArray[i][j]['H']=_this.H
            }
          }

          resolve(true)
        })
      })


    },
    // 获取自定义分辨率接口
    getDefineTimingList(){
      console.log("获取分辨率列表")
      getDefineTimingListApi({
        cmd:'getDefineTimingList'
      }).then(res=>{

        // this.DefineTimingList=res.list

        for (let i in this.OutFormatConfigs){
          this.DefineTimingList.push(this.OutFormatConfigs[i])
        }
        res.list.forEach((item,index)=>{
          this.DefineTimingList.push(item)
          // this.OutFormatConfigs[27+index]=item
          // Object.assign(this.OutFormatConfigs, {  })
        })
        console.log(this.OutFormatConfigs,'this.OutFormatConfigs')
        this.getCardList()
      }).catch(err=>{
        this.$message.error(i18n.t('spl.FailedResolutionList'))
      })

      console.log(this.DefineTimingList,'this.DefineTimingList')
    },
    // 切换分组
    switchGroup(){
      settingCgrpApi({
        cmd:'settingCgrp',
        Group: parseInt(this.activeIndex)
      }).then(res=>{
        console.log('切换分组成功')
      })
    },
  },
}
</script>

<style lang="scss" scoped>
.el-radio-group {
  display: inline-grid;
  grid-template-columns: repeat(4,60px);
}
.fontsize16{
  font-size: 16px;
}
.box-card{
  margin-bottom: 20px;
}
.el-row {
  /*margin-bottom: 10px;*/
  &:last-child {
    margin-bottom: 0;
  }
}
.grid-main-wrapper{

}
.grid-col-wrapper{
  position: relative;
  margin: 1px;
  width: 125px;
  height: 125px;
  background: #d3dce6;
  &.active{
    background: #99a9bf;
  }
  .outSite{
    position: absolute;
    left: 0;
    bottom: 0;
    font-size: 16px;
  }
  .scene_name{
    position: absolute;
    right: 0;
    bottom: 0;
    font-size: 16px;
  }
}
/*.grid-col-wrapper{*/
/*  margin: 5px;*/
/*  width: 125px;*/
/*  height: 125px;*/
/*  background: #99a9bf;*/
/*}*/

</style>
