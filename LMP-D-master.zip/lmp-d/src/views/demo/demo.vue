<template>
  <div style="padding: 30px;display:flex;flex-direction: row;flex-wrap: wrap;">
<!--    <websocket :in="1"></websocket>-->
<!--    <input v-model.lazy="number1" max="200" min="100"  type="number" v-validateNumber.a.b="{max:200,min:100}">-->
<!--    <input v-model.lazy="number2" max="20"  min="10" type="number" v-validateNumber="{max:20,min:10}">-->
<!--    <el-button type="primary" size="mini" @click="logNumber">确定</el-button>-->
  </div>
</template>
<script>
  import websocket from '@/components/websocket'
  export default {
    components:{
      websocket
    },
    data(){
      return {
        number1:'',
        number2:'',
      }
    },
    methods:{
      logNumber(){
        console.log(this.number1,'number1')
        console.log(this.number2,'number2')
      }
    }
  }
</script>

<style lang="scss" scoped>


</style>
