<template>
  <div class="padding30">
    <el-tabs v-model="activeName" @tab-click="handleClick">
      <el-tab-pane :label="$t('set.InputCard')" name="in"></el-tab-pane>
      <el-tab-pane :label="$t('set.outputCard')" name="out"></el-tab-pane>
      <!--      <el-tab-pane label="双通道卡" name="d_inout"></el-tab-pane>-->
      <el-tab-pane :label="$t('set.controlCard')" name="ctrl"></el-tab-pane>
      <!--      <el-tab-pane label="前面板" name="button"></el-tab-pane>-->
      <!--        <el-tab-pane label="背板" name="back"></el-tab-pane>-->
    </el-tabs>
    <!--输入卡和输出卡 单卡-->
    <div
      v-if="
        activeName !== 'ctrl' &&
          activeName !== 'button' &&
          activeName !== 'back' &&
          activeName !== 'd_inout'
      "
    >
      <el-card class="box-card">
        <div slot="header" class="clearfix">
          <el-switch
            v-model="isType"
            :active-text="$t('upgrade.byType')"
            :active-value="255"
            :inactive-text="$t('upgrade.pressCard')"
            :inactive-value="0"
          >
          </el-switch>

          <!--          <span-->
          <!--            >请选择需要升级的{{-->
          <!--              activeName === "in" ? "输入卡" : "输出卡"-->
          <!--            }}</span-->
          <!--          >-->
        </div>
        <!--        <el-checkbox-group v-model="checkedCardList" @change="groupChange">-->
        <!--          <template v-for="card in sortList">-->
        <!--            <el-checkbox-->
        <!--              :disabled="card.disabled"-->
        <!--              :label="card.ch"-->
        <!--              :key="card.ch"-->
        <!--              >{{ card.rename }}</el-checkbox-->
        <!--            >-->
        <!--          </template>-->
        <!--        </el-checkbox-group>-->
        <!--        按类型升级-->
        <el-radio-group v-if="isType === 255" v-model="checkedCardTypeRadio">
          <template
            v-if="activeName === 'in'"
            v-for="card in checkedInTypeList"
          >
            <el-radio :label="card.type" :key="card.type">{{
              card.name
            }}</el-radio>
          </template>

          <template
            v-if="activeName === 'out'"
            v-for="card in checkedOutTypeList"
          >
            <el-radio :label="card.type" :key="card.type">{{
              card.name
            }}</el-radio>
          </template>
        </el-radio-group>
        <!--        按卡升级-->
        <el-radio-group v-else v-model="checkedCardRadio">
          <template v-for="card in sortList">
            <el-radio :label="card.ch" :key="card.ch">{{
              card.rename
            }}</el-radio>
          </template>
        </el-radio-group>
      </el-card>
    </div>
    <!--双卡 100 101 102-->
    <!--    <div v-if="activeName === 'd_inout'">-->
    <!--      <el-card class="box-card">-->
    <!--        <div slot="header" class="clearfix">-->
    <!--          <span>请勾选需要升级的板卡</span>-->
    <!--        </div>-->
    <!--        <el-form>-->
    <!--          <el-form-item label="一入一出卡:">-->
    <!--            <el-checkbox-group v-model="in_out_checkedCardList">-->
    <!--              <el-checkbox-->
    <!--                v-for="card in in_out_sortList"-->
    <!--                :label="card.ch"-->
    <!--                :key="card.ch"-->
    <!--                >{{ card.rename }}</el-checkbox-->
    <!--              >-->
    <!--            </el-checkbox-group>-->
    <!--          </el-form-item>-->
    <!--          <el-form-item label="双输入卡:">-->
    <!--            <el-checkbox-group v-model="in_in_checkedCardList">-->
    <!--              <el-checkbox-->
    <!--                v-for="card in in_in_sortList"-->
    <!--                :label="card.ch"-->
    <!--                :key="card.ch"-->
    <!--                >{{ card.rename }}</el-checkbox-->
    <!--              >-->
    <!--            </el-checkbox-group>-->
    <!--          </el-form-item>-->
    <!--          <el-form-item label="双输出卡:">-->
    <!--            <el-checkbox-group v-model="out_out_checkedCardList">-->
    <!--              <el-checkbox-->
    <!--                v-for="card in out_out_sortList"-->
    <!--                :label="card.ch"-->
    <!--                :key="card.ch"-->
    <!--                >{{ card.rename }}</el-checkbox-->
    <!--              >-->
    <!--            </el-checkbox-group>-->
    <!--          </el-form-item>-->
    <!--        </el-form>-->
    <!--      </el-card>-->
    <!--    </div>-->

    <div style="display: flex;">
      <div style="flex-grow: 5" v-show="activeName === 'in'">
        <uploadBin
          ref="upgrade_inCard_mcu"
          :title="$t('upgrade.MCUUpgradeInputCard')"
          name="upgrade_inCard_mcu"
          :url="`/api/upgrade_inCard_mcu?ch=[${[...checkedCardList]}]`"
          packType="mcu"
          :cardType="activeName"
          :mode="isType"
          :ch="isType === 255 ? checkedCardTypeRadio : checkedCardRadio"
        ></uploadBin>
      </div>
      <div style="flex-grow: 5" v-show="activeName === 'in'">
        <uploadBin
          ref="upgrade_inCard_fpga"
          :title="$t('upgrade.FPGAUpgradeInputCard')"
          name="upgrade_inCard_fpga"
          :url="`/api/upgrade_inCard_fpga?ch=[${[...checkedCardList]}]`"
          packType="fpga"
          :cardType="activeName"
          :mode="isType"
          :ch="isType === 255 ? checkedCardTypeRadio : checkedCardRadio"
        ></uploadBin>
      </div>
      <div style="flex-grow: 5" v-show="activeName === 'out'">
        <uploadBin
          ref="upgrade_outCard_mcu"
          :title="$t('upgrade.MCUUpgradeOutputCard')"
          name="upgrade_outCard_mcu"
          :url="`/api/upgrade_outCard_mcu?ch=[${[...checkedCardList]}]`"
          packType="mcu"
          :cardType="activeName"
          :mode="isType"
          :ch="isType === 255 ? checkedCardTypeRadio : checkedCardRadio"
        ></uploadBin>
      </div>
      <div style="flex-grow: 5" v-show="activeName === 'out'">
        <uploadBin
          ref="upgrade_outCard_fpga"
          :title="$t('upgrade.FPGAUpgradeOutputCard')"
          name="upgrade_outCard_fpga"
          :url="`/api/upgrade_outCard_fpga?ch=[${[...checkedCardList]}]`"
          packType="fpga"
          :cardType="activeName"
          :mode="isType"
          :ch="isType === 255 ? checkedCardTypeRadio : checkedCardRadio"
        ></uploadBin>
      </div>
      <div style="flex-grow: 5" v-show="activeName === 'd_inout'">
        <uploadBin
          ref="upgrade_in_out_Card_mcu"
          title="一入一出卡"
          name="upgrade_in_out_Card_mcu"
          :url="
            `/api/upgrade_in_out_Card_mcu?ch=[${[...in_out_checkedCardList]}]`
          "
        ></uploadBin>
      </div>
      <div style="flex-grow: 5" v-show="activeName === 'd_inout'">
        <uploadBin
          ref="upgrade_in_in_Card_mcu"
          title="双输入卡"
          name="upgrade_in_in_Card_mcu"
          :url="
            `/api/upgrade_in_in_Card_mcu?ch=[${[...in_in_checkedCardList]}]`
          "
        ></uploadBin>
      </div>
      <div style="flex-grow: 5" v-show="activeName === 'd_inout'">
        <uploadBin
          ref="upgrade_out_out_Card_mcu"
          title="双输出卡"
          name="upgrade_out_out_Card_mcu"
          :url="
            `/api/upgrade_out_out_Card_mcu?ch=[${[...out_out_checkedCardList]}]`
          "
        ></uploadBin>
      </div>
      <!--      <div style="flex-grow: 5" v-show="activeName === 'ctrl'">-->
      <!--        <uploadBin-->
      <!--          ref="upgrade_ctlCard_web"-->
      <!--          :title="$t('upgrade.webUpgrade')"-->
      <!--          name="upgrade_ctlCard_web"-->
      <!--          :url="`/api/upgrade_ctlCard_hi`"-->
      <!--          packType="web"-->
      <!--          :cardType="activeName"-->
      <!--          :mode="isType"-->
      <!--          :ch="isType === 255 ? checkedCardTypeRadio : checkedCardRadio"-->
      <!--        ></uploadBin>-->
      <!--      </div>-->
      <div style="flex-grow: 5" v-show="activeName === 'ctrl'">
        <uploadBin
          ref="upgrade_ctlCard_hi"
          :title="$t('upgrade.SOCUpgrade')"
          name="upgrade_ctlCard_hi"
          :url="`/api/upgrade_ctlCard_hi`"
          packType="hi"
          :cardType="activeName"
          :mode="0"
          :ch="0"
        ></uploadBin>
      </div>
      <div style="flex-grow: 5" v-show="activeName === 'ctrl'">
        <uploadBin
          ref="upgrade_ctlCard_mcu"
          :title="$t('upgrade.MCUControlUpgrade')"
          name="upgrade_ctlCard_mcu"
          :url="`/api/upgrade_ctlCard_mcu`"
          packType="mcu"
          :cardType="activeName"
          :mode="0"
          :ch="0"
        ></uploadBin>
      </div>
      <div style="flex-grow: 5" v-show="activeName === 'ctrl'">
        <uploadBin
          ref="upgrade_ctlCard_FPGA"
          :title="$t('upgrade.FPGAControlUpgrade')"
          name="upgrade_ctlCard_FPGA"
          :url="`/api/upgrade_ctlCard_FPGA`"
          packType="fpga"
          :cardType="activeName"
          :mode="0"
          :ch="0"
        ></uploadBin>
      </div>

      <!--      <div style="flex-grow: 5" v-show="activeName === 'button'">-->
      <!--        <uploadBin-->
      <!--          ref="upgrade_key_board"-->
      <!--          title="前面板升级"-->
      <!--          name="upgrade_key_board"-->
      <!--          :url="`/api/upgrade_key_board`"-->
      <!--        ></uploadBin>-->
      <!--      </div>-->

      <!--        <div style="flex-grow: 5" v-show="activeName==='back'">-->
      <!--          <uploadBin ref="upgrade_back_board_fpga" title="背板升级" name="upgrade_back_board_fpga" :url="`/api/upgrade_back_board_fpga`"></uploadBin>-->
      <!--        </div>-->
    </div>
    <div v-if="dialogVisible">
      <div class="coverdiv"></div>
      <div class="toast">
        <el-progress
          :percentage="percentage"
          :status="percentageStatus"
        ></el-progress>
      </div>
    </div>
  </div>
</template>

<script>
import uploadBin from "@/components/uploadBin";
import {
  CardListApi,
  CardDetailApi,
  getInputCardListApi,
  getOutCardListApi
} from "@/api/home";
export default {
  name: "index",
  components: {
    uploadBin
  },
  data() {
    return {
      // 卡板类型名字
      NameList: {
        1: "HDMI",
        4: "VGA",
        23: "DP4K",
        17: "HDMI4K",
        24: "HDMI4K60_",
        10: "HDMI",
        11: "DVI_VS",
        58: "HDMI_VS",
        59: "DVI_VS",
        49: "HDMI",
        100: "HDMI",
        101: "HDMI",
        102: "HDMI",
        3: "CVBS",
        51: "HDBT",
        2: "DVI",
        50: "DVI",
        81: "HDMI4_",
        82: "DVI4_",
        6: "SDI",
        53: "SDI"
      },
      // 已插卡的输入卡类型列表
      checkedInTypeList: [
        { type: 1, name: "HDMI" },
        { type: 2, name: "DVI" },
        { type: 3, name: "CVBS" },
        { type: 4, name: "VGA" },
        { type: 5, name: "DVI_I" },
        { type: 6, name: "SDI" },
        { type: 10, name: "HDMI_VS" },
        { type: 11, name: "DVI_VS" },
        { type: 17, name: "HDMI4K" },
        { type: 18, name: "DVI4K" },
        { type: 23, name: "DP4K" },
        { type: 24, name: "HDMI4K60_" }
      ],
      // 已插卡的输出卡类型列表
      checkedOutTypeList: [
        { type: 49, name: "HDMI" },
        { type: 50, name: "DVI" },
        { type: 51, name: "CVBS" },
        { type: 52, name: "VGA" },
        { type: 53, name: "DVI_I" },
        { type: 54, name: "SDI" },
        { type: 58, name: "HDMI_VS" },
        { type: 59, name: "DVI_VS" },
        { type: 81, name: "HDMI4" },
        { type: 82, name: "DVI4" }
      ],
      NameList2: {
        1: "HDMI",
        2: "DVI",
        3: "CVBS",
        4: "VGA",
        5: "DVI_I",
        6: "SDI",
        10: "HDMI_VS",
        11: "DVI_VS",
        17: "HDMI4K",
        18: "DVI4K",
        23: "DP4K",
        24: "HDMI4K60_",

        49: "HDMI",
        50: "DVI",
        51: "CVBS",
        52: "VGA",
        53: "DVI_I",
        54: "SDI",
        58: "HDMI_VS",
        59: "DVI_VS",

        81: "HDMI4",
        82: "DVI4",
        113: "HDMI8",
        114: "DVI8",
        145: "OM"
      },
      // 进度条弹窗状态
      dialogVisible: false,
      // 进度条进度值
      percentage: 0,
      // 进度条状态
      percentageStatus: null,
      activeName: "in",
      file: "",
      fileList: [],
      List: {
        in: [],
        out: [],
        d_inout: {
          in_out: [],
          in_in: [],
          out_out: []
        }
      },
      // 选中的板卡 老的模式
      checkedCardList: [],
      // 是否按照类型升级
      isType: 0,
      // 选中的卡号 单选
      checkedCardRadio: null,
      // 选中的卡类型 单选
      checkedCardTypeRadio: null,
      in_out_checkedCardList: [],
      in_in_checkedCardList: [],
      out_out_checkedCardList: [],
      // 板卡列表
      cardTAGList: []
    };
  },
  computed: {
    sortList() {
      return this.sortByKey(this.List[this.activeName], "ch"); //将数组中的数据按照ch进行排序
    },
    in_out_sortList() {
      return this.sortByKey(this.List.d_inout.in_out, "ch"); //将数组中的数据按照ch进行排序
    },
    in_in_sortList() {
      return this.sortByKey(this.List.d_inout.in_in, "ch"); //将数组中的数据按照ch进行排序
    },
    out_out_sortList() {
      return this.sortByKey(this.List.d_inout.out_out, "ch"); //将数组中的数据按照ch进行排序
    }
  },
  mounted() {
    const _this = this;

    Promise.all([
      getInputCardListApi({ cmd: "incard_info_sync" }),
      getOutCardListApi({ cmd: "outcard_info_sync" })
    ]).then(res => {
      let inData = res[0]; // {cID: 1, type: 10, name: "", clip: Array(4)}
      let outData = res[1]; // {cID: 1, gID: 1, type: 50, name: ""}
      // console.log(inData, "inData");
      // console.log(outData, "outData");
      let inChArray = [];
      for (let i = 0; i < inData.length; i += 4) {
        inChArray.push(inData.slice(i, i + 4));
      }
      console.log(inChArray, "inChArray");
      // let inType = [];
      inChArray.forEach(item => {
        let { cID, type } = item[0];
        const ch = Math.ceil(cID / 4);
        if (ch && type) {
          this.cardTAGList.push({
            ch,
            type
          });
          // inType.push(type);
          this.List.in.push({
            ch: ch,
            disabled: false,
            card_type: type,
            rename: item.name ? item.name : `${this.NameList[type] + ch}`
          });
        }
      });
      // checkedInTypeList
      // console.log(Array.from(new Set(inType)), "Array.from(new Set(inType))");
      // this.checkedInTypeList = Array.from(new Set(inType)).map(type => {
      //   return {
      //     type,
      //     name: _this.NameList2[type]
      //   };
      // });

      let outChArray = [];
      for (let i = 0; i < outData.length; i += 4) {
        outChArray.push(outData.slice(i, i + 4));
      }
      // let outType = [];
      outChArray.forEach(item => {
        let { cID, type } = item[0];
        const ch = Math.ceil(cID / 4);
        if (ch && type) {
          this.cardTAGList.push({
            ch,
            type
          });
          // outType.push(type);
          this.List.out.push({
            ch: ch,
            disabled: false,
            card_type: type,
            rename: item.name ? item.name : `${this.NameList[type] + ch}`
          });
        }
      });
      // checkedOutTypeList
      // this.checkedOutTypeList = Array.from(new Set(outType)).map(type => {
      //   return {
      //     type,
      //     name: _this.NameList2[type]
      //   };
      // });
    });

    // window.onbeforeunload = function(e) {
    //   var e = window.event || e;
    //   e.returnValue = "确定离开当前页面吗？";
    // };

    // CardListApi({ cmd: "LinkInfo" })
    //   .then(res => {
    //     this.cardTAGList = res.link_status.filter(item => item.type && 1);
    //   })
    //   .then(() => {
    //     this.cardTAGList.forEach(item => {
    //       CardDetailApi({ cmd: "CardInfo", cardIndex: item.ch }).then(i => {
    //         if (
    //           i.list.card_type === 1 ||
    //           i.list.card_type === 3 ||
    //           i.list.card_type === 2 ||
    //           i.list.card_type === 5
    //         ) {
    //           this.List.in.push({
    //             ch: i.list.ch,
    //             disabled: false,
    //             card_type: i.list.card_type,
    //             rename: i.list.rename
    //               ? i.list.rename
    //               : `${this.NameList[i.list.card_type] + i.list.ch}`
    //           });
    //         }
    //         // if(i.list.card_type===5){
    //         //   this.List.in.push({
    //         //     ch:`SDIin_B_${i.list.ch}`,
    //         //     disabled:false,
    //         //     type:'B',
    //         //     card_type:i.list.card_type,
    //         //     rename:i.list.rename?i.list.rename:`${this.NameList[i.list.card_type]+i.list.ch+'_u19'}`
    //         //   })
    //         //   this.List.in.push({
    //         //     ch:`SDIin_A_${i.list.ch}`,
    //         //     disabled:false,
    //         //     type:'A',
    //         //     card_type:i.list.card_type,
    //         //     rename:i.list.rename?i.list.rename:`${this.NameList[i.list.card_type]+i.list.ch+'_u5'}`
    //         //   })
    //         // }
    //         if (
    //           i.list.card_type === 49 ||
    //           i.list.card_type === 51 ||
    //           i.list.card_type === 50 ||
    //           i.list.card_type === 53
    //         ) {
    //           this.List.out.push({
    //             ch: i.list.ch,
    //             disabled: false,
    //             card_type: i.list.card_type,
    //             rename: i.list.rename
    //               ? i.list.rename
    //               : `${this.NameList[i.list.card_type] + i.list.ch}`
    //           });
    //         }
    //         if (i.list.card_type === 100) {
    //           this.List.d_inout.in_out.push({
    //             ch: i.list.ch,
    //             disabled: false,
    //             card_type: i.list.card_type,
    //             rename: i.list.rename
    //               ? i.list.rename
    //               : `${this.NameList[i.list.card_type] + i.list.ch}`
    //           });
    //         }
    //         if (i.list.card_type === 101) {
    //           this.List.d_inout.in_in.push({
    //             ch: i.list.ch,
    //             disabled: false,
    //             card_type: i.list.card_type,
    //             rename: i.list.rename
    //               ? i.list.rename
    //               : `${this.NameList[i.list.card_type] + i.list.ch}`
    //           });
    //         }
    //         if (i.list.card_type === 102) {
    //           this.List.d_inout.out_out.push({
    //             ch: i.list.ch,
    //             disabled: false,
    //             card_type: i.list.card_type,
    //             rename: i.list.rename
    //               ? i.list.rename
    //               : `${this.NameList[i.list.card_type] + i.list.ch}`
    //           });
    //         }
    //       });
    //     });
    //   });
  },
  methods: {
    groupChange(val) {
      console.log(val, "组变化了的值");
      console.log(this.activeName, "activeName");
      if (this.activeName === "in") {
        // 第一次勾选
        if (val.length === 1) {
          let indexCh;
          if (typeof val[0] === "string") {
            indexCh = val[0].split("_")[2];
          } else if (typeof val[0] === "number") {
            indexCh = val[0];
          }
          console.log(indexCh, "indexCh");
          let fristItem = this.cardTAGList.filter(
            item => item.ch === parseInt(indexCh)
          );
          console.log(fristItem, "fristItem");
          console.log(fristItem[0].type, "fristItem[0].type");
          let fristType = fristItem[0].type;
          // if (fristType===5){
          //   this.List.in.forEach(item=>{
          //     if (item.type!==val[0].split('_')[1]){
          //       item.disabled=true
          //     }
          //   })
          // }else {
          //   this.List.in.forEach(item=>{
          //     if (item.card_type!==fristType){
          //       item.disabled=true
          //     }
          //   })
          // }

          this.List.in.forEach(item => {
            if (item.card_type !== fristType) {
              item.disabled = true;
            }
          });
        }
        // 取消所有勾选
        if (val.length === 0) {
          this.List.in.forEach(item => {
            item.disabled = false;
          });
        }
      }
      if (this.activeName === "out") {
        // 第一次勾选
        if (val.length === 1) {
          let indexCh;
          if (typeof val[0] === "string") {
            indexCh = val[0].split("_")[1];
          } else if (typeof val[0] === "number") {
            indexCh = val[0];
          }
          console.log(indexCh, "indexCh");
          let fristItem = this.cardTAGList.filter(
            item => item.ch === parseInt(indexCh)
          );
          // console.log(fristItem,'fristItem')
          // console.log(fristItem[0].type,'fristItem[0].type')
          let fristType = fristItem[0].type;
          this.List.out.forEach(item => {
            if (item.card_type !== fristType) {
              item.disabled = true;
            }
          });
        }
        // 取消所有勾选
        if (val.length === 0) {
          this.List.out.forEach(item => {
            item.disabled = false;
          });
        }
      }
    },
    percentageValue(val) {
      if (val.singe) {
        this.dialogVisible = val.singe;
        this.percentage = val.percent;
        if (val.percent === 100) {
          this.percentageStatus = "success";
        }
      } else {
        this.dialogVisible = false;
      }
    },
    sortByKey(array, key) {
      return array.sort(function(a, b) {
        var x = a[key];
        var y = b[key];
        return x < y ? -1 : x > y ? 1 : 0;
      });
    },
    handleClick(tab, event) {
      let _this = this;
      console.log(tab.name, "tabbbbname");
      this.checkedCardList = [];
      this.checkedCardRadio = null;
      this.in_out_checkedCardList = [];
      this.in_in_checkedCardList = [];
      this.out_out_checkedCardList = [];
      if (tab.name === "in") {
        _this.$refs["upgrade_inCard_mcu"].clearFiles();
        _this.$refs["upgrade_inCard_fpga"].clearFiles();
      }
      if (tab.name === "out") {
        _this.$refs["upgrade_outCard_mcu"].clearFiles();
        _this.$refs["upgrade_outCard_fpga"].clearFiles();
      }
      if (tab.name === "ctrl") {
        _this.$refs["upgrade_ctlCard_mcu"].clearFiles();
        _this.$refs["upgrade_ctlCard_hi"].clearFiles();
      }
      if (tab.name === "button") {
        _this.$refs["upgrade_key_board"].clearFiles();
      }
      if (tab.name === "d_inout") {
        _this.$refs["upgrade_in_in_Card_mcu"].clearFiles();
        _this.$refs["upgrade_in_out_Card_mcu"].clearFiles();
        _this.$refs["upgrade_out_out_Card_mcu"].clearFiles();
      }
      // if (tab.name==='back'){
      //   _this.$refs['upgrade_back_board_fpga'].clearFiles()
      // }

      // 清楚disabled状态
      this.List.in.forEach(item => {
        item.disabled = false;
      });
      this.List.out.forEach(item => {
        item.disabled = false;
      });
    },
    beforeUploadFile(file) {
      let extension = file.name.substring(file.name.lastIndexOf(".") + 1);
      let size = file.size / 1024 / 1024;
      if (extension !== "bin") {
        this.$notify.warning({
          title: "警告",
          message: `只能上传bin（即后缀是.bin）的文件`
        });
      }
      if (size > 10) {
        this.$notify.warning({
          title: "警告",
          message: `文件大小不得超过10M`
        });
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.el-tabs >>> .el-tabs__item {
  color: #ffffff;
}
.el-tabs >>> .el-tabs__item.is-active {
  color: #1890ff;
}
.coverdiv {
  /*遮罩层*/
  display: block;
  position: fixed;
  left: 0;
  top: 0;
  bottom: 0;
  right: 0;
  z-index: 9999;
  background-color: #000000;
  opacity: 0.8;
}
.toast {
  /*弹窗*/
  width: 40%;
  height: 0;
  /*background: transparent;*/
  background: rgba(0, 0, 0, 0.8);
  border-radius: 12px;
  position: fixed;
  margin: auto;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
  z-index: 18888;
}
.box-card {
  flex: 1;
  margin: 20px;
}

/*.toast >>> .el-progress__text{*/
/*   color: #ffffff!important;*/
/* }*/
</style>
