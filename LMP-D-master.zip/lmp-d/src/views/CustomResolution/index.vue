<template>
  <div class="padding30">
    <!--操作栏-->
    <div class="filter-container">
      <div class="filter-item">
        <el-button type="primary" @click="addTag" size="mini">{{
          $t("res.add")
        }}</el-button>
      </div>
    </div>
    <!--表格-->
    <el-table :data="tagTable" border height="70vh">
      <el-table-column prop="Name" :label="$t('res.Name')" align="center" />
      <el-table-column
        prop="H_ACTIVE"
        :label="$t('res.H_ACTIVE')"
        align="center"
      />
      <el-table-column
        prop="V_ACTIVE"
        :label="$t('res.V_ACTIVE')"
        align="center"
      />
      <el-table-column prop="H_FP" :label="$t('res.H_FP')" align="center" />
      <el-table-column prop="V_FP" :label="$t('res.V_FP')" align="center" />
      <el-table-column prop="H_SYNC" :label="$t('res.H_SYNC')" align="center" />
      <el-table-column prop="V_SYNC" :label="$t('res.V_SYNC')" align="center" />
      <el-table-column prop="H_POL" :label="$t('res.H_POL')" align="center">
        <template slot-scope="{ row }">
          <span v-if="row.H_POL === 1">+</span>
          <span v-if="row.H_POL === 0">-</span>
        </template>
      </el-table-column>
      <el-table-column prop="V_POL" :label="$t('res.V_POL')" align="center">
        <template slot-scope="{ row }">
          <span v-if="row.V_POL === 1">+</span>
          <span v-if="row.V_POL === 0">-</span>
        </template>
      </el-table-column>
      <el-table-column prop="H_BP" :label="$t('res.H_BP')" align="center" />
      <el-table-column prop="V_BP" :label="$t('res.V_BP')" align="center" />
      <el-table-column
        prop="H_TOTAL"
        :label="$t('res.H_TOTAL')"
        align="center"
      />
      <el-table-column
        prop="V_TOTAL"
        :label="$t('res.V_TOTAL')"
        align="center"
      />
      <el-table-column prop="Fps" :label="$t('res.Fps')" align="center" />
      <el-table-column
        header-align="center"
        align="center"
        :label="$t('user.actionBar')"
        width="160px"
      >
        <template slot-scope="{ row }">
          <el-button
            type="primary"
            size="mini"
            @click="handleEvent('edit', row)"
            >{{ $t("res.edit") }}</el-button
          >
          <el-button
            type="danger"
            size="mini"
            @click="handleEvent('del', row)"
            >{{ $t("res.delete") }}</el-button
          >
        </template>
      </el-table-column>
    </el-table>
    <!--分页组件-->
    <!--    <el-row type="flex" justify="center" align="middle" style="padding-top: 30px;">-->
    <!--      <el-col>-->
    <!--        <el-pagination-->
    <!--          background-->
    <!--          :current-page.sync="tablePagination.query.curPage"-->
    <!--          :page-sizes="tablePagination.pagesizes"-->
    <!--          :page-size.sync="tablePagination.query.pagesize"-->
    <!--          layout="total, sizes, prev, pager, next, jumper"-->
    <!--          :total="tablePagination.total"-->
    <!--          @size-change="handleSizeChange"-->
    <!--          @current-change="handleCurrentChange"-->
    <!--        />-->
    <!--      </el-col>-->
    <!--    </el-row>-->
    <!--添加标签的弹框-->
    <el-dialog
      :title="dialog.title"
      :visible.sync="dialog.visible"
      :before-close="DialogBeforeClose"
      width="40%"
    >
      <el-form
        ref="form"
        :model="dialog.form"
        inline
        :label-position="dialog.labelPosition"
        :rules="dialog.rules"
        label-width="120px"
      >
        <el-form-item :label="$t('res.Name') + '：'" prop="Name">
          <el-input class="width200" v-model="dialog.form.Name"></el-input>
        </el-form-item>
        <el-form-item label=" ">
          {{ "" }}
        </el-form-item>
        <el-form-item :label="$t('res.H_ACTIVE') + '：'" prop="H_ACTIVE">
          <el-input
            class="width200"
            v-model.number="dialog.form.H_ACTIVE"
          ></el-input>
        </el-form-item>
        <el-form-item :label="$t('res.V_ACTIVE') + '：'" prop="V_ACTIVE">
          <el-input
            class="width200"
            v-model.number="dialog.form.V_ACTIVE"
          ></el-input>
        </el-form-item>
        <el-form-item :label="$t('res.H_FP') + '：'" prop="H_FP">
          <el-input
            class="width200"
            v-model.number="dialog.form.H_FP"
          ></el-input>
        </el-form-item>
        <el-form-item :label="$t('res.V_FP') + '：'" prop="V_FP">
          <el-input
            class="width200"
            v-model.number="dialog.form.V_FP"
          ></el-input>
        </el-form-item>
        <!--        <el-form-item label="垂直前沿：">-->
        <!--          <el-input v-model="dialog.form.V_FP"></el-input>-->
        <!--        </el-form-item>-->
        <el-form-item :label="$t('res.H_SYNC') + '：'" prop="H_SYNC">
          <el-input
            class="width200"
            v-model.number="dialog.form.H_SYNC"
          ></el-input>
        </el-form-item>
        <el-form-item :label="$t('res.V_SYNC') + '：'" prop="V_SYNC">
          <el-input
            class="width200"
            v-model.number="dialog.form.V_SYNC"
          ></el-input>
        </el-form-item>
        <el-form-item :label="$t('res.H_POL') + '：'" prop="H_POL">
          <el-select
            class="width200"
            v-model.number="dialog.form.H_POL"
            placeholder="请选择"
          >
            <el-option label="+" :value="1"></el-option>
            <el-option label="-" :value="0"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item :label="$t('res.V_POL') + '：'" prop="V_POL">
          <el-select
            class="width200"
            v-model.number="dialog.form.V_POL"
            placeholder="请选择"
          >
            <el-option label="+" :value="1"></el-option>
            <el-option label="-" :value="0"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item :label="$t('res.H_BP') + '：'" prop="H_BP">
          <el-input
            class="width200"
            v-model.number="dialog.form.H_BP"
          ></el-input>
        </el-form-item>
        <el-form-item :label="$t('res.V_BP') + '：'" prop="V_BP">
          <el-input
            class="width200"
            v-model.number="dialog.form.V_BP"
          ></el-input>
        </el-form-item>
        <el-form-item :label="$t('res.H_TOTAL') + '：'" prop="H_TOTAL">
          <el-input class="width200" v-model.number="CH_TOTAL"></el-input>
        </el-form-item>
        <el-form-item :label="$t('res.V_TOTAL') + '：'" prop="V_TOTAL">
          <el-input class="width200" v-model.number="CV_TOTAL"></el-input>
        </el-form-item>
        <el-form-item :label="$t('res.Rate') + '：'">
          <el-input disabled v-model="ClockRate"></el-input>
        </el-form-item>
        <el-form-item :label="$t('res.Fps') + '：'" prop="Fps">
          <el-input
            class="width200"
            v-model.number="dialog.form.Fps"
          ></el-input>
        </el-form-item>
        <!--        <el-form-item label="可编程时钟倍频系数：">-->
        <!--          <el-input v-model="dialog.form.M"></el-input>-->
        <!--        </el-form-item>-->
        <!--        <el-form-item label="可编程时钟分频系数：">-->
        <!--          <el-input v-model="dialog.form.D"></el-input>-->
        <!--        </el-form-item>-->
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button size="mini" @click="DialogBeforeClose">{{
          $t("home.cancel")
        }}</el-button>
        <el-button
          v-if="dialog.t === '添加'"
          type="primary"
          size="mini"
          @click="dialogEnter('add')"
          >{{ $t("home.enter") }}</el-button
        >
        <el-button
          v-else
          type="primary"
          size="mini"
          @click="dialogEnter('edit')"
          >{{ $t("home.enter") }}</el-button
        >
      </div>
    </el-dialog>
  </div>
</template>

<script>
import {
  getDefineTimingListApi,
  newDefineTimingApi,
  editDefineTimingApi,
  delDefineTimingApi
} from "@/api/CustomResolution";
import i18n from "@/lang";
const HaveNameList = [
  "1920x1080@60",
  "1920x1080@50",
  "1280x720@60",
  "1280x720@50",
  "800x600@60",
  "1024x768@60",
  "1280x768@60",
  "1280x800@60",
  "1280x960@60",
  "1280x1024@60",
  "1360x768@60",
  "1400x1050@60",
  "1440x900@60",
  "1600x900@60",
  "1680x1050@60",
  "1280x768 RB",
  "1280x800 RB",
  "1440x900 RB",
  "1400x1050 RB",
  "1600x900 RB",
  "1680x1050 RB",
  "1920x1080 RB",
  "1920x1200 RB",
  "2560x920 RB",
  "1080x1920 RB",
  "1536x1536@60"
];
export default {
  name: "Index",
  data() {
    const validateName = (rule, value, callback) => {
      if (value === "") {
        callback(new Error(i18n.t("res.PleaseName")));
      } else if (HaveNameList.includes(value)) {
        callback(new Error(i18n.t("res.nameAlready")));
      } else {
        callback();
      }
    };
    return {
      /* 表格数据*/
      tagTable: [],
      form: {
        cmd: "newDefineTiming",
        Id: "",
        Name: "", // 自定义名字
        H_ACTIVE: 1920, // 水平有效像素
        V_ACTIVE: 1080, // 垂直有效像素
        H_FP: 88, // 水平前沿
        V_FP: 4, // 垂直前沿
        H_SYNC: 44, // 水平同步宽度
        V_SYNC: 5, // 垂直同步宽度
        H_POL: 1, // 水平同步极性
        V_POL: 1, // 垂直同步极性
        H_BP: 148, // 水平后沿
        V_BP: 36, // 垂直后沿
        H_TOTAL: 2200, // 水平总数
        V_TOTAL: 1125, // 垂直总数
        ClockRate: "", // 点时钟
        Fps: 60, // 刷新率
        M: "", // 可编程时钟倍频系数
        D: 222 // 可编程时钟分频系数    111默认  222自定义
      },
      /* 添加弹窗相关*/
      dialog: {
        visible: false,
        loading: false,
        title: "",
        t: "",
        labelPosition: "right",
        form: {
          cmd: "newDefineTiming",
          Id: "",
          Name: "", // 自定义名字
          H_ACTIVE: "", // 水平有效像素
          V_ACTIVE: "", // 垂直有效像素
          H_FP: "", // 水平前沿
          V_FP: "", // 垂直前沿
          H_SYNC: "", // 水平同步宽度
          V_SYNC: "", // 垂直同步宽度
          H_POL: "", // 水平同步极性
          V_POL: "", // 垂直同步极性
          H_BP: "", // 水平后沿
          V_BP: "", // 垂直后沿
          H_TOTAL: "", // 水平总数
          V_TOTAL: "", // 垂直总数
          ClockRate: "", // 点时钟
          Fps: "", // 刷新率
          M: "", // 可编程时钟倍频系数
          D: "" // 可编程时钟分频系数
        },
        rules: {
          Name: [{ validator: validateName, trigger: "blur" }],
          H_ACTIVE: [
            {
              required: true,
              message: i18n.t("res.PleaseHorizontal"),
              trigger: "blur"
            }
          ],
          V_ACTIVE: [
            {
              required: true,
              message: i18n.t("res.PleaseVertical"),
              trigger: "blur"
            }
          ],
          H_FP: [
            {
              required: true,
              message: i18n.t("res.PleaseFrontier"),
              trigger: "blur"
            }
          ],
          V_FP: [
            {
              required: true,
              message: i18n.t("res.PleaseFront"),
              trigger: "blur"
            }
          ],
          H_SYNC: [
            {
              required: true,
              message: i18n.t("res.Pleasehorizontalsyncwidth"),
              trigger: "blur"
            }
          ],
          V_SYNC: [
            {
              required: true,
              message: i18n.t("res.Pleaseverticalsyncwidth"),
              trigger: "blur"
            }
          ],
          H_POL: [
            {
              required: true,
              message: i18n.t("res.Pleasehorizontalsyncpolarity"),
              trigger: "blur"
            }
          ],
          V_POL: [
            {
              required: true,
              message: i18n.t("res.Pleaseverticalsyncpolarity"),
              trigger: "blur"
            }
          ],
          H_BP: [
            {
              required: true,
              message: i18n.t("res.Pleasehorizontaltrailingedge"),
              trigger: "blur"
            }
          ],
          V_BP: [
            {
              required: true,
              message: i18n.t("res.Pleaseverticaltrailingedge"),
              trigger: "blur"
            }
          ],
          H_TOTAL: [
            {
              required: true,
              message: i18n.t("res.Pleasetotalnumberlevels"),
              trigger: "blur"
            }
          ],
          V_TOTAL: [
            {
              required: true,
              message: i18n.t("res.Pleasetotalnumberverticals"),
              trigger: "blur"
            }
          ],
          Fps: [
            {
              required: true,
              message: i18n.t("res.Pleaserefreshrate"),
              trigger: "blur"
            }
          ]
        }
      },
      /* 分页组件*/
      tablePagination: {
        pagesizes: [5, 10, 20, 50, 100], // 每页显示个数选择器的选项设置
        total: 100, // 总条目数
        loading: false, // 是否加载loading动画
        query: {
          curPage: 1, // 当前页数
          pagesize: 20 // 每页显示条目个数，支持 .sync 修饰符
        }
      }
    };
  },
  computed: {
    CH_TOTAL: function() {
      let H_ACTIVE = parseInt(this.dialog.form.H_ACTIVE);
      let H_FP = parseInt(this.dialog.form.H_FP);
      let H_SYNC = parseInt(this.dialog.form.H_SYNC);
      let H_BP = parseInt(this.dialog.form.H_BP);
      return H_ACTIVE + H_FP + H_SYNC + H_BP;
    },
    CV_TOTAL: function() {
      let V_ACTIVE = parseInt(this.dialog.form.V_ACTIVE);
      let V_FP = parseInt(this.dialog.form.V_FP);
      let V_SYNC = parseInt(this.dialog.form.V_SYNC);
      let V_BP = parseInt(this.dialog.form.V_BP);
      return V_ACTIVE + V_FP + V_SYNC + V_BP;
    },
    ClockRate: function() {
      return (this.dialog.form.Fps * this.CH_TOTAL * this.CV_TOTAL) / 1000000;
    }
  },
  mounted() {
    this.getList();
  },
  methods: {
    /* 点击添加按钮弹窗*/
    addTag() {
      this.dialog.title = i18n.t("res.add");
      this.dialog.t = "添加";
      Object.assign(this.dialog.form, this.form);
      this.dialog.visible = true;
    },
    /* 选择项改变时*/
    handleSizeChange(val) {
      const query = this.tablePagination.query;
      query.pagesize = val; // 每页条数
      query.curPage = 1; // 每页条数切换，重置当前页
      this.getList();
    },
    /* 当前页改变时*/
    handleCurrentChange(val) {
      this.tablePagination.query.curPage = val; // 当前页
      this.getList();
    },
    /* 获取表格数据*/
    getList() {
      let data = {
        pageNumber: this.tablePagination.query.curPage,
        pageSize: this.tablePagination.query.pagesize
      };
      getDefineTimingListApi({ cmd: "getDefineTimingList" }).then(res => {
        this.tagTable = res.list;
        // this.tablePagination.total=res.data.totalRow
        // this.tablePagination.query.curPage=res.data.pageNumber
        // this.tablePagination.query.pagesize=res.data.pageSize
      });
    },
    handleEvent(event, data) {
      switch (event) {
        case "edit":
          // 编辑
          this.dialog.form.Id = data.Id;
          this.dialog.title = i18n.t("res.edit");
          this.dialog.t = "编辑";
          this.dialog.visible = true;
          // for (let i in this.dialog.form){
          //   this.dialog.form[i]=''
          // }
          this.dialog.form.cmd = "editDefineTiming";
          Object.assign(this.dialog.form, data);
          break;
        case "del":
          // 删除
          this.$confirm(
            i18n.t("res.deleteResolutionTip"),
            i18n.t("home.deleteAllTip"),
            {
              confirmButtonText: i18n.t("home.enter"),
              cancelButtonText: i18n.t("home.cancel"),
              type: "warning"
            }
          )
            .then(() => {
              delDefineTimingApi({
                cmd: "delDefineTiming",
                Id: data.Id
              })
                .then(res => {
                  this.$message.success(res.msg);
                })
                .then(res => {
                  this.getList();
                });
            })
            .catch(() => {
              this.$message({
                type: "info",
                message: i18n.t("res.Undeleted")
              });
            });

          break;
        default:
          break;
      }
    },
    /*弹框的确定事件 分为添加和编辑*/
    dialogEnter(type) {
      let state;
      this.$refs.form.validate(val => (val ? (state = true) : (state = false)));
      if (!state) {
        return false;
      }
      let data = {};
      let API;
      if (type === "add") {
        API = newDefineTimingApi;
        // this.dialog.form.M = this.tagTable.length + 29;
        // Fout = (numberIndex * Mx) / Dx;
        const { M, D } = this.computedMD(this.ClockRate);
        this.dialog.form.D = D;
        this.dialog.form.M = M;
        this.dialog.form.ClockRate = this.ClockRate;
        this.dialog.form.H_TOTAL = this.CH_TOTAL;
        this.dialog.form.V_TOTAL = this.CV_TOTAL;
      } else if (type === "edit") {
        API = editDefineTimingApi;
        // Object.assign(data,{Id:this.dialog.form.id})
      }

      API(this.dialog.form)
        .then(res => {
          this.$message.success(res.msg);
        })
        .then(res => {
          this.DialogBeforeClose("");
          this.getList();
        });
    },
    // 计算MD
    computedMD(ClockRate) {
      var numberIndex = 27.0;
      var M = 0;
      var D = 0;
      var Mx = 0;
      var Dx = 0;
      var e = 0;
      var e_min = 1.0;
      var Fout = 0;
      var Dmul = 0;
      var clock_rate = Number(ClockRate);
      var Freal = 0;

      for (D = 3; D < 128; D++) {
        Dmul = (clock_rate / numberIndex) * D;
        M = parseInt(Dmul);
        if (Dmul - M > 0.5) {
          M += 1;
        }
        if (M <= 4000 && M >= 12) {
          Freal = (numberIndex * M) / D;
          e = Math.abs(Freal - clock_rate);
          if (e < e_min) {
            e_min = e;
            Mx = M;
            Dx = D;
          }
        }
      }
      return {
        M: Mx,
        D: Dx
      };
    },
    DialogBeforeClose(done) {
      this.$refs.form.resetFields();
      if (typeof done === "function") {
        done();
      } else {
        this.dialog.visible = false;
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.width200 {
  width: 200px;
}
</style>
