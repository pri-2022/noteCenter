<template>
  <div style="width: 100%;padding: 10px">
    <p style="text-align: center">
      {{ $t("set.outputCard") }}{{ ch_index }} {{ $t("set.port") }}{{ ch }}
    </p>
    <el-form ref="form" :model="form" label-position="left" label-width="120px">
      <!--      <el-form-item label="端口: ">-->
      <!--        <el-select v-model="ch_indexCopy" placeholder="端口" @change="portChang">-->
      <!--          <el-option-->
      <!--            v-for="item in portData"-->
      <!--            :key="`${item.ch+'_'+(item.port_index===undefined?'0':item.port_index)}`"-->
      <!--            :label="`${form.rename}(${item.port_type===undefined?`${InOutType[item.card_type]}`:`${item.port_type===1?'输入卡':'输出卡'}`})`"-->
      <!--            :value="`${item.ch+'_'+(item.port_index===undefined?'0':item.port_index)}`">-->
      <!--          </el-option>-->
      <!--          &lt;!&ndash;TODO: 去掉区分端口&ndash;&gt;-->
      <!--          &lt;!&ndash;:label="`${form.rename+'_'+(item.port_index===undefined?'0':item.port_index)}(${item.port_type===undefined?`${InOutType[item.card_type]}`:`${item.port_type===1?'输入卡':'输出卡'}`})`"&ndash;&gt;-->
      <!--        </el-select>-->
      <!--      </el-form-item>-->
      <!--      <el-form-item label="亮度：">-->
      <!--        <el-slider v-model="form.brightbess" :min="0" :max="100" @change="brightbessChange"></el-slider>-->
      <!--      </el-form-item>-->
      <!--SDI输出卡选择分辨率时只有前面四个选项-->
      <!--      <el-form-item label="分辨率：" v-if="card_type===53">-->
      <!--        <el-select v-model="form.timing" placeholder="请选择分辨率" @change="timingChange">-->
      <!--          &lt;!&ndash;          <el-option :label="item.Name" :value="index" v-for="(item,index) of OutFormatConfigs"></el-option>&ndash;&gt;-->
      <!--          <el-option :label="item.Name" :value="item.M" v-for="(item,index) in DefineTimingList.slice(0,6)"></el-option>-->
      <!--        </el-select>-->
      <!--      </el-form-item>-->
      <!--      <el-form-item label="分辨率：" v-else>-->
      <!--        <el-select v-model="form.timing" placeholder="请选择分辨率" @change="timingChange">-->
      <!--          <el-option :label="item.Name" :value="item.M" v-for="(item,index) in DefineTimingList.slice(2)"></el-option>-->
      <!--        </el-select>-->
      <!--      </el-form-item>-->
      <!--      <el-form-item label="分辨率自定义：">-->
      <!--        <el-button type="primary" size="mini" @click="handleTimingDialog">添加</el-button>-->
      <!--      </el-form-item>-->
      <!--      <el-form-item label="分辨率模式：" v-if="card_type!==53">-->
      <!--        <el-select v-model="form.sta" placeholder="请选择分辨率模式" @change="staChange">-->
      <!--          <el-option label="手动" :value="0"></el-option>-->
      <!--          <el-option label="自动" :value="1"></el-option>-->
      <!--        </el-select>-->
      <!--      </el-form-item>-->

      <!--      <el-form-item label="信号格式：" v-if="card_type!==53">-->
      <!--        <el-select v-model="form.hdmi_dvi_choose" placeholder="请选择信号格式" @change="outModeConfigChange">-->
      <!--          <el-option label="Auto" :value="0"></el-option>-->
      <!--          <el-option label="HDMI" :value="1"></el-option>-->
      <!--          <el-option label="DVI" :value="2"></el-option>-->
      <!--        </el-select>-->
      <!--      </el-form-item>-->
      <!--      <el-form-item label="画面：">-->
      <!--        <el-select v-model="form.screen_status" placeholder="请选择画面" @change="outFreedConfigChange">-->
      <!--          <el-option label="关闭" :value="0"></el-option>-->
      <!--          <el-option label="正常" :value="1"></el-option>-->
      <!--          <el-option label="冻结" :value="2"></el-option>-->
      <!--          <el-option label="黑屏" :value="3"></el-option>-->
      <!--        </el-select>-->
      <!--      </el-form-item>-->
      <!--      <el-form-item label="输出模拟音频: " v-if="card_type!==53">-->
      <!--        <el-switch-->
      <!--          @change="analogChange"-->
      <!--          v-model="form.a_analog_flag"-->
      <!--          :active-value="1"-->
      <!--          :inactive-value="0"-->
      <!--          active-color="#13ce66"-->
      <!--          active-text="开"-->
      <!--          inactive-text="关"-->
      <!--          inactive-color="#ff4949"-->
      <!--        ></el-switch>-->
      <!--      </el-form-item>-->
      <!--      <el-form-item label="输出数字音频: " v-if="card_type!==53">-->
      <!--        <el-switch-->
      <!--          @change="embeddedChange"-->
      <!--          v-model="form.a_embedded_flag"-->
      <!--          :active-value="1"-->
      <!--          :inactive-value="0"-->
      <!--          active-color="#13ce66"-->
      <!--          active-text="开"-->
      <!--          inactive-text="关"-->
      <!--          inactive-color="#ff4949"-->
      <!--        ></el-switch>-->
      <!--      </el-form-item>-->

      <el-form-item :label="$t('set.portNameModification') + ': '">
        <el-input v-model="form.rename">
          <el-button
            type="primary"
            size="mini"
            slot="append"
            @click="handleoutcardRenameEnter"
            >{{ $t("home.enter") }}</el-button
          >
        </el-input>
      </el-form-item>
      <!--      <el-form-item label="POE控制开关" v-if="card_type===3||card_type===51">-->
      <!--        <el-select v-model="form.POE" placeholder="请选择状态" @change="POEChang">-->
      <!--          <el-option label="开" :value="1"></el-option>-->
      <!--          <el-option label="关" :value="0"></el-option>-->
      <!--        </el-select>-->
      <!--      </el-form-item>-->
      <!--      <el-form-item>-->
      <!--        <el-button type="danger" size="mini" @click="resetCard">板卡恢复默认</el-button>-->
      <!--      </el-form-item>-->
      <el-form-item :label="$t('set.softwareVersion') + '：'">{{
        "V" + form.ver_sw
      }}</el-form-item>
      <el-form-item :label="$t('set.hardwareVersion') + '：'">{{
        "V" + form.ver_hw
      }}</el-form-item>
      <el-form-item :label="$t('set.fpgaVersion') + '：'">{{
        "V" + form.ver_fpga
      }}</el-form-item>
    </el-form>
    <!--添加自定义分辨率弹窗-->
    <!--    <el-dialog-->
    <!--      title="添加自定义分辨率"-->
    <!--      :visible.sync="dialog.timing.visible"-->
    <!--      width="40%"-->
    <!--    >-->
    <!--      <el-form style="display: flex;flex-wrap: wrap;" ref="formTiming" :model="dialog.timing.form" inline label-position="right" label-width="120px">-->
    <!--        <el-form-item label="自定义名称：">-->
    <!--          <el-input class="width200" v-model="dialog.timing.form.Name"></el-input>-->
    <!--        </el-form-item>-->
    <!--        <el-form-item label=" ">-->
    <!--          {{''}}-->
    <!--        </el-form-item>-->
    <!--        <el-form-item label="水平有效像素: ">-->
    <!--          <el-input class="width200" v-model.number="dialog.timing.form.H_ACTIVE"></el-input>-->
    <!--        </el-form-item>-->
    <!--        <el-form-item label="垂直有效像素: ">-->
    <!--          <el-input class="width200" v-model.number="dialog.timing.form.V_ACTIVE"></el-input>-->
    <!--        </el-form-item>-->
    <!--        <el-form-item label="水平前沿：">-->
    <!--          <el-input class="width200" v-model.number="dialog.timing.form.H_FP"></el-input>-->
    <!--        </el-form-item>-->
    <!--        <el-form-item label="垂直前沿：">-->
    <!--          <el-input class="width200" v-model.number="dialog.timing.form.V_FP"></el-input>-->
    <!--        </el-form-item>-->
    <!--&lt;!&ndash;        <el-form-item label="垂直前沿：">&ndash;&gt;-->
    <!--&lt;!&ndash;          <el-input v-model="dialog.timing.form.V_FP"></el-input>&ndash;&gt;-->
    <!--&lt;!&ndash;        </el-form-item>&ndash;&gt;-->
    <!--        <el-form-item label="水平同步宽度：">-->
    <!--          <el-input class="width200" v-model.number="dialog.timing.form.H_SYNC"></el-input>-->
    <!--        </el-form-item>-->
    <!--        <el-form-item label="垂直同步宽度：">-->
    <!--          <el-input class="width200" v-model.number="dialog.timing.form.V_SYNC"></el-input>-->
    <!--        </el-form-item>-->
    <!--        <el-form-item label="水平同步极性：">-->
    <!--          <el-select class="width200" v-model.number="dialog.timing.form.H_POL" placeholder="请选择">-->
    <!--            <el-option label="+" :value="1"></el-option>-->
    <!--            <el-option label="-" :value="0"></el-option>-->
    <!--          </el-select>-->
    <!--        </el-form-item>-->
    <!--        <el-form-item label="垂直同步极性：">-->
    <!--          <el-select class="width200" v-model.number="dialog.timing.form.V_POL" placeholder="请选择">-->
    <!--            <el-option label="+" :value="1"></el-option>-->
    <!--            <el-option label="-" :value="0"></el-option>-->
    <!--          </el-select>-->
    <!--        </el-form-item>-->
    <!--        <el-form-item label="水平后沿：">-->
    <!--          <el-input class="width200" v-model.number="dialog.timing.form.H_BP"></el-input>-->
    <!--        </el-form-item>-->
    <!--        <el-form-item label="垂直后沿：">-->
    <!--          <el-input class="width200" v-model.number="dialog.timing.form.V_BP"></el-input>-->
    <!--        </el-form-item>-->
    <!--        <el-form-item label="水平总数：">-->
    <!--          <el-input class="width200" v-model.number="dialog.timing.form.H_TOTAL"></el-input>-->
    <!--        </el-form-item>-->
    <!--        <el-form-item label="垂直总数：">-->
    <!--          <el-input class="width200" v-model.number="dialog.timing.form.V_TOTAL"></el-input>-->
    <!--        </el-form-item>-->
    <!--&lt;!&ndash;        <el-form-item label="点时钟：">&ndash;&gt;-->
    <!--&lt;!&ndash;          <el-input v-model="dialog.timing.form.ClockRate"></el-input>&ndash;&gt;-->
    <!--&lt;!&ndash;        </el-form-item>&ndash;&gt;-->
    <!--        <el-form-item label="刷新率：">-->
    <!--          <el-input class="width200" v-model.number="dialog.timing.form.Fps"></el-input>-->
    <!--        </el-form-item>-->
    <!--&lt;!&ndash;        <el-form-item label="可编程时钟倍频系数：">&ndash;&gt;-->
    <!--&lt;!&ndash;          <el-input v-model="dialog.timing.form.M"></el-input>&ndash;&gt;-->
    <!--&lt;!&ndash;        </el-form-item>&ndash;&gt;-->
    <!--&lt;!&ndash;        <el-form-item label="可编程时钟分频系数：">&ndash;&gt;-->
    <!--&lt;!&ndash;          <el-input v-model="dialog.timing.form.D"></el-input>&ndash;&gt;-->
    <!--&lt;!&ndash;        </el-form-item>&ndash;&gt;-->

    <!--      </el-form>-->
    <!--      <span slot="footer" class="dialog-footer">-->
    <!--        <el-button @click="dialog.timing.visible = false">取 消</el-button>-->
    <!--        <el-button type="primary" @click="AddTimingEnter">确 定</el-button>-->
    <!--      </span>-->
    <!--    </el-dialog>-->
  </div>
</template>

<script>
import CapTion from "@/components/CapTion";
import { CardDetailApi, verApi } from "@/api/home";
import {
  out_brightness,
  setting_timing,
  out_res_auto,
  out_mode,
  out_freed,
  out_audio_analog,
  out_audio_embedded,
  rename_incard,
  rename_outcard,
  debounce,
  CLEAR_SUB,
  set_poe
} from "@/utils";
import {
  settingTimingApi,
  outBrightnessConfigApi,
  settingResAutoApi,
  outModeConfigApi,
  outFreedConfigApi,
  outAudioControlApi,
  outcardRenameApi,
  newDefineTimingApi,
  getDefineTimingListApi
} from "@/api/OutCard";
import { poeControlApi, subCardDefaultApi } from "@/api/InCard";
import i18n from "@/lang";

export default {
  name: "OutCard",
  components: {
    CapTion
  },
  props: {
    ch: {
      type: Number,
      default: 0
    }, // 端口ID
    card_type: Number,
    ch_index: Number, // 卡ID
    type: Number,
    handleCh: Object
  },
  mounted() {
    // this.getDefineTimingList();

    console.log(this.ch_index, "this.ch_index");
    this.ch_indexCopy = this.ch_index;
    // const loading = this.$loading({
    //   lock: true,
    //   text: '正在获取数据...',
    //   spinner: 'el-icon-loading',
    //   background: 'rgba(0, 0, 0, 0.7)'
    // })
    // 获取当前输出卡的板卡详情
    this.getList();

    if (localStorage.getItem("verData") && false) {
      const res = JSON.parse(localStorage.getItem("verData"));
      const chItem = res.outcard.filter(
        item => item.ch === parseInt(this.ch_index)
      );
      const { fpga, hw, mcu } = chItem[0];
      this.form.ver_sw = mcu;
      this.form.ver_hw = hw;
      this.form.ver_fpga = fpga;
    } else {
      verApi().then(res => {
        localStorage.setItem("verData", JSON.stringify(res));
        console.log(res, "res");
        console.log(res.outcard, "res.outcard");
        const chItem = res.outcard.filter(
          item => item.ch === parseInt(this.ch_index)
        );
        const { fpga, hw, mcu } = chItem[0];
        this.form.ver_sw = mcu;
        this.form.ver_hw = hw;
        this.form.ver_fpga = fpga;
      });
    }

    // this.socketApi.sendSock({}, data => {
    //   console.log("websocket接收到的数据OutCard", data);
    //   this.$parent.setCard(data, this.ch);
    //   // 输出卡亮度同步
    //   if (data.Cmd === "out_brightness") {
    //     let JsonData = out_brightness(data.data); // 解析指令
    //     if (parseInt(JsonData.out) === this.ch) {
    //       this.form.brightbess = parseInt(JsonData.brightbess);
    //     }
    //   }
    //   // 输出卡选择分辨率指令解析
    //   if (data.Cmd === "setting_timing") {
    //     let JsonData = setting_timing(data.data); // 解析指令
    //     if (parseInt(JsonData.out) === this.ch) {
    //       this.form.timing = parseInt(JsonData.M);
    //       this.form.sta = 0;
    //       this.form.screen_status = 1;
    //
    //       // for (let i in this.OutFormatConfigs){
    //       //   if (this.OutFormatConfigs[i].Name==JsonData.name){
    //       //     this.form.timing=Number(i)
    //       //   }
    //       // }
    //     }
    //   }
    //   // 分辨率模式切换同步 out_res_auto
    //   if (data.Cmd === "out_res_auto") {
    //     let JsonData = out_res_auto(data.data); // 解析指令
    //     if (parseInt(JsonData.out) === this.ch) {
    //       this.form.sta = parseInt(JsonData.sta);
    //     }
    //   }
    //   // 信号格式切换同步 out_mode
    //   if (data.Cmd === "out_mode") {
    //     let JsonData = out_mode(data.data); // 解析指令
    //     if (parseInt(JsonData.out) === this.ch) {
    //       this.form.hdmi_dvi_choose = parseInt(JsonData.mode);
    //     }
    //   }
    //   // 画面切换同步 out_freed
    //   if (data.Cmd === "out_freed") {
    //     let JsonData = out_freed(data.data); // 解析指令
    //     if (parseInt(JsonData.out) === this.ch) {
    //       this.form.screen_status = parseInt(JsonData.mode);
    //     }
    //   }
    //   // 输出模拟音频切换同步
    //   if (data.Cmd === "out_audio_analog") {
    //     let JsonData = out_audio_analog(data.data); // 解析指令
    //     if (parseInt(JsonData.out) === this.ch) {
    //       this.form.a_analog_flag = parseInt(JsonData.mode);
    //     }
    //   }
    //   // 输出外嵌音频切换同步
    //   if (data.Cmd === "out_audio_embedded") {
    //     let JsonData = out_audio_embedded(data.data); // 解析指令
    //     if (parseInt(JsonData.out) === this.ch) {
    //       this.form.a_embedded_flag = parseInt(JsonData.mode);
    //     }
    //   }
    //   // 输出卡重命名切换同步  重名名的指令和输入卡的一样
    //   if (data.Cmd === "rename_incard") {
    //     let JsonData = rename_incard(data.data);
    //     if (parseInt(JsonData.in) === this.ch) {
    //       this.form.rename = JsonData.name;
    //     }
    //   }
    //   // 输出卡重命名同步
    //   if (data.Cmd === "rename_outcard") {
    //     let JsonData = rename_outcard(data.data);
    //     if (parseInt(JsonData.in) === this.ch) {
    //       this.form.rename = JsonData.name;
    //     }
    //   }
    //
    //   // 单卡恢复默认指令同步
    //   if (data.Cmd === "CLEAR_SUB") {
    //     let JsonData = CLEAR_SUB(data.data);
    //     if (parseInt(JsonData.in) === this.ch) {
    //       this.getList();
    //     }
    //   }
    //
    //   // 解析POE开关控制指令
    //   if (data.Cmd === "set_poe") {
    //     let JsonData = set_poe(data.data);
    //     if (parseInt(JsonData.in) === this.ch) {
    //       this.form.POE = parseInt(JsonData.poe);
    //     }
    //   }
    // });
  },
  data() {
    return {
      ch_indexCopy: "",
      // 卡板类型名字
      NameList: {
        1: "HDMI",
        4: "VGA",
        23: "DP4K",
        17: "HDMI4K",
        24: "HDMI4K60_",
        10: "HDMI",
        11: "DVI_VS",
        58: "HDMI",
        59: "DVI",
        49: "HDMI",
        100: "HDMI",
        101: "HDMI",
        102: "HDMI",
        3: "CVBS",
        51: "HDBT",
        2: "DVI",
        50: "DVI",
        81: "HDMI4_",
        82: "DVI4_",
        6: "SDI",
        53: "SDI"
      },
      // 输入卡还是输出卡
      InOutType: {
        1: "输入卡",
        2: "输入卡",
        5: "输入卡",
        6: "输入卡",
        11: "输入卡",
        58: "输出卡",
        59: "输出卡",
        49: "输出卡",
        // 100:'HDMI',
        // 101:'HDMI',
        // 102:'HDMI',
        3: "输入卡",
        4: "输入卡",
        23: "输入卡",
        17: "输入卡",
        24: "输入卡",
        51: "输出卡",
        50: "输出卡",
        53: "输出卡",
        81: "输出卡",
        82: "输出卡"
      },
      portData: [],
      form: {
        POE: 0,
        sta: "",
        brightbess: 0,
        timing: "",
        hdmi_dvi_choose: "",
        screen_status: "",
        a_analog_flag: 0,
        a_embedded_flag: 0,
        rename: "",
        ver_hw: "", // 硬件版本
        ver_sw: "", // 软件版本
        ver_fpga: "" // FPGA版本
      },
      dialog: {
        timing: {
          visible: false,
          form: {
            cmd: "newDefineTiming",
            Name: "1920x1080@60", // 自定义名字
            H_ACTIVE: 1920, // 水平有效像素
            V_ACTIVE: 1080, // 垂直有效像素
            H_FP: 88, // 水平前沿
            V_FP: 4, // 垂直前沿
            H_SYNC: 44, // 水平同步宽度
            V_SYNC: 5, // 垂直同步宽度
            H_POL: 1, // 水平同步极性
            V_POL: 1, // 垂直同步极性
            H_BP: 148, // 水平后沿
            V_BP: 36, // 垂直后沿
            H_TOTAL: 2200, // 水平总数
            V_TOTAL: 1125, // 垂直总数
            ClockRate: "", // 点时钟
            Fps: 60, // 刷新率
            M: "", // 可编程时钟倍频系数
            D: "" // 可编程时钟分频系数
          }
        }
      },
      OutFormatConfigs: {
        1: {
          Name: "1920x1080@60",
          H_ACTIVE: 1920,
          H_TOTAL: 2200,
          H_BP: 148,
          H_FP: 88,
          H_SYNC: 44,
          H_POL: 1,
          V_ACTIVE: 1080,
          V_TOTAL: 1125,
          V_BP: 36,
          V_FP: 4,
          V_SYNC: 5,
          V_POL: 1,
          Rate: 148.5,
          Fps: 60,
          M: 22,
          D: 4
        },
        2: {
          Name: "1920x1080@50",
          H_ACTIVE: 1920,
          H_TOTAL: 2640,
          H_BP: 148,
          H_FP: 528,
          H_SYNC: 44,
          H_POL: 1,
          V_ACTIVE: 1080,
          V_TOTAL: 1125,
          V_BP: 36,
          V_FP: 4,
          V_SYNC: 5,
          V_POL: 1,
          Rate: 148.5,
          Fps: 50,
          M: 22,
          D: 4
        },
        3: {
          Name: "1280x720@60",
          H_FP: 110,
          H_POL: 1,
          H_SYNC: 40,
          H_BP: 220,
          H_ACTIVE: 1280,
          H_TOTAL: 1650,
          V_FP: 5,
          V_POL: 1,
          V_SYNC: 5,
          V_BP: 20,
          V_ACTIVE: 720,
          V_TOTAL: 750,
          Fps: 60,
          M: 22,
          D: 8,
          Rate: 148.5
        },
        4: {
          Name: "1280x720@50",
          H_FP: 440,
          H_POL: 1,
          H_SYNC: 40,
          H_BP: 220,
          H_ACTIVE: 1280,
          H_TOTAL: 1980,
          V_FP: 5,
          V_POL: 1,
          V_SYNC: 5,
          V_BP: 20,
          V_ACTIVE: 720,
          V_TOTAL: 750,
          Fps: 50,
          M: 22,
          D: 8,
          Rate: 74.25
        },
        5: {
          Name: "800x600@60",
          H_FP: 40,
          H_POL: 1,
          H_SYNC: 128,
          H_BP: 88,
          H_ACTIVE: 800,
          H_TOTAL: 1056,
          V_FP: 1,
          V_POL: 1,
          V_SYNC: 4,
          V_BP: 23,
          V_ACTIVE: 600,
          V_TOTAL: 628,
          Fps: 60,
          M: 28,
          D: 19,
          Rate: 40
        },
        6: {
          Name: "1024x768@60",
          H_FP: 24,
          H_POL: 0,
          H_SYNC: 136,
          H_BP: 160,
          H_ACTIVE: 1024,
          H_TOTAL: 1344,
          V_FP: 3,
          V_POL: 0,
          V_SYNC: 6,
          V_BP: 29,
          V_ACTIVE: 768,
          V_TOTAL: 806,
          Fps: 60,
          M: 65,
          D: 27,
          Rate: 65
        },
        7: {
          Name: "1280x768@60",
          H_FP: 64,
          H_POL: 0,
          H_SYNC: 128,
          H_BP: 192,
          H_ACTIVE: 1280,
          H_TOTAL: 1664,
          V_FP: 3,
          V_POL: 1,
          V_SYNC: 7,
          V_BP: 20,
          V_ACTIVE: 768,
          V_TOTAL: 798,
          Fps: 60,
          M: 180,
          D: 61,
          Rate: 79.5
        },
        8: {
          Name: "1280x800@60",
          H_FP: 72,
          H_POL: 0,
          H_SYNC: 128,
          H_BP: 200,
          H_ACTIVE: 1280,
          H_TOTAL: 1680,
          V_FP: 3,
          V_POL: 1,
          V_SYNC: 6,
          V_BP: 22,
          V_ACTIVE: 800,
          V_TOTAL: 831,
          Fps: 60,
          M: 273,
          D: 88,
          Rate: 83.5
        },
        9: {
          Name: "1280x960@60",
          H_FP: 96,
          H_POL: 1,
          H_SYNC: 112,
          H_BP: 312,
          H_ACTIVE: 1280,
          H_TOTAL: 1800,
          V_FP: 1,
          V_POL: 1,
          V_SYNC: 3,
          V_BP: 36,
          V_ACTIVE: 960,
          V_TOTAL: 1000,
          Fps: 60,
          M: 12,
          D: 3,
          Rate: 108
        },
        10: {
          Name: "1280x1024@60",
          H_FP: 48,
          H_POL: 1,
          H_SYNC: 112,
          H_BP: 248,
          H_ACTIVE: 1280,
          H_TOTAL: 1688,
          V_FP: 1,
          V_POL: 1,
          V_SYNC: 3,
          V_BP: 38,
          V_ACTIVE: 1024,
          V_TOTAL: 1066,
          Fps: 60,
          M: 12,
          D: 3,
          Rate: 108
        },
        11: {
          Name: "1360x768@60",
          H_FP: 64,
          H_POL: 1,
          H_SYNC: 112,
          H_BP: 256,
          H_ACTIVE: 1360,
          H_TOTAL: 1792,
          V_FP: 3,
          V_POL: 1,
          V_SYNC: 6,
          V_BP: 18,
          V_ACTIVE: 768,
          V_TOTAL: 795,
          Fps: 60,
          M: 19,
          D: 6,
          Rate: 85.5
        },
        12: {
          Name: "1400x1050@60",
          H_FP: 88,
          H_POL: 0,
          H_SYNC: 144,
          H_BP: 232,
          H_ACTIVE: 1400,
          H_TOTAL: 1864,
          V_FP: 3,
          V_POL: 1,
          V_SYNC: 4,
          V_BP: 32,
          V_ACTIVE: 1050,
          V_TOTAL: 1089,
          Fps: 60,
          M: 415,
          D: 92,
          Rate: 121.75
        },
        13: {
          Name: "1440x900@60",
          H_FP: 80,
          H_POL: 0,
          H_SYNC: 152,
          H_BP: 232,
          H_ACTIVE: 1400,
          H_TOTAL: 1904,
          V_FP: 3,
          V_POL: 1,
          V_SYNC: 6,
          V_BP: 25,
          V_ACTIVE: 900,
          V_TOTAL: 934,
          Fps: 60,
          M: 71,
          D: 18,
          Rate: 106.5
        },
        14: {
          Name: "1600x900@60",
          H_FP: 88,
          H_POL: 0,
          H_SYNC: 168,
          H_BP: 256,
          H_ACTIVE: 1600,
          H_TOTAL: 2112,
          V_FP: 3,
          V_POL: 1,
          V_SYNC: 5,
          V_BP: 26,
          V_ACTIVE: 900,
          V_TOTAL: 934,
          Fps: 60,
          M: 320,
          D: 73,
          Rate: 118.25
        },
        15: {
          Name: "1680x1050@60",
          H_FP: 104,
          H_POL: 0,
          H_SYNC: 176,
          H_BP: 280,
          H_ACTIVE: 1680,
          H_TOTAL: 2240,
          V_FP: 3,
          V_POL: 1,
          V_SYNC: 6,
          V_BP: 30,
          V_ACTIVE: 1050,
          V_TOTAL: 1089,
          Fps: 60,
          M: 65,
          D: 12,
          Rate: 146.25
        },
        16: {
          Name: "1280x768 RB",
          H_FP: 48,
          H_POL: 1,
          H_SYNC: 32,
          H_BP: 80,
          H_ACTIVE: 1280,
          H_TOTAL: 1440,
          V_FP: 3,
          V_POL: 0,
          V_SYNC: 7,
          V_BP: 12,
          V_ACTIVE: 768,
          V_TOTAL: 790,
          Fps: 60,
          M: 91,
          D: 36,
          Rate: 68.25
        },
        17: {
          Name: "1280x800 RB",
          H_FP: 48,
          H_POL: 1,
          H_SYNC: 32,
          H_BP: 80,
          H_ACTIVE: 1280,
          H_TOTAL: 1440,
          V_FP: 3,
          V_POL: 0,
          V_SYNC: 6,
          V_BP: 14,
          V_ACTIVE: 800,
          V_TOTAL: 823,
          Fps: 60,
          M: 71,
          D: 27,
          Rate: 71
        },
        18: {
          Name: "1440x900 RB",
          H_FP: 48,
          H_POL: 1,
          H_SYNC: 32,
          H_BP: 80,
          H_ACTIVE: 1440,
          H_TOTAL: 1600,
          V_FP: 3,
          V_POL: 0,
          V_SYNC: 6,
          V_BP: 17,
          V_ACTIVE: 900,
          V_TOTAL: 926,
          Fps: 60,
          M: 135,
          D: 41,
          Rate: 88.75
        },
        19: {
          Name: "1400x1050 RB",
          H_FP: 48,
          H_POL: 1,
          H_SYNC: 32,
          H_BP: 80,
          H_ACTIVE: 1400,
          H_TOTAL: 1560,
          V_FP: 3,
          V_POL: 0,
          V_SYNC: 4,
          V_BP: 23,
          V_ACTIVE: 1050,
          V_TOTAL: 1080,
          Fps: 60,
          M: 101,
          D: 27,
          Rate: 101
        },
        20: {
          Name: "1600x900 RB",
          H_FP: 24,
          H_POL: 1,
          H_SYNC: 80,
          H_BP: 96,
          H_ACTIVE: 1600,
          H_TOTAL: 1800,
          V_FP: 1,
          V_POL: 1,
          V_SYNC: 3,
          V_BP: 96,
          V_ACTIVE: 900,
          V_TOTAL: 1000,
          Fps: 60,
          M: 12,
          D: 3,
          Rate: 108
        },
        21: {
          Name: "1680x1050 RB",
          H_FP: 48,
          H_POL: 1,
          H_SYNC: 32,
          H_BP: 80,
          H_ACTIVE: 1680,
          H_TOTAL: 1840,
          V_FP: 3,
          V_POL: 0,
          V_SYNC: 6,
          V_BP: 21,
          V_ACTIVE: 1050,
          V_TOTAL: 1080,
          Fps: 60,
          M: 119,
          D: 27,
          Rate: 119
        },
        22: {
          Name: "1920x1080 RB",
          H_FP: 48,
          H_POL: 1,
          H_SYNC: 32,
          H_BP: 80,
          H_ACTIVE: 1920,
          H_TOTAL: 2080,
          V_FP: 3,
          V_POL: 0,
          V_SYNC: 5,
          V_BP: 23,
          V_ACTIVE: 1080,
          V_TOTAL: 1111,
          Fps: 60,
          M: 277,
          D: 54,
          Rate: 138.5
        },
        23: {
          Name: "1920x1200 RB",
          H_FP: 48,
          H_POL: 1,
          H_SYNC: 32,
          H_BP: 80,
          H_ACTIVE: 1920,
          H_TOTAL: 2080,
          V_FP: 3,
          V_POL: 0,
          V_SYNC: 6,
          V_BP: 26,
          V_ACTIVE: 1200,
          V_TOTAL: 1235,
          Fps: 60,
          M: 137,
          D: 24,
          Rate: 154
        },
        24: {
          Name: "2560x920 RB",
          H_FP: 32,
          H_POL: 1,
          H_SYNC: 44,
          H_BP: 48,
          H_ACTIVE: 2560,
          H_TOTAL: 2684,
          V_FP: 4,
          V_POL: 0,
          V_SYNC: 5,
          V_BP: 36,
          V_ACTIVE: 920,
          V_TOTAL: 965,
          Fps: 60,
          M: 495,
          D: 86,
          Rate: 155.4036
        },
        25: {
          Name: "1080x1920 RB",
          H_FP: 88,
          H_POL: 1,
          H_SYNC: 44,
          H_BP: 148,
          H_ACTIVE: 1080,
          H_TOTAL: 1360,
          V_FP: 3,
          V_POL: 1,
          V_SYNC: 4,
          V_BP: 36,
          V_ACTIVE: 1920,
          V_TOTAL: 1963,
          Fps: 60,
          M: 528,
          D: 89,
          Rate: 157.51112
        },
        26: {
          Name: "1536x1536@60",
          H_FP: 32,
          H_POL: 1,
          H_SYNC: 24,
          H_BP: 48,
          H_ACTIVE: 1536,
          H_TOTAL: 1640,
          V_FP: 4,
          V_POL: 0,
          V_SYNC: 5,
          V_BP: 30,
          V_ACTIVE: 1536,
          V_TOTAL: 1575,
          Fps: 60,
          M: 781,
          D: 126,
          Rate: 154.98
        }
      },
      DefineTimingList: []
    };
  },
  methods: {
    portChang(val) {
      console.log(val, "选择的端口");
      let type =
        this.portData[parseInt(val.split("_")[1])].port_type === 1
          ? "in"
          : "out";
      this.$parent.sendCompoentItem(
        this.handleCh,
        type,
        parseInt(val.split("_")[1])
      );
    },
    // 获取板卡详情
    getList() {
      const outList = JSON.parse(localStorage.getItem("outListData"));
      outList.forEach(item => {
        if (item.cID == this.ch) {
          this.form.rename = item.name
            ? item.name
            : `${this.NameList[item.type] + item.cID}`;
        }
      });

      // CardDetailApi({
      //   cmd: "CardInfo",
      //   cardIndex: Number(this.ch),
      //   port_index: parseInt(this.ch_index),
      //   type: Number(this.type)
      // })
      //   .then(res => {
      //     let data;
      //     if (res.list.port) {
      //       // 双通道的卡
      //       data = res.list.port[parseInt(this.ch_index.split("_")[1])];
      //       this.portData = [...res.list.port];
      //     } else {
      //       // 单通道的卡
      //       data = res.list;
      //       this.portData = [res.list];
      //     }
      //
      //     this.form.ver_sw = data.ver_sw;
      //     this.form.ver_hw = data.ver_hw;
      //     this.form.ver_fpga = data.ver_fpga;
      //
      //     this.form.brightbess = data.brightbess;
      //     let timing = data.timing;
      //     console.log(timing, "timingggggg");
      //     // let name=`${timing.H_active}x${timing.V_active}@${timing.Rate}`
      //     // console.log(name,'当前输出卡的名字，组合规则为 H_active+V_active+@+Rate')
      //     // this.DefineTimingList.forEach((it,index)=>{
      //     //   // console.log(it,'it')
      //     //   // console.log(it.H_ACTIVE,'it.H_ACTIVE')
      //     //   // console.log(it.V_ACTIVE,'it.V_ACTIVE')
      //     //   // console.log(it.Fps,'it.Fps')
      //     //   if (it.H_ACTIVE==timing.H_active&&it.V_ACTIVE==timing.V_active&&it.Fps==timing.Fps){
      //     //     this.form.timing=index
      //     //   }
      //     //
      //     // })
      //
      //     this.form.timing = parseInt(timing.M);
      //
      //     // for (let i in this.OutFormatConfigs) {
      //     //   if (this.OutFormatConfigs[i].Name===name){
      //     //     this.form.timing=i
      //     //   }
      //     // }
      //     // if(data.card_type===49||data.card_type===51){ // HDMI HDBT
      //     //   this.form.rename = data.rename ? data.rename : `${this.NameList[data.card_type]+data.ch}`
      //     // }
      //
      //     this.form.rename = data.rename
      //       ? data.rename
      //       : `${this.NameList[data.card_type] + data.ch}`;
      //     this.form.a_analog_flag = data.a_analog_flag ? 1 : 0;
      //     this.form.a_embedded_flag = data.a_embedded_flag ? 1 : 0;
      //     this.form.hdmi_dvi_choose = data.hdmi_dvi_choose;
      //     this.form.sta = data.res_auto;
      //     this.form.screen_status = data.screen_status;
      //
      //     this.form.POE = data.poe;
      //   })
      //   .then(_ => {
      //     // let a=setTimeout(function() {
      //     //   loading.close()
      //     //   clearTimeout(a)
      //     // },1000)
      //     // loading.close()
      //   })
      //   .catch(err => {
      //     // this.$message.error('获取输出卡详情失败')
      //     // loading.close()
      //   });
    },
    // 获取自定义分辨率接口
    getDefineTimingList() {
      getDefineTimingListApi({
        cmd: "getDefineTimingList"
      })
        .then(res => {
          // this.DefineTimingList=res.list

          for (let i in this.OutFormatConfigs) {
            this.DefineTimingList.push(this.OutFormatConfigs[i]);
          }
          res.list.forEach((item, index) => {
            this.DefineTimingList.push(item);
            // this.OutFormatConfigs[27+index]=item
            // Object.assign(this.OutFormatConfigs, {  })
          });
          console.log(this.OutFormatConfigs, "this.OutFormatConfigs");
        })
        .catch(err => {
          this.$message.error(i18n.t("set.FailedResolutionList"));
        });

      console.log(this.DefineTimingList, "this.DefineTimingList");
    },
    // // 弹出自定义分辨率窗口
    // handleTimingDialog() {
    //   this.dialog.timing.visible = true
    // },
    // 自定义分辨率窗口确定事件
    // AddTimingEnter(){
    //   newDefineTimingApi(this.dialog.timing.form).then(res=>{
    //     this.getDefineTimingList()
    //     this.$message.success('添加成功')
    //     this.dialog.timing.visible = false
    //   }).catch(err=>{
    //     this.$message.error('添加自定义分辨失败')
    //   })
    // },
    // 选择分辨率下拉框
    timingChange(val) {
      console.log(val, "分辨率");
      console.log(this.DefineTimingList[val], "分辨率值");
      let ite = this.DefineTimingList.filter(item => item.M == val);
      console.log(ite, "所选择的值");
      settingTimingApi({
        cmd: "settingTiming",
        ...ite[0],
        Ch: this.ch,
        port_index: parseInt(this.ch_index),
        Group: 1
      })
        .then(res => {
          this.$message.success(i18n.t("set.SuccessfulOperation"));
        })
        .catch(err => {
          this.$message.error(i18n.t("set.FailedSelectResolution"));
        });
    },
    // 调节亮度事件
    brightbessChange(val) {
      outBrightnessConfigApi({
        cmd: "outBrightnessConfig",
        Ch: this.ch,
        port_index: parseInt(this.ch_index),
        value: val
      })
        .then(res => {
          this.$message.success(i18n.t("set.BrightnessSuccessfully"));
        })
        .catch(err => {
          this.$message.error(i18n.t("set.BrightnessFailed"));
        });
    },
    // 选择分辨率模式
    staChange(val) {
      settingResAutoApi({
        cmd: "settingResAuto",
        Ch: this.ch,
        port_index: parseInt(this.ch_index),
        En: val
      });
    },
    // 选择信号格式
    outModeConfigChange(val) {
      outModeConfigApi({
        cmd: "outModeConfig",
        Ch: this.ch,
        port_index: parseInt(this.ch_index),
        mode: val
      });
    },
    // 切换画面
    outFreedConfigChange(val) {
      outFreedConfigApi({
        cmd: "outFreedConfig",
        Ch: this.ch,
        port_index: parseInt(this.ch_index),
        index: val
      });
    },
    // 输出模拟开关切换事件
    analogChange(val) {
      outAudioControlApi({
        cmd: "outAudioControl",
        mode: "analog",
        ch: this.ch,
        port_index: parseInt(this.ch_index),
        en: val
      });
    },
    // 输出外嵌开关切换事件
    embeddedChange(val) {
      outAudioControlApi({
        cmd: "outAudioControl",
        mode: "embedded",
        ch: this.ch,
        port_index: parseInt(this.ch_index),
        en: val
      });
    },
    // 输出卡名字命名
    handleoutcardRenameEnter: debounce(
      function() {
        const _this = this;
        if (this.form.rename.length > 10) {
          this.$message.info(i18n.t("set.TheLengthName"));
          return false;
        }
        outcardRenameApi({
          cmd: "outcardRename",
          ch: this.ch,
          port_index: parseInt(this.ch_index),
          name: this.form.rename
        })
          .then(res => {
            this.$message.success(i18n.t("set.SuccessModified"));
            const outListData = JSON.parse(localStorage.getItem("outListData"));
            outListData.forEach(item => {
              if (item.cID === _this.ch) {
                item.name = _this.form.rename;
              }
            });
            localStorage.setItem("outListData", JSON.stringify(outListData));
          })
          .catch(err => {
            this.$message.error(i18n.t("set.failEdit"));
          });
      },
      1000,
      false
    ),
    POEChang(val) {
      console.log(val, "POE选择的值");
      poeControlApi({
        cmd: "poeControl",
        ch: this.ch,
        port_index: parseInt(this.ch_index),
        sta: val
      }).then(res => {
        this.$message.success(i18n.t("set.ChooseSuccess"));
      });
    },
    // 板卡恢复默认
    resetCard() {
      let _this = this;
      this.$confirm("此操作将恢复板卡至默认状态, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
        closeOnClickModal: false,
        beforeClose(action, instance, done) {
          if (action == "confirm") {
            instance.$refs["confirm"].$el.onclick = a();

            function a(e) {
              console.log(2);
              e = e || window.event;
              if (e.detail != 0) {
                done();
              }
            }
          } else {
            done();
          }
        }
      }).then(() => {
        subCardDefaultApi({
          cmd: "subCardDefault",
          port_index: parseInt(this.ch_index),
          Ch: _this.ch
        }).then(res => {
          _this.$message.success("恢复默认成功");
          // _this.getList()
        });
      });
    }
  }
};
</script>

<style lang="scss" scoped>
.el-form >>> .el-form-item {
  margin-bottom: 10px;
}
.width200 {
  width: 200px;
}
.el-form >>> .el-form-item__label {
  color: #ffffff;
}

.el-form >>> .el-form-item__content {
  margin-right: 20px;
}

.el-dialog__wrapper >>> .el-dialog {
  background-color: #434343;

  .el-dialog__title {
    color: #ffffff;
  }

  .el-dialog__body {
    text-align: center;
  }
}

.el-switch >>> .el-switch__label {
  color: #ffffff;
}
</style>
