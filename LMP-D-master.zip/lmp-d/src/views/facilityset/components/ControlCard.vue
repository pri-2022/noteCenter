<template>
  <div style="width: 100%;padding: 10px">
    <p style="text-align: center">{{ $t("set.controlCard") }}</p>
    <el-form ref="form" :model="form" label-position="left" label-width="110px">
      <el-form-item :label="$t('set.changIp') + ': '">
        <el-input v-model="form.ip"></el-input>
      </el-form-item>
      <el-form-item :label="$t('set.mask') + ': '">
        <!--        <el-input v-model="form.mask"></el-input>-->
        <span>{{ form.mask }}</span>
      </el-form-item>
      <el-form-item :label="$t('set.gateway') + ': '">
        <!--        <el-input v-model="form.gateway"></el-input>-->
        <span>{{ form.gateway }}</span>
      </el-form-item>
      <el-form-item label="Mac: ">
        <!--        <el-input v-model="form.mac"></el-input>-->
        <span>{{ form.mac }}</span>
      </el-form-item>
      <el-form-item :label="$t('set.PortNumber') + ': '">
        <!--        <el-input v-model="form.port"></el-input>-->
        <span>{{ form.port }}</span>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" size="mini" @click="modifyIpInfo">{{
          $t("home.enter")
        }}</el-button>
      </el-form-item>

      <el-form-item>
        <el-button type="danger" size="mini" @click="recoverInfo">{{
          $t("set.reset")
        }}</el-button>
      </el-form-item>

      <el-form-item :label="$t('set.fanAdjustment') + ': '">
        <el-select
          v-model="fengshan"
          @change="settingFanChang"
          :placeholder="$t('set.PleaseSpeed')"
        >
          <el-option :value="1" :label="$t('set.lowSpeed')"></el-option>
          <el-option :value="2" :label="$t('set.mediumSpeed')"></el-option>
          <el-option :value="3" :label="$t('set.highSpeed')"></el-option>
        </el-select>
      </el-form-item>

      <el-form-item :label="$t('set.brightness') + ': '">
        <el-slider
          v-model="form.brightbess"
          :min="0"
          :max="100"
          @change="brightbessChange"
        ></el-slider>
      </el-form-item>

      <!--      <el-form-item label="温度: ">-->
      <!--        {{`${wendu||0}℃`}}-->
      <!--      </el-form-item>-->

      <!--      <el-form-item label="功耗: ">-->
      <!--        {{`${dev_power||0}W`}}-->
      <!--      </el-form-item>-->

      <el-form-item :label="$t('set.webVersion') + ': '">
        {{ VersionInfo.web }}
      </el-form-item>
      <el-form-item label="SOC: ">
        {{ VersionInfo.core }}
      </el-form-item>
      <el-form-item label="MCU: ">
        {{ "V" + VersionInfo.ctrlmcu }}
      </el-form-item>
      <el-form-item label="FPGA: ">
        {{ "V" + VersionInfo.fpga }}
      </el-form-item>

      <!--      <el-form-item label="前面板版本: ">-->
      <!--        {{VersionInfo.frontmcu}}-->
      <!--      </el-form-item>-->

      <!--      <el-form-item label="背板版本: ">-->
      <!--&lt;!&ndash;        {{VersionInfo.backfpga}}&ndash;&gt;-->
      <!--        V1.0.0-->
      <!--      </el-form-item>-->
    </el-form>
  </div>
</template>

<script>
import {
  GetIpInfoApi,
  modifyIpInfoApi,
  GetVersionInfoApi,
  factoryDefaultApi,
  settingFanApi
} from "@/api/ControlCard";
import { CLEAR_SUB, fan_setting } from "@/utils";
import { outBrightnessConfigApi } from "@/api/OutCard";
import { verApi, DevInfoApi } from "@/api/home";
import { websocketsend } from "@/utils/ws";
import { ginfo_syncApi } from "@/api/SplicingSettings";
import i18n from "@/lang";

export default {
  name: "ControlCard",
  data() {
    return {
      fengshan: "",
      dev_power: "",
      wendu: "",
      form: {
        mask: "",
        ip: "",
        gateway: "",
        mac: "",
        port: "",
        brightbess: 0
      },
      VersionInfo: {
        core: "",
        hisi: "",
        ctrlmcu: "", // 控制板 mcu 版本
        frontmcu: "", // 前面板mcu版本
        backfpga: "", // 背板 fpga版本
        fpga: ""
      }
    };
  },
  mounted() {
    let _this = this;
    this.GetIpInfo();

    if (localStorage.getItem("verData") && false) {
      const res = JSON.parse(localStorage.getItem("verData"));
      const { fpga, mcu } = res.ctrlcard;
      //     this.VersionInfo.core = res.VersionInfo.hisi.core;
      //     this.VersionInfo.web = res.VersionInfo.hisi.web;
      this.VersionInfo.ctrlmcu = mcu;
      this.VersionInfo.fpga = fpga;
      //     this.VersionInfo.frontmcu = res.VersionInfo.front.mcu;
      //     this.VersionInfo.backfpga = res.VersionInfo.back.fpga;
    } else {
      verApi().then(res => {
        localStorage.setItem("verData", JSON.stringify(res));
        const { fpga, mcu } = res.ctrlcard;
        this.VersionInfo.ctrlmcu = mcu;
        this.VersionInfo.fpga = fpga;
      });
    }

    ginfo_syncApi({ cmd: "ginfo_sync" }).then(res => {
      let gid = 0;
      const GroupContext = res
        .map(item => {
          if (item["ginfo sync"]) {
            gid = item["ginfo sync"]["curr grp"];
            return item["ginfo sync"].context;
          }
        })
        .filter(Boolean);
      console.log("GroupContext", GroupContext);
      const itemGroup = GroupContext.find(item => item.gID === gid);
      let brightness = itemGroup.ScreenCof.Brightness;
      console.log(brightness, "brightness1");
      if (brightness >= 128) {
        brightness -= 128;
        brightness *= 50 / 127;
      } else {
        brightness *= 50 / 127;
        brightness += 50;
      }
      brightness = Math.round(brightness);
      console.log(brightness, "brightness2");
      this.form.brightbess = brightness;
    });

    GetVersionInfoApi({
      cmd: "getVersionInfo"
    })
      .then(res => {
        console.log(res, "查询版本信息");
        this.VersionInfo.core = res.VersionInfo.hisi.core;
        this.VersionInfo.web = res.VersionInfo.hisi.web;
        // this.VersionInfo.ctrlmcu = res.VersionInfo.ctrl.mcu;
        // this.VersionInfo.frontmcu = res.VersionInfo.front.mcu;
        // this.VersionInfo.backfpga = res.VersionInfo.back.fpga;
      })
      .catch(err => {
        // this.$message.error("查询版本信息失败");
      });

    // 获取设备信息
    DevInfoApi({
      cmd: "DevInfo"
    }).then(res => {
      /*fan_speed: 1
front_lock: 0
message_en: 1
temperature: 33
type: "FMX16-U"*/
      // this.wendu = res.dev_info.temperature; // 温度
      this.fengshan = res["fan speed"]; // 风扇
      // this.dev_power = res.dev_info.dev_power.toFixed(2); // 功耗
    });

    // this.socketApi.sendSock({}, data => {
    //   console.log("websocket接收的数据ControlCard：", data);
    //   // 监听恢复出厂设置指令
    //   if (data.Cmd === "CLEAR") {
    //     // 恢复出厂设置 恢复默认
    //     window.location.href = "http://192.168.0.178";
    //   }
    //   // 监听风扇指令
    //   if (data.Cmd === "fan_setting") {
    //     let JsonData = fan_setting(data.data);
    //     _this.fengshan = parseInt(JsonData.step);
    //     console.log(_this.fengshan, "_this.fengshan");
    //   }
    //   this.$parent.setCard(data, undefined);
    // });
  },
  methods: {
    // 调节亮度事件
    brightbessChange(val) {
      console.log(val);
      let value = parseInt(val);
      if (value >= 50) {
        value -= 50;
        value *= 127 / 50;
      } else {
        value *= 127 / 50;
        value += 128;
      }
      value = Math.round(value);
      ginfo_syncApi({ cmd: "ginfo_sync" }).then(res => {
        console.log(res, "res");
        const ginfoSync = res.find(item => item["ginfo sync"]);
        const Group = ginfoSync["ginfo sync"]["curr grp"];
        websocketsend(
          `(setting,gtone,brightness,${Group},${value})\r\n`,
          res => {
            console.log(res, "res");
          }
        );
        console.log(ginfoSync);
      });

      // outBrightnessConfigApi({
      //   cmd: 'outBrightnessConfig',
      //   Ch: this.ch,
      //   port_index: parseInt(this.ch_index),
      //   value: val
      // }).then(res => {
      //   this.$message.success('调节亮度成功')
      // }).catch(err=>{
      //   this.$message.error('调节亮度失败')
      // })
    },
    // 控制风扇
    settingFanChang(val) {
      settingFanApi({
        cmd: "settingFan",
        step: val
      }).then(res => {
        // this.$message.success('切换成功')
      });
    },
    // 获取控制卡信息
    GetIpInfo() {
      const ipInfoData = JSON.parse(localStorage.getItem("ipInfoData"));
      const { gac, ip, mac, mask, port } = ipInfoData;
      this.form.mask = mask;
      this.form.ip = ip;
      this.form.gateway = gac;
      this.form.mac = mac;
      this.form.port = port;
      // GetIpInfoApi({
      //   cmd: "GetIpInfo"
      // })
      //   .then(res => {
      //     this.form.mask = res.mask;
      //     this.form.ip = res.ip;
      //     this.form.gateway = res.gateway;
      //     this.form.mac = res.mac;
      //     this.form.port = res.port;
      //   })
      //   .catch(err => {
      //     this.$message.error("获取控制卡信息失败");
      //   });
    },
    // 修改控制卡信息
    modifyIpInfo() {
      modifyIpInfoApi({
        cmd: "modifyIpInfo",
        ip: this.form.ip,
        mac: this.form.mac,
        mask: this.form.mask,
        gateway: this.form.gateway,
        port: this.form.port
      })
        .then(res => {
          this.$message.success(i18n.t("set.SuccessModified"));
          this.$store.dispatch("user/logout").then(() => {
            window.open(`http://${this.form.ip}/#/login`, "_self");
          });
        })
        .catch(err => {
          this.$message.error(i18n.t("set.failEdit"));
        });
    },
    // 恢复出厂设置
    recoverInfo() {
      let _this = this;
      this.$confirm(
        i18n.t("set.ThisRestoreContinue"),
        i18n.t("home.deleteAllTip"),
        {
          confirmButtonText: i18n.t("home.enter"),
          cancelButtonText: i18n.t("home.cancel"),
          type: "warning",
          closeOnClickModal: false,
          beforeClose(action, instance, done) {
            if (action == "confirm") {
              instance.$refs["confirm"].$el.onclick = a();

              function a(e) {
                console.log(2);
                e = e || window.event;
                if (e.detail != 0) {
                  done();
                }
              }
            } else {
              done();
            }
          }
        }
      )
        .then(() => {
          factoryDefaultApi({ cmd: "factoryDefault" })
            .then(res => {
              const loading = _this.$loading({
                lock: true,
                text: i18n.t("set.factoryResetSuccessful"),
                spinner: "el-icon-loading",
                background: "rgba(0, 0, 0, 0.7)"
              });
              let a = setTimeout(function() {
                loading.close();
                clearTimeout(a);
                _this.$store.dispatch("user/logout");
                window.location.href = "/";
              }, 2000);
            })
            .catch(err => {
              _this.$message.error(i18n.t("set.FailedRestore"));
            });
        })
        .catch(err => {});
    },
    maskBlur(val) {
      this.modifyIpInfo();
    },
    ipBlur(val) {
      this.modifyIpInfo();
      // if (process.env.NODE_ENV === 'development'){
      //   window.open(`http://${this.form.ip}/#/layout/facilityset`,'_blank')
      // }else {
      //   window.open(`http://${this.form.ip}/#/layout/facilityset`,'_self')
      // }
      window.open(`http://${this.form.ip}/#/login`, "_blank");
    },
    gatewayBlur(val) {
      this.modifyIpInfo();
    },
    macBlur(val) {
      this.modifyIpInfo();
    },
    portBlur(val) {
      this.modifyIpInfo();
    }
  }
};
</script>

<style lang="scss" scoped>
.el-form >>> .el-form-item {
  margin-bottom: 10px;
}
.el-form >>> .el-form-item__label {
  color: #ffffff;
}

.el-form >>> .el-form-item__content {
  margin-right: 20px;
}

.el-dialog__wrapper >>> .el-dialog {
  background-color: #434343;

  .el-dialog__title {
    color: #ffffff;
  }

  .el-dialog__body {
    text-align: center;
  }
}

.el-switch >>> .el-switch__label {
  color: #ffffff;
}
</style>
