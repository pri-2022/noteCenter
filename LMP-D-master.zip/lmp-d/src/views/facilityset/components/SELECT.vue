<template>
  <div>
    <el-button-group>
      <el-button v-for="item of port" type="info" @click="handleClick(typeList[item.port_type],item.port_index)">{{`${typeList[item.port_type]==='in'?'输入':'输出'}_${item.port_index===0?'0':'1'}`}}</el-button>
    </el-button-group>
  </div>
</template>

<script>
  import {CardDetailApi} from "@/api/home";

  export default {
    name: "SELECT",
    props: {
      card_type: Number,
      ch: Number,
      handleCh: Object,
    },
    mounted() {
      this.getList()
    },
    data() {
      return {
        port:[],
        typeList:{
          1:'in',
          49:'out'
        }
      }
    },
    methods: {
      getList(){
        CardDetailApi({ cmd: 'CardInfo', cardIndex: Number(this.ch) }).then(res => {
          this.port=[...res.list.port]
        })
      },
      handleClick(type,index) {
        console.log(type,'type')
        this.$parent.sendCompoentItem(this.handleCh,type,index)
      }
    },
  }
</script>

<style scoped>

</style>
