<template>
    <div></div>
</template>

<script>
  export default {
    name: 'noCard'
  }
</script>

<style scoped>

</style>
