<template>
  <div style="width: 100%;padding: 10px">
    <p style="text-align: center">
      {{ $t("set.InputCard") }}{{ ch_index }} {{ $t("set.port") }}{{ ch }}
    </p>
    <el-form ref="form" :model="form" label-position="left" label-width="130px">
      <!--      <el-form-item label="端口: ">-->
      <!--        <el-select v-model="ch_indexCopy" placeholder="端口" @change="portChang">-->
      <!--          <el-option-->
      <!--            v-for="item in portData"-->
      <!--            :key="`${item.ch+'_'+(item.port_index===undefined?'0':item.port_index)}`"-->
      <!--            :label="`${form.rename}(${item.port_type===undefined?`${InOutType[item.card_type]}`:`${item.port_type===1?'输入卡':'输出卡'}`})`"-->
      <!--            :value="`${item.ch+'_'+(item.port_index===undefined?'0':item.port_index)}`">-->
      <!--          </el-option>-->
      <!--          &lt;!&ndash;TODO: 去掉区分端口&ndash;&gt;-->
      <!--          &lt;!&ndash;:label="`${form.rename+'_'+(item.port_index===undefined?'0':item.port_index)}(${item.port_type===undefined?`${InOutType[item.card_type]}`:`${item.port_type===1?'输入卡':'输出卡'}`})`"&ndash;&gt;-->
      <!--        </el-select>-->
      <!--      </el-form-item>-->
      <!--      <el-form-item label="切换音频源：" v-show="card_type!==5">-->
      <!--        <el-switch-->
      <!--          v-model="form.audio"-->
      <!--          :active-value="1"-->
      <!--          :inactive-value="0"-->
      <!--          active-color="#13ce66"-->
      <!--          inactive-text="外嵌"-->
      <!--          active-text="本地"-->
      <!--          inactive-color="#ff4949"-->
      <!--          @change="inAudioChooseChange"-->
      <!--        />-->
      <!--      </el-form-item>-->

      <!--      <el-form-item label="输入格式: " v-show="card_type===2">-->
      <!--        <el-select v-model="form.set_insubcard" placeholder="请选择输入格式" @change="set_insubcardChange">-->
      <!--          <el-option label="HDMI" :value="1"/>-->
      <!--          <el-option label="DVI" :value="2"/>-->
      <!--          <el-option label="VGA" :value="3"/>-->
      <!--          <el-option label="Ypbpr" :value="4"/>-->
      <!--          <el-option label="CVBS" :value="5"/>-->
      <!--        </el-select>-->
      <!--      </el-form-item>-->
      <!--      <el-form-item label="EDID: " v-show="card_type !== 5">-->
      <!--        &lt;!&ndash;SDI输入卡没有EDID，音频等功能&ndash;&gt;-->
      <!--        <el-select-->
      <!--          v-model="form.edid_index"-->
      <!--          placeholder="请选择EDID"-->
      <!--          @change="edid_indexChange"-->
      <!--        >-->
      <!--          <el-option label="1080p-2.0" :value="97" />-->
      <!--          <el-option label="1080p-5.1" :value="98" />-->
      <!--          <el-option label="720p-2.0" :value="99" />-->
      <!--          <el-option label="720p-5.1" :value="100" />-->
      <!--          <el-option label="4k-2.0" :value="101" />-->
      <!--          <el-option label="自定义EDID" :value="102" />-->
      <!--          <el-option-->
      <!--            v-for="i of sortoutputList"-->
      <!--            :label="i.rename ? i.rename : `${NameList[i.card_type]}${i.ch}`"-->
      <!--            :value="i.index_s"-->
      <!--          />-->
      <!--        </el-select>-->
      <!--      </el-form-item>-->
      <el-form-item
        label="EDID: "
        v-show="card_type !== 5 && card_type !== 3 && card_type !== 6"
      >
        <el-upload
          :ref="uploadName"
          class="upload-demo"
          accept=".bin"
          action
          :limit="1"
          :file-list="fileList"
          :on-exceed="uploadExceed"
          :on-change="handleChange"
          :http-request="httpRequest"
          :auto-upload="false"
        >
          <el-button slot="trigger" size="small">{{
            $t("upgrade.select")
          }}</el-button>
          <el-button size="small" type="info" @click.prevent="submitUpload">{{
            $t("upgrade.Upload")
          }}</el-button>
        </el-upload>
      </el-form-item>
      <!--      <el-form-item label="默认EDID: " v-show="card_type!==5">-->
      <!--        <el-button type="info" size="mini" @click="edidInitHandle">恢复默认</el-button>-->
      <!--      </el-form-item>-->

      <el-form-item :label="$t('set.osdSettings') + ': '">
        <el-button type="info" @click="fontDialog">{{
          $t("set.DetailedSettings")
        }}</el-button>
      </el-form-item>
      <!--      <el-form-item label="字幕显示: ">-->
      <!--        <el-button type="info" @click="fontDisPlayDialog">显示设置</el-button>-->
      <!--      </el-form-item>-->
      <el-form-item :label="$t('set.osdSwitch') + ': '">
        <el-switch
          v-model="form.en"
          :active-value="1"
          :inactive-value="0"
          active-color="#13ce66"
          :inactive-text="$t('set.off')"
          :active-text="$t('set.on')"
          inactive-color="#ff4949"
          @change="inSubtitleChange"
        />
      </el-form-item>

      <el-form-item :label="$t('set.portNameModification') + ': '">
        <el-input v-model="form.rename">
          <el-button
            type="primary"
            size="mini"
            slot="append"
            @click="handleincardRenameEnter"
            >{{ $t("home.enter") }}</el-button
          >
        </el-input>
      </el-form-item>
      <!--      <el-form-item-->
      <!--        :label="$t('set.poeControlSwitch') + ': '"-->
      <!--        v-if="card_type === 3 || card_type === 51"-->
      <!--      >-->
      <!--        <el-select v-model="form.POE" @change="POEChang">-->
      <!--          <el-option :label="$t('set.on')" :value="1"></el-option>-->
      <!--          <el-option :label="$t('set.off')" :value="0"></el-option>-->
      <!--        </el-select>-->
      <!--      </el-form-item>-->
      <!--      <el-form-item v-show="card_type === 2">-->
      <!--        <el-button type="primary" size="mini" @click="DIVup">{{-->
      <!--          $t("set.dviUpgrade")-->
      <!--        }}</el-button>-->
      <!--      </el-form-item>-->
      <!--      <el-form-item>-->
      <!--        <el-button type="danger" size="mini" @click="resetCard">板卡恢复默认</el-button>-->
      <!--      </el-form-item>-->
      <el-form-item>
        <el-button type="info" size="mini" @click="inClipDialog">{{
          $t("set.cuttingPlan")
        }}</el-button>
      </el-form-item>
      <el-form-item :label="$t('set.resolution') + '：'">{{
        `${form.H}*${form.W}`
      }}</el-form-item>
      <el-form-item :label="$t('set.softwareVersion') + '：'">{{
        "V" + form.ver_sw
      }}</el-form-item>
      <el-form-item :label="$t('set.hardwareVersion') + '：'">{{
        "V" + form.ver_hw
      }}</el-form-item>
      <el-form-item :label="$t('set.fpgaVersion') + '：'">{{
        "V" + form.ver_fpga
      }}</el-form-item>
    </el-form>
    <!--字幕详细设置弹窗-->
    <el-dialog
      :title="$t('set.osdSettings')"
      :visible.sync="dialog.font.visible"
      center
      class="dialogFontVisible"
      width="50%"
    >
      <el-form
        ref="formTiming"
        style="text-align: left;display: flex;flex-wrap: wrap;justify-content: space-between;"
        :model="dialog.font.form"
        inline
        label-position="left"
        label-width="110px"
      >
        <el-form-item :label="$t('set.Font') + '：'">
          <el-select
            class="width200"
            v-model="dialog.font.form.family"
            :placeholder="$t('set.FontHolder')"
          >
            <el-option :label="$t('set.boldFace')" value="SimHei" />
            <el-option :label="$t('set.italics')" value="KaiTi" />
            <el-option :label="$t('set.newSong')" value="NSimSun" />
            <!--            <el-option label="微软雅黑" value="微软雅黑" />-->
            <el-option :label="$t('set.songTi')" value="SimSun" />
            <el-option :label="$t('set.imitateSong')" value="FangSong" />
          </el-select>
        </el-form-item>
        <el-form-item :label="$t('set.fontSize') + '：'">
          <el-select
            class="width200"
            v-model="dialog.font.form.fontsize"
            :placeholder="$t('set.fontSizeHolder')"
          >
            <!--            <el-option label="6px" :value="6" />-->
            <!--            <el-option label="7px" :value="7" />-->
            <!--            <el-option label="8px" :value="8" />-->
            <!--            <el-option label="9px" :value="9" />-->
            <!--            <el-option label="10px" :value="10" />-->
            <!--            <el-option label="11px" :value="11" />-->
            <!--            <el-option label="12px" :value="12" />-->
            <!--            <el-option label="14px" :value="14" />-->
            <el-option label="16px" :value="16" />
            <!--            <el-option label="18px" :value="18" />-->
            <el-option label="20px" :value="20" />
            <!--            <el-option label="22px" :value="22" />-->
            <el-option label="24px" :value="24" />
            <!--            <el-option label="26px" :value="26" />-->
            <el-option label="28px" :value="28" />
            <el-option label="36px" :value="36" />
            <el-option label="48px" :value="48" />
            <el-option label="72px" :value="72" />
            <!--            <el-option label="80px" :value="80" />-->
            <!--            <el-option label="100px" :value="100" />-->
          </el-select>
        </el-form-item>
        <el-form-item :label="$t('set.Effect') + '：'">
          <el-select
            class="width200"
            v-model="dialog.font.form.result"
            multiple
            collapse-tags
            :placeholder="$t('set.pleaseSelectTheEffect')"
          >
            <el-option :label="$t('set.Bold')" value="Blod" />
            <el-option :label="$t('set.Italic')" value="Italic" />
            <el-option :label="$t('set.Strikethrough')" value="Strickout" />
            <el-option :label="$t('set.Underscore')" value="Underline" />
          </el-select>
        </el-form-item>
        <el-form-item :label="$t('set.subtitleContent') + '：'">
          <el-input class="width200" v-model="dialog.font.form.content" />
        </el-form-item>

        <el-form-item :label="$t('set.currentResolution') + '：'">
          <span style="color: #ffffff">{{ `${form.H}*${form.W}` }}</span>
        </el-form-item>
        <el-form-item :label="$t('set.transparentBackground') + '：'">
          <el-switch
            class="width200"
            v-model="dialog.font.form.bc_transparent"
            :active-value="1"
            :inactive-value="0"
            active-color="#13ce66"
            :inactive-text="$t('set.opaque')"
            :active-text="$t('set.transparent')"
            inactive-color="#ff4949"
          />
        </el-form-item>
        <el-form-item :label="$t('set.displayPositionX') + '：'">
          <el-input
            class="width200"
            v-model.number="dialog.font.form.X"
            type="number"
            :max="form.H"
            :min="0"
          />
        </el-form-item>
        <el-form-item :label="$t('set.displayPositionY') + '：'">
          <el-input
            class="width200"
            v-model.number="dialog.font.form.Y"
            type="number"
            :max="form.W"
            :min="0"
          />
        </el-form-item>

        <el-form-item :label="$t('set.fontColor') + '：'">
          <el-color-picker
            class="width200"
            v-model="dialog.font.form.Fc"
            color-format="rgb"
          />
          <!--          <span style="color: #ffffff">{{dialog.font.form.Fc}}</span>-->
        </el-form-item>
        <el-form-item :label="$t('set.backgroundColor') + '：'">
          <el-color-picker
            class="width200"
            v-model="dialog.font.form.Bc"
            color-format="rgb"
          />
          <!--          <span style="color: #ffffff">{{dialog.font.form.Bc}}</span>-->
        </el-form-item>
        <!--        <el-form-item label=" ">-->
        <!--          {{' '}}-->
        <!--        </el-form-item>-->
        <el-form-item :label="$t('set.previewEffect') + '：'">
          <!--          <canvas ref="canvasFont"></canvas>-->
          <CapTion
            ref="CapTion"
            :isXY="isXY"
            @isXYHandle="isXYHandle"
            :Bc="dialog.font.form.Bc"
            :Fc="dialog.font.form.Fc"
            :Y="dialog.font.form.Y"
            :X="dialog.font.form.X"
            :bc_transparent="dialog.font.form.bc_transparent"
            :result="dialog.font.form.result"
            :fontsize="dialog.font.form.fontsize"
            :font="dialog.font.form.family"
            :ch="ch"
            v-model="dialog.font.form.content"
          />
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialog.font.visible = false">{{
          $t("set.Cancel")
        }}</el-button>
        <el-button type="info" @click="handleFontPreview">{{
          $t("set.preview")
        }}</el-button>
        <el-button type="primary" @click="handleFontEnter">{{
          $t("set.Enter")
        }}</el-button>
      </span>
    </el-dialog>
    <!--    裁剪方案-->
    <el-dialog
      :title="$t('set.cuttingPlan')"
      :visible.sync="dialog.clip.visible"
      center
      class="dialogFontVisible"
      :before-close="dialogClipClose"
    >
      <el-table :data="dialog.clip.table" style="width: 100%">
        <el-table-column prop="sytle" label="ID" align="center">
        </el-table-column>
        <el-table-column label="X" align="center">
          <template slot-scope="{ row }">
            <el-input
              size="mini"
              v-model="row.wnd_size[0]"
              :disabled="row.disabled"
            ></el-input>
            <!--            <span>{{row.wnd_size[0]}}</span>-->
          </template>
        </el-table-column>
        <el-table-column label="Y" align="center">
          <template slot-scope="{ row }">
            <el-input
              size="mini"
              v-model="row.wnd_size[1]"
              :disabled="row.disabled"
            ></el-input>
            <!--            <span>{{row.wnd_size[1]}}</span>-->
          </template>
        </el-table-column>
        <el-table-column label="W" align="center">
          <template slot-scope="{ row }">
            <el-input
              size="mini"
              v-model="row.wnd_size[2]"
              :disabled="row.disabled"
            ></el-input>
            <!--            <span>{{row.wnd_size[2]}}</span>-->
          </template>
        </el-table-column>
        <el-table-column label="H" align="center">
          <template slot-scope="{ row }">
            <el-input
              size="mini"
              v-model="row.wnd_size[3]"
              :disabled="row.disabled"
            ></el-input>
            <!--            <span>{{row.wnd_size[3]}}</span>-->
          </template>
        </el-table-column>
        <el-table-column
          :label="$t('user.actionBar')"
          align="center"
          width="200px"
        >
          <template slot-scope="{ row, $index }">
            <el-button
              v-if="row.disabled"
              size="mini"
              type="primary"
              @click="inClipEdit(row, $index)"
              >{{ $t("res.edit") }}</el-button
            >
            <el-button
              v-else
              size="mini"
              type="success"
              @click="inClip(row, $index)"
              >{{ $t("home.enter") }}</el-button
            >
            <el-button
              v-if="row.disabled"
              size="mini"
              type="danger"
              @click="inClipDel(row, $index)"
              >{{ $t("home.delete") }}</el-button
            >
            <el-button
              v-else
              size="mini"
              type="info"
              @click="inClipCancel(row, $index)"
              >{{ $t("home.cancel") }}</el-button
            >
          </template>
        </el-table-column>
      </el-table>
    </el-dialog>
  </div>
</template>

<script>
// 点阵取模
import CapTion from "@/components/CapTion";
import {
  CardListApi,
  CardDetailApi,
  SendInOutSeatApi,
  SyncSceneApi,
  scene_saveApi,
  getScenceDataApi,
  scene_callApi,
  scene_delApi,
  scene_rotateApi,
  scene_rotate_argsApi,
  scene_pollingApi,
  edidChooseApi,
  edidLearnInApi,
  set_insubcardApi,
  TerminalApi,
  verApi
} from "@/api/home";
import {
  poeControlApi,
  inAudioChooseApi,
  edidInitApi,
  updateEdidApi,
  inSubtitleApi,
  incardRenameApi,
  inSubtitleArgsApi,
  InCardResInfoApi,
  subCardDefaultApi,
  infoReportConfigApi,
  inSubtitleTransApi,
  argsFontApi,
  sendData
} from "@/api/InCard";
import {
  rgbOrRgbaToArray,
  in_audio_choose,
  edid_choose,
  rename_incard,
  in_subtitle,
  in_sub_disp,
  edid_init,
  debounce, // 防抖
  CLEAR_SUB,
  set_insubcard,
  set_poe
} from "@/utils";
import { websocketsend } from "@/utils/ws";
import i18n from "@/lang";

export default {
  name: "OutCard",
  components: {
    CapTion
  },
  props: {
    ch: {
      type: Number,
      default: 0
    }, // 端口ID
    card_type: Number,
    ch_index: Number, // 卡ID
    type: Number,
    handleCh: Object
  },
  computed: {
    sortoutputList() {
      return this.sortByKey(this.outputList, "ch"); //将studet数组中的数据按照年龄进行排序
    }
  },
  data() {
    return {
      ch_indexCopy: "",
      // xy是否符合
      isXY: false,
      // 输入输出卡映射关系表
      CardINOUTList: {
        1: "1_0",
        2: "1_1",
        3: "2_0",
        4: "2_1",
        5: "3_0",
        6: "3_1",
        7: "4_0",
        8: "4_1",
        9: "5_0",
        10: "5_1",
        11: "6_0",
        12: "6_1",
        13: "7_0",
        14: "7_1",
        15: "8_0",
        16: "8_1",
        17: "9_0",
        18: "9_1",
        19: "10_0",
        20: "10_1",
        21: "11_0",
        22: "11_1",
        23: "12_0",
        24: "12_1",
        25: "13_0",
        26: "13_1",
        27: "14_0",
        28: "14_1",
        29: "15_0",
        30: "15_1",
        31: "16_0",
        32: "16_1",
        33: "17_0",
        34: "17_1",
        35: "18_0",
        36: "18_1",
        37: "19_0",
        38: "19_1",
        39: "20_0",
        40: "20_1",
        41: "21_0",
        42: "21_1",
        43: "22_0",
        44: "22_1",
        45: "23_0",
        46: "23_1",
        47: "24_0",
        48: "24_1",
        49: "25_0",
        50: "25_1",
        51: "26_0",
        52: "26_1",
        53: "27_0",
        54: "27_1",
        55: "28_0",
        56: "28_1",
        57: "29_0",
        58: "29_1",
        59: "30_0",
        60: "30_1",
        61: "31_0",
        62: "31_1",
        63: "32_0",
        64: "32_1"
      },
      // 卡板类型名字
      NameList: {
        1: "HDMI",
        4: "VGA",
        23: "DP4K",
        17: "HDMI4K",
        24: "HDMI4K60_",
        10: "HDMI",
        11: "DVI_VS",
        58: "HDMI",
        59: "DVI",
        49: "HDMI",
        100: "HDMI",
        101: "HDMI",
        102: "HDMI",
        3: "CVBS",
        51: "HDBT",
        2: "DVI",
        50: "DVI",
        81: "HDMI4_",
        82: "DVI4_",
        6: "SDI",
        53: "SDI"
      },
      // 输入卡还是输出卡
      InOutType: {
        1: "输入卡",
        2: "输入卡",
        5: "输入卡",
        6: "输入卡",
        11: "输入卡",
        58: "输出卡",
        59: "输出卡",
        49: "输出卡",
        // 100:'HDMI',
        // 101:'HDMI',
        // 102:'HDMI',
        3: "输入卡",
        4: "输入卡",
        23: "输入卡",
        17: "输入卡",
        24: "输入卡",
        51: "输出卡",
        50: "输出卡",
        53: "输出卡",
        81: "输出卡",
        82: "输出卡"
      },
      uploadName: "",
      fileList: [], // 上传文件列表EDID
      cardTAGList: [],
      outputList: [], // 输出卡列表
      portData: [],
      form: {
        audio: 0,
        set_insubcard: "",
        edid_index: "", // EDID   发送时：  前五个 abcde 后五个是输出卡ch   接受时： 大于17的为ASCII码 97:a 98:b 99:c 100:d 101:e
        EDIDfile: null, // 自定义EDID文件
        en: 0, // 0关闭 1打开
        rename: "",
        ver_hw: "", // 硬件版本
        ver_sw: "", // 软件版本
        ver_fpga: "", // FPGA版本
        H: 0,
        W: 0,
        POE: 0
      },
      dialog: {
        font: {
          visible: false,
          form: {
            content: "",
            family: "宋体",
            fontsize: 72,
            result: [],

            X: 0,
            Y: 0,
            bc_transparent: 0, // 0不透明 1透明
            Fc: "rgb(255,255,255)",
            Bc: "rgb(0,89,255)",
            H: 0,
            W: 0
          }
        },
        fontDisPlay: {
          visible: false,
          form: {
            X: 0,
            Y: 0,
            bc_transparent: 1, // 0不透明 1透明
            Fc: null,
            Bc: null,
            H: 0,
            W: 0
          }
        },
        clip: {
          visible: false,
          table: [
            { sytle: 1, wnd_size: [0, 0, 0, 0], disabled: true },
            { sytle: 2, wnd_size: [0, 0, 0, 0], disabled: true },
            { sytle: 3, wnd_size: [0, 0, 0, 0], disabled: true },
            { sytle: 4, wnd_size: [0, 0, 0, 0], disabled: true }
          ]
        }
      }
    };
  },
  mounted() {
    let _this = this;
    console.log(this.card_type, "this.card_type");
    console.log(this.type, "this.type");
    console.log(this.ch, "this.ch");
    console.log(this.ch_index, "this.ch_index");
    console.log(this.handleCh, "this.handleCh");
    this.ch_indexCopy = this.ch_index;
    // 设置EDID上传文件的名字
    this.uploadName = "upload" + this.ch;
    // const loading = this.$loading({
    //   lock: true,
    //   text: '正在获取数据...',
    //   spinner: 'el-icon-loading',
    //   background: 'rgba(0, 0, 0, 0.7)'
    // })
    /*获取板卡分辨率*/
    this.getResInfo();
    /* 获取板卡列表标识符*/
    // CardListApi({cmd: 'LinkInfo'}).then(res => {
    //   this.cardTAGList = res.link_status.filter(item => item.type && 1)
    // }).then(() => {
    //   this.cardTAGList.forEach(item => {
    //     CardDetailApi({cmd: 'CardInfo', cardIndex: item.ch}).then(i => {
    //       // sdi输出卡不作为学习通道
    //       if (i.list.card_type === 49 || i.list.card_type === 51 || i.list.card_type === 50 || i.list.card_type === 100 || i.list.card_type === 102) { // 输出卡
    //
    //         if (i.list.port) {
    //           // 找到通道提升之后的值   例如 8 -》 15
    //           let portAs
    //           let portBs
    //           for (let j in this.CardINOUTList){
    //             if (this.CardINOUTList[j]===`${i.list.ch}_0`){
    //               portAs=j
    //             }
    //             if (this.CardINOUTList[j]===`${i.list.ch}_1`){
    //               portBs=j
    //             }
    //           }
    //           console.log('portAs:',portAs)
    //           console.log('portBs:',portBs)
    //           let port = i.list.port
    //           let portA ={...port[0],index_s:parseInt(portAs)}
    //           let portB = {...port[1],index_s:parseInt(portBs)}
    //           this.outputList.push(portA)
    //           this.outputList.push(portB)
    //         } else {
    //           let portAs
    //           for (let j in this.CardINOUTList){
    //             if (this.CardINOUTList[j]===`${i.list.ch}_0`){
    //               portAs=j
    //             }
    //           }
    //           this.outputList.push({...i.list,index_s:parseInt(portAs)})
    //         }
    //
    //       }
    //     })
    //   })
    //   console.log(this.outputList, 'this.outputList值')
    // }).catch(err => {
    //   this.$message.error('获取板卡列表失败')
    // })
    // 获取板卡详情
    this.getList();

    if (localStorage.getItem("verData")) {
      const res = JSON.parse(localStorage.getItem("verData"));
      const chItem = res.incard.filter(
        item => item.ch === parseInt(this.ch_index)
      );
      const { fpga, hw, mcu } = chItem[0];
      this.form.ver_sw = mcu;
      this.form.ver_hw = hw;
      this.form.ver_fpga = fpga;
    } else {
      verApi().then(res => {
        localStorage.setItem("verData", JSON.stringify(res));
        const chItem = res.incard.filter(
          item => item.ch === parseInt(this.ch_index)
        );
        const { fpga, hw, mcu } = chItem[0];
        this.form.ver_sw = mcu;
        this.form.ver_hw = hw;
        this.form.ver_fpga = fpga;
      });
    }

    // this.socketApi.sendSock({}, data => {
    //   console.log("websocket接收到的数据InCard", data);
    //   this.$parent.setCard(data, this.ch);
    //   // 输入卡的音频源切换指令同步
    //   if (data.Cmd === "in_audio_choose") {
    //     let JsonData = in_audio_choose(data.data); // 解析指令
    //     // console.log(JsonData,'JsonData')
    //     // console.log(parseInt(this.ch_index.split('_')[1]),'parseInt(this.ch_index.split(\'_\')[1])')
    //     // console.log(JsonData.in.split('-')[1]==='a'?0:1,'端口')
    //     let ch_port = parseInt(this.ch_index.split("_")[1]);
    //     let JsonDataInPort = JsonData.in.split("-")[1] === "a" ? 0 : 1;
    //     console.log(JsonData.in, "JsonData.in");
    //     console.log(parseInt(JsonData.in), "parseInt(JsonData.in)");
    //     console.log(this.ch, "this.ch");
    //     // if (parseInt(JsonData.in)===this.ch&&ch_port===JsonDataInPort){
    //     if (parseInt(JsonData.in) === this.ch) {
    //       // console.log('执行了')
    //       this.form.audio = parseInt(JsonData.choose);
    //     }
    //   }
    //   // 输入卡EDID指令同步 前六个
    //   if (data.Cmd === "edid_choose") {
    //     let JsonData = edid_choose(data.data);
    //     if (parseInt(JsonData.in) === this.ch) {
    //       if (JsonData.type === "choose") {
    //         this.form.edid_index = parseInt(JsonData.choose) + 96;
    //       }
    //     }
    //   }
    //   //输入卡EDID指令同步 后六个
    //   if (data.Cmd === "edid_learn") {
    //     let JsonData = edid_choose(data.data);
    //     if (parseInt(JsonData.in) === this.ch) {
    //       if (JsonData.type === "learn") {
    //         this.form.edid_index = parseInt(JsonData.choose);
    //         // this.form.edid_index = parseInt(this.CardINOUTList[parseInt(JsonData.choose)].split('_')[0])
    //       }
    //     }
    //   }
    //   // 输入卡命名同步
    //   if (data.Cmd === "rename_incard") {
    //     let JsonData = rename_incard(data.data);
    //     if (parseInt(JsonData.in) === this.ch) {
    //       console.log("ws命名同步执行到了");
    //       this.form.rename = JsonData.name;
    //     }
    //   }
    //   // 字幕开关
    //   if (data.Cmd === "in_subtitle") {
    //     let JsonData = in_subtitle(data.data);
    //     if (parseInt(JsonData.in) === this.ch) {
    //       this.form.en = parseInt(JsonData.mode);
    //     }
    //   }
    //   // 字幕开关
    //   if (data.Cmd === "in_sub_disp") {
    //     let JsonData = in_sub_disp(data.data);
    //     if (parseInt(JsonData.in) === this.ch) {
    //       this.form.en = parseInt(JsonData.mode);
    //     }
    //   }
    //   // 默认EDID同步 edid_init
    //   if (data.Cmd === "edid_init") {
    //     let JsonData = edid_init(data.data);
    //     if (parseInt(JsonData.in) === this.ch) {
    //       this.form.edid_index = 97;
    //     }
    //   }
    //   // 检测分辨率
    //   // 拔卡   或者输出卡信号插拔
    //   if (data.status_refresh) {
    //     data.status_refresh.list.forEach(i => {
    //       const ch = Number(i.ch);
    //       if (ch === _this.ch) {
    //         if (i.res_h && i.res_v) {
    //           _this.form.H = i.res_h;
    //           _this.form.W = i.res_v;
    //         }
    //       }
    //     });
    //   }
    //   // 插卡
    //   if (data.Cmd === "list") {
    //     const ch = Number(data.list.ch);
    //     if (data.list.card_type == 1) {
    //       // 输入卡
    //       if (ch === _this.ch) {
    //         if (data.res_h && data.res_v) {
    //           _this.form.H = data.res_h;
    //           _this.form.W = data.res_v;
    //         }
    //       }
    //     }
    //   }
    //   // 单卡恢复默认指令同步
    //   if (data.Cmd === "CLEAR_SUB") {
    //     let JsonData = CLEAR_SUB(data.data);
    //     if (parseInt(JsonData.in) === this.ch) {
    //       _this.getResInfo();
    //       _this.getList();
    //     }
    //   }
    //   // 解析DIV输入卡切换输入格式同步指令
    //   if (data.Cmd === "set_insubcard") {
    //     let JsonData = set_insubcard(data.data);
    //     if (parseInt(JsonData.in) === this.ch) {
    //       _this.form.set_insubcard = parseInt(JsonData.step);
    //     }
    //   }
    //   // 解析POE开关控制指令  form.POE
    //   if (data.Cmd === "set_poe") {
    //     let JsonData = set_poe(data.data);
    //     if (parseInt(JsonData.in) === this.ch) {
    //       _this.form.POE = parseInt(JsonData.poe);
    //     }
    //   }
    // });
  },
  methods: {
    // clip dialog关闭之后
    dialogClipClose(done) {
      this.dialog.clip.table.forEach(item => (item.disabled = true));
      const inList = JSON.parse(localStorage.getItem("incardListData"));
      inList.forEach(item => {
        if (item.cID === this.ch) {
          if (item.clip) {
            item.clip.forEach(i => {
              this.dialog.clip.table.forEach(j => {
                if (i.sytle === j.sytle) {
                  j.wnd_size = i.wnd_size;
                }
              });
            });
          }
        }
      });
      done();
    },
    inClipDialog() {
      if (this.form.H && this.form.W) {
        this.dialog.clip.visible = true;
      } else {
        this.$message.error(i18n.t("set.NoSignal"));
      }
    },
    // 剪裁方案
    inClip(row, index) {
      console.log(index, "index");
      console.log(row.sytle, "row.sytle");
      const [x, y, w, h] = row.wnd_size.map(i => parseInt(`${i}`));
      console.log(x, "x");
      console.log(y, "y");
      console.log(w, "w");
      console.log(h, "h");
      console.log(this.form.W, "this.form.W");
      console.log(this.form.H, "this.form.H");
      if (x + w > this.form.H || y + h > this.form.W) {
        this.$message.error(i18n.t("set.crossBorder"));
      } else {
        sendData(
          `(in,clip,${this.ch},${row.sytle},${x},${y},${w},${h})\r\n`,
          false,
          500
        );
        row.disabled = true;
      }
      // this.form.H;
      // this.form.W;
      // inClipApi({
      //   cmd:'inClip',
      //   Vsrc_CH:this.ch,
      //   port_index: 0,
      //   style:index+1,
      //   x:parseInt(row.wnd_size[0]),
      //   y:parseInt(row.wnd_size[1]),
      //   w:parseInt(row.wnd_size[2]),
      //   h:parseInt(row.wnd_size[3])
      // }).then(res=>{
      //   row.sytle=parseInt(index+1)
      //   row.disabled=true
      // })
    },
    inClipDel(row, index) {
      sendData(`(in,dcut,${this.ch},${row.sytle})\r\n`, false, 500);
      row.disabled = true;
      row.wnd_size = [0, 0, 0, 0];
      const inList = JSON.parse(localStorage.getItem("incardListData"));
      inList.forEach(item => {
        if (item.cID === this.ch) {
          if (item.clip) {
            item.clip.forEach(i => {
              if (i.sytle === row.sytle) {
                i.wnd_size = [0, 0, 0, 0];
              }
            });
          }
        }
      });
      localStorage.setItem("incardListData", JSON.stringify(inList));
    },
    inClipCancel(row, index) {
      row.disabled = true;
    },
    inClipEdit(row, index) {
      const [x, y, w, h] = row.wnd_size.map(i => parseInt(`${i}`));
      row.wnd_size = [x, y, w ? w : this.form.H, h ? h : this.form.W];
      row.disabled = false;
    },
    portChang(val) {
      console.log(val, "选择的端口");
      let type =
        this.portData[parseInt(val.split("_")[1])].port_type === 1
          ? "in"
          : "out";
      this.$parent.sendCompoentItem(
        this.handleCh,
        type,
        parseInt(val.split("_")[1])
      );
    },
    // 判断XY是否超出屏幕
    isXYHandle(obj) {
      const _this = this;
      console.log(obj, "图片obj");
      console.log(obj.imgData, "图片像素数据");
      console.log(obj.imgData.byteLength / 4, "图片像素个数");

      if (_this.form.H && _this.form.W) {
        let maX = _this.form.H - obj.width;
        let maY = _this.form.W - obj.height;

        if (_this.dialog.font.form.X >= 0) {
          if (
            _this.dialog.font.form.X > maX &&
            _this.dialog.font.form.X !== 0
          ) {
            _this.$message.error(`${i18n.t("set.maxX")}${maX}`);
            _this.dialog.font.form.X = maX;
            _this.isXY = false;
          } else {
            _this.isXY = true;
          }
        } else {
          _this.dialog.font.form.X = 0;
        }

        if (_this.dialog.font.form.Y >= 0) {
          if (
            _this.dialog.font.form.Y > maY &&
            _this.dialog.font.form.Y !== 0
          ) {
            _this.$message.error(`${i18n.t("set.maxY")}${maY}`);
            _this.dialog.font.form.Y = maY;
            _this.isXY = false;
          } else {
            _this.isXY = true;
          }
        } else {
          _this.dialog.font.form.Y = 0;
        }
      } else {
        _this.dialog.font.form.X = 0;
        _this.dialog.font.form.Y = 0;
        _this.isXY = true;
      }

      this.sendFont({
        data: obj.imgData,
        width: obj.width,
        height: obj.height
      });
    },
    sendFont(data) {
      const _this = this;
      let a = "";
      let b = "";
      for (let i = 0; i < data.data.length; i += 4) {
        if (data.data[i] > 127) {
          a += "1";
        } else {
          a += "0";
        }
      }
      console.log(a, "a");
      if (a.length > 65536) {
        this.$message.error(i18n.t("set.TheTotalData"));
        return false;
      }
      const loading = this.$loading({
        lock: true,
        text: "正在设置...",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      for (let j = 0; j < a.length; j += 8) {
        let ite = a.substr(j, 8);
        b += parseInt(ite, 2) + ",";
      }

      let bArray = b.split(",");
      let cArray = bArray.slice(0, bArray.length - 1).map(i => {
        if (parseInt(i).toString(16) === "0") {
          return "00";
        } else {
          return parseInt(i).toString(16);
        }
      });

      inSubtitleApi({
        cmd: "inSubtitle",
        ch: _this.ch,
        port_index: parseInt(this.ch_index),
        en: 0
      }).then(res => {
        infoReportConfigApi({ cmd: "infoReportConfig", en: 0 }).then(res => {
          inSubtitleTransApi({
            cmd: "inSubtitleTrans",
            ch: _this.ch,
            packsize: cArray.length,
            pic_w: data.width,
            pic_h: data.height,
            data: cArray
          }).then(res => {
            // websocketsend(
            //   `(in,subtitle,trans,${_this.ch},0,0)\r\n`,
            //   res => {},
            //   false
            // );
            argsFontApi({
              cmd: "argsFont",
              ch: _this.ch,
              FontAttri: {
                Blod: _this.dialog.font.form.result.includes("Blod") ? 1 : 0,
                Italic: _this.dialog.font.form.result.includes("Italic")
                  ? 1
                  : 0,
                Strickout: _this.dialog.font.form.result.includes("Strickout")
                  ? 1
                  : 0,
                Underline: _this.dialog.font.form.result.includes("Underline")
                  ? 1
                  : 0
              },
              Size: _this.dialog.font.form.fontsize,
              Text: _this.dialog.font.form.content,
              FontName: _this.dialog.font.form.family
            }).then(res => {
              inSubtitleArgsApi({
                cmd: "inSubtitleArgs",
                ch: _this.ch,
                bc_transparent: _this.dialog.font.form.bc_transparent,
                Flag: "",
                Fc: rgbOrRgbaToArray(_this.dialog.font.form.Fc),
                Bc: rgbOrRgbaToArray(_this.dialog.font.form.Bc),
                X:
                  _this.dialog.font.form.X % 2 === 0
                    ? _this.dialog.font.form.X
                    : _this.dialog.font.form.X + 1, // const ox = val % 2 === 0 ? val : val + 1;
                Y: _this.dialog.font.form.Y,
                W: data.width,
                H: data.height
              }).then(res => {
                inSubtitleApi({
                  cmd: "inSubtitle",
                  ch: _this.ch,
                  port_index: parseInt(this.ch_index),
                  en: 1
                }).then(res => {
                  infoReportConfigApi({ cmd: "infoReportConfig", en: 1 }).then(
                    () => {
                      loading.close();
                      _this.$message.success(i18n.t("set.fontDataSuccess"));

                      _this.form.en = 1;
                      // 修改本地存储的输入卡列表信息
                      const incardListData = JSON.parse(
                        localStorage.getItem("incardListData")
                      );
                      incardListData.forEach(item => {
                        if (item.cID === _this.ch) {
                          item["subTitleInfo"] = {
                            Agrs: {
                              bg_rgb: rgbOrRgbaToArray(
                                _this.dialog.font.form.Bc
                              ),
                              text_rgb: rgbOrRgbaToArray(
                                _this.dialog.font.form.Fc
                              ),
                              transparent:
                                _this.dialog.font.form.bc_transparent,
                              visible: 1,
                              x:
                                _this.dialog.font.form.X % 2 === 0
                                  ? _this.dialog.font.form.X
                                  : _this.dialog.font.form.X + 1,
                              y: _this.dialog.font.form.Y,
                              w: data.width,
                              h: data.height
                            },
                            body: _this.dialog.font.form.content,
                            font: {
                              B: _this.dialog.font.form.result.includes("Blod")
                                ? 1
                                : 0,
                              I: _this.dialog.font.form.result.includes(
                                "Italic"
                              )
                                ? 1
                                : 0,
                              S: _this.dialog.font.form.result.includes(
                                "Strickout"
                              )
                                ? 1
                                : 0,
                              U: _this.dialog.font.form.result.includes(
                                "Underline"
                              )
                                ? 1
                                : 0,
                              name: _this.dialog.font.form.family,
                              size: _this.dialog.font.form.fontsize
                            }
                          };
                        }
                      });
                      localStorage.setItem(
                        "incardListData",
                        JSON.stringify(incardListData)
                      );
                    }
                  );
                });
              });
            });
          });
        });
      });
    },
    // 获取分辨率
    getResInfo() {
      InCardResInfoApi({
        // 获取分辨率
        cmd: "InCardResInfo",
        port_index: parseInt(this.ch_index), // 卡ID
        ch: this.ch // 端口ID
      })
        .then(res => {
          this.form.H = res.h;
          this.form.W = res.v;
        })
        .catch(err => {
          this.$message.error(i18n.t("set.QueryFailed"));
        });
    },
    // 获取板卡详情
    getList() {
      const inList = JSON.parse(localStorage.getItem("incardListData"));
      inList.forEach(item => {
        if (item.cID === this.ch) {
          this.form.rename = item.name
            ? item.name
            : `${this.NameList[item.type] + item.cID}`;
          if (item.subTitleInfo) {
            const { Agrs, body, font } = item.subTitleInfo;
            const { bg_rgb, h, text_rgb, transparent, visible, w, x, y } = Agrs;
            const { name, size, B, I, S, U } = font;
            this.form.en = visible;
            this.dialog.font.form.fontsize = size;
            this.dialog.font.form.family = name;
            this.dialog.font.form.content = body;
            this.dialog.font.form.bc_transparent = transparent;
            this.dialog.font.form.X = x;
            this.dialog.font.form.Y = y;
            this.dialog.font.form.Fc = `rgb(${text_rgb.join(",")})`;
            this.dialog.font.form.Bc = `rgb(${bg_rgb.join(",")})`;
            B ? this.dialog.font.form.result.push("Blod") : "";
            I ? this.dialog.font.form.result.push("Italic") : "";
            S ? this.dialog.font.form.result.push("Strickout") : "";
            U ? this.dialog.font.form.result.push("Underline") : "";
          }

          if (item.clip) {
            item.clip.forEach(i => {
              this.dialog.clip.table.forEach(j => {
                if (i.sytle === j.sytle) {
                  j.wnd_size = i.wnd_size;
                }
              });
            });
          }
        }
      });
      // 获取当前输入卡的板卡详情
      // CardDetailApi({
      //   cmd: "CardInfo",
      //   cardIndex: Number(this.ch),
      //   port_index: parseInt(this.ch_index),
      //   type: Number(this.type)
      // })
      //   .then(res => {
      //     console.log(Number(this.ch), "当前输入卡板卡ID");
      //     console.log(res, "当前输入卡板卡详情");
      //     let data;
      //     if (res.list.port) {
      //       // 双通道的卡
      //       data = res.list.port[parseInt(this.ch_index.split("_")[1])];
      //       this.portData = [...res.list.port];
      //     } else {
      //       // 单通道的卡
      //       data = res.list;
      //       this.portData = [res.list];
      //     }
      //     const subtitle_info = data.subtitle_info;
      //     // if(data.card_type===1||data.card_type===3){ // HDMI  CVBS
      //     //   this.form.rename = data.rename ? data.rename : `${this.NameList[data.card_type]+data.ch}`
      //     // }
      //
      //     this.form.ver_sw = data.ver_sw;
      //     this.form.ver_hw = data.ver_hw;
      //     this.form.ver_fpga = data.ver_fpga;
      //
      //     this.form.rename = data.rename
      //       ? data.rename
      //       : `${this.NameList[data.card_type] + data.ch}`;
      //     this.form.en = subtitle_info.agrs.visible;
      //     this.form.audio = data.audio;
      //     this.form.set_insubcard = data.dvi_singal_format || "";
      //     this.form.edid_index = data.edid_index;
      //
      //     this.form.POE = data.poe;
      //     // 字幕参数回显
      //     /*
      //     * "subtitle_info":	{
      //     "text":	"你好呀41221",
      //     "font":	{
      //       "name":	"宋体",
      //       "name_index":	1,
      //       "size":	72,
      //       "B":	1,
      //       "I":	0,
      //       "S":	0,
      //       "U":	0
      //     },
      //     "agrs":	{
      //       "visible":	1,
      //       "transparent":	0,
      //       "x":	0,
      //       "y":	0,
      //       "w":	576,
      //       "h":	72,
      //       "text_rgb":	[255, 255, 255],
      //       "bg_rgb":	[0, 0, 0]
      //     }
      //   }
      //     * */
      //     this.dialog.font.form.family = subtitle_info.font.name
      //       ? subtitle_info.font.name
      //       : "楷体";
      //     this.dialog.font.form.fontsize = subtitle_info.font.size
      //       ? subtitle_info.font.size
      //       : 36;
      //     let { B, I, S, U } = subtitle_info.font;
      //     this.dialog.font.form.result = [
      //       B ? "Blod" : null,
      //       I ? "Italic" : null,
      //       S ? "Strickout" : null,
      //       U ? "Underline" : null
      //     ].filter(item => item);
      //     this.dialog.font.form.content = subtitle_info.text
      //       ? subtitle_info.text
      //       : data.rename
      //       ? data.rename
      //       : `${this.NameList[data.card_type] + data.ch}`;
      //     this.dialog.font.form.bc_transparent = subtitle_info.agrs.transparent;
      //     this.dialog.font.form.X = subtitle_info.agrs.x;
      //     this.dialog.font.form.Y = subtitle_info.agrs.y;
      //     let { text_rgb, bg_rgb } = subtitle_info.agrs;
      //     this.dialog.font.form.Fc = `rgb(${text_rgb[0]},${text_rgb[1]},${
      //       text_rgb[2]
      //     })`;
      //     this.dialog.font.form.Bc = `rgb(${bg_rgb[0]},${bg_rgb[1]},${
      //       bg_rgb[2]
      //     })`;
      //     console.log(
      //       this.dialog.font.form.result,
      //       "this.dialog.font.form.result"
      //     );
      //   })
      //   .then(_ => {
      //     // let a=setTimeout(function() {
      //     //   loading.close()
      //     //   clearTimeout(a)
      //     // },1000)
      //     // loading.close()
      //   })
      //   .catch(err => {
      //     // this.$message.error('获取输入卡详情失败')
      //     // loading.close()
      //   });
    },
    sortByKey(array, key) {
      return array.sort(function(a, b) {
        var x = a[key];
        var y = b[key];
        return x < y ? -1 : x > y ? 1 : 0;
      });
    },
    // 输入音频选择事件
    inAudioChooseChange(val) {
      inAudioChooseApi({
        cmd: "inAudioChoose",
        ch: this.ch,
        port_index: parseInt(this.ch_index),
        type: val
      })
        .then(res => {
          this.$message.success(i18n.t("set.InputSuccessfully"));
        })
        .catch(err => {
          this.$message.error(i18n.t("set.InputFailed"));
        });
    },
    // 切换输入格式
    set_insubcardChange(val) {
      set_insubcardApi({
        cmd: "set_insubcard",
        ch: this.ch,
        sta: val
      }).then(res => {
        this.$message.success(i18n.t("set.SuccessModified"));
      });
    },
    // EDID选择事件
    edid_indexChange(val) {
      console.log(val);
      if (val > 96) {
        // 选择的前五个
        edidChooseApi({
          cmd: "edidChoose",
          ch_in: this.ch,
          port_index: parseInt(this.ch_index),
          index: val - 96
        })
          .then(res => {
            this.$message.success(i18n.t("set.SuccessModified"));
          })
          .catch(err => {
            this.$message.error(i18n.t("set.EDIDFailed"));
          });
      } else {
        // 选择的是后五个(输出卡)
        edidLearnInApi({
          cmd: "edidLearnIn",
          ch_in: this.ch,
          port_index: parseInt(this.CardINOUTList[val].split("_")[1]),
          ch_out: parseInt(this.CardINOUTList[val].split("_")[0])
        })
          .then(res => {
            this.$message.success(i18n.t("set.SuccessModified"));
          })
          .catch(err => {
            this.$message.error(i18n.t("set.EDIDFailed"));
          });
      }
    },
    // EDID恢复默认事件
    edidInitHandle() {
      edidInitApi({
        cmd: "edidInit",
        port_index: parseInt(this.ch_index),
        ch: this.ch
      })
        .then(res => {
          this.form.edid_index = 97;
          this.$message.success(i18n.t("set.EDIDInitSuccessfully"));
        })
        .catch(err => {
          this.$message.error(i18n.t("set.EDIDInitFailed"));
        });
    },
    // 覆盖上传行为
    httpRequest() {
      const _this = this;
      console.log(this.form.EDIDfile, "this.form.EDIDfile");
      const r = new FileReader();
      r.readAsArrayBuffer(this.form.EDIDfile);
      r.onload = function() {
        console.log(r.result, "r.result");
        async function main() {
          await sendData(`(in,echg,${_this.ch})\r\n`, false, 500);
          await sendData(r.result, true, 200);
        }
        main().then(() => {
          _this.$message.success(i18n.t("set.UploadedSuccessfully"));
        });
      };
      // const formData = new FormData();
      // formData.append("EDID", this.form.EDIDfile);
      // updateEdidApi(formData, this.ch)
      //   .then(res => {
      //     this.$message.success(i18n.t("set.UploadedSuccessfully"));
      //   })
      //   .catch(err => {
      //     this.$message.error(i18n.t("set.EDIDUploadFailed"));
      //   });
    },
    submitUpload() {
      if (!this.fileList.length) {
        this.$message.info(i18n.t("set.selectEDID"));
        return false;
      }
      this.$refs[this.uploadName].submit();
    },
    handleRemove(file, fileList) {
      console.log(file, fileList);
    },
    uploadExceed(files, fileList) {
      this.$set(fileList[0], "raw", files[0]);
      this.$set(fileList[0], "name", files[0].name);
      this.$refs[this.uploadName].clearFiles(); //清除文件
      this.$refs[this.uploadName].handleStart(files[0]); //选择文件后的赋值方法
      console.log(this.fileList);
    },
    handleChange(file, fileList) {
      console.log(file.raw, "file.raw文件");
      this.fileList = [];
      this.fileList.push(file);
      this.form.EDIDfile = file.raw;
    },
    handlePreview(file) {
      console.log(file);
    },
    // 点击字幕详细设置按钮
    fontDialog() {
      if (!this.dialog.font.form.content) {
        this.dialog.font.form.content = this.form.rename;
      }
      this.dialog.font.visible = true;
    },
    // 点击字幕显示设置按钮
    fontDisPlayDialog() {
      InCardResInfoApi({
        // 获取分辨率
        cmd: "InCardResInfo",
        port_index: parseInt(this.ch_index),
        ch: this.ch
      })
        .then(res => {
          this.dialog.fontDisPlay.form.H = res.h;
          this.dialog.fontDisPlay.form.W = res.v;
          this.dialog.fontDisPlay.visible = true;
        })
        .catch(err => {
          this.$message.error(i18n.t("set.QueryFailed"));
        });
    },
    // 字幕开关事件
    inSubtitleChange(val) {
      const _this = this;

      const incardListData = JSON.parse(localStorage.getItem("incardListData"));
      incardListData.forEach(item => {
        if (item.cID === _this.ch) {
          if (item.subTitleInfo) {
            item.subTitleInfo.Agrs.visible = val;
            inSubtitleApi({
              cmd: "inSubtitle",
              ch: _this.ch,
              port_index: parseInt(_this.ch_index),
              en: val
            })
              .then(res => {
                _this.$message.success(i18n.t("set.SwitchSuccessfully"));
              })
              .catch(err => {
                _this.$message.error(i18n.t("set.SubtitleSwitchFailed"));
                _this.form.en = 0;
              });
          } else {
            _this.$message.error(i18n.t("set.PleaseOSDFirst"));
            _this.form.en = 0;
          }
        }
      });
      localStorage.setItem("incardListData", JSON.stringify(incardListData));
    },
    // 输入板卡重命名
    handleincardRenameEnter: debounce(
      function() {
        const _this = this;
        if (this.form.rename.length > 10) {
          this.$message.info(i18n.t("set.TheLengthName"));
          return false;
        }
        incardRenameApi({
          cmd: "incardRename",
          ch: this.ch,
          port_index: parseInt(this.ch_index),
          name: this.form.rename
        })
          .then(res => {
            this.$message.success(i18n.t("set.SuccessModified"));
            const incardListData = JSON.parse(
              localStorage.getItem("incardListData")
            );
            incardListData.forEach(item => {
              if (item.cID === _this.ch) {
                item.name = _this.form.rename;
              }
            });
            localStorage.setItem(
              "incardListData",
              JSON.stringify(incardListData)
            );
          })
          .catch(err => {
            this.$message.error(i18n.t("set.failEdit"));
          });
      },
      1000,
      false
    ),
    POEChang(val) {
      console.log(val, "POE选择的值");
      poeControlApi({
        cmd: "poeControl",
        ch: this.ch,
        sta: val
      }).then(res => {
        this.$message.success(i18n.t("set.ChooseSuccess"));
      });
    },
    // DIV升级
    DIVup() {
      TerminalApi({
        cmd: "Terminal",
        tans_msg: `(updata,MST182,in,${this.ch})`
      }).then(res => {
        console.log(res, "Terminal信息");
        if (res.msg === "ok") {
          this.$message.success(i18n.t("set.SuccessfulOperation"));
        }
        // console.log(`%c串口返回信息：`,'color: #43bb88;font-size: 24px;font-weight: bold;text-decoration: underline;')
        // console.log(`%c${JSON.stringify(res.tans_msg_ret)}`,'color: #43bb88;font-size: 24px;font-weight: bold;text-decoration: underline;')
      });
    },
    // 板卡恢复默认
    resetCard() {
      let _this = this;
      this.$confirm("此操作将恢复板卡至默认状态, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
        closeOnClickModal: false,
        beforeClose(action, instance, done) {
          if (action == "confirm") {
            instance.$refs["confirm"].$el.onclick = a();

            function a(e) {
              console.log(2);
              e = e || window.event;
              if (e.detail != 0) {
                done();
              }
            }
          } else {
            done();
          }
        }
      }).then(() => {
        subCardDefaultApi({
          cmd: "subCardDefault",
          Ch: _this.ch
        }).then(res => {
          _this.$message.success(i18n.t("set.RestoreSuccess"));
          // _this.getList()
        });
      });
    },
    // 输入卡字幕显示参数设置
    // inSubtitleArgsEnter() {
    //   inSubtitleArgsApi({
    //     cmd: 'inSubtitleArgs',
    //     ch: this.ch,
    //     bc_transparent: this.dialog.fontDisPlay.form.bc_transparent,
    //     Flag: '',
    //     Fc: rgbOrRgbaToArray(this.dialog.fontDisPlay.form.Fc),
    //     Bc: rgbOrRgbaToArray(this.dialog.fontDisPlay.form.Bc),
    //     X: this.dialog.fontDisPlay.form.X,
    //     Y: this.dialog.fontDisPlay.form.Y,
    //     W: '',
    //     H: ''
    //   }).then(res => {
    //     this.$message.success('设置成功')
    //     this.dialog.fontDisPlay.visible = false
    //   }).catch(err=>{
    //     this.$message.error('输入卡字幕显示参数设置失败')
    //   })
    // },
    // 预览字体
    handleFontPreview() {
      this.$refs.CapTion.fontCopy2();
    },
    // 提交字幕数据
    handleFontEnter() {
      this.$refs.CapTion.font3();
    }
  }
};
</script>
<style lang="scss" scoped>
.el-form >>> .el-form-item {
  margin-bottom: 10px;
}
.width200 {
  width: 8.375vw;
}

.upload-demo >>> .el-upload-list__item-name {
  color: #ffffff !important;
}

.upload-demo >>> .el-icon-document {
  color: #ffffff !important;
}

.upload-demo >>> .el-upload-list__item:hover {
  background-color: #000000;
}

.button_class {
  /*min-width: 200px;*/
}

.el-form >>> .el-form-item__label {
  color: #ffffff;
}

.el-form >>> .el-form-item__content {
  margin-right: 20px;
}

.el-dialog__wrapper >>> .el-dialog {
  background-color: #434343;

  .el-dialog__title {
    color: #ffffff;
  }

  .el-dialog__body {
    text-align: center;
  }
}

.el-switch >>> .el-switch__label {
  color: #ffffff;
}
</style>
<style>
.dialogFontVisible > .el-dialog--center {
  width: 765px !important;
}
</style>
