<template>
  <div>
    <div
      class="warp"
      :class="[
        notOverflowType.includes(MineType) ? 'warp_height' : 'warp_overflow'
      ]"
      style="margin-top: 25px;"
      :style="isIpadMac ? IpadMacStyle : ''"
    >
      <div class="left">
        <!--      <div class="leftTip">{{ $t("tip.PortTip") }}</div>-->
        <div class="left-content">
          <div>
            <div
              v-for="item of inCardList"
              :class="[
                'left-content-img-warp',
                handleCh == item ? 'active' : '',
                item.card_type == 777 ? 'd' : ''
              ]"
            >
              <img
                v-if="item.card_type == 1"
                src="~assets/facilityset/HDMI输入卡.png"
                :usemap="`#in${item.ch}`"
                :ref="`in${item.ch}`"
                :id="`in${item.ch}`"
                draggable="false"
                @dragstart.stop.prevent="imgfalse"
                class="left-content-img"
              />
              <img
                v-else-if="item.card_type == 3"
                src="~assets/facilityset/CVBS输入卡.png"
                :usemap="`#in${item.ch}`"
                :ref="`in${item.ch}`"
                :id="`in${item.ch}`"
                draggable="false"
                @dragstart.stop.prevent="imgfalse"
                class="left-content-img"
              />
              <img
                v-else-if="item.card_type == 4"
                src="~assets/facilityset/VGA输入卡.png"
                :usemap="`#in${item.ch}`"
                :ref="`in${item.ch}`"
                :id="`in${item.ch}`"
                draggable="false"
                @dragstart.stop.prevent="imgfalse"
                class="left-content-img"
              />
              <img
                v-else-if="item.card_type == 6"
                src="~assets/facilityset/SDI输入卡.png"
                :usemap="`#in${item.ch}`"
                :ref="`in${item.ch}`"
                :id="`in${item.ch}`"
                draggable="false"
                @dragstart.stop.prevent="imgfalse"
                class="left-content-img"
              />
              <img
                v-else-if="item.card_type == 23"
                src="~assets/facilityset/DP4K输入卡.png"
                :usemap="`#in${item.ch}`"
                :ref="`in${item.ch}`"
                :id="`in${item.ch}`"
                draggable="false"
                @dragstart.stop.prevent="imgfalse"
                class="left-content-img"
              />
              <img
                v-else-if="item.card_type == 17"
                src="~assets/facilityset/HDMI4K输入卡.png"
                :usemap="`#in${item.ch}`"
                :ref="`in${item.ch}`"
                :id="`in${item.ch}`"
                draggable="false"
                @dragstart.stop.prevent="imgfalse"
                class="left-content-img"
              />
              <img
                v-else-if="item.card_type == 24"
                src="~assets/facilityset/HDMI4K60输入卡.png"
                :usemap="`#in${item.ch}`"
                :ref="`in${item.ch}`"
                :id="`in${item.ch}`"
                draggable="false"
                @dragstart.stop.prevent="imgfalse"
                class="left-content-img"
              />
              <img
                v-else-if="item.card_type == 10"
                src="~assets/facilityset/HDMI输入卡.png"
                :usemap="`#in${item.ch}`"
                :ref="`in${item.ch}`"
                :id="`in${item.ch}`"
                draggable="false"
                @dragstart.stop.prevent="imgfalse"
                class="left-content-img"
              />
              <img
                v-else-if="item.card_type == 2"
                src="~assets/facilityset/DVI输入卡.png"
                :usemap="`#in${item.ch}`"
                :ref="`in${item.ch}`"
                :id="`in${item.ch}`"
                draggable="false"
                @dragstart.stop.prevent="imgfalse"
                class="left-content-img"
              />
              <img
                v-else-if="item.card_type == 11"
                src="~assets/facilityset/DVI输入卡.png"
                :usemap="`#in${item.ch}`"
                :ref="`in${item.ch}`"
                :id="`in${item.ch}`"
                draggable="false"
                @dragstart.stop.prevent="imgfalse"
                class="left-content-img"
              />
              <img
                v-else-if="item.card_type == 100"
                src="~assets/facilityset/HDMIIO卡.png"
                :usemap="`#in${item.ch}`"
                :ref="`in${item.ch}`"
                :id="`in${item.ch}`"
                draggable="false"
                @dragstart.stop.prevent="imgfalse"
                class="left-content-img"
              />
              <img
                v-else-if="item.card_type == 101"
                src="~assets/facilityset/2路HDMI输入卡.png"
                :usemap="`#in${item.ch}`"
                :ref="`in${item.ch}`"
                :id="`in${item.ch}`"
                draggable="false"
                @dragstart.stop.prevent="imgfalse"
                class="left-content-img"
              />
              <img
                v-else-if="item.card_type == 555"
                src="~assets/facilityset/控制卡.png"
                :usemap="`#in${item.ch}`"
                ref="kongzhika"
                :id="`in${item.ch}`"
                draggable="false"
                @dragstart.stop.prevent="imgfalse"
                class="left-content-img"
                @click="handleChEvent(item)"
              />
              <img
                v-else-if="item.card_type == 666"
                src="~assets/facilityset/板卡切图-1.png"
                :usemap="`#in${item.ch}`"
                :ref="`in${item.ch}`"
                :id="`in${item.ch}`"
                draggable="false"
                @dragstart.stop.prevent="imgfalse"
                class="left-content-img"
              />
              <img
                v-else-if="item.card_type == 777"
                src="~assets/facilityset/电源.png"
                :usemap="`#in${item.ch}`"
                :ref="`in${item.ch}`"
                :id="`in${item.ch}`"
                draggable="false"
                @dragstart.stop.prevent="imgfalse"
                class="left-content-img"
              />
              <img
                v-else-if="item.card_type == 5"
                src="~assets/facilityset/SDI输入卡.png"
                :usemap="`#in${item.ch}`"
                :ref="`in${item.ch}`"
                :id="`in${item.ch}`"
                draggable="false"
                @dragstart.stop.prevent="imgfalse"
                class="left-content-img"
              />
              <img
                v-else
                src="~assets/facilityset/板卡切图-1.png"
                :usemap="`#in${item.ch}`"
                :ref="`in${item.ch}`"
                :id="`in${item.ch}`"
                draggable="false"
                @dragstart.stop.prevent="imgfalse"
                class="left-content-img"
              />
              <map :name="`in${item.ch}`" v-if="item.arrayCID">
                <i
                  shape="rect"
                  :coords="item.rectArray[0]"
                  :style="{
                    left: `${item.rectArray[0].split(',')[0]}px`,
                    top: `${item.rectArray[0].split(',')[1]}px`
                  }"
                  @click="handleCard(item, item.arrayCID[0], 0)"
                />
                <i
                  shape="rect"
                  :coords="item.rectArray[1]"
                  :style="{
                    left: `${item.rectArray[1].split(',')[0]}px`,
                    top: `${item.rectArray[1].split(',')[1]}px`
                  }"
                  @click="handleCard(item, item.arrayCID[1], 0)"
                />
                <i
                  shape="rect"
                  v-if="item.rectArray[2]"
                  :coords="item.rectArray[2]"
                  :style="{
                    left: `${item.rectArray[2].split(',')[0]}px`,
                    top: `${item.rectArray[2].split(',')[1]}px`
                  }"
                  @click="handleCard(item, item.arrayCID[2], 0)"
                />
                <i
                  shape="rect"
                  v-if="item.rectArray[3]"
                  :coords="item.rectArray[3]"
                  :style="{
                    left: `${item.rectArray[3].split(',')[0]}px`,
                    top: `${item.rectArray[3].split(',')[1]}px`
                  }"
                  @click="handleCard(item, item.arrayCID[3], 0)"
                />
              </map>
              <!--            <a href="#">-->
              <!--              <img src="~assets/facilityset/HDMI输入卡.png" ismap="ismap" draggable="false" @dragstart.stop.prevent="imgfalse" class="left-content-img">-->
              <!--            </a>-->
            </div>
          </div>

          <div>
            <div
              v-for="item of outCardList"
              :class="[
                'left-content-img-warp',
                handleCh == item ? 'active' : '',
                item.card_type == 777 ? 'd' : ''
              ]"
            >
              <img
                v-if="item.card_type == 58"
                src="~assets/facilityset/HDMI输出卡.png"
                :usemap="`#out${item.ch}`"
                :ref="`out${item.ch}`"
                :id="`out${item.ch}`"
                draggable="false"
                @dragstart.stop.prevent="imgfalse"
                class="left-content-img"
              />
              <img
                v-else-if="item.card_type == 59"
                src="~assets/facilityset/DVI输出卡.png"
                :usemap="`#out${item.ch}`"
                :ref="`out${item.ch}`"
                :id="`out${item.ch}`"
                draggable="false"
                @dragstart.stop.prevent="imgfalse"
                class="left-content-img"
              />
              <img
                v-else-if="item.card_type == 49"
                src="~assets/facilityset/HDMI输出卡.png"
                :usemap="`#out${item.ch}`"
                :ref="`out${item.ch}`"
                :id="`out${item.ch}`"
                draggable="false"
                @dragstart.stop.prevent="imgfalse"
                class="left-content-img"
              />
              <img
                v-else-if="item.card_type == 81"
                src="~assets/facilityset/HDMI4图层输出卡.png"
                :usemap="`#out${item.ch}`"
                :ref="`out${item.ch}`"
                :id="`out${item.ch}`"
                draggable="false"
                @dragstart.stop.prevent="imgfalse"
                class="left-content-img"
              />
              <img
                v-else-if="item.card_type == 50"
                src="~assets/facilityset/DVI输出卡.png"
                :usemap="`#out${item.ch}`"
                :ref="`out${item.ch}`"
                :id="`out${item.ch}`"
                draggable="false"
                @dragstart.stop.prevent="imgfalse"
                class="left-content-img"
              />
              <img
                v-else-if="item.card_type == 82"
                src="~assets/facilityset/DVI4图层输出卡.png"
                :usemap="`#out${item.ch}`"
                :ref="`out${item.ch}`"
                :id="`out${item.ch}`"
                draggable="false"
                @dragstart.stop.prevent="imgfalse"
                class="left-content-img"
              />
              <img
                v-else-if="item.card_type == 51"
                src="~assets/facilityset/HDBaseT输出卡.png"
                :usemap="`#out${item.ch}`"
                :ref="`out${item.ch}`"
                :id="`out${item.ch}`"
                draggable="false"
                @dragstart.stop.prevent="imgfalse"
                class="left-content-img"
              />
              <img
                v-else-if="item.card_type == 100"
                src="~assets/facilityset/HDMIIO卡.png"
                :usemap="`#out${item.ch}`"
                :ref="`out${item.ch}`"
                :id="`out${item.ch}`"
                draggable="false"
                @dragstart.stop.prevent="imgfalse"
                class="left-content-img"
              />
              <img
                v-else-if="item.card_type == 102"
                src="~assets/facilityset/2路HDMI输出卡.png"
                :usemap="`#out${item.ch}`"
                :ref="`out${item.ch}`"
                :id="`out${item.ch}`"
                draggable="false"
                @dragstart.stop.prevent="imgfalse"
                class="left-content-img"
              />
              <img
                v-else-if="item.card_type == 555"
                src="~assets/facilityset/控制卡.png"
                :usemap="`#out${item.ch}`"
                ref="kongzhika"
                :id="`out${item.ch}`"
                draggable="false"
                @dragstart.stop.prevent="imgfalse"
                class="left-content-img"
                @click="handleChEvent(item)"
              />
              <img
                v-else-if="item.card_type == 666"
                src="~assets/facilityset/板卡切图-1.png"
                :usemap="`#out${item.ch}`"
                :ref="`out${item.ch}`"
                :id="`out${item.ch}`"
                draggable="false"
                @dragstart.stop.prevent="imgfalse"
                class="left-content-img"
              />
              <img
                v-else-if="item.card_type == 777"
                src="~assets/facilityset/电源.png"
                :usemap="`#out${item.ch}`"
                :ref="`out${item.ch}`"
                :id="`out${item.ch}`"
                draggable="false"
                @dragstart.stop.prevent="imgfalse"
                class="left-content-img"
              />
              <img
                v-else-if="item.card_type == 53"
                src="~assets/facilityset/SDI输出卡.png"
                :usemap="`#out${item.ch}`"
                :ref="`out${item.ch}`"
                :id="`out${item.ch}`"
                draggable="false"
                @dragstart.stop.prevent="imgfalse"
                class="left-content-img"
              />
              <img
                v-else
                src="~assets/facilityset/板卡切图-1.png"
                :usemap="`#out${item.ch}`"
                :ref="`out${item.ch}`"
                :id="`out${item.ch}`"
                draggable="false"
                @dragstart.stop.prevent="imgfalse"
                class="left-content-img"
              />
              <map :name="`out${item.ch}`" v-if="item.arrayCID">
                <i
                  shape="rect"
                  :coords="item.rectArray[0]"
                  :style="{
                    left: `${item.rectArray[0].split(',')[0]}px`,
                    top: `${item.rectArray[0].split(',')[1]}px`
                  }"
                  @click="handleCard(item, item.arrayCID[0], 1)"
                />

                <i
                  shape="rect"
                  :coords="item.rectArray[1]"
                  :style="{
                    left: `${item.rectArray[1].split(',')[0]}px`,
                    top: `${item.rectArray[1].split(',')[1]}px`
                  }"
                  @click="handleCard(item, item.arrayCID[1], 1)"
                />
                <i
                  shape="rect"
                  v-if="item.rectArray[2]"
                  :coords="item.rectArray[2]"
                  :style="{
                    left: `${item.rectArray[2].split(',')[0]}px`,
                    top: `${item.rectArray[2].split(',')[1]}px`
                  }"
                  @click="handleCard(item, item.arrayCID[2], 1)"
                />
                <i
                  shape="rect"
                  v-if="item.rectArray[3]"
                  :coords="item.rectArray[3]"
                  :style="{
                    left: `${item.rectArray[3].split(',')[0]}px`,
                    top: `${item.rectArray[3].split(',')[1]}px`
                  }"
                  @click="handleCard(item, item.arrayCID[3], 1)"
                />
              </map>
              <!--                        <a href="#">-->
              <!--                          <img src="~assets/facilityset/HDMI输出卡.png" ismap="ismap" draggable="false" @dragstart.stop.prevent="imgfalse" class="left-content-img">-->
              <!--                        </a>-->
            </div>
          </div>

          <div class="d">
            <img src="~assets/facilityset/电源.png" alt="" class="d-img" />
            <!--          <a href="#">-->
            <!--            <img src="~assets/facilityset/电源.png" alt="" class="d-img" ismap="ismap">-->
            <!--          </a>-->
          </div>
        </div>
        <!--      <div :class="['left-content',subCardNum===32?'flex_wrap':'']">-->
        <!--        <div v-for="item of GridList" :class="['left-content-img-warp',handleCh==item?'active':'',item.card_type==777?'d':'']" @click="handleCard(item)">-->
        <!--          <img v-if="item.card_type==1" src="~assets/facilityset/HDMI输入卡.png" alt="" draggable="false" @dragstart.stop.prevent="imgfalse" class="left-content-img">-->
        <!--          <img v-else-if="item.card_type==49" src="~assets/facilityset/HDMI输出卡.png" alt="" draggable="false" @dragstart.stop.prevent="imgfalse" class="left-content-img">-->
        <!--          <img v-else-if="item.card_type==2" src="~assets/facilityset/DVI输入卡.png" alt="" draggable="false" @dragstart.stop.prevent="imgfalse" class="left-content-img">-->
        <!--          <img v-else-if="item.card_type==50" src="~assets/facilityset/DVI输出卡.png" alt="" draggable="false" @dragstart.stop.prevent="imgfalse" class="left-content-img">-->
        <!--          <img v-else-if="item.card_type==3" src="~assets/facilityset/HDBaseT输入卡.png" alt="" draggable="false" @dragstart.stop.prevent="imgfalse" class="left-content-img">-->
        <!--          <img v-else-if="item.card_type==51" src="~assets/facilityset/HDBaseT输出卡.png" alt="" draggable="false" @dragstart.stop.prevent="imgfalse" class="left-content-img">-->
        <!--          <img v-else-if="item.card_type==100" src="~assets/facilityset/HDMIIO卡.png" alt="" draggable="false" @dragstart.stop.prevent="imgfalse" class="left-content-img">-->
        <!--          <img v-else-if="item.card_type==101" src="~assets/facilityset/2路HDMI输入卡.png" alt="" draggable="false" @dragstart.stop.prevent="imgfalse" class="left-content-img">-->
        <!--          <img v-else-if="item.card_type==102" src="~assets/facilityset/2路HDMI输出卡.png" alt="" draggable="false" @dragstart.stop.prevent="imgfalse" class="left-content-img">-->
        <!--          <img v-else-if="item.card_type==555" src="~assets/facilityset/控制卡.png" alt="" draggable="false" @dragstart.stop.prevent="imgfalse" class="left-content-img">-->
        <!--          <img v-else-if="item.card_type==666" src="~assets/facilityset/板卡切图-1.png" alt="" draggable="false" @dragstart.stop.prevent="imgfalse" class="left-content-img">-->
        <!--          <img v-else-if="item.card_type==777" src="~assets/facilityset/电源.png" alt="" draggable="false" @dragstart.stop.prevent="imgfalse" class="left-content-img">-->
        <!--          <img v-else-if="item.card_type==5" src="~assets/facilityset/SDI输入卡.png" alt="" draggable="false" @dragstart.stop.prevent="imgfalse" class="left-content-img">-->
        <!--          <img v-else-if="item.card_type==53" src="~assets/facilityset/SDI输出卡.png" alt="" draggable="false" @dragstart.stop.prevent="imgfalse" class="left-content-img">-->
        <!--          <img v-else src="~assets/facilityset/板卡切图-1.png" alt="" draggable="false" @dragstart.stop.prevent="imgfalse" class="left-content-img">-->
        <!--          &lt;!&ndash;            <svg-icon v-if="item.singal_flagClass" class="xinhaoClass" icon-class="xinhao" />&ndash;&gt;-->
        <!--          <img v-if="item.singal_flagClass" class="xinhaoClass" src="./img/xinhao.png">-->
        <!--&lt;!&ndash;          <img v-if="item.hpd_link" class="xinhaoClass" src="./img/xinhao.png">&ndash;&gt;-->
        <!--          <span :class="['num',item.hpd_link?'hpd_link_active':'']" :title="item.hpd_link?'此输出卡已连接显示屏':''">{{ item.ch }}</span>-->
        <!--        </div>-->
        <!--        <div v-if="subCardNum===16" class="left-content-img-warp" @click="handleCard({card_type:555,ch:555})">-->
        <!--          <img src="~assets/facilityset/控制卡.png" alt="" class="left-content-img ">-->
        <!--        </div>-->
        <!--        <div v-if="subCardNum===16" class="left-content-img-warp d">-->
        <!--          <img src="~assets/facilityset/电源.png" alt="" class="left-content-img ">-->
        <!--        </div>-->
        <!--      </div>-->
      </div>
      <div class="right">
        <div class="right-content">
          <component
            :is="componentName"
            :handleCh="handleCh"
            :key="cID"
            :ch_index="ch"
            :ch="cID"
            :type="type"
            :card_type="handleCh.card_type"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import InCard from "./components/InCard";
import OutCard from "./components/OutCard";
import ControlCard from "./components/ControlCard";
import noCard from "./components/noCard";
import SELECT from "./components/SELECT";
import {
  CardListApi,
  CardDetailApi,
  DevInfoApi,
  SendInOutSeatApi,
  SyncSceneApi,
  scene_saveApi,
  getScenceDataApi,
  scene_callApi,
  scene_delApi,
  scene_rotateApi,
  scene_rotate_argsApi,
  getInputCardListApi,
  getOutCardListApi
} from "@/api/home";
import {
  initWebSocket,
  websocketsend,
  onOffer,
  WS,
  stringToArrayBuffer
} from "@/utils/ws";
import _ from "lodash";

export default {
  name: "Index",
  components: {
    SELECT,
    InCard,
    OutCard,
    ControlCard,
    noCard
  },
  data() {
    return {
      // 判断是不是ipad mac
      isIpadMac: !!window.navigator.userAgent.match(/(Mac|iPad)/i),
      IpadMacStyle: {
        transform: "scaleY(0.8)",
        "transform-origin": "left top"
      },
      // 已经插卡的列表
      cardTAGList: [],
      ch_index: "",
      type: 0, // 0 输入 1 输出
      cID: "",
      ch: "",
      // 当前点击的板卡
      handleCh: {},
      // 右侧当前的组件
      componentName: "",
      DevInfoType: {
        "LCD-ADV-8*8": {},
        "LCD-ADV-8*12": {
          colCardNum: 3, // 纵向有几张卡
          controlPosition: "left"
        },
        "LCD-ADV-20*16": {
          colCardNum: 5, // 纵向有几张卡
          controlPosition: "right"
        },
        "LCD-ADV-36*36": {
          colCardNum: 10, // 纵向有几张卡
          controlPosition: "left"
        },
        "LCD-ADV-72*72": {
          colCardNum: 20, // 纵向有几张卡
          controlPosition: "left"
        }
      },
      MineType: "",
      notOverflowType: ["LCD-ADV-8*8", "LCD-ADV-8*12", "LCD-ADV-20*16"], // 不抖动
      colCardNum: 5, // 纵向几张卡
      controlPosition: "right", // 控制卡的位置
      inCardList: {
        1: { ch: "", card_type: 0, cID: [] }
      },
      outCardList: {
        1: { ch: "", card_type: 0, cID: [] }
      }
    };
  },
  created() {
    if (!WS) {
      initWebSocket();
    }
  },
  mounted() {
    console.log(
      "!!window.navigator.userAgent.match(/(Mac|iPad)/i):",
      !!window.navigator.userAgent.match(/(Mac|iPad)/i)
    );
    // const loading = this.$loading({
    //   lock: true,
    //   text: '正在获取数据...',
    //   spinner: 'el-icon-loading',
    //   background: 'rgba(0, 0, 0, 0.7)'
    // });
    const _this = this;
    if (localStorage.getItem("systemType")) {
      const type = localStorage.getItem("systemType");
      this.MineType = type;
      let { colCardNum, controlPosition } = this.DevInfoType[type];
      console.log(colCardNum, controlPosition);
      this.colCardNum = colCardNum;
      this.controlPosition = controlPosition;
      document
        .getElementsByTagName("body")[0]
        .style.setProperty("--facilityset_height", `${colCardNum * 75}px`);
      for (let i = 1; i <= colCardNum; i++) {
        if (i === colCardNum) {
          this.inCardList[i] = {
            card_type: controlPosition === "left" ? 555 : 0,
            ch: ""
          };
          this.outCardList[i] = {
            card_type: controlPosition === "right" ? 555 : 0,
            ch: ""
          };
        } else {
          this.inCardList[i] = {
            card_type: 0,
            ch: ""
          };
          this.outCardList[i] = {
            card_type: 0,
            ch: ""
          };
        }
      }
    } else {
      DevInfoApi({
        cmd: "DevInfo"
      }).then(res => {
        let type = res.type;
        // let type = "LCD-ADV-72*72";
        localStorage.setItem("systemType", type);
        this.MineType = type;
        let { colCardNum, controlPosition } = this.DevInfoType[type];
        console.log(colCardNum, controlPosition);
        this.colCardNum = colCardNum;
        this.controlPosition = controlPosition;
        document
          .getElementsByTagName("body")[0]
          .style.setProperty("--facilityset_height", `${colCardNum * 75}px`);
        for (let i = 1; i <= colCardNum; i++) {
          if (i === colCardNum) {
            this.inCardList[i] = {
              card_type: controlPosition === "left" ? 555 : 0,
              ch: ""
            };
            this.outCardList[i] = {
              card_type: controlPosition === "right" ? 555 : 0,
              ch: ""
            };
          } else {
            this.inCardList[i] = {
              card_type: 0,
              ch: ""
            };
            this.outCardList[i] = {
              card_type: 0,
              ch: ""
            };
          }
        }
        console.log(this.inCardList, "this.inCardList");
        console.log(this.outCardList, "this.outCardList");
      });
    }
    let port2Type = [23, 17, 24, 81, 82];
    Promise.all([
      getInputCardListApi({ cmd: "incard_info_sync" }),
      getOutCardListApi({ cmd: "outcard_info_sync" })
    ])
      .then(res => {
        // console.log(this.$refs["kongzhika"][0], "kongzhika");

        let rectArray = [];
        [
          [40, 18, 130, 53],
          [150, 18, 240, 53],
          [260, 18, 350, 53],
          [370, 18, 460, 53]
        ].forEach(i => {
          let rect = this.coords(i, "kongzhika");
          rectArray.push(rect);
        });

        let rectArrayDP4K_HDMI4K = [];
        [[40, 18, 130, 53], [260, 18, 350, 53]].forEach(i => {
          let rect = this.coords(i, "kongzhika");
          rectArrayDP4K_HDMI4K.push(rect);
        });

        let inData = res[0];
        let outData = res[1];

        // 新版的解析方式有问题 先注释掉 使用原版的解析方式
        // let inList = _this.cardOrder(inData);
        // inList.forEach(item => {
        //   let { ch, card_type, arrayCID } = item;
        //   if (port2Type.includes(item.card_type)) {
        //     this.inCardList[ch] = {
        //       ch,
        //       card_type,
        //       arrayCID,
        //       rectArray: rectArrayDP4K_HDMI4K
        //     };
        //   } else {
        //     this.inCardList[ch] = { ch, card_type, arrayCID, rectArray };
        //   }
        // });
        // console.log("Promise.all:", res);
        // 旧版的解析方式
        let inChArray = [];
        for (let i = 0; i < inData.length; i += 4) {
          inChArray.push(inData.slice(i, i + 4));
        }
        inChArray.forEach(item => {
          let arrayCID = [];

          console.log(item, "inChArrayItem");
          item.forEach(i => {
            if (port2Type.includes(i.type)) {
              if (i.cID % 2 !== 0) {
                arrayCID.push(i.cID);
              }
            } else {
              arrayCID.push(i.cID);
            }
          });
          let { cID, type } = item[0];
          const ch = Math.ceil(cID / 4);
          if (ch && type) {
            if (port2Type.includes(type)) {
              this.inCardList[ch] = {
                ch,
                card_type: type,
                arrayCID,
                rectArray: rectArrayDP4K_HDMI4K
              };
            } else {
              this.inCardList[ch] = {
                ch,
                card_type: type,
                arrayCID,
                rectArray
              };
            }
          }
        });

        // 注释掉新版的解析方式
        // let outList = _this.cardOrder(outData);
        // outList.forEach(item => {
        //   let { ch, card_type, arrayCID } = item;
        //   if (port2Type.includes(item.card_type)) {
        //     this.outCardList[ch] = {
        //       ch,
        //       card_type,
        //       arrayCID,
        //       rectArray: rectArrayDP4K_HDMI4K
        //     };
        //   } else {
        //     this.outCardList[ch] = { ch, card_type, arrayCID, rectArray };
        //   }
        // });
        // 旧版的解析方式
        let outChArray = [];
        for (let i = 0; i < outData.length; i += 4) {
          outChArray.push(outData.slice(i, i + 4));
        }
        outChArray.forEach(item => {
          console.log(item, "outItem");
          let arrayCID = [];
          item.forEach(i => {
            if (port2Type.includes(i.type)) {
              if (i.cID % 2 !== 0) {
                arrayCID.push(i.cID);
              }
            } else {
              arrayCID.push(i.cID);
            }
          });
          let { cID, type } = item[0];
          const ch = Math.ceil(cID / 4);
          if (ch && type) {
            if (port2Type.includes(type)) {
              this.outCardList[ch] = {
                ch,
                card_type: type,
                arrayCID,
                rectArray: rectArrayDP4K_HDMI4K
              };
            } else {
              this.outCardList[ch] = {
                ch,
                card_type: type,
                arrayCID,
                rectArray
              };
            }
          }
        });
        this.$forceUpdate();
        console.log(res, "promise_all");
      })
      .then(() => {
        stringToArrayBuffer("(ip)\r\n").then(res => {
          WS.send(res);
        });
      });

    // getInputCardListApi({
    //   cmd:'incard_info_sync'
    // }).then(r=>{
    //   let inData=r.incard_info_sync
    //
    //   let inChArray=[]
    //   for (let i=0;i<inData.length;i+=4){
    //     inChArray.push(inData.slice(i,i+4))
    //   }
    //   inChArray.forEach(item=>{
    //     let arrayCID=[]
    //     item.forEach(i=>arrayCID.push(i.cID))
    //     let {ch,type}=item[0]
    //     if (ch&&type){
    //       this.inCardList[ch]={ch,card_type:type,arrayCID}
    //     }
    //   })
    //
    //   // this.$forceUpdate()
    // })
    //
    // getOutCardListApi({
    //   cmd:'outcard_info_sync'
    // }).then(r=>{
    //   let outChArray=[]
    //   let outData=r.outcard_info_sync
    //   for (let i=0;i<outData.length;i+=4){
    //     outChArray.push(outData.slice(i,i+4))
    //   }
    //   outChArray.forEach(item=>{
    //     let arrayCID=[]
    //     item.forEach(i=>arrayCID.push(i.cID))
    //     let {ch,type}=item[0]
    //     if (ch&&type){
    //       this.outCardList[ch]={ch,card_type:type,arrayCID}
    //     }
    //   })
    // })

    // 接收websocket数据
    // this.socketApi.sendSock({}, data => {
    //   console.log("websocket接收到的数据facilityset", data);
    //   this.setCard(data);
    // });

    onOffer(offerData => {
      console.log(
        "............................onOffer...................................."
      );
      // console.log(offerData, "offerData");
      offerData.forEach(data => {
        if (
          data.indexOf("status_refresh") !== -1 &&
          data.indexOf("input") !== -1
        ) {
          let item = JSON.parse(data);
          let { input, output } = item.status_refresh;
          let rectArray = [];
          [
            [40, 18, 130, 53],
            [150, 18, 240, 53],
            [260, 18, 350, 53],
            [370, 18, 460, 53]
          ].forEach(i => {
            let rect = this.coords(i, "kongzhika");
            rectArray.push(rect);
          });

          let rectArrayDP4K_HDMI4K = [];
          [[40, 18, 130, 53], [260, 18, 350, 53]].forEach(i => {
            let rect = this.coords(i, "kongzhika");
            rectArrayDP4K_HDMI4K.push(rect);
          });

          if (input.length) {
            // ch: 1
            // signal: [0, 0, 1, 0]
            // type: 10
            input.forEach(i => {
              let cIDList = [
                i.ch * 4 - 3,
                i.ch * 4 - 2,
                i.ch * 4 - 1,
                i.ch * 4
              ];
              let cIDList4k = [i.ch * 4 - 3, i.ch * 4 - 1];

              // rectArray
              // rectArrayDP4K_HDMI4K

              if (i.type) {
                if (port2Type.includes(i.type)) {
                  _this.inCardList[i.ch] = {
                    ch: i.ch,
                    card_type: i.type,
                    arrayCID: cIDList4k,
                    rectArray: rectArrayDP4K_HDMI4K
                  };
                } else {
                  _this.inCardList[i.ch] = {
                    ch: i.ch,
                    card_type: i.type,
                    arrayCID: cIDList,
                    rectArray
                  };
                }

                const incardListData = JSON.parse(
                  localStorage.getItem("incardListData")
                );
                incardListData.forEach(item => {
                  if (cIDList.includes(item.cID)) {
                    item.type = i.type;
                  }
                });
                localStorage.setItem(
                  "incardListData",
                  JSON.stringify(incardListData)
                );

                // 插卡
                // cIDList.forEach(cID => {
                //   _this.inList[cID] = {
                //     card_type: i.type,
                //     ch: cID,
                //     clip: [],
                //     rename: `${_this.NameList[i.type] + cID}`,
                //     singal_flag: 0
                //   };
                // });
                // 拔插信号
                // const ch = i.ch;
                // const signalList = i.signal;
                // console.log(i, "inputItem");
                // signalList.forEach((j, index) => {
                //   const cID = index - 3 + ch * 4;
                //   console.log(`cID: ${cID},signal: ${j}`);
                //   _this.inList[cID].singal_flag = j;
                // });
              } else {
                // 拔卡
                _this.inCardList[i.ch].card_type = 0;
                _this.inCardList[i.ch].arrayCID = null;
                _this.inCardList[i.ch].rectArray = null;
                _this.componentName = "";

                //outListData
                //incardListData
                const incardListData = JSON.parse(
                  localStorage.getItem("incardListData")
                );
                incardListData.forEach(item => {
                  if (cIDList.includes(item.cID)) {
                    item.type = 0;
                  }
                });
                localStorage.setItem(
                  "incardListData",
                  JSON.stringify(incardListData)
                );
              }
            });
          }
          if (output.length) {
            output.forEach(i => {
              let cIDList = [
                i.ch * 4 - 3,
                i.ch * 4 - 2,
                i.ch * 4 - 1,
                i.ch * 4
              ];
              let cIDList4k = [i.ch * 4 - 3, i.ch * 4 - 1];
              if (i.type) {
                if (port2Type.includes(i.type)) {
                  _this.outCardList[i.ch] = {
                    ch: i.ch,
                    card_type: i.type,
                    arrayCID: cIDList4k,
                    rectArray: rectArrayDP4K_HDMI4K
                  };
                } else {
                  // 插卡
                  _this.outCardList[i.ch] = {
                    ch: i.ch,
                    card_type: i.type,
                    arrayCID: cIDList,
                    rectArray
                  };
                }

                const outListData = JSON.parse(
                  localStorage.getItem("outListData")
                );
                outListData.forEach(item => {
                  if (cIDList.includes(item.cID)) {
                    item.type = i.type;
                  }
                });
                localStorage.setItem(
                  "outListData",
                  JSON.stringify(outListData)
                );
              } else {
                // 拔卡
                _this.outCardList[i.ch].card_type = 0;
                _this.outCardList[i.ch].arrayCID = null;
                _this.outCardList[i.ch].rectArray = null;
                _this.componentName = "";

                //outListData
                //incardListData
                const outListData = JSON.parse(
                  localStorage.getItem("outListData")
                );
                outListData.forEach(item => {
                  if (cIDList.includes(item.cID)) {
                    item.type = 0;
                  }
                });
                localStorage.setItem(
                  "outListData",
                  JSON.stringify(outListData)
                );
              }
            });
          }
          _this.$forceUpdate();

          console.log(JSON.parse(data));
        }
      });
    });

    // 浏览器窗口放大时拼控的窗体等比缩放
    if (
      !window.navigator.userAgent.match(
        /(Intel Mac|phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|IEMobile|MQQBrowser|JUC|Fennec|wOSBrowser|BrowserNG|WebOS|Symbian|Windows Phone)/i
      )
    ) {
      window.addEventListener("resize", this.handlerReload, false);
    }
  },
  destroyed() {
    // 离开路由之后断开websocket连接
    window.removeEventListener("resize", this.handlerReload, false);
  },
  methods: {
    handlerReload() {
      window.location.reload();
    },
    cardOrder(list) {
      const res = _.sortBy(list, "cID");
      let port2Type = [23, 17, 24, 81, 82];
      let obj = {};
      for (let i = 0; i < res.length; i++) {
        let item = res[i];
        if (obj[item.type]) {
          obj[item.type].list.push(item);
          obj[item.type].arrayCID.push(item.cID);
        } else {
          let ch;
          if (port2Type.includes(item.type)) {
            if (item.cID === 1) {
              ch = 1;
            } else {
              ch = Math.floor(item.cID / 2);
            }
          } else {
            ch = Math.ceil(item.cID / 4);
          }
          obj[item.type] = {
            ch: ch,
            card_type: item.type,
            list: [item],
            arrayCID: [item.cID]
          };
        }
      }
      return _.orderBy(obj, "ch");
    },
    setCard(data, chc) {
      if (chc) {
        console.log(data, chc, "子组件传递过来的值");
      }
      let _this = this;
      // 拔卡   或者输出卡信号插拔
      if (data.status_refresh) {
        data.status_refresh.list.forEach(i => {
          console.log(i.ch, "拔卡的ch看看是否是字符串");
          const ch =
            parseInt(i.ch) > 14 && _this.subCardNum === 32
              ? parseInt(i.ch) + 3
              : parseInt(i.ch);
          if (!i.type) {
            _this.GridList[ch].ch = "";
            _this.GridList[ch].name = "";
            _this.GridList[ch].card_type = 0;
            _this.GridList[ch].singal_flagClass = "";
            _this.GridList[ch].hpd_link = 0;
            console.log(ch, "ch");
            if (chc) {
              console.log(chc, "chc,子组件传过来的CH");
              if (parseInt(i.ch) === chc) {
                _this.handleCard({
                  card_type: 0,
                  ch: "",
                  hpd_link: 0,
                  name: "",
                  singal_flagClass: ""
                });
              }
            }
          } else {
            // 信号插拔
            // _this.GridList[ch].hpd_link = i.hpd_link
            // if (i.singal_flag){
            //   _this.GridList[ch].singal_flagClass = 'singal_flag'
            // }else {
            //   _this.GridList[ch].singal_flagClass = ''
            // }

            if (i.propertyIsEnumerable("singal_flag")) {
              if (i.singal_flag) {
                _this.GridList[ch].singal_flagClass = "singal_flag";
              } else {
                _this.GridList[ch].singal_flagClass = "";
              }
            }

            if (i.propertyIsEnumerable("hpd_link")) {
              _this.GridList[ch].hpd_link = i.hpd_link;
            }
          }
          // 更新分辨率
        });
      }
      // 插卡
      if (data.Cmd === "list") {
        console.log(data.list.ch, "插卡的ch看看是否是字符串");
        const ch =
          parseInt(data.list.ch) > 14 && _this.subCardNum === 32
            ? parseInt(data.list.ch) + 3
            : parseInt(data.list.ch);
        _this.GridList[ch].ch = parseInt(data.list.ch);
        _this.GridList[ch].name = data.list.rename
          ? data.list.rename
          : `HDMI${ch}`;
        if (
          data.list.card_type == 1 ||
          data.list.card_type == 3 ||
          data.list.card_type == 4 ||
          data.list.card_type == 6 ||
          data.list.card_type == 11 ||
          data.list.card_type == 17 ||
          data.list.card_type == 24 ||
          data.list.card_type == 23 ||
          data.list.card_type == 100 ||
          data.list.card_type == 101 ||
          data.list.card_type == 2 ||
          data.list.card_type == 5
        ) {
          // 输入卡
          _this.GridList[ch].card_type = data.list.card_type;
          if (data.list.singal_flag) {
            _this.GridList[ch].singal_flagClass = "singal_flag";
          } else {
            _this.GridList[ch].singal_flagClass = "";
          }
        }
        if (
          data.list.card_type == 49 ||
          data.list.card_type == 51 ||
          data.list.card_type == 100 ||
          data.list.card_type == 102 ||
          data.list.card_type == 50 ||
          data.list.card_type == 81 ||
          data.list.card_type == 82 ||
          data.list.card_type == 53
        ) {
          // 输出卡
          _this.GridList[ch].card_type = data.list.card_type;
          _this.GridList[ch].hpd_link = data.list.hpd_link;
        }
      }
    },
    coords(array, usemap) {
      let imgDom = this.$refs[`${usemap}`];
      // let imgDom = document.getElementById(`#${usemap}`)
      let arr = [...array];
      let nArray = null;
      for (const i in imgDom) {
        let imgWidth = imgDom[i].offsetWidth;
        let imgHeight = imgDom[i].offsetHeight;
        let widthRate = 500 / imgWidth;
        let heightRate = 60 / imgHeight;
        let x1 = arr[0] / widthRate;
        let y1 = arr[1] / heightRate;
        let x2 = arr[2] / widthRate;
        let y2 = arr[3] / heightRate;
        nArray = [x1, y1, x2, y2];
      }
      console.log("...............");
      console.log(imgDom, "imgDom");
      console.log(nArray, "nArray");
      console.log(usemap, "usemap");
      return nArray ? nArray.join() : "";
    },
    handleChEvent(item) {
      console.log(item, "item");
      this.componentName = "ControlCard";
    },
    imgfalse(e) {
      return false;
    },
    handleCard(item, cID, type) {
      // if (!item.card_type){return false}

      // this.handleCh = item
      console.log(cID, "cID");
      this.cID = cID;
      this.ch = item.ch;
      this.type = type;
      // return false;
      console.log(item, "点击的板卡信息");
      console.log(item.card_type, "item.card_type");
      this.handleCh.card_type = item.card_type;
      if (
        item.card_type === 1 ||
        item.card_type === 10 ||
        item.card_type === 3 ||
        item.card_type === 4 ||
        item.card_type === 17 ||
        item.card_type === 24 ||
        item.card_type === 23 ||
        item.card_type === 6 ||
        item.card_type === 11 ||
        item.card_type === 2 ||
        item.card_type === 5
      ) {
        this.ch_index = `${item.ch}_0`;
        this.componentName = "InCard";
      } else if (
        item.card_type === 49 ||
        item.card_type === 58 ||
        item.card_type === 59 ||
        item.card_type === 51 ||
        item.card_type === 50 ||
        item.card_type === 81 ||
        item.card_type === 82 ||
        item.card_type === 53
      ) {
        this.ch_index = `${item.ch}_0`;
        this.componentName = "OutCard";
      } else if (item.card_type === 555) {
        this.componentName = "ControlCard";
      } else if (item.card_type === 666) {
        // 底图卡暂无
        this.componentName = "noCard";
      } else if (item.card_type === 777) {
        // 电源
        this.componentName = "noCard";
      } else if (item.card_type === 100) {
        // 1入1出卡 2input 2output
        // this.componentName = 'SELECT'
        this.sendCompoentItem(item, "in", 0);
      } else if (item.card_type === 101) {
        this.componentName = "SELECT";
      } else if (item.card_type === 102) {
        this.componentName = "SELECT";
      } else {
        this.componentName = "noCard";
      }
    },
    sendCompoentItem(item, type, index) {
      console.log(item, "子组件传递上来的数据");
      this.handleCh = item;
      this.ch_index = `${item.ch}_${index}`;
      if (type === "in") {
        this.componentName = "InCard";
      }
      if (type === "out") {
        this.componentName = "OutCard";
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.warp_height {
  /*0812机型*/
  height: calc(100vh - 100px);
}
.warp_overflow {
  /*非0812机型*/
  overflow: auto;
}
.warp {
  display: flex;
  .left {
    flex-basis: 1300px;
    display: flex;
    justify-content: center;
    align-items: center;
    /*border-left: 2px solid #000000;*/
    .flex_wrap {
      flex-wrap: wrap;
    }
    @keyframes bgFadeIn {
      0% {
        opacity: 0;
      }
      //50% {
      //  opacity: 0.5;
      //}
      100% {
        opacity: 1;
      }
    }
    .left-content {
      width: 100%;
      /*height: 280px;*/
      background: url("~assets/facilityset/SY-LMP.png");
      background-size: 100% 100%;
      background-repeat: no-repeat;
      animation: bgFadeIn 1s ease-in both;
      //background-color: #181818;
      display: flex;
      justify-content: space-around;
      align-items: center;
      /*flex-wrap: wrap;*/
      .left-content-img-warp {
        width: 500px;
        height: 60px;
        margin: 15px 5px;
        position: relative;

        .left-content-img {
          width: 100%;
          height: 100%;
          border-radius: 8px;
        }

        .xinhaoClass {
          position: absolute;
          left: 22px;
          top: 5px;
          width: 17px;
          height: 17px;
        }

        .num {
          position: absolute;
          left: 25px;
          bottom: 0;
          font-size: 16px;
          color: #ffffff;
        }

        .num.hpd_link_active {
          color: springgreen;
        }
      }

      .d {
        //width: 100%;/*宽 500像素 高 60像素*/
        height: var(--facilityset_height); /*输入卡的插槽数量*122*/
        margin: 15px 5px;
        position: relative;

        .d-img {
          //width: 100%;
          height: 100%;
          transition: height 1s ease-in;
          border-radius: 8px;
        }
      }

      .left-content-img-warp.active {
        border: 2px solid #007acc;
      }
    }
  }
  .leftTip {
    position: absolute;
    top: 13%;
    left: 0;
    color: #ffffff;
    font-size: 16px;
    animation: bgFadeIn 3s ease-in both;
  }
  .right {
    border-left: 2px solid #000000;
    min-width: 410px;
    flex: 1;

    .right-content {
      color: #ffffff;
      display: flex;
      justify-content: center;
      align-items: center;
      text-align: left;
      width: 380px;
      margin: 40px auto;
    }
  }
}

map {
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  display: flex;
  justify-content: space-evenly;
  align-items: center;
  area,
  i {
    position: absolute;
    display: inline-block !important;
    width: 90px;
    height: 30px;
    //outline: 2px solid rgb(24, 144, 255);
  }
}
</style>
