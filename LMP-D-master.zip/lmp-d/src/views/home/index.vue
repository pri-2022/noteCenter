<template>
  <div>
    <!--    头部-->
    <div class="header">
      <p class="header_title cursorDefault">{{ $t("login.title") }}</p>
      <div class="center-top-buttonGroup">
        <!--        <p class="ptn-btn-124 light">分组1</p>-->
        <!--        <p class="ptn-btn-124">分组2</p>-->
        <!--        <p class="ptn-btn-124">分组3</p>-->
        <!--        <p class="ptn-btn-124">分组3</p>-->
        <p
          :title="
            (item.name ? item.name : $t('home.group') + item.gID) +
              '_' +
              gTypeList[item.panel_type ? item.panel_type : 1]
          "
          :class="[
            'ptn-btn-124',
            'headerCenter',
            item.gID === gid ? 'light' : ''
          ]"
          v-for="item of GroupContext"
          @click="handleClick(item)"
        >
          {{
            (item.name ? item.name : $t("home.group") + item.gID) +
              "_" +
              gTypeList[item.panel_type ? item.panel_type : 1]
          }}
        </p>
      </div>
      <div style="display: flex;align-items: center;justify-content: flex-end;">
        <!--        <svg-icon style="font-size: 25px;margin-right: 10px;" class-name="outlogin" icon-class="outlogin" @click="toLogin"></svg-icon>-->

        <el-dropdown
          class="avatar-container right-menu-item hover-effect"
          trigger="click"
        >
          <div class="avatar-wrapper">
            <svg-icon
              style="font-size: 25px;margin-right: 10px;"
              class-name="outlogin"
              icon-class="outlogin"
            ></svg-icon>
          </div>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item divided @click.native="toLogin">
              <span style="display:block;">{{ $t("navbar.logOut") }}</span>
            </el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>

        <svg-icon
          v-if="permit === 2"
          style="font-size: 32px;color: #ffffff;"
          class-name="Settingsvgicon"
          icon-class="Setting"
          @click="toSetting"
        ></svg-icon>

        <!--        <p  class="ptn-btn-80" @click="toLogin">退出</p>-->
      </div>
    </div>
    <!--    中间部分-->
    <div class="content">
      <!--      左侧栏-->
      <div class="left">
        <div class="left-header cursorDefault">{{ $t("home.inlist") }}</div>
        <div class="left-list">
          <div class="left-list-input-warp">
            <el-input
              v-model="searchInCardInput"
              clearable
              @clear="searchInCardInputClear"
              @input="searchInCardInputChange"
            >
              <svg-icon
                @click="searchInCard"
                slot="append"
                icon-class="search"
                class-name="search"
              />
            </el-input>
            <!--            <input type="text" class="input" v-model="searchInCardInput">-->
            <!--            <div class="img-warp" @click="searchInCard"><img src="~assets/home/web1x_search.png"></div>-->
          </div>
          <ul class="left-list-ul">
            <div
              v-for="item of inList"
              :key="item.port_index ? `${item.ch}_${item.port_index}` : item.ch"
              v-if="item"
              :title="
                item.rename
                  ? item.rename
                  : `${NameList[item.card_type] + item.ch}`
              "
            >
              <div
                v-if="item.ch"
                :class="[
                  item.clip.length && item.card_type !== 0
                    ? 'clipWarp'
                    : 'clipWarpNoHover'
                ]"
              >
                <li
                  v-if="
                    item.card_type === 1 ||
                      item.card_type === 10 ||
                      item.card_type === 3 ||
                      item.card_type === 4 ||
                      item.card_type === 6 ||
                      item.card_type === 11 ||
                      item.card_type === 17 ||
                      item.card_type === 24 ||
                      item.card_type === 23 ||
                      item.card_type === 100 ||
                      item.card_type === 101 ||
                      item.card_type === 2 ||
                      item.card_type === 5
                  "
                  :id="`in${item.ch}`"
                  draggable="true"
                  :class="[
                    'left-list-ul-li',
                    handleChCopy ==
                    (item.port_index === undefined
                      ? `${item.ch}_0`
                      : `${item.ch}_${item.port_index}`)
                      ? 'light'
                      : ''
                  ]"
                  :data-ch="
                    item.port_index === undefined
                      ? `${item.ch}_0`
                      : `${item.ch}_${item.port_index}`
                  "
                  @dblclick="dbLineHeight"
                  @click="
                    LineHeight(
                      item.ch,
                      item.rename
                        ? item.rename
                        : `${NameList[item.card_type] +
                            item.ch +
                            (item.port_index === undefined
                              ? '_0'
                              : `_${item.port_index}`)}`,
                      item.singal_flag,
                      item,
                      0
                    )
                  "
                  @dragstart="
                    drag(
                      $event,
                      item.rename
                        ? item.rename
                        : `${NameList[item.card_type] +
                            item.ch +
                            (item.port_index === undefined
                              ? '_0'
                              : `_${item.port_index}`)}`,
                      item.singal_flag,
                      item,
                      0
                    )
                  "
                >
                  <img
                    v-if="item.singal_flag"
                    src="~assets/home/light.png"
                    draggable="false"
                    class="pointer_events_none"
                    alt=""
                  />
                  <img
                    v-else
                    src="~assets/home/huise.png"
                    alt=""
                    draggable="false"
                    class="pointer_events_none"
                  />
                  <!--TODO: 输入卡名称显示去掉区分端口0 1-->
                  <!--                <span style="overflow: hidden;text-overflow: ellipsis;white-space: nowrap;">{{ item.rename?item.rename:`${NameList[item.card_type]+item.ch+(item.port_index===undefined?'':`_${item.port_index}`)}` }}</span>-->
                  <span
                    style="overflow: hidden;text-overflow: ellipsis;white-space: nowrap;"
                    >{{
                      item.rename
                        ? item.rename
                        : `${NameList[item.card_type] +
                            item.ch +
                            (item.port_index === undefined ? "" : "")}`
                    }}</span
                  >
                </li>
                <div
                  class="clipUl"
                  v-if="item.clip.length && item.card_type !== 0"
                >
                  <template v-for="i of item.clip">
                    <p
                      draggable="true"
                      v-if="i.sytle"
                      class="clipLi"
                      @dragstart="
                        drag(
                          $event,
                          item.rename
                            ? item.rename
                            : `${NameList[item.card_type] +
                                item.ch +
                                (item.port_index === undefined
                                  ? '_0'
                                  : `_${item.port_index}`)}`,
                          item.singal_flag,
                          item,
                          i.sytle
                        )
                      "
                      @click="
                        LineHeight(
                          item.ch,
                          item.rename
                            ? item.rename
                            : `${NameList[item.card_type] +
                                item.ch +
                                (item.port_index === undefined
                                  ? '_0'
                                  : `_${item.port_index}`)}`,
                          item.singal_flag,
                          item,
                          i.sytle
                        )
                      "
                    >
                      {{
                        item.rename
                          ? item.rename
                          : `${NameList[item.card_type] +
                              item.ch +
                              (item.port_index === undefined ? "" : "")}`
                      }}-{{ i.sytle }}
                    </p>
                  </template>
                </div>
              </div>
            </div>
          </ul>
        </div>
      </div>
      <!--      分组以及栅格系统-->
      <div class="center">
        <div class="center-top" id="centerTop" style="overflow: auto;">
          <!--鼠标右键菜单-->

          <VueContextMenu
            class="right-menu"
            :target="contextMenuTarget"
            :show="contextMenuVisible"
            isdata="data-sid"
            @update:show="show => (contextMenuVisible = show)"
          >
            <a
              href="javascript:;"
              :class="[
                contextItem.lock ? 'pointer_events_none not_allowed' : ''
              ]"
              @click="contextHandler('置顶')"
              >{{ $t("home.Top") }}</a
            >
            <a
              href="javascript:;"
              :class="[
                contextItem.lock ? 'pointer_events_none not_allowed' : ''
              ]"
              @click="contextHandler('置底')"
              >{{ $t("home.setAtTheEnd") }}</a
            >
            <a
              href="javascript:;"
              :class="[
                contextItem.lock
                  ? 'pointer_events_none not_allowed'
                  : contextItem.isF
                  ? 'pointer_events_none not_allowed'
                  : ''
              ]"
              @click="contextHandler('放大')"
              >{{ $t("home.enlarge") }}</a
            >
            <a
              href="javascript:;"
              :class="[
                contextItem.lock
                  ? 'pointer_events_none not_allowed'
                  : contextItem.isF
                  ? ''
                  : 'pointer_events_none not_allowed'
              ]"
              @click="contextHandler('缩小')"
              >{{ $t("home.narrow") }}</a
            >
            <a
              v-if="contextItem.lock"
              :class="[
                contextItem.lockAll ? 'pointer_events_none not_allowed' : ''
              ]"
              href="javascript:;"
              @click="contextHandler('锁定', 0)"
              >{{ $t("home.unlock") }}</a
            >
            <a v-else href="javascript:;" @click="contextHandler('锁定', 1)">{{
              $t("home.lock")
            }}</a>
            <a
              v-if="contextItem.isM"
              href="javascript:;"
              :class="[
                contextItem.lock ? 'pointer_events_none not_allowed' : ''
              ]"
              @click="contextHandler('全屏', 0)"
              >{{ $t("home.cancelFullScreen") }}</a
            >
            <a
              v-else
              href="javascript:;"
              :class="[
                contextItem.lock ? 'pointer_events_none not_allowed' : ''
              ]"
              @click="contextHandler('全屏', 1)"
              >{{ $t("home.fullScreen") }}</a
            >
            <a
              href="javascript:;"
              :class="[
                contextItem.lock ? 'pointer_events_none not_allowed' : ''
              ]"
              @click="contextHandler('属性')"
              >{{ $t("home.property") }}</a
            >
            <a
              href="javascript:;"
              :class="[
                contextItem.lock ? 'pointer_events_none not_allowed' : ''
              ]"
              @click="contextHandler('关闭')"
              >{{ $t("home.close") }}</a
            >
          </VueContextMenu>

          <template v-for="it in SencenNum">
            <!--grid布局-->
            <div
              :ref="`ptngridwarp${it - 1}`"
              :id="`ptngridwarp${it - 1}`"
              class="ptn-grid-warp-grid"
              style="transform: scale(1,1);transform-origin: center;"
              @mouseup="up($event, 'fu')"
            >
              <!--原版没有几行几列-->
              <div
                v-for="(item, i) of GridArray"
                :ref="item.outputCh ? `${item.outputCh + 'ref'}` : ''"
                :id="item.outputCh ? `${item.outputCh + 'ref'}` : ''"
                :key="i"
                :class="['ptn-grid-warp-grid-item', item.handleClass]"
                :style="{
                  left: `${item.X}px`,
                  top: `${item.Y}px`,
                  width: `${item.W}px`,
                  height: `${item.H}px`,
                  zIndex: `${item.output ? 0 : -1}`
                }"
                :data-rongqindex="i"
                @drop.capture="GridArrayDrop($event, item)"
                @dragover.capture="GridArrayDragOver($event, item)"
                @click="GridArrayItemClick(item)"
              >
                <!--              <websocket :in="1"></websocket>-->
                <template>
                  <div class="ptn-grid-item-i-16 show">
                    <transition name="fade" mode="out-in">
                      <span
                        v-if="item.import"
                        :class="['import cursorDefault', item.singal_flagClass]"
                        >{{ item.import }}</span
                      >
                    </transition>
                  </div>
                  <div class="ptn-grid-item-i-16">
                    <!--                <span class="close">关闭</span>-->
                    <svg-icon
                      v-if="item.importCh"
                      @click.stop="closeIN(item.outputCh, item.card_type, i)"
                      icon-class="close"
                      class-name="close"
                    />
                  </div>
                  <div class="ptn-grid-item-i-16">
                    <span :class="['output cursorDefault', item.hpd_link]">{{
                      item.output
                    }}</span>
                  </div>
                  <div class="ptn-grid-item-i-16">
                    <span class="index cursorDefault">{{
                      $t("home.screen") + (i + 1)
                    }}</span>
                  </div>
                </template>
              </div>
              <template>
                <div
                  :ref="`${item.num + 'mouseWarp' + (it - 1)}`"
                  :id="`${'mouseWarp' + initial_index + item.num}`"
                  :class="[
                    'border',
                    item.isM ? '' : 'tem',
                    item.isW ? 'wuxiao' : '',
                    flag === item.num ? 'border' : '',
                    contextItem.num == item.num ? 'windowBorder' : ''
                  ]"
                  :data-sid="item.haState"
                  :style="item.styleObj"
                  v-for="item of Layers"
                  class="windowLH"
                  v-if="!(item.mark & 0x08)"
                  :key="item.num + 'key'"
                  @click.prevent="toggleClass($event, item)"
                  @dblclick="dbWindowClick($event, item, item.isF)"
                  @mousedown="down($event, item)"
                  @mousemove="move($event, item)"
                  @mouseleave="leave($event, item)"
                  @contextmenu="windowContext($event, item)"
                  @drop="windowDrop($event, item)"
                  @dragover="windowAllowDrop($event, item)"
                  @touchstart.stop.prevent="touchstartWindow($event, item, 1)"
                  @touchmove="touchmoveWindow($event, item)"
                  @touchend.stop.prevent="touchendWindow($event, item)"
                >
                  <div
                    v-show="item.isTitle"
                    style="display: flex;justify-content: space-between;align-items: center;background: #273D4F;"
                    :style="{
                      background:
                        item.styleObj.background === '#909399'
                          ? '#6d6d6d'
                          : '#273D4F'
                    }"
                    class="pointer_events_none"
                  >
                    <span style="white-space: nowrap;" class="scaleFontSize"
                      >{{ item.name
                      }}{{
                        item.haState
                          ? item.singal_flag
                            ? ""
                            : "[ " + $t("home.noSignal") + " ]"
                          : "[ " + $t("home.invalidWindow") + " ]"
                      }}</span
                    >
                    <div
                      style="display: flex;flex-wrap: nowrap;pointer-events:auto;"
                      v-if="!isMobile"
                    >
                      <svg-icon
                        v-if="item.isM"
                        style="margin-right: 5px;cursor: auto;font-size: 28px"
                        class="scaleIconSize"
                        data-colse="switchWindow"
                        @click="switchWindow(item)"
                        icon-class="huanyuan"
                        class-name="huanyuan"
                        clickTypeName="switchWindow"
                      />
                      <svg-icon
                        v-else
                        style="margin-right: 5px;cursor: auto;font-size: 28px"
                        class="scaleIconSize"
                        data-colse="switchWindow"
                        @click="switchWindow(item)"
                        icon-class="zuidahua"
                        class-name="zuidahua"
                        clickTypeName="switchWindow"
                      />
                      <svg-icon
                        style="cursor: auto;pointer-events:auto;font-size: 28px"
                        class="scaleIconSize"
                        data-colse="closeWindow"
                        @click="closeWindow(item, $event)"
                        icon-class="close2"
                        class-name="close2"
                        clickTypeName="closeWindow"
                      />
                    </div>
                  </div>
                  <span
                    :data-sid="item.haState"
                    class="pointer_events_none scaleFontSize"
                    style="white-space: nowrap;"
                    >{{ $t("home.windowSign") }} :{{ item.num }};</span
                  >
                  <br />
                  <span
                    :data-sid="item.haState"
                    class="pointer_events_none scaleFontSize"
                    style="white-space: nowrap;"
                    >{{ $t("home.stackingNumber") }} :{{ item.zIndex }};</span
                  >
                  <br />
                  <span
                    :data-sid="item.haState"
                    class="pointer_events_none scaleFontSize"
                    style="white-space: nowrap;"
                    >{{ $t("home.windowPosition") }} :({{
                      item.isM ? 0 : item.inpX
                    }},{{ item.isM ? 0 : item.inpY }});</span
                  >
                  <br />
                  <span
                    :data-sid="item.haState"
                    class="pointer_events_none scaleFontSize"
                    style="white-space: nowrap;"
                    >{{ $t("home.windowSize") }} :({{
                      item.isM ? W : item.inpW
                    }},{{ item.isM ? H : item.inpH }});</span
                  >

                  <!--                  <ZRTC :data-sid="item.haState" :ch="item.num"></ZRTC>-->

                  <!--                  <svg-->
                  <!--                    v-if="isMobile"-->
                  <!--                    style="position: absolute;bottom: 0;right: 0;transform-origin: bottom right;"-->
                  <!--                    t="1630916783870"-->
                  <!--                    class="icon scaleFontSize"-->
                  <!--                    viewBox="0 0 1024 1024"-->
                  <!--                    version="1.1"-->
                  <!--                    xmlns="http://www.w3.org/2000/svg"-->
                  <!--                    p-id="4771"-->
                  <!--                    width="64"-->
                  <!--                    height="64"-->
                  <!--                    @touchstart.stop.prevent="touchstartWindow($event, item, 2)"-->
                  <!--                  >-->
                  <!--                    <path-->
                  <!--                      d="M938.666667 938.666667 853.333333 938.666667 853.333333 853.333333 938.666667 853.333333 938.666667 938.666667M938.666667 768 853.333333 768 853.333333 682.666667 938.666667 682.666667 938.666667 768M768 938.666667 682.666667 938.666667 682.666667 853.333333 768 853.333333 768 938.666667M768 768 682.666667 768 682.666667 682.666667 768 682.666667 768 768M597.333333 938.666667 512 938.666667 512 853.333333 597.333333 853.333333 597.333333 938.666667M938.666667 597.333333 853.333333 597.333333 853.333333 512 938.666667 512 938.666667 597.333333Z"-->
                  <!--                      p-id="4772"-->
                  <!--                      fill="#ffffff"-->
                  <!--                    ></path>-->
                  <!--                  </svg>-->

                  <svg
                    v-if="isMobile"
                    style="position: absolute;bottom: 0;right: 0;transform-origin: bottom right;"
                    width="32"
                    height="32"
                    xmlns="http://www.w3.org/2000/svg"
                    @touchstart.stop.prevent="touchstartWindow($event, item, 2)"
                  >
                    <g>
                      <title>background</title>
                      <rect
                        fill="none"
                        id="canvas_background"
                        height="402"
                        width="582"
                        y="-1"
                        x="-1"
                      />
                    </g>
                    <g>
                      <title>Layer 1</title>
                      <rect
                        stroke="#ffffff"
                        id="svg_1"
                        height="5.9374"
                        width="6.1249"
                        y="13.0313"
                        x="25.1251"
                        stroke-width="1.5"
                        fill="#fff"
                      />
                      <rect
                        stroke="#ffffff"
                        id="svg_4"
                        height="5.9374"
                        width="6.1249"
                        y="23.59362"
                        x="12.93755"
                        stroke-width="1.5"
                        fill="#fff"
                      />
                      <rect
                        stroke="#ffffff"
                        id="svg_5"
                        height="5.9374"
                        width="6.1249"
                        y="13.1563"
                        x="12.93755"
                        stroke-width="1.5"
                        fill="#fff"
                      />
                      <rect
                        stroke="#ffffff"
                        id="svg_6"
                        height="5.9374"
                        width="6.1249"
                        y="4.28144"
                        x="25.1251"
                        stroke-width="1.5"
                        fill="#fff"
                      />
                      <rect
                        stroke="#ffffff"
                        id="svg_7"
                        height="5.9374"
                        width="6.1249"
                        y="23.65612"
                        x="25.1251"
                        stroke-width="1.5"
                        fill="#fff"
                      />
                      <rect
                        stroke="#ffffff"
                        id="svg_8"
                        height="5.9374"
                        width="6.1249"
                        y="23.71862"
                        x="0.75"
                        stroke-width="1.5"
                        fill="#fff"
                      />
                    </g>
                  </svg>
                </div>
              </template>
            </div>
          </template>
        </div>
        <div class="left-header">
          <!--          <el-button type="info" icon="el-icon-s-grid">预布局</el-button>-->
          <!--          <el-button type="info" icon="el-icon-full-screen">一键开窗</el-button>-->
          <el-button type="info" @click="clearScene" icon="el-icon-delete">{{
            $t("home.clearScreenButton")
          }}</el-button>
          <el-button
            v-if="isMobile"
            type="info"
            :disabled="contextItem.lock"
            @click="contextHandler('置顶')"
            >{{ $t("home.Top") }}</el-button
          >
          <el-button
            v-if="isMobile"
            type="info"
            :disabled="contextItem.lock"
            @click="contextHandler('置底')"
            >{{ $t("home.setAtTheEnd") }}</el-button
          >
          <el-button
            v-if="isMobile"
            type="info"
            :disabled="contextItem.lock ? true : contextItem.isF ? true : false"
            @click="contextHandler('放大')"
            >{{ $t("home.enlarge") }}</el-button
          >
          <el-button
            v-if="isMobile"
            type="info"
            :disabled="contextItem.lock ? true : contextItem.isF ? false : true"
            @click="contextHandler('缩小')"
            >{{ $t("home.narrow") }}</el-button
          >
          <el-button
            v-if="isMobile && contextItem.lock"
            type="info"
            @click="contextHandler('锁定', 0)"
            >{{ $t("home.unlock") }}</el-button
          >
          <el-button
            v-if="isMobile && !contextItem.lock"
            type="info"
            :disabled="contextItem.lockAll ? true : false"
            @click="contextHandler('锁定', 1)"
            >{{ $t("home.lock") }}</el-button
          >
          <el-button
            v-if="isMobile && contextItem.isM"
            type="info"
            :disabled="contextItem.lock"
            @click="contextHandler('全屏', 0)"
            >{{ $t("home.cancelFullScreen") }}</el-button
          >
          <el-button
            v-if="isMobile && !contextItem.isM"
            type="info"
            :disabled="contextItem.lock"
            @click="contextHandler('全屏', 1)"
            >{{ $t("home.fullScreen") }}</el-button
          >
          <el-button
            v-if="isMobile"
            type="info"
            :disabled="contextItem.lock"
            @click="contextHandler('属性')"
            >{{ $t("home.property") }}</el-button
          >
          <el-button
            v-if="isMobile"
            type="info"
            :disabled="contextItem.lock"
            @click="contextHandler('关闭')"
            >{{ $t("home.close") }}</el-button
          >
          <miniview
            :out-warp="'#centerTop'"
            :in-warp="'#ptngridwarp0'"
          ></miniview>
        </div>

        <!--        <div class="center-bottom">-->
        <!--          <div-->
        <!--            class="center-bottom-item cursorDefault"-->
        <!--            :key="item.index"-->
        <!--            v-for="item of videoList"-->
        <!--            @drop="videoDrop($event, item)"-->
        <!--            @dragover="videoDragover($event, item)"-->
        <!--          >-->
        <!--            &lt;!&ndash;            <svg-icon v-if="item.in" @click.stop="closeVideo(item)" icon-class="close"  class-name='videoCloseClass' />&ndash;&gt;-->
        <!--            &lt;!&ndash;            <websocket v-if="item.in" :in="item.in"></websocket>&ndash;&gt;-->
        <!--            &lt;!&ndash;            <span v-else>视频预览{{item.index}}</span>&ndash;&gt;-->
        <!--            <span>视频预览{{ item.index }}</span>-->
        <!--          </div>-->
        <!--          &lt;!&ndash;          <div class="center-bottom-item cursorDefault">&ndash;&gt;-->
        <!--          &lt;!&ndash;            <websocket :in="1"></websocket>&ndash;&gt;-->
        <!--          &lt;!&ndash;          </div>&ndash;&gt;-->
        <!--          &lt;!&ndash;          <div class="center-bottom-item cursorDefault">视频预览2</div>&ndash;&gt;-->
        <!--          &lt;!&ndash;          <div class="center-bottom-item cursorDefault">视频预览3</div>&ndash;&gt;-->
        <!--          &lt;!&ndash;          <div class="center-bottom-item cursorDefault">视频预览4</div>&ndash;&gt;-->
        <!--        </div>-->
      </div>
      <div class="right" data-html2canvas-ignore="true">
        <p class="scene-button cursorDefault">{{ $t("home.outList") }}</p>
        <ul class="scene-ul scrollbar" id="scene_ul">
          <!--          active-->
          <template v-if="sceneList.length">
            <div
              v-for="item of sceneList"
              :key="item.sID"
              :id="`scene_ul_li${item.sID}`"
              :title="item.name ? item.name : `${$t('home.scenes') + item.sID}`"
            >
              <li
                ref="sceneULi"
                :class="['scene-ul-li', item.sID === activeSID ? 'active' : '']"
                @click="selectSceneULiDialog(item)"
              >
                <img
                  :src="item.localImg"
                  draggable="false"
                  @dragstart.stop.prevent="imgfalse"
                  class="elimg"
                />
              </li>
              <span :data-sid="item.sID" class="span cursorDefault"
                >{{ item.name ? item.name : `场景${item.sID}` }}
                <!-- : {{item.sID}}--></span
              >
            </div>
          </template>
        </ul>
        <div class="button-list">
          <button
            class="button-list-item"
            :disabled="dialog.poll.form.en === 1"
            @click="saveSceneDialog"
          >
            {{ $t("home.saveSceneButton") }}
          </button>
          <button class="button-list-item" @click="pollDialog">
            {{ $t("home.scenePollingButton") }}
          </button>
          <button
            class="button-list-item"
            :disabled="dialog.poll.form.en === 1"
            @click="delSceneAll"
          >
            {{ $t("home.deleteAllButton") }}
          </button>
        </div>
      </div>
    </div>

    <!--场景轮询弹窗-->
    <el-dialog
      :title="$t('home.scenePollingSettings')"
      :visible.sync="dialog.poll.visible"
      width="40%"
      :close-on-click-modal="false"
    >
      <el-form
        ref="pollform"
        :model="dialog.poll.form"
        :rules="pollRules"
        label-width="250px"
        label-position="left"
      >
        <el-form-item
          :label="$t('home.pleaseSelectAPollingScene') + '：'"
          prop="Id_group"
        >
          <el-checkbox v-model="allCheckStae" @change="allCheckChange"
            >全选</el-checkbox
          >
          <el-checkbox-group v-model="dialog.poll.form.Id_group">
            <el-checkbox
              v-for="i of sceneList.length && sceneList"
              :label="i.sID"
              :key="i.sID"
              @change="oneCheckChange"
              name="type"
              >{{ i.name }}
            </el-checkbox>
          </el-checkbox-group>
        </el-form-item>
        <el-form-item :label="$t('home.pollingInterval') + '(s)：'">
          <el-slider
            v-if="dialog.poll.visible"
            v-model="dialog.poll.form.period"
            :min="5"
            :max="120"
          />
        </el-form-item>
        <el-form-item :label="$t('home.scenePollingSwitch') + '：'">
          <el-switch
            v-model="dialog.poll.form.en"
            @change="sceneSwitch"
            :active-value="1"
            :inactive-value="0"
            active-color="#13ce66"
            inactive-color="#ff4949"
          />
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialog.poll.visible = false">{{
          $t("home.cancel")
        }}</el-button>
        <el-button type="primary" @click="dialogPollEnter">{{
          $t("home.enter")
        }}</el-button>
      </span>
    </el-dialog>
    <!--    场景预览弹窗-->
    <el-dialog
      :title="dialog.scene.title"
      center
      :visible.sync="dialog.scene.visible"
      width="30%"
    >
      <!--      <img :src="dialog.scene.form.dataurl" style="width: 100%;height: 100%" alt="">-->
      <el-image
        style="height: 300px"
        :src="dialog.scene.form.dataurl"
        :preview-src-list="[dialog.scene.form.dataurl]"
      >
      </el-image>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialog.scene.visible = false">{{
          $t("home.cancel")
        }}</el-button>
        <el-button type="primary" @click="dialogSceneUse">{{
          $t("home.transfer")
        }}</el-button>
        <el-button type="danger" @click="dialogSceneDell">{{
          $t("home.delete")
        }}</el-button>
        <el-button type="primary" @click="dialogSceneRename">{{
          $t("home.rename")
        }}</el-button>
      </span>
    </el-dialog>

    <!--保存场景的弹框-->
    <el-dialog
      :title="$t('home.saveSceneDialogTip')"
      :visible.sync="dialog.addpoll.visible"
      width="30%"
      :close-on-click-modal="false"
    >
      <el-form
        ref="addpollform"
        :model="dialog.addpoll.form"
        :rules="rules"
        label-width="130px"
        label-position="left"
      >
        <el-form-item
          :label="$t('home.saveSceneDialogName') + ':'"
          prop="Scene_name"
        >
          <el-input v-model="dialog.addpoll.form.Scene_name"></el-input>
        </el-form-item>
        <el-form-item :label="$t('home.saveSceneDialogID') + ':'" prop="Id">
          <el-select
            v-model.number="dialog.addpoll.form.Id"
            placeholder="请选择场景编号"
          >
            <el-option
              :label="index"
              :value="index"
              :key="index"
              v-for="(item, index) of pollNumList"
            ></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialog.addpoll.visible = false">{{
          $t("home.cancel")
        }}</el-button>
        <el-button type="primary" @click="dialogAddpollEnter">{{
          $t("home.enter")
        }}</el-button>
      </span>
    </el-dialog>
    <!--窗体属性弹窗-->
    <el-dialog
      :title="$t('home.formProperties')"
      :visible.sync="dialogWindow.visible"
      width="30%"
      :close-on-click-modal="false"
    >
      <el-form ref="form" :model="dialogWindow.form" label-width="100px">
        <el-form-item :label="$t('home.titleSwitch')">
          <el-switch
            v-model="dialogWindow.form.isTitle"
            active-color="#13ce66"
            :active-value="1"
            inactive-color="#ff4949"
            :inactive-value="0"
          >
          </el-switch>
        </el-form-item>
        <el-form-item :label="$t('home.windowCoordinates')">
          <el-input v-model="dialogWindow.form.X" type="number" size="mini"
            ><span slot="prepend">X:</span></el-input
          >
          <el-input v-model="dialogWindow.form.Y" type="number" size="mini"
            ><span slot="prepend">Y:</span></el-input
          >
        </el-form-item>

        <el-form-item :label="$t('home.windowSize')">
          <el-input v-model="dialogWindow.form.W" type="number" size="mini"
            ><span slot="prepend">{{ $t("home.wide") }}:</span></el-input
          >
          <el-input v-model="dialogWindow.form.H" type="number" size="mini"
            ><span slot="prepend">{{ $t("home.high") }}:</span></el-input
          >
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogWindow.visible = false">{{
          $t("home.cancel")
        }}</el-button>
        <el-button type="primary" @click="dialogWindowEnter">{{
          $t("home.enter")
        }}</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import {
  CardDetailApi,
  SendInOutSeatApi,
  SyncSceneApi,
  scene_saveApi,
  getScenceDataApi,
  scene_callApi,
  scene_delApi,
  scene_rotateApi,
  scene_rotate_argsApi,
  scene_pollingApi,
  windowOpenApi,
  windowChngApi,
  windowNewChangeApi,
  windowMoveApi,
  windowCloseApi,
  syncWindowApi,
  windowLayerControlApi,
  windowAttriConfigApi,
  windowClearApi,
  getInputCardListApi,
  getOutCardListApi,
  windowInChangeApi
} from "@/api/home";
import html2canvas from "html2canvas";

import {
  sw,
  getStyle,
  Notification,
  scene_save,
  scene_del,
  rename_scene,
  scene_rotate
} from "@/utils/index.js";
// import websocket from "@/components/websocket";
import {
  ginfo_syncApi,
  groupRenameApi,
  settingCgrpApi,
  timingInfoApi
} from "@/api/SplicingSettings";
import VueContextMenu from "@/components/contextmen/index.vue";
// import ZRTC from "@/components/rtc/index.vue";
import miniview from "@/components/miniview/index.vue";
import {
  initWebSocket,
  websocketsend,
  WS,
  onOffer,
  WSNULL,
  globalCallback
} from "@/utils/ws";
import { orderBy, uniqBy, remove } from "lodash";
import i18n from "@/lang";
Promise.allSettled =
  Promise.allSettled ||
  function(promises) {
    return new Promise(function(resolve, reject) {
      if (!Array.isArray(promises)) {
        return reject(new TypeError("arguments must be an array"));
      }
      var resolvedCounter = 0;
      var promiseNum = promises.length;
      var resolvedValues = new Array(promiseNum);
      for (var i = 0; i < promiseNum; i++) {
        (function(i) {
          Promise.resolve(promises[i]).then(
            function(value) {
              resolvedCounter++;
              resolvedValues[i] = value;
              if (resolvedCounter == promiseNum) {
                return resolve(resolvedValues);
              }
            },
            function(reason) {
              resolvedCounter++;
              resolvedValues[i] = reason;
              if (resolvedCounter == promiseNum) {
                return reject(reason);
              }
            }
          );
        })(i);
      }
    });
  };

Array.prototype.flat =
  Array.prototype.flat ||
  function(count) {
    let c = count || 1;
    let len = this.length;
    let ret = [];
    if (this.length == 0) return this;
    while (c--) {
      let _arr = [];
      let flag = false;
      if (ret.length == 0) {
        flag = true;
        for (let i = 0; i < len; i++) {
          if (this[i] instanceof Array) {
            ret.push(...this[i]);
          } else {
            ret.push(this[i]);
          }
        }
      } else {
        for (let i = 0; i < ret.length; i++) {
          if (ret[i] instanceof Array) {
            flag = true;
            _arr.push(...ret[i]);
          } else {
            _arr.push(ret[i]);
          }
        }
        ret = _arr;
      }
      if (!flag && c == Infinity) {
        break;
      }
    }
    return ret;
  };
const inputValidatorGroupRename = value => !!value; // 判断非空
export default {
  name: "Index",
  components: {
    // ZRTC,
    // websocket,
    VueContextMenu,
    miniview
  },
  data() {
    var validateId = (rule, value, callback) => {
      console.log(value, "选择的场景编号");
      let i = this.sceneList.filter(item => item.sID === value);
      if (i.length) {
        callback(new Error(`编号为${value}的场景已存在,继续提交将替换此场景`));
      } else {
        // if (this.dialog.addpoll.form.Id !== '') {
        //   this.$refs.addpollform.validateField('Id');
        // }
        callback();
      }
    };
    return {
      // 宫格区域外围宽高
      WarpWidth: 0,
      WarpHeight: 0,
      // 点击分组的loading
      handleClickLoading: null,
      // abcd拖拽的内容
      evData: null,
      // 全选状态
      allCheckStae: false,
      // 模拟双击
      touchStartTime: 0,
      // 是否为移动端
      // isMobile: window.navigator.userAgent.match(
      //   /(Intel Mac|phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|IEMobile|MQQBrowser|JUC|Fennec|wOSBrowser|BrowserNG|WebOS|Symbian|Windows Phone)/i
      // ),
      isMobile: "ontouchstart" in document.documentElement,
      // touchstartWindow 是否已经触摸了一个窗
      istouchstartWindow: false,
      // 分组ID范围
      gidRangList: {
        1: 0,
        2: 4000,
        3: 8000,
        4: 12000
      },
      // 分组列表
      GroupContext: [],
      // 屏幕类型列表
      gTypeList: {
        1: "LCD",
        2: "LED"
      },
      // 当前分组
      gid: null,
      Rows: null,
      Cols: null,
      GridTwoArray: [], // 宫格的二维数组 坐标
      GridLJArray: [], // 逻辑子屏的数组 坐标
      omap: [],
      haveOUTArray: [], // 黑块
      isMove: false, // 是否正在移动
      isNewMove: false, // 是否正在移动 new
      // 图层列表
      Layers: [],
      // 全屏时关闭的窗口ID
      closeWindowID: [],
      // 当前BOX的宽高以及xy
      inpW: 0,
      inpH: 0,
      inpX: 0,
      inpY: 0,
      boxEdit: null,
      acitveDom: null,
      flag: null,
      index: 9000,
      num: 0,
      // 视频预览列表
      videoList: {
        1: {
          index: 1,
          in: null
        },
        2: {
          index: 2,
          in: null
        },
        3: {
          index: 3,
          in: null
        },
        4: {
          index: 4,
          in: null
        }
      },
      // 卡板类型名字
      NameList: {
        1: "HDMI",
        4: "VGA",
        23: "DP4K",
        17: "HDMI4K",
        24: "HDMI4K60_",
        10: "HDMI",
        11: "DVI_VS",
        58: "HDMI",
        59: "DVI",
        49: "HDMI",
        100: "HDMI",
        101: "HDMI",
        102: "HDMI",
        3: "CVBS",
        51: "HDBT",
        2: "DVI",
        50: "DVI",
        81: "HDMI4_",
        82: "DVI4_",
        6: "SDI",
        53: "SDI"
      },
      permit: null, // 用户权限
      // 输入卡的列表
      inList: {
        1: "",
        2: "",
        3: "",
        4: "",
        5: "",
        6: "",
        7: "",
        8: "",
        9: "",
        10: "",
        11: "",
        12: "",
        13: "",
        14: "",
        15: "",
        16: "",
        17: "",
        18: "",
        19: "",
        20: "",
        21: "",
        22: "",
        23: "",
        24: "",
        25: "",
        26: "",
        27: "",
        28: "",
        29: "",
        30: "",
        31: "",
        32: "",
        33: "",
        34: "",
        35: "",
        36: "",
        37: "",
        38: "",
        39: "",
        40: ""
      },
      // 搜索输入卡的输入框
      searchInCardInput: "",
      // 当前活动窗体ID
      activeSID: "",
      // 映射关系里面有几个输出卡
      hasOutListLength: 0,
      // 是否手动调用场景
      isScene_call: false,
      // 是否web调用场景
      isWebSwitch: false,
      // 右键菜单显示状态
      contextMenuVisible: false,
      contextMenuTarget: document.body,
      contextItem: {},
      windowTarget: null, //当前窗体的ev
      loading: null, // 输出宫格区域的loading
      // 窗体属性弹窗
      dialogWindow: {
        visible: false,
        form: {
          isTitle: 0,
          X: 0,
          Y: 0,
          W: 0,
          H: 0
        }
      },
      // 场景截图数据
      dataurl: "",
      subCardNum: 16,
      // 横向缩放比
      Wrate: 1,
      // 纵向缩放比
      Hrate: 1,
      // 水平间距
      hgap: 0,
      // 垂直间距
      vgap: 0,
      // 最小宽度
      minWidth: 160,
      // 最小高度
      minHeight: 80,
      W: "",
      H: "",
      H_ACTIVE: "",
      V_ACTIVE: "",

      // 轮播图的index
      initial_index: 0,
      // 屏幕数量
      SencenNum: 1,
      // 输入输出卡映射关系表
      CardINOUTList: {
        1: "1_0",
        2: "1_1",
        3: "2_0",
        4: "2_1",
        5: "3_0",
        6: "3_1",
        7: "4_0",
        8: "4_1",
        9: "5_0",
        10: "5_1",
        11: "6_0",
        12: "6_1",
        13: "7_0",
        14: "7_1",
        15: "8_0",
        16: "8_1",
        17: "9_0",
        18: "9_1",
        19: "10_0",
        20: "10_1",
        21: "11_0",
        22: "11_1",
        23: "12_0",
        24: "12_1",
        25: "13_0",
        26: "13_1",
        27: "14_0",
        28: "14_1",
        29: "15_0",
        30: "15_1",
        31: "16_0",
        32: "16_1",
        33: "17_0",
        34: "17_1",
        35: "18_0",
        36: "18_1",
        37: "19_0",
        38: "19_1",
        39: "20_0",
        40: "20_1",
        41: "21_0",
        42: "21_1",
        43: "22_0",
        44: "22_1",
        45: "23_0",
        46: "23_1",
        47: "24_0",
        48: "24_1",
        49: "25_0",
        50: "25_1",
        51: "26_0",
        52: "26_1",
        53: "27_0",
        54: "27_1",
        55: "28_0",
        56: "28_1",
        57: "29_0",
        58: "29_1",
        59: "30_0",
        60: "30_1",
        61: "31_0",
        62: "31_1",
        63: "32_0",
        64: "32_1"
      },
      // 有效无效映射
      haStateList: {
        0: 1,
        1: 1,
        2: 0
      },
      // 空屏幕数据
      GridArray: {
        // 1: {
        //   import: '', // 输入卡的名字
        //   importCh: '', // 输入卡的ID
        //   output: '', // 输出卡的名字
        //   outputCh: '', // 输出卡的ID
        //   handleClass: '', // 当前的背景色class    .out表示已经插入输出卡  .active 输入卡已经拖入输出卡位置
        //   singal_flagClass: '',
        //   hpd_link: '', card_type: ''
        // }
      },
      // 板卡标识符列表
      cardTAGList: [],
      // 输入卡列表包含详情的
      cardImportListDetails: [],
      cardImportListDetailsCopy: {},
      // 正在拖动的输入板卡序号
      handleCh: "",
      handleChCopy: "",
      // 正在拖动的输入板卡的名字   rename或者板卡类型加上序号
      handleChName: "",
      // 正在托工的输入卡是否有信号
      handleSingal_flag: "",
      handleVsrc_clip_style: 0,
      // 输出卡列表包含详情的
      cardOutputListDetails: [],
      cardOutputChList: [],
      // 场景列表
      sceneList: [],
      // 场景ID列表
      sceneIDList: [],
      rules: {
        Id: [{ validator: validateId, trigger: "change" }],
        Scene_name: [
          { required: true, message: "请输入场景名称", trigger: "change" },
          {
            min: 3,
            max: 10,
            message: "长度在 3 到 10 个字符",
            trigger: "change"
          }
        ]
      },
      pollRules: {
        Id_group: [
          {
            type: "array",
            required: true,
            message: "请选择场景",
            trigger: "change"
          }
        ]
      },
      // 弹窗
      dialog: {
        poll: {
          // 场景轮询弹窗数据
          visible: false,
          form: {
            Id_group: [],
            period: 10,
            en: 0 // 场景轮询开关   0关 1开
          }
        },
        scene: {
          visible: false,
          title: "",
          form: {
            sid: "",
            name: "",
            dataurl: "",
            sw: []
          }
        },
        addpoll: {
          visible: false,
          title: "",
          form: {
            Scene_name: "",
            Id: ""
          }
        },
        dellAll: {
          visible: false,
          form: {
            Id: ""
          }
        }
      },
      // 场景数值列表
      pollNumList: {}
    };
  },
  computed: {
    sortList() {
      return this.sortByKey(this.cardTAGList, "ch"); //将数组中的数据按照ch进行排序
    }
  },
  created() {
    if (!WS) {
      initWebSocket();
    }
  },
  mounted() {
    // websocketsend(`(info,report,0)\r\n`, res => {
    //   console.log("上报开关的响应数据：", res);
    // });
    // const s = setTimeout(function() {
    //   websocketsend(`(info,report,1)\r\n`, res => {
    //     console.log("上报开关的响应数据：", res);
    //   });
    //   clearTimeout(s);
    // }, 15000);
    const _this = this;
    this.boxEdit = this.$refs[`ptngridwarp${_this.initial_index}`][0];
    // console.log(this.boxEdit,'this.boxEdit')
    this.permit = parseInt(localStorage.getItem("permit"));
    this.subCardNum = parseInt(localStorage.getItem("subCardNum"));

    // console.log(this.permit,'this.permit')

    _this.getList();
    // _this.getscene_polling()
    // _this.getSyncScene();
    // setTimeout(function() {
    //   _this.getSyncScene()
    // },1000)

    // this.socketApi.sendSock({}, data => {
    //   console.log("websocket接收的数据home：", data);
    //   // 先判断是插卡还是拔卡   再判断输入卡还是输出卡
    //   // 拔卡 type为0  不为0 是插卡     根据ch获取详情 判断card_type判断 1是输入卡 2是输出卡
    //   // 如果是插卡并且是输出卡  则改变屏幕对应位置上的背景颜色为out和输出卡名字
    //   // 如果是插卡并且是输入卡   则在输入列表添加插入的卡 并且判断是否有信号
    //
    //   // 插拔卡信息 拔信号
    //   if (data.status_refresh) {
    //     data.status_refresh.list.forEach(b => {
    //       const ch = Number(b.ch);
    //       if (!b.card_type) {
    //         // 拔卡
    //
    //         for (const i in _this.inList) {
    //           if (_this.inList[i].ch === ch) {
    //             _this.inList[i] = "";
    //           }
    //         }
    //         // for (const i in _this.GridArray) {
    //         //   if (parseInt(_this.GridArray[i].outputCh.split('_')[0]) === ch) {
    //         //     for (const j in _this.GridArray[i]) {
    //         //       // TODO: 拼控版本不让拔卡
    //         //       // _this.GridArray[i][j] = ''
    //         //     }
    //         //   }
    //         // }
    //       } else {
    //         // 插卡
    //
    //         // 插入输入端口
    //         if (
    //           b.card_type === 1 ||
    //           b.card_type === 3 ||
    //           b.card_type === 2 ||
    //           b.card_type === 5
    //         ) {
    //           // 输入卡
    //           _this.inListInsert(ch, b);
    //         }
    //
    //         // 插拔信号
    //         if (_this.inList[ch]) {
    //           // in
    //           _this.inList[ch].singal_flag = b.singal_flag ? "singal_flag" : "";
    //           for (let j in _this.GridArray) {
    //             if (_this.GridArray[j].importCh == b.ch) {
    //               _this.GridArray[j].singal_flagClass = b.singal_flag
    //                 ? "singal_flag"
    //                 : "";
    //             }
    //           }
    //           // 更新已经开窗了的输入端口信号源标识
    //           _this.Layers.forEach(item => {
    //             if (item.Vsrc_CH == b.ch) {
    //               item.singal_flag = b.singal_flag ? 1 : 0;
    //             }
    //           });
    //         }
    //       }
    //     });
    //   }
    //   // 接收到的当前正在轮询的场景数据
    //   if (data.Cmd === "scene") {
    //     if (_this.isScene_call) {
    //       // 如果是手动调用场景则不进行渲染
    //       _this.isScene_call = false;
    //       return false;
    //     }
    //     // 之清空蓝色对应关系
    //     _this.clearOnlyBlue();
    //     const sceneData = data.scene;
    //     const inout = sceneData.inout;
    //     const index = sceneData.index;
    //     const group = sceneData.group;
    //     _this.activeSID = index;
    //     const sceneAfter = {};
    //     // 正确的映射关系
    //     // let b=[0,0,0,0,0,0,0,0,0,0,0,0,5,6,11,11,11,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    //     let b = inout;
    //     b.forEach((i, index) => {
    //       if (i < 64 && i) {
    //         // 建立映射关系   sceneAfter里面的key就是输出卡ch 也是屏幕位置序号    value是输入卡ch
    //         sceneAfter[index + 1] = i;
    //       }
    //     });
    //     console.log(sceneAfter, "推送的sceneAfter");
    //     const C = []; // 当前已经插入的卡
    //     _this.cardTAGList.forEach(ite => {
    //       C.push(ite.ch);
    //     });
    //     for (const i in sceneAfter) {
    //       // let GridInIndex
    //       let GridOutIndex;
    //       for (let GridI in this.GridArray) {
    //         // if (this.GridArray[GridI].importCh===this.CardINOUTList[this.dialog.scene.form.sw[i]]){
    //         //   GridInIndex=GridI
    //         // }
    //         if (
    //           this.GridArray[GridI].outputCh === this.CardINOUTList[Number(i)]
    //         ) {
    //           GridOutIndex = GridI;
    //         }
    //         // console.log(this.GridArray[GridI].importCh,'this.GridArray[GridI].importCh')
    //         // console.log(this.GridArray[GridI].outputCh,'this.GridArray[GridI].outputCh')
    //       }
    //       let outIndexString = this.CardINOUTList[Number(i)];
    //       let outIndex = this.CardINOUTList[Number(i)].split("_")[0];
    //       let inIndexString = this.CardINOUTList[sceneAfter[i]];
    //       let inIndex = this.CardINOUTList[sceneAfter[i]].split("_")[0];
    //
    //       // console.log(GridOutIndex,'GridOutIndex')
    //       // console.log(_this.GridArray,'_this.GridArray')
    //       // console.log(_this.GridArray[GridOutIndex],'_this.GridArray[GridOutIndex]')
    //
    //       _this.GridArray[GridOutIndex].importCh = inIndexString;
    //       if (C.includes(Number(outIndex))) {
    //         // 背景颜色以输出卡为准 已经插卡的输出卡为蓝色 没插的为灰色
    //         _this.GridArray[GridOutIndex].handleClass = "active";
    //         _this.GridArray[GridOutIndex].outputCh = outIndexString;
    //       } else {
    //         _this.GridArray[GridOutIndex].handleClass = "";
    //       }
    //
    //       // 获取输出卡的详情
    //       CardDetailApi({ cmd: "CardInfo", cardIndex: Number(outIndex) }).then(
    //         out => {
    //           if (C.includes(Number(outIndex))) {
    //             _this.GridArray[GridOutIndex].output = out.list.rename
    //               ? out.list.rename
    //               : `${_this.NameList[out.list.card_type] + outIndexString}`;
    //           } else {
    //             _this.GridArray[GridOutIndex].output = out.list.rename
    //               ? out.list.rename
    //               : `${_this.NameList[out.list.card_type] + outIndexString}` +
    //                 ":已拔卡";
    //           }
    //         }
    //       );
    //       // 获取输入卡的详情，得到名字 是否有信号
    //       CardDetailApi({ cmd: "CardInfo", cardIndex: Number(inIndex) }).then(
    //         in_item => {
    //           if (C.includes(Number(inIndex))) {
    //             // 输入卡的名字
    //             _this.GridArray[GridOutIndex].import = in_item.list.rename
    //               ? in_item.list.rename
    //               : `${_this.NameList[in_item.list.card_type] + inIndexString}`;
    //             // 输入卡有无信号
    //             if (in_item.list.singal_flag) {
    //               _this.GridArray[GridOutIndex].singal_flagClass =
    //                 "singal_flag";
    //             }
    //           } else {
    //             _this.GridArray[GridOutIndex].import = in_item.list.rename
    //               ? in_item.list.rename
    //               : `${_this.NameList[in_item.list.card_type] +
    //                   inIndexString}` + ":已拔卡";
    //             if (in_item.list.singal_flag) {
    //               _this.GridArray[GridOutIndex].singal_flagClass =
    //                 "singal_flag";
    //             }
    //           }
    //         }
    //       );
    //     }
    //   }
    //   // 背板指令推送
    //   if (data.Cmd === "sw") {
    //     const swData = sw(data.data);
    //     console.log(swData, "swData");
    //     const input = swData.input;
    //     if (swData.type === "input_switch_output") {
    //       // 输入卡X 切换到 对应的输出卡
    //       const output = swData.output;
    //       let input_index;
    //       let input_port;
    //       // 判断input是否带端口
    //       if (input.indexOf("-") > 0) {
    //         // 带端口
    //         input_index = input.split("-")[0];
    //         input_port = input.split("-")[1] === "a" ? 0 : 1;
    //       } else {
    //         // 不带端口
    //         input_index = parseInt(input);
    //         input_port = 0;
    //       }
    //
    //       console.log(output, input_index, input_port, "输入卡id和端口");
    //       CardDetailApi({
    //         cmd: "CardInfo",
    //         cardIndex: Number(input_index)
    //       }).then(res => {
    //         output.forEach(i => {
    //           let i_index;
    //           let i_port;
    //           // 判断输出ch是否带端口
    //           if (i.indexOf("-") > 0) {
    //             // 带端口
    //             i_index = i.split("-")[0];
    //             i_port = i.split("-")[1] === "a" ? 0 : 1;
    //           } else {
    //             // 不带端口
    //             i_index = parseInt(i);
    //             i_port = 0;
    //           }
    //
    //           console.log(i, i_index, i_port, "输出卡id和端口");
    //           let importGridIndex;
    //           for (let j in _this.GridArray) {
    //             if (_this.GridArray[j].outputCh === `${i_index}_${i_port}`) {
    //               importGridIndex = j;
    //               // console.log(importGridIndex,'importGridIndex')
    //             }
    //           }
    //
    //           let in_res;
    //           if (res.list.port) {
    //             // 输入卡是双通道
    //             in_res = res.list.port[input_port];
    //           } else {
    //             // 输入卡是单通道
    //             in_res = res.list;
    //           }
    //
    //           if (_this.cardOutputChList.includes(Number(i_index))) {
    //             _this.GridArray[Number(importGridIndex)].handleClass = "active";
    //             _this.GridArray[Number(importGridIndex)].import = in_res.rename
    //               ? in_res.rename
    //               : `${_this.NameList[in_res.card_type] +
    //                   `${input_index}_${input_port}`}`;
    //             _this.GridArray[
    //               Number(importGridIndex)
    //             ].importCh = `${input_index}_${input_port}`;
    //             console.log(in_res.singal_flag, "in_res.singal_flag");
    //             if (in_res.singal_flag) {
    //               _this.GridArray[Number(importGridIndex)].singal_flagClass =
    //                 "singal_flag";
    //             } else {
    //               _this.GridArray[Number(importGridIndex)].singal_flagClass =
    //                 "";
    //             }
    //           }
    //         });
    //       });
    //     }
    //     if (swData.type === "c") {
    //       //  关掉所有输入卡X
    //       for (const i in _this.GridArray) {
    //         if (_this.GridArray[i].importCh == parseInt(input)) {
    //           _this.GridArray[parseInt(i)].handleClass = "out";
    //           _this.GridArray[parseInt(i)].import = "";
    //           _this.GridArray[parseInt(i)].importCh = "";
    //           _this.GridArray[parseInt(i)].singal_flagClass = "";
    //         }
    //       }
    //     }
    //     // (sw,0,12)
    //     if (swData.type === "close_output") {
    //       swData.output.forEach(i => {
    //         let out_index = i.split("-")[0];
    //         let out_port =
    //           i.indexOf("-") > 0 ? (i.split("-")[1] === "a" ? 0 : 1) : 0;
    //         console.log(out_index, "out_index");
    //         console.log(out_port, "out_port");
    //         console.log(_this.GridArray, "_this.GridArray");
    //         if (out_index) {
    //           let outGridIndex;
    //           for (let j in _this.GridArray) {
    //             if (
    //               _this.GridArray[j].outputCh === `${out_index}_${out_port}`
    //             ) {
    //               outGridIndex = j;
    //             }
    //           }
    //           console.log(outGridIndex, "outGridIndex");
    //           console.log(_this.cardOutputChList, "_this.cardOutputChList");
    //           if (_this.cardOutputChList.includes(Number(out_index))) {
    //             _this.GridArray[outGridIndex].import = "";
    //             _this.GridArray[outGridIndex].importCh = "";
    //             _this.GridArray[outGridIndex].handleClass = "out";
    //             _this.GridArray[outGridIndex].singal_flagClass = "";
    //           }
    //         }
    //       });
    //     }
    //
    //     if (swData.type === "a") {
    //       //  所有已经插入的输出卡切换到输入卡X
    //       CardDetailApi({ cmd: "CardInfo", cardIndex: Number(input) }).then(
    //         res => {
    //           for (const i in _this.GridArray) {
    //             if (_this.GridArray[i].output) {
    //               // 有输出卡的时候
    //               _this.GridArray[Number(i)].handleClass = "active";
    //               _this.GridArray[Number(i)].import = res.list.rename
    //                 ? res.list.rename
    //                 : `${_this.NameList[res.list.card_type] + res.list.ch}`;
    //               _this.GridArray[Number(i)].importCh = Number(input);
    //               if (res.list.singal_flag) {
    //                 _this.GridArray[Number(i)].singal_flagClass = "singal_flag";
    //               }
    //             }
    //           }
    //         }
    //       );
    //     }
    //     // 清空屏幕指令
    //     if (swData.type === "close_all") {
    //       for (const i in _this.GridArray) {
    //         for (const j in _this.GridArray[i]) {
    //           _this.GridArray[i].import = "";
    //           _this.GridArray[i].importCh = "";
    //           if (_this.GridArray[i].outputCh) {
    //             _this.GridArray[i].handleClass = "out";
    //           } else {
    //             _this.GridArray[i].output = "";
    //           }
    //           _this.GridArray[i].singal_flagClass = "";
    //         }
    //       }
    //     }
    //   }
    //   // 保存场景同步
    //   if (data.Cmd === "scene_save") {
    //     const scene_saveData = scene_save(data.data);
    //     console.log(scene_saveData, "scene_saveData");
    //     if (_this.isWebSwitch) {
    //       _this.isWebSwitch = false;
    //       return false;
    //     }
    //     _this.setImage().then(r => {
    //       if (r) {
    //         scene_saveApi({
    //           cmd: "scene_save",
    //           Group: _this.gid,
    //           Id: parseInt(scene_saveData.sceneId),
    //           dataurl: _this.dataurl,
    //           Scene_name: scene_saveData.sceneName
    //         }).then(res => {
    //           _this.getSyncScene();
    //         });
    //       }
    //     });
    //     // _this.sceneList.push({
    //     //   name:scene_saveData.sceneName,
    //     //   sID: scene_saveData.sceneId,
    //     //   dataurl: '',
    //     // })
    //   }
    //   // 删除场景同步
    //   if (data.Cmd === "scene_del") {
    //     const scene_delData = scene_del(data.data);
    //     console.log(scene_delData, "scene_delData");
    //     if (scene_delData.type === "clearOne") {
    //       // clearOne删除单个场景  clearAll清空场景
    //       _this.sceneList.forEach((item, index) => {
    //         if (item.sID == scene_delData.sceneId) {
    //           _this.sceneList.splice(index, 1);
    //         }
    //       });
    //     } else {
    //       _this.sceneList = [];
    //     }
    //   }
    //   // 场景重命名 rename_scene
    //   if (data.Cmd === "rename_scene") {
    //     const rename_sceneData = rename_scene(data.data);
    //     let i = _this.sceneList.filter(
    //       item => item.sID == rename_sceneData.sceneId
    //     );
    //     _this.sceneList.forEach(item => {
    //       if (item.sID == rename_sceneData.sceneId) {
    //         item.name = rename_sceneData.sceneName;
    //       }
    //     });
    //     console.log(i, "iii");
    //   }
    //   // 场景保存 开关同步
    //   if (data.Cmd === "scene_rotate") {
    //     const scene_rotateData = scene_rotate(data.data);
    //     // 是否WEB调用，如果是，则不用解析此刻的指令
    //     if (_this.isWebSwitch) {
    //       _this.isWebSwitch = false;
    //       return false;
    //     }
    //     _this.dialog.poll.form.en = parseInt(scene_rotateData.switchState);
    //   }
    //   // 拼控场景同步
    //   if (data.Cmd === "sceneInfo") {
    //     let { gId, sId, sceneWndInfo } = data.sceneInfo;
    //     this.Layers = [];
    //     let layouts = sceneWndInfo.map(item => {
    //       return {
    //         styleObj: {
    //           width: `${item.w * _this.Wrate}px`,
    //           height: `${item.h * _this.Hrate}px`,
    //           position: "absolute",
    //           background: _this.CreateColor(item.wID % 36, 36),
    //           left: `${item.x * _this.Wrate}px`,
    //           top: `${item.y * _this.Hrate}px`,
    //           zIndex: item.order,
    //           "min-width": "160px",
    //           "min-height": "80px"
    //         },
    //         inpW: item.w,
    //         inpH: item.h,
    //         inpX: item.x,
    //         inpY: item.y,
    //         zIndex: item.order, // 叠放序号
    //         num: item.wID, // 窗口标志
    //         name: _this.CardINOUTList[item.in_ch],
    //         singal_flag: 0, // 有无信号
    //         // haState: _this.haStateList[item.flag], // 窗体是否有效 0 无效 1有效 默认0; 对应flag 0 灰色 1正常 2wu无效
    //         haState: 1, // 窗体是否有效 0 无效 1有效 默认0; 对应flag 0 灰色 1正常 2wu无效
    //         isM: false, // 是否最大化满屏 默认false
    //         isW: false, // 是否无效窗口 默认false
    //         isF: false, // 是否放大 默认false
    //         contextMenuVisible: false, // 是否显示右键菜单
    //         Vsrc_CH: item.in_ch,
    //         Vsrc_clip_style: item.clip_style,
    //         lock: 1, // 是否锁定窗口 0无效 1锁定  场景轮询状态下全部窗体禁用拖拽
    //         lockAll: true,
    //         isTitle: 1, // 是否显示标题 0不显示 1显示 默认1显示
    //         x: 0, // 放大之后存储x轴
    //         y: 0, // 放大之后存储y轴
    //         w: 0, // 放大之后存储w宽
    //         h: 0, // 放大之后存储h高
    //         mark: item.mark
    //       };
    //     });
    //     layouts.forEach(item => {
    //       switch (item.mark) {
    //         // 0,非全屏，非锁屏，标题开
    //         case 0: {
    //           break;
    //         }
    //         // 1，全屏，非锁屏，标题开
    //         case 1: {
    //           item.isM = true;
    //           break;
    //         }
    //         // 2，非全屏，锁屏，标题开
    //         case 2: {
    //           item.lock = 1;
    //           break;
    //         }
    //         // 3，全屏，锁屏，标题开
    //         case 3: {
    //           item.isM = true;
    //           item.lock = 1;
    //           break;
    //         }
    //         // 4，非全屏，非锁屏，标题关
    //         case 4: {
    //           item.isTitle = 0;
    //           break;
    //         }
    //         // 5，全屏，非锁屏，标题关
    //         case 5: {
    //           item.isM = true;
    //           item.isTitle = 0;
    //           break;
    //         }
    //         // 6，非全屏，锁屏，标题关
    //         case 6: {
    //           item.lock = 1;
    //           item.isTitle = 0;
    //           break;
    //         }
    //         // 7，全屏，锁屏，标题关
    //         case 7: {
    //           item.isM = true;
    //           item.lock = 1;
    //           item.isTitle = 0;
    //           break;
    //         }
    //       }
    //     });
    //     this.Layers.push(...layouts);
    //     let a = setTimeout(function() {
    //       _this.computedWindowColor();
    //     }, 1000);
    //   }
    // });

    onOffer(function(offerData) {
      console.log(
        "............................onOffer...................................."
      );
      // console.log(JSON.stringify(offerData));
      // console.log(offerData);
      let port2Type = [23, 17, 81, 82]; // 只有两个端口
      let port1Type = [24]; // 只有一个端口
      offerData.forEach(data => {
        // 先屏蔽这段自动刷新的代码
        // if (data.indexOf(`(out,osdflag,`) !== -1) {
        //   // 上位机重新映射的时候会发这个指令，这时候底图会清空，当作是清空底图的指令
        //   window.location.reload();
        // }
        // if (data.indexOf(`(out,mapflag,`) !== -1) {
        //   // 检测底图开关
        //   console.log(data);
        //   const { data: mapFlagData } = JSON.parse(data);
        //   const [a, b, c, isOpen, d] = mapFlagData.split(",");
        //   console.log(isOpen, "isOpen");
        //   if (isOpen === "1") {
        //     console.log("检测到开了底图");
        //     if (_this.isWebSwitch) {
        //       _this.isWebSwitch = false;
        //     } else {
        //       window.location.reload();
        //     }
        //   } else {
        //     console.log("检测到关了底图");
        //   }
        // }
        if (data.indexOf(`{\n\t\"scene_polling\":\t{`) !== -1) {
          // const scenceData = JSON.parse(data.split(`\r\n\r\n`)[0]);
          // 轮询场景的数据
          const scenceData = JSON.parse(data);
          const { gID, sID } = scenceData.scene_polling;
          if (_this.gid === gID) {
            _this.activeSID = sID;
            let domUl = document.querySelector("#scene_ul");
            let domli = document.getElementById(`scene_ul_li${sID}`);
            domUl.scrollTo(0, domli.offsetTop - 100);

            scene_callApi({
              cmd: "scene_call",
              gid: _this.gid,
              Id: sID
            }).then(() => {
              _this.getSyncWindow();
            });
            console.log("场景轮询数据: ", scenceData);
          }
        }
        // if (data.indexOf(`{\n\t\"status_refresh\":\t{`) !== -1) {
        //   // 监听拔插信号
        //   const parseDate = JSON.parse(data);
        //   parseDate.status_refresh.input.forEach(item => {
        //     const ch = item.ch;
        //     const signalList = item.signal;
        //     signalList.forEach((i, index) => {
        //       const cID = index - 3 + ch * 4;
        //       console.log(`cID: ${cID},signal: ${i}`);
        //       _this.inList[cID].singal_flag = i;
        //     });
        //   });
        //   // console.log(parseDate);
        // }

        // 监听开窗
        // if (
        //   data.indexOf("ok") !== -1 &&
        //   data.indexOf("wnd,open") !== -1 &&
        //   false
        // ) {
        //   if (_this.isWebSwitch) {
        //     _this.isWebSwitch = false;
        //     return false;
        //   }
        //
        //   console.log(JSON.parse(data), "开窗数据");
        //   const item = JSON.parse(data);
        //   const arr = item.data.replace(/\(|\)\s*/g, "").split(",");
        //   const [
        //     win,
        //     open,
        //     Group,
        //     value,
        //     ID,
        //     Vsrc_CH,
        //     Vsrc_clip_style,
        //     x,
        //     y,
        //     w,
        //     h
        //   ] = arr;
        //   console.log(arr);
        //   let zIndexmax = _this.Layers.length
        //     ? Math.max(..._this.Layers.map(item => parseInt(item.zIndex)))
        //     : 0;
        //   let incardListData = JSON.parse(
        //     localStorage.getItem("incardListData")
        //   );
        //   let inputItem = incardListData.find(i => i.cID === parseInt(Vsrc_CH));
        //   let inputName = inputItem.name
        //     ? inputItem.name
        //     : `${_this.NameList[inputItem.type]}${inputItem.cID}`;
        //   let ite = {
        //     styleObj: {
        //       width: `${parseInt(w) * _this.Wrate - 4}px`,
        //       height: `${parseInt(h) * _this.Hrate - 4}px`,
        //       position: "absolute",
        //       background: 1
        //         ? _this.CreateColor(parseInt(ID) % 36, 36)
        //         : "rgba(0,0,0,0.2)",
        //       left: `${parseInt(x) * _this.Wrate + 2}px`,
        //       top: `${parseInt(y) * _this.Hrate + 2}px`,
        //       // zIndex:haStateItem.length ? zIndexmax + 1 : 0 ,
        //       zIndex: 1 ? zIndexmax + 1 : 0,
        //       "min-width": `${_this.minWidth}px`,
        //       "min-height": `${_this.minHeight}px`
        //     },
        //     inpW: parseInt(w),
        //     inpH: parseInt(h),
        //     inpX: parseInt(x),
        //     inpY: parseInt(y),
        //     // zIndex: haStateItem.length ? zIndexmax + 1 : 0, // 叠放序号
        //     zIndex: 1 ? zIndexmax + 1 : 0, // 叠放序号
        //     num: parseInt(ID), // 窗口标志
        //     name: inputName,
        //     singal_flag: JsonEvData.singal_flag, // 有无信号
        //     haState: 1, // 窗体是否有效 0 无效 1有效 默认0
        //     isM: false, // 是否最大化满屏 默认false
        //     isW: false, // 是否无效窗口 默认false
        //     isF: false, // 是否放大 默认false
        //     contextMenuVisible: false, // 是否显示右键菜单
        //     Vsrc_CH: parseInt(Vsrc_CH), // 输入源通道
        //     Vsrc_clip_style: parseInt(Vsrc_clip_style), // 信号裁剪方案
        //     lock: 0, // 是否锁定窗口 0无效 1锁定
        //     isTitle: 1, // 是否显示标题 0不显示 1显示 默认1显示
        //     x: 0, // 放大之后存储x轴
        //     y: 0, // 放大之后存储y轴
        //     w: 0, // 放大之后存储w宽
        //     h: 0, // 放大之后存储h高
        //     mark: 0,
        //     flag: 1
        //   };
        // }

        if (
          data.indexOf("status_refresh") !== -1 &&
          data.indexOf("input") !== -1
        ) {
          let item = JSON.parse(data);
          let { input, output } = item.status_refresh;
          if (input.length) {
            // ch: 1
            // signal: [0, 0, 1, 0]
            // type: 10
            input.forEach(i => {
              if (i.type) {
                // 插卡
                let cIDList = [
                  i.ch * 4 - 3,
                  i.ch * 4 - 2,
                  i.ch * 4 - 1,
                  i.ch * 4
                ]; // 4个端口
                let cIDList4k = [i.ch * 4 - 3, i.ch * 4 - 1]; // 2个端口
                let cIDList1 = [i.ch * 4 - 3]; // 1个端口
                console.log(cIDList, "cIDList");
                if (port2Type.includes(i.type)) {
                  cIDList4k.forEach(cID => {
                    _this.inList[cID] = {
                      card_type: i.type,
                      ch: cID,
                      clip: [],
                      rename: `${_this.NameList[i.type] + cID}`,
                      singal_flag: 0
                    };
                  });
                } else if (port1Type.includes(i.type)) {
                  cIDList1.forEach(cID => {
                    _this.inList[cID] = {
                      card_type: i.type,
                      ch: cID,
                      clip: [],
                      rename: `${_this.NameList[i.type] + cID}`,
                      singal_flag: 0
                    };
                  });
                } else {
                  cIDList.forEach(cID => {
                    _this.inList[cID] = {
                      card_type: i.type,
                      ch: cID,
                      clip: [],
                      rename: `${_this.NameList[i.type] + cID}`,
                      singal_flag: 0
                    };
                  });
                }

                // 拔插信号
                const ch = i.ch;
                const signalList = i.signal;
                console.log(i, "inputItem");
                signalList.forEach((j, index) => {
                  const cID = index - 3 + ch * 4;
                  console.log(`cID: ${cID},signal: ${j}`);
                  if (_this.inList[cID]) {
                    _this.inList[cID].singal_flag = j;
                  }
                });
              } else {
                // 拔卡
                let cIDList = [
                  i.ch * 4 - 3,
                  i.ch * 4 - 2,
                  i.ch * 4 - 1,
                  i.ch * 4
                ];
                cIDList.forEach(j => {
                  _this.inList[j] = "";
                });
                console.log(cIDList, "cIDList");
              }
            });
          }
          if (output.length) {
            output.forEach(i => {
              let cIDList = [
                i.ch * 4 - 3,
                i.ch * 4 - 2,
                i.ch * 4 - 1,
                i.ch * 4
              ];
              if (i.type) {
                // 插卡
                cIDList.forEach(cID => {
                  let ompItem = _this.omap.find(o => o.Phy_ch == cID);
                  if (ompItem) {
                    _this.GridArray.forEach(j => {
                      if (j.Logic_ch == ompItem.Logic_ch) {
                        j.handleClass = "out";
                        j.card_type = i.type;
                        j.output = `${_this.NameList[i.type] + cID}`;
                        j.outputCh = cID;
                      }
                    });
                  }
                });
              } else {
                // 拔卡
                cIDList.forEach(cID => {
                  _this.GridArray.forEach(j => {
                    if (j.outputCh == cID) {
                      j.handleClass = null;
                      j.card_type = null;
                      j.output = null;
                      j.outputCh = null;
                    }
                  });
                });
              }
            });
          }
          console.log(JSON.parse(data));
        }
      });
    });

    // 按照上位机算法生成36个颜色
    this.CreateColor();
    // 浏览器窗口放大时拼控的窗体等比缩放
    // window.addEventListener("orientationchange", this.handlerReload, false);
    window.addEventListener("resize", this.resizeWindow, false);
  },
  beforeDestroy() {},
  destroyed() {
    // 离开路由之后断开websocket连接
    window.removeEventListener("orientationchange", this.handlerReload, false);
    window.removeEventListener("resize", this.resizeWindow, false);
  },
  watch: {
    initial_index(newValue, oldValue) {
      this.initial_index = newValue;
      this.boxEdit = this.$refs[`ptngridwarp${this.initial_index}`][0];
      this.Layers = [];
    }
  },
  methods: {
    topChangeOrder(window) {
      const _this = this;
      _this.contextItem = window;
      return new Promise(resolve => {
        // 按层叠序号升序
        let LayersAscOrder = orderBy(_this.Layers, ["zIndex"], ["asc"]); // asc升序 desc降序
        // 先删掉需要置顶的窗
        let notHaveContextItem = remove(LayersAscOrder, i => {
          return i.num !== _this.contextItem.num;
        });

        notHaveContextItem.push(_this.contextItem);
        notHaveContextItem.forEach((item, index) => {
          let order = index + 1;
          if (order === 1) {
            item.styleObj.zIndex = 1;
            item.zIndex = 1;
          } else {
            let leftItem = notHaveContextItem[index - 1];
            let leftItemzIndex = leftItem.zIndex;
            let marginspace = _this.is4kInput(leftItem) ? 2 : 1;
            item.styleObj.zIndex = leftItemzIndex + marginspace;
            item.zIndex = leftItemzIndex + marginspace;
          }
        });
        setTimeout(resolve, 0);
      });
    },
    resizeWindow() {
      if (!this.isMobile) {
        window.location.reload();
      }
    },
    handlerReload() {
      try {
        let angle = window.orientation || window.screen.orientation.angle;
        if (angle !== 0 && angle !== 180) {
          window.location.reload();
        }
      } catch (e) {
        console.log(e);
      }
    },
    // 单个checkbox改变事件
    oneCheckChange() {
      this.allCheckStae = false;
    },
    // 全选场景
    allCheckChange(val) {
      if (val) {
        this.sceneList.forEach(item => {
          this.dialog.poll.form.Id_group.push(item.sID);
        });
      } else {
        this.dialog.poll.form.Id_group = [];
      }
    },
    // 从上位机搬过来的自动关窗逻辑
    autoCloseWindow(pWinWidget) {
      const _this = this;
      const outCardPortCount = 2;
      // 找出与此窗相交的映射区域
      const WindowHaveOmaps = _this.getWindowIntersectOmap(item);
      // 升序处理
      const WindowHaveOmapsOrder = orderBy(
        WindowHaveOmaps,
        ["Logic_ch"],
        ["asc"]
      );
      // 需要灰掉的窗ID列表
      const listWillCloseWindow = [];
      // 输入卡列表信息
      const inCardListStorage = JSON.parse(
        localStorage.getItem("incardListData")
      );
      for (let i = 0; i < WindowHaveOmapsOrder.length; i++) {
        let item = WindowHaveOmapsOrder[i];
        // 找出映射区域对应的输出卡类型
        let outCardInfo = _this.GridArray.find(
          i => i.Logic_ch === item.Logic_ch
        );
        // 当前输出卡最大能开的图层  81到112是占4图层的卡
        let outCardPortCount =
          outCardInfo.card_type >= 81 && outCardInfo.card_type <= 112 ? 4 : 2;
        //找出与当前映射区域相交的所有窗
        let omapHaveWindows = _this.getOmapHaveWindow(item);
        // 升序处理
        let omapHaveWindowsOrder = orderBy(
          omapHaveWindows,
          ["zIndex"],
          ["asc"]
        ); // asc升序 desc降序
        let curScreenLayerCount = 0;
        let tempWin = null;
        let bFlag = false;
        for (let j = 0; j < omapHaveWindowsOrder.length; j++) {
          let pWin = omapHaveWindowsOrder[j];
          if (pWin.flag === 1) {
            // 只遍历亮窗
            // 获取与当前窗体关联的输入卡信息
            const inCardInfo = inCardListStorage.find(
              i => i.cID === item.Vsrc_CH
            );
            // (!pWin.lock || pWin.bBaseMap) 暂时不考虑底图
            if (pWin.num !== pWinWidget.num && !bFlag && !pWin.lock) {
              tempWin = pWin.num;
              bFlag = true;
            }
            curScreenLayerCount++;
            if (inCardInfo) {
              if (
                (inCardInfo.type >= 17 && inCardInfo.type <= 48) ||
                inCardInfo.type === 23
              ) {
                // 4k占两个图层的输入卡
                curScreenLayerCount++;
              }
            }
          }
        }
        if (
          !listWillCloseWindow.includes(tempWin) &&
          tempWin &&
          curScreenLayerCount > outCardPortCount
        ) {
          listWillCloseWindow.push(tempWin);
        }
      }
      if (listWillCloseWindow.length) {
        for (let i = 0; i < listWillCloseWindow.length; i++) {
          let id = listWillCloseWindow[i];
          for (let j = 0; j < _this.Layers.length; j++) {
            let item = _this.Layers[j];
            if (item.num === id) {
              // 找到对应的窗
              item.flag = 0;
              let dom = window.document.querySelector(`#mouseWarp0${item.num}`);
              item.styleObj.background = 0
                ? _this.CreateColor(item.num % 36, 36)
                : "#909399";
              dom.style.background = 0
                ? _this.CreateColor(item.num % 36, 36)
                : "#909399";
            }
          }
        }
        windowNewChangeApi({
          cmd: "windowNewChange",
          Group: _this.gid,
          value: 0,
          ID: listWillCloseWindow
        });
        _this.autoCloseWindow(pWinWidget);
      }
    },
    // 从上位机搬过来的自动开窗逻辑
    autoOpenWindow() {
      console.log("执行了自动开窗逻辑");
      const _this = this;
      const outCardPortCount = 2; // 输出卡图层数
      const listAutoOpenWin = [];
      for (let i = 0; i < _this.GridArray.length; i++) {
        let psc = _this.GridArray[i];
        if (psc.card_type) {
          let omap = _this.omap.find(item => item.Logic_ch === psc.Logic_ch); // 映射区域
          //找出与当前映射区域相交的所有窗
          let omapHaveWindows = _this.getOmapHaveWindow(omap);
          // 降序处理
          let omapHaveWindowsOrder = orderBy(
            omapHaveWindows,
            ["zIndex"],
            ["desc"]
          ); // asc升序 desc降序
          // console.log("omapHaveWindowsOrder:", omapHaveWindowsOrder);
          // 输入卡列表信息
          const inCardListStorage = JSON.parse(
            localStorage.getItem("incardListData")
          );
          omapHaveWindowsOrder.forEach(item => {
            if (item.flag === 0) {
              // 找灰窗
              // 计算与灰窗相交的映射区域(屏幕)
              const gayWindowHaveOmaps = _this.getWindowIntersectOmap(item);
              console.log(item.num, "item.num");
              console.log(gayWindowHaveOmaps, "与灰窗item.num相交的映射区域");
              // 升序处理
              const gayWindowHaveOmapsOrder = orderBy(
                gayWindowHaveOmaps,
                ["Logic_ch"],
                ["asc"]
              );
              let bCanOpen = true;
              let residueLayer = 0; // 默认可用图层

              // let itemWindow = item;
              let outmaplist = [];
              for (let j = 0; j < gayWindowHaveOmapsOrder.length; j++) {
                let item = gayWindowHaveOmapsOrder[j];
                // 找出映射区域对应的输出卡类型
                let outCardInfo = _this.GridArray.find(
                  i => i.Logic_ch === item.Logic_ch
                );
                // 当前输出卡最大能开的图层  81到112是占4图层的卡
                let outCardPortCount =
                  outCardInfo.card_type >= 81 && outCardInfo.card_type <= 112
                    ? 4
                    : 2;
                // 当前输出卡已经开的图层 默认0
                let curScreenLayerCount = 0;
                // 计算与映射区域相交的窗有哪些
                let listTempWindow = _this.getOmapHaveWindow(item);
                listTempWindow.forEach(item => {
                  if (item.flag === 1) {
                    curScreenLayerCount++;
                    // 找出与这个窗关联的输入卡信息 获取卡类型
                    const inCardInfo = inCardListStorage.find(
                      i => i.cID === item.Vsrc_CH
                    );

                    if (inCardInfo) {
                      if (
                        (inCardInfo.type >= 17 && inCardInfo.type <= 48) ||
                        inCardInfo.type === 23
                      ) {
                        // 4k占两个图层的输入卡
                        curScreenLayerCount++;
                      }
                    }
                    if (item.mark & 0x08) {
                      // 判断底图，每个底图都是占用一个图层
                      if (outCardPortCount === 2) {
                        // 两图层的输出
                        outmaplist.push(item.num);
                      }
                    }
                  }
                });
                if (curScreenLayerCount >= outCardPortCount) {
                  bCanOpen = false;
                  break;
                }
                if (residueLayer != 1) {
                  console.log(outCardPortCount, "outCardPortCount输出卡图层数");
                  console.log(
                    curScreenLayerCount,
                    "curScreenLayerCount已占图层"
                  );
                  residueLayer = outCardPortCount - curScreenLayerCount; // 计算剩余图层
                  console.log(residueLayer, "residueLayer");
                  // console.log(itemWindow, "item这个窗");
                }
              }
              if (bCanOpen) {
                console.log(bCanOpen, "bCanOpen");
                // 找出与这个窗关联的输入卡信息 获取卡类型
                const inCardInfo = inCardListStorage.find(
                  i => i.cID === item.Vsrc_CH
                );
                console.log(inCardInfo, "inCardInfo");

                if (
                  residueLayer > 1 ||
                  (!(
                    (inCardInfo &&
                      inCardInfo.type >= 17 &&
                      inCardInfo &&
                      inCardInfo.type <= 48) ||
                    (inCardInfo && inCardInfo.type === 23)
                  ) &&
                    residueLayer == 1)
                ) {
                  console.log("进入亮窗1");
                  // 设置亮窗
                  item.flag = 1;
                  let dom = window.document.querySelector(
                    `#mouseWarp0${item.num}`
                  );
                  item.styleObj.background = 1
                    ? _this.CreateColor(item.num % 36, 36)
                    : "#909399";
                  if (dom) {
                    dom.style.background = 1
                      ? _this.CreateColor(item.num % 36, 36)
                      : "#909399";
                  }

                  // 把窗ID添加到listAutoOpenWin
                  listAutoOpenWin.push(item.num);
                } else {
                  // 如果剩余的亮窗是底图，则灰掉底图再亮窗
                  console.log("residueLayer: ", residueLayer);
                  console.log("outmaplist: ", outmaplist);
                  if (residueLayer === 1 && outmaplist.length === 1) {
                    item.flag = 1; // 先把item的标志改了
                    windowNewChangeApi({
                      cmd: "windowNewChange",
                      Group: _this.gid,
                      value: 0,
                      ID: outmaplist
                    }).then(() => {
                      _this.Layers.forEach(item => {
                        if (item.num === outmaplist[0]) {
                          item.flag = 0;
                          let dom = window.document.querySelector(
                            `#mouseWarp0${item.num}`
                          );
                          item.styleObj.background = 0
                            ? _this.CreateColor(item.num % 36, 36)
                            : "#909399";
                          if (dom) {
                            dom.style.background = 0
                              ? _this.CreateColor(item.num % 36, 36)
                              : "#909399";
                          }
                        }
                      });
                      console.log("进入亮窗2");
                      console.log("亮窗ID是：", item.num);
                      // 设置亮窗
                      item.flag = 1;
                      let dom = window.document.querySelector(
                        `#mouseWarp0${item.num}`
                      );
                      item.styleObj.background = 1
                        ? _this.CreateColor(item.num % 36, 36)
                        : "#909399";
                      if (dom) {
                        dom.style.background = 1
                          ? _this.CreateColor(item.num % 36, 36)
                          : "#909399";
                      }
                      windowNewChangeApi({
                        cmd: "windowNewChange",
                        Group: _this.gid,
                        value: 1,
                        ID: [item.num]
                      });
                    });
                  }
                }
              }
            }
          });
        }
      }
      if (listAutoOpenWin.length) {
        console.log("自动开窗计算出需要开窗的ID：", listAutoOpenWin);
        windowNewChangeApi({
          cmd: "windowNewChange",
          Group: _this.gid,
          value: 1,
          ID: listAutoOpenWin
        });
      }
      _this.loading.close();
    },
    // 判断此灰窗能否亮起
    isWindowGayToLight(GayWindow, notOmap) {
      // 求相交映射区域有哪些
      let _this = this;
      // 找出与当前窗体相交的映射区域有哪些
      let ItemOmap = _this.getWindowIntersectOmap(GayWindow);
      console.log(ItemOmap, "与当前灰窗相交的映射区域ItemOmap");
      console.log(notOmap, "notOmap");
      if (ItemOmap.length) {
        let omapBooleanList = [];
        ItemOmap.forEach(a => {
          // let ItemOmapWindow = _this.getOmapHaveWindow(a);
          // console.log(ItemOmapWindow, "当前映射区域的已开窗");
          // // 判断当前映射区域的窗体里面有没有两个亮窗
          // let hasLightWindow = ItemOmapWindow.filter(item => item.flag === 1);
          // omapBooleanList.push(hasLightWindow.length < 2);

          // 找出这个灰窗与 置底窗相交的区域 相交的区域
          let GayWindowAndItemWindowOmap = notOmap.find(
            i => i.Logic_ch === a.Logic_ch
          );
          console.log(GayWindowAndItemWindowOmap, "GayWindowAndItemWindowOmap");
          // 排除掉GayWindowAndItemWindowOmap
          if (GayWindowAndItemWindowOmap) {
            if (a.Logic_ch !== GayWindowAndItemWindowOmap.Logic_ch) {
              // 找出当前映射区域有哪些窗体
              let ItemOmapWindow = _this.getOmapHaveWindow(a);
              console.log(ItemOmapWindow, "当前映射区域的已开窗");
              // 判断当前映射区域的窗体里面有没有两个亮窗
              let hasLightWindow = ItemOmapWindow.filter(
                item => item.flag === 1
              );
              omapBooleanList.push(hasLightWindow.length < 2);
            }
          } else {
            // 说明其它相交的区域里有两个亮窗，这时不能弹起
            // omapBooleanList.push(false);
          }
        });
        return omapBooleanList.every(item => item);
      }
    },
    // 计算LCD最大屏幕宽高 计算屏幕缩放比
    computedScene(gID, Rows, Cols) {
      let _this = this;
      return new Promise((resolve, reject) => {
        // 根据窗口大小和分辨率算出缩放比
        timingInfoApi({ Group: gID }).then(res => {
          const { H_active, V_active } = res;
          localStorage.setItem(
            "timingData",
            JSON.stringify({
              H_active,
              V_active
            })
          );
          _this.H_ACTIVE = H_active;
          _this.V_ACTIVE = V_active;
          if (_this.$root.GroupType === 1) {
            _this.W = (H_active + _this.hgap) * Cols;
            _this.H = (V_active + _this.vgap) * Rows;
          }
          if (_this.$root.GroupType === 2) {
            let currentGroupOmap = _this.omap.filter(i => i.gid === _this.gid);
            // console.log(currentGroupOmap.length);
            // console.log(Cols * Rows);
            if (currentGroupOmap.length === Cols * Rows) {
              let wlist = [];
              let hlist = [];
              currentGroupOmap.forEach(i => {
                wlist.push(i.x + i.w);
                hlist.push(i.y + i.h);
              });
              _this.W = Math.max(...wlist);
              _this.H = Math.max(...hlist);
            } else {
              _this.W = (H_active + _this.hgap) * Cols;
              _this.H = (V_active + _this.vgap) * Rows;
            }
          }

          let scaleRateX = Rows > Cols ? Cols / Rows : 1;
          let scaleRateY = Cols > Rows ? Rows / Cols : 1;
          // let switchValue = Rows * Cols <= 49;
          let switchValue = Rows < 7 && Cols < 7;
          // let switchValue = false;
          console.log(switchValue, "switchValue");
          let WarpWidth = switchValue
            ? getStyle(_this.$refs["ptngridwarp0"][0], "width")
            : H_active * Cols * (1 / scaleRateX) * 0.1;
          let WarpHeight = switchValue
            ? getStyle(_this.$refs["ptngridwarp0"][0], "height")
            : V_active * Rows * (1 / scaleRateY) * 0.1;
          _this.WarpWidth = WarpWidth;
          _this.WarpHeight = WarpHeight;
          let dom = document.querySelector("#ptngridwarp0");
          if (!switchValue && Rows * Cols >= 49) {
            dom.style.transformOrigin = "left top";
          }
          _this.Wrate = parseFloat(WarpWidth) / _this.W;
          _this.Hrate = parseFloat(WarpHeight) / _this.H;
          _this.minWidth = _this.Wrate * 160;
          _this.minHeight = _this.Hrate * 80;
          console.log(_this.minWidth, "最小宽度");
          console.log(_this.minHeight, "最小高度");
          // 计算宫格坐标
          _this.computedXYArray(Rows, Cols);
          _this.computedLJArray(Rows * 2, Cols * 2, 2, 2);
          resolve(true);
        });
      });
    },
    // 选择分组时的点击事件
    handleClick(item) {
      let _this = this;
      // if (this.dialog.poll.form.en) {
      //   this.$message.info("场景轮询状态不能切换分组");
      //   return false;
      // }
      this.gid = item.gID; // 设置当前分组ID
      this.Layers = [];
      // 切换分组
      // settingCgrpApi({
      //   cmd: "settingCgrp",
      //   Group: parseInt(this.gid)
      // });
      console.log("发送切换分组指令");
      websocketsend(`(setting,cgrp,${this.gid})\r\n`, () => {});

      this.handleClickLoading = this.$loading({
        lock: true,
        text: i18n.t("home.dataLoading") + "...",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      console.log(item, "当前分组信息");
      console.log(item.panel_type, "当前分组类型");
      console.log(item.gID, "当前分组ID");
      console.log(item.Rows, "当前分组行数");
      console.log(item.Cols, "当前分组列数");
      this.$root.GroupType = item.panel_type ? item.panel_type : 1; // 设置当前的屏幕类型
      this.Rows = item.Rows || 3;
      this.Cols = item.Cols || 3;
      this.hgap = item.hgap || 0;
      this.vgap = item.vgap || 0;
      let scaleRateX = this.Rows > this.Cols ? this.Cols / this.Rows : 1;
      let scaleRateY = this.Cols > this.Rows ? this.Rows / this.Cols : 1;
      let __scaleX =
        this.Rows > this.Cols ? Math.abs(this.Rows - this.Cols) : 1;
      let __scaleY =
        this.Cols > this.Rows ? Math.abs(this.Rows - this.Cols) : 1;
      let dom = document.querySelector("#ptngridwarp0");
      dom.style.transform = `scale(${scaleRateX},${scaleRateY})`;
      let body = document.getElementsByTagName("body")[0];
      body.style.setProperty("--scaleX", 1 / scaleRateX);
      body.style.setProperty("--scaleY", 1 / scaleRateY);
      this.computedScene(item.gID, this.Rows, this.Cols).then(res => {
        // 生成
        let GridArray = _this.computedGrid(this.Rows, this.Cols);
        // _this.omap.filter(i => i.gid === _this.gid&&_this.cardOutputChList.includes(parseInt(i.Phy_ch))).forEach(i => {
        //   GridArray.forEach(item => {
        //     if (item.Logic_ch === i.Logic_ch) {
        //       item.H = i.h * _this.Hrate;
        //       item.W = i.w * _this.Wrate;
        //       item.X = i.x * _this.Wrate;
        //       item.Y = i.y * _this.Hrate;
        //     }
        //   });
        // });
        _this.GridArray = [...GridArray];
        console.log(GridArray, "GridArray");
        // TODO: LMP-D: 获取输出通道列表
        // getOutCardListApi({
        //   cmd: "outcard_info_sync"
        // })
        //   .then(res => {
        //     // // 分组映射关系过滤(过滤掉没有插卡的映射关系)
        //     // let cardOutCardList = res.outcard_info_sync.filter(
        //     //   item => item.gID == _this.gid
        //     // );
        //     // this.cardOutputListDetails = [...cardOutCardList];
        //     // let cIDList = [];
        //     // this.cardOutputListDetails.forEach(item => {
        //     //   cIDList.push(item.cID);
        //     //   this.cardOutputChList.push(parseInt(item.cID));
        //     // });
        //     // _this.omap
        //     //   .filter(
        //     //     i =>
        //     //       i.gid === _this.gid &&
        //     //       _this.cardOutputChList.includes(parseInt(i.Phy_ch))
        //     //   )
        //     //   .forEach(i => {
        //     //     GridArray.forEach(item => {
        //     //       if (item.Logic_ch === i.Logic_ch) {
        //     //         item.H = i.h * _this.Hrate;
        //     //         item.W = i.w * _this.Wrate;
        //     //         item.X = i.x * _this.Wrate;
        //     //         item.Y = i.y * _this.Hrate;
        //     //       }
        //     //     });
        //     //   });
        //     // console.log(
        //     //   this.cardOutputListDetails,
        //     //   "this.cardOutputListDetails"
        //     // );
        //     // let itemOmap = _this.omap.filter(
        //     //   i => i.gid === _this.gid && cIDList.includes(i.Phy_ch)
        //     // );
        //     // // let itemOmap=_this.omap.filter(i => i.gid === _this.gid)
        //     // if (itemOmap.length === 0) {
        //     //   loading1.close();
        //     // }
        //     // itemOmap.forEach(i => {
        //     //   GridArray.forEach(item => {
        //     //     if (item.Logic_ch === i.Logic_ch) {
        //     //       let itemOmapOutCard = this.cardOutputListDetails.filter(
        //     //         j => j.cID === i.Phy_ch
        //     //       );
        //     //       item.output = itemOmapOutCard[0].name
        //     //         ? itemOmapOutCard[0].name
        //     //         : `${_this.NameList[itemOmapOutCard[0].type]}${i.Phy_ch}`;
        //     //       item.outputCh = i.Phy_ch;
        //     //       item.card_type = itemOmapOutCard[0].type;
        //     //       item.handleClass = "out";
        //     //     }
        //     //   });
        //     // });
        //     // loading1.close();
        //   })
        //   .catch(err => {
        //     loading1.close();
        //   });

        websocketsend("(sync,outcard)\r\n", res => {
          console.log("查询输出卡的数据callback: ", res);
          console.log("映射数据：", _this.omap);
          const outList = res.reduce((arr, item) => {
            if (item.outcard_info_sync) {
              arr.push(item.outcard_info_sync);
            }
            return arr.flat();
          }, []);
          console.log(outList);
          localStorage.setItem("outListData", JSON.stringify(outList));
          // 分组映射关系过滤(过滤掉没有插卡的映射关系)
          let cardOutCardList = outList.filter(item => item.gID == _this.gid);
          // console.log("_this.gid:", _this.gid);
          // console.log("cardOutCardList:", cardOutCardList);
          this.cardOutputListDetails = [...cardOutCardList];
          let cIDList = [];
          this.cardOutputListDetails.forEach(item => {
            cIDList.push(item.cID);
            this.cardOutputChList.push(parseInt(item.cID));
          });
          _this.omap
            .filter(
              i =>
                i.gid === _this.gid &&
                _this.cardOutputChList.includes(parseInt(i.Phy_ch))
            )
            .forEach(i => {
              GridArray.forEach(item => {
                if (
                  item.Logic_ch === i.Logic_ch &&
                  _this.$root.GroupType === 2
                ) {
                  item.H = i.h * _this.Hrate;
                  item.W = i.w * _this.Wrate;
                  item.X = i.x * _this.Wrate; // LCD不用覆盖x和y
                  item.Y = i.y * _this.Hrate;
                }
              });
            });
          console.log(this.cardOutputListDetails, "this.cardOutputListDetails");
          let itemOmap = _this.omap.filter(
            i => i.gid === _this.gid && cIDList.includes(i.Phy_ch)
          );
          // let itemOmap=_this.omap.filter(i => i.gid === _this.gid)
          if (itemOmap.length === 0) {
            // loading1.close();
          }
          itemOmap.forEach(i => {
            GridArray.forEach(item => {
              if (item.Logic_ch === i.Logic_ch) {
                let itemOmapOutCard = _this.cardOutputListDetails.filter(
                  j => j.cID === i.Phy_ch
                );
                // console.log(
                //   itemOmapOutCard[0].type,
                //   "itemOmapOutCard[0].type"
                // );
                if (itemOmapOutCard && itemOmapOutCard[0].type) {
                  item.output = itemOmapOutCard[0].name
                    ? itemOmapOutCard[0].name
                    : `${_this.NameList[itemOmapOutCard[0].type]}${i.Phy_ch}`;
                  item.outputCh = i.Phy_ch;
                  item.card_type = itemOmapOutCard[0].type;
                  item.handleClass = "out";
                }
              }
            });
          });
          // loading1.close();
          // 获取场景列表
          _this.getSyncScene();
        });
      });
      this.index = 9000; // 每次点击分组重置叠层序号

      // this.Layers = []; // 清空拼控的窗体

      document
        .getElementsByTagName("body")[0]
        .style.setProperty("--columns", item.Cols);
      document
        .getElementsByTagName("body")[0]
        .style.setProperty("--rows", item.Rows);

      // ginfo_syncApi({
      //   cmd: "ginfo_sync"
      // }).then(res => {
      //   this.omap = [...res.omap];
      // });
      // 窗口同步
      _this.getSyncWindow();
    },
    // 同步层叠序号
    syncWindowOrder() {
      let _this = this;
      return new Promise((resolve, reject) => {
        syncWindowApi({
          cmd: "syncWindow",
          Group: _this.gid
        }).then(res => {
          console.log("执行了syncWindowOrder");
          let itemGroupWindow = [...res].filter(i => i.gID == _this.gid);
          _this.Layers.forEach(i => {
            itemGroupWindow.forEach(j => {
              if (i.num === j.wID && i.haState) {
                i.styleObj.zIndex = j.order;
                i.zIndex = j.order;
                i.flag = j.flag;
                let dom = window.document.querySelector(`#mouseWarp0${i.num}`);
                i.styleObj.background = j.flag
                  ? _this.CreateColor(i.num % 36, 36)
                  : "#909399";
                dom.style.background = j.flag
                  ? _this.CreateColor(i.num % 36, 36)
                  : "#909399";
              }
            });
          });
          resolve(true);
        });
      });
    },
    // 移动或者开窗逻辑
    moveOropenWindow(Item, type) {
      this.loading = this.$loading({
        lock: true,
        text: "Loading",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      let _this = this;
      // _this.autoOpenWindow();
      // 找出与当前窗体相交的映射区域有哪些
      let ItemOmap = this.getWindowIntersectOmap(Item);
      console.log(ItemOmap, "找出与当前窗体相交的映射区域有哪些");

      if (ItemOmap.length) {
        // 这是有效窗
        function gay() {
          return new Promise(resolve => {
            // 计算哪些需要灰哪些需要亮
            _this.computedGayNum(ItemOmap, Item).then(res => {
              if (res.isGay.length) {
                // 需要灰窗
                console.log(res.isGay, "res.isGay");
                console.log(_this.Layers, "_this.Layers");
                let ID0 = Array.from(new Set([...res.isGay]));

                _this.Layers.forEach(i => {
                  if (ID0.includes(i.num) && i.haState) {
                    // i.styleObj.zIndex = Item.order;
                    // i.zIndex = Item.order;

                    i.flag = 0;
                    let dom = window.document.querySelector(
                      `#mouseWarp0${i.num}`
                    );
                    i.styleObj.background = 0
                      ? _this.CreateColor(i.num % 36, 36)
                      : "#909399";
                    if (dom) {
                      dom.style.background = 0
                        ? _this.CreateColor(i.num % 36, 36)
                        : "#909399";
                    }
                  }
                });

                windowNewChangeApi({
                  cmd: "windowNewChange",
                  Group: _this.gid,
                  value: 0,
                  ID: ID0
                }).then($ => {
                  if (type === "open") {
                    _this.Layers.push(Item);
                    console.log("open2");
                    windowOpenApi({
                      cmd: "windowOpen",
                      Group: _this.gid,
                      value: 1, // 0 灰色 1正常 2wu无效
                      ID: Item.num, // 窗口ID （0-65535）
                      Vsrc_CH: Item.Vsrc_CH, //信号源通道
                      Vsrc_clip_style: Item.Vsrc_clip_style, // 信号源裁剪方案
                      x: Item.inpX, // 起点x
                      y: Item.inpY, // 起点y
                      w: Item.inpW, // 结束x 或者 窗体宽
                      h: Item.inpH // 结束y 或者 窗体高
                    });
                  }
                  if (type === "move") {
                    if (Item.styleObj.background === "rgba(0,0,0,0.2)") {
                      console.log("open3");
                      windowOpenApi({
                        cmd: "windowOpen",
                        Group: _this.gid,
                        value: 1, // 0 灰色 1正常 2wu无效
                        ID: Item.num, // 窗口ID （0-65535）
                        Vsrc_CH: Item.Vsrc_CH, //信号源通道
                        Vsrc_clip_style: Item.Vsrc_clip_style, // 信号源裁剪方案
                        x: Item.inpX, // 起点x
                        y: Item.inpY, // 起点y
                        w: Item.inpW, // 结束x 或者 窗体宽
                        h: Item.inpH // 结束y 或者 窗体高
                      });
                    } else {
                      console.log("move2");
                      let value = Item.styleObj.background == "#909399" ? 0 : 1;
                      windowMoveApi({
                        cmd: "windowMove",
                        value: value, // 0 灰色 1正常 2无效
                        ID: Item.num, // 窗口ID （0-65535）
                        x: parseInt(Item.inpX), // 起点x
                        y: parseInt(Item.inpY), // 起点y
                        w: parseInt(Item.inpW), // 结束x 或者 窗体宽
                        h: parseInt(Item.inpH) // 结束y 或者 窗体高
                      });
                    }
                  }
                });
              } else {
                // 不需要灰窗直接发open或者move
                // 开窗
                if (type === "open") {
                  _this.Layers.push(Item);
                  console.log("open1");
                  windowOpenApi({
                    cmd: "windowOpen",
                    Group: _this.gid,
                    value: 1, // 0 灰色 1正常 2wu无效
                    ID: Item.num, // 窗口ID （0-65535）
                    Vsrc_CH: Item.Vsrc_CH, //信号源通道
                    Vsrc_clip_style: Item.Vsrc_clip_style, // 信号源裁剪方案
                    x: Item.inpX, // 起点x
                    y: Item.inpY, // 起点y
                    w: Item.inpW, // 结束x 或者 窗体宽
                    h: Item.inpH // 结束y 或者 窗体高
                  });
                }
                // 移动 并且不是全屏
                if (type === "move" && !Item.isM) {
                  console.log("move1");
                  if (Item.styleObj.background === "rgba(0,0,0,0.2)") {
                    async function run1() {
                      // 先灰窗
                      await _this
                        .computedGayNum(ItemOmap, Item, true)
                        .then(res => {
                          console.log(res.isGay, "移动无效窗后先灰窗");
                          if (res.isGay.length) {
                            let ID0 = Array.from(new Set([...res.isGay]));

                            _this.Layers.forEach(i => {
                              if (ID0.includes(i.num) && i.haState) {
                                // i.styleObj.zIndex = Item.order;
                                // i.zIndex = Item.order;

                                i.flag = 0;
                                let dom = window.document.querySelector(
                                  `#mouseWarp0${i.num}`
                                );
                                i.styleObj.background = 0
                                  ? _this.CreateColor(i.num % 36, 36)
                                  : "#909399";
                                if (dom) {
                                  dom.style.background = 0
                                    ? _this.CreateColor(i.num % 36, 36)
                                    : "#909399";
                                }
                              }
                            });

                            windowNewChangeApi({
                              cmd: "windowNewChange",
                              Group: _this.gid,
                              value: 0,
                              ID: ID0
                            });
                          }
                        });
                      console.log("当前移动的窗是无效窗");
                      console.log("当前映射区域只有一个窗或者无窗");
                      console.log("open4");
                      console.log("再开窗");

                      Item.zIndex = _this.Layers.length;
                      Item.flag = 1;
                      let dom = window.document.querySelector(
                        `#mouseWarp0${Item.num}`
                      );
                      Item.styleObj.background = 1
                        ? _this.CreateColor(Item.num % 36, 36)
                        : "#909399";
                      dom.style.background = 1
                        ? _this.CreateColor(Item.num % 36, 36)
                        : "#909399";
                      await windowOpenApi({
                        cmd: "windowOpen",
                        Group: _this.gid,
                        value: 1, // 0 灰色 1正常 2wu无效
                        ID: Item.num, // 窗口ID （0-65535）
                        Vsrc_CH: Item.Vsrc_CH, //信号源通道
                        Vsrc_clip_style: Item.Vsrc_clip_style, // 信号源裁剪方案
                        x: Item.inpX, // 起点x
                        y: Item.inpY, // 起点y
                        w: Item.inpW, // 结束x 或者 窗体宽
                        h: Item.inpH // 结束y 或者 窗体高
                      }).then(_ => {});
                    }
                    run1();
                  } else {
                    let value = Item.styleObj.background == "#909399" ? 0 : 1;
                    windowMoveApi({
                      cmd: "windowMove",
                      value: value, // 0 灰色 1正常 2无效
                      ID: Item.num, // 窗口ID （0-65535）
                      x: parseInt(Item.inpX), // 起点x
                      y: parseInt(Item.inpY), // 起点y
                      w: parseInt(Item.inpW), // 结束x 或者 窗体宽
                      h: parseInt(Item.inpH) // 结束y 或者 窗体高
                    });
                  }
                }
              }
            });
            // 从1000改成500
            setTimeout(resolve, 500);
          });
        }
        function light() {
          return new Promise(resolve => {
            // 亮窗逻辑
            // let ItemOmap = _this.omap.filter(i => i.gid === _this.gid);
            // let ID2 = [];
            // _this
            //   .computedLightNum(ItemOmap, Item)
            //   .then(res => {
            //     if (res.isLight.length) {
            //       console.log(res.isLight, "res.isLight");
            //       let ID1 = Array.from(new Set([...res.isLight]));
            //       ID2 = res.isLight;
            //       windowNewChangeApi({
            //         cmd: "windowNewChange",
            //         Group: _this.gid,
            //         value: 1,
            //         ID: ID1
            //       });
            //       _this.Layers.forEach(i => {
            //         if (ID1.includes(i.num) && i.haState) {
            //           // i.styleObj.zIndex = Item.order;
            //           // i.zIndex = Item.order;
            //           i.flag = 1;
            //           let dom = window.document.querySelector(
            //             `#mouseWarp0${i.num}`
            //           );
            //           i.styleObj.background = 1
            //             ? _this.CreateColor(i.num % 36, 36)
            //             : "#909399";
            //           dom.style.background = 1
            //             ? _this.CreateColor(i.num % 36, 36)
            //             : "#909399";
            //         }
            //       });
            //     }
            //   })
            //   .then(_ => {
            //     // 注释掉和后台同步
            //     // let a = setTimeout(function() {
            //     //   _this.syncWindowOrder();
            //     //   clearTimeout(a);
            //     // }, 1000);
            //   })
            //   .then(_ => {
            //     if (type === "move" && ID2.includes(Item.num)) {
            //       console.log("move3");
            //       windowMoveApi({
            //         cmd: "windowMove",
            //         value: 1, // 0 灰色 1正常 2无效
            //         ID: Item.num, // 窗口ID （0-65535）
            //         x: parseInt(Item.inpX), // 起点x
            //         y: parseInt(Item.inpY), // 起点y
            //         w: parseInt(Item.inpW), // 结束x 或者 窗体宽
            //         h: parseInt(Item.inpH) // 结束y 或者 窗体高
            //       });
            //     }
            //   });

            _this.autoOpenWindow();
            setTimeout(resolve, 500);
          });
        }

        async function run() {
          await gay();
          await light();
        }
        run().then(_ => {});
      } else {
        // 没有相交的映射就是无效窗
        console.log("没有相交，这时候的窗体时无效窗");
        if (type === "open") {
          return false;
        }

        // 从有效到无效窗
        // 其他窗口先减去order
        _this.Layers.forEach(item => {
          if (item.zIndex > Item.zIndex && Item.zIndex !== 0) {
            item.zIndex -= 1;
          }
        });

        windowChngApi({
          cmd: "windowChng",
          value: 2, // 0 灰色 1正常 2wu无效
          ID: Item.num, // 窗口ID （0-65535）
          Group: _this.gid,
          Vsrc_CH: Item.Vsrc_CH, //信号源通道
          Vsrc_clip_style: Item.Vsrc_clip_style, // 信号源裁剪方案
          x: Item.inpX, // 起点x
          y: Item.inpY, // 起点y
          w: Item.inpW, // 结束x 或者 窗体宽
          h: Item.inpH // 结束y 或者 窗体高
        }).then(res => {
          _this.autoOpenWindow();
          // 亮窗逻辑
          let dom = window.document.querySelector(`#mouseWarp0${Item.num}`);
          Item.zIndex = 0;
          Item.flag = 0;
          Item.styleObj.background = "rgba(0,0,0,0.2)";
          dom.style.background = "rgba(0,0,0,0.2)";

          // let ItemOmap = this.omap.filter(i => i.gid === this.gid);
          // _this.computedLightNum(ItemOmap, Item).then(res => {
          //   if (res.isLight.length) {
          //     console.log(res.isLight, "无相交的res.isLight");
          //     let ID1 = Array.from(new Set([...res.isLight]));
          //
          //     _this.Layers.forEach(i => {
          //       if (ID1.includes(i.num) && i.haState) {
          //         // i.styleObj.zIndex = Item.order;
          //         // i.zIndex = Item.order;
          //         i.flag = 1;
          //         let dom = window.document.querySelector(
          //           `#mouseWarp0${i.num}`
          //         );
          //         i.styleObj.background = 1
          //           ? _this.CreateColor(i.num % 36, 36)
          //           : "#909399";
          //         dom.style.background = 1
          //           ? _this.CreateColor(i.num % 36, 36)
          //           : "#909399";
          //       }
          //     });
          //
          //     windowNewChangeApi({
          //       cmd: "windowNewChange",
          //       Group: _this.gid,
          //       value: 1,
          //       ID: ID1
          //     }).then(res => {
          //       // 注释掉和后台同步
          //       // _this.syncWindowOrder();
          //       // let a=setTimeout(function () {
          //       //   _this.syncWindowOrder()
          //       //   clearTimeout(a)
          //       // },1000)
          //     });
          //   }
          // });
        });
      }
    },
    // 根据当前窗体相交的映射区域计算哪些灰窗 isMoveWuXiao布尔值 是否从无效窗到有效窗时找一个层级最低的窗
    computedGayNum(ItemOmap, Item, isMoveWuXiao) {
      let _this = this;
      let incardListData = JSON.parse(localStorage.getItem("incardListData"));
      return new Promise((resolve, reject) => {
        let isGay = [];
        ItemOmap.forEach(a => {
          console.log("................................");
          console.log(a.Logic_ch, "当前区域");
          // 找出当前映射区域的输出卡类型
          let { card_type: outType } = _this.GridArray.find(
            i => i.Logic_ch === a.Logic_ch
          );
          // 当前映射区域的输出卡图层数
          let outCardPortCount = outType >= 81 && outType <= 112 ? 4 : 2;
          console.log(outCardPortCount, "当前区域拥有图层数");
          // 找出当前映射区域有哪些窗体
          let ItemOmapWindow = _this.getOmapHaveWindow(a);
          console.log(ItemOmapWindow, "当前映射区域的已开窗");
          // 判断当前映射区域的窗体里面有没有两个亮窗
          let hasLightWindow = ItemOmapWindow.filter(item => item.flag);
          let hasLightWindowID = [];
          let hasLightWindowOrder = [];
          let allCount = 0; // 此输出卡累计占用的图层数
          console.log(hasLightWindow, "此区域的亮窗");
          hasLightWindow.forEach(item => {
            if (item.num !== Item.num) {
              allCount += 1;
              hasLightWindowID.push(item.num);
              hasLightWindowOrder.push(item.zIndex);
              // if (item.mark & 0x08) {
              //   // 是底图
              // }
              let inItem = incardListData.find(i => i.cID === item.Vsrc_CH);
              if (inItem) {
                let { type: inType } = inItem;
                if ((inType >= 17 && inType <= 48) || inType === 23) {
                  allCount += 1;
                  // 输入卡是4k
                  hasLightWindowID.push(item.num);
                }
              }

              if (false) {
                // 如果有底图字幕占用图层数还需要加1
                allCount += 1;
              }
            }
          });

          // 计算剩余图层数
          let surplusCount = outCardPortCount - allCount;

          console.log(allCount, "已占有图层");
          console.log(surplusCount, "剩余图层图");
          // 剩余图层数等于0或者剩余图层数小于新开窗输入源的占用图层数时，需要灰窗
          let { type: ItemType } = incardListData.find(
            i => i.cID === Item.Vsrc_CH
          );
          let inCount =
            (ItemType >= 17 && ItemType <= 48) || ItemType === 23 ? 2 : 1;
          if (
            surplusCount === 0 ||
            surplusCount < inCount ||
            surplusCount < 0
          ) {
            // Item输入卡是4k的话,需要两个图层位置
            let needCount =
              (ItemType >= 17 && ItemType <= 48) || ItemType === 23 ? 2 : 1;
            console.log(needCount, "当前拖动的窗需要的图层数量");
            let notHaveMeLightWindow = hasLightWindow.filter(
              item => item.num !== Item.num
            );
            console.log(notHaveMeLightWindow, "notHaveMeLightWindow");
            let notId = [];
            // 优先灰掉底图
            let mapWindows = notHaveMeLightWindow.filter(i => i.mark & 0x08);
            let notMapWindows = notHaveMeLightWindow.filter(
              i => !(i.mark & 0x08)
            );
            let mapAndnotMap = mapWindows.concat(notMapWindows);
            let needCountCopy = needCount;
            mapAndnotMap.forEach(item => {
              if (!notId.includes(item.num)) {
                if (needCount > 0 && surplusCount !== needCountCopy) {
                  // if (needCount > 0) {
                  let inItem = incardListData.find(i => i.cID === item.Vsrc_CH);
                  let itemCount;
                  if (inItem) {
                    let { type: notHaveMeType } = inItem;
                    itemCount =
                      (notHaveMeType >= 17 && notHaveMeType <= 48) ||
                      notHaveMeType === 23
                        ? 2
                        : 1;
                  } else {
                    itemCount = 1;
                  }

                  console.log(item.num, "item.num");
                  console.log(itemCount, "itemCount");
                  console.log(Item.flag, "Item.flag");
                  console.log(isMoveWuXiao, "isMoveWuXiao");

                  surplusCount += itemCount;
                  needCount -= itemCount;
                  if (Item.flag !== 0) {
                    // 保证不是灰窗 如果是灰窗就没必要再灰窗
                    isGay.push(item.num);
                    notId.push(item.num);
                  }

                  if (
                    Item.flag === 0 &&
                    Item.styleObj.background !== "rgba(0,0,0,0.2)"
                  ) {
                    // 排除亮窗和无效窗
                    mapWindows.forEach(i => {
                      isGay.push(i.num);
                      notId.push(i.num);
                    });
                  }
                  if (isMoveWuXiao) {
                    isGay.push(item.num);
                    notId.push(item.num);
                  }
                }
              }
            });
          }
          // 如果移动的是无效窗
          if (isMoveWuXiao) {
            let indexMin = Math.min(...hasLightWindowOrder);
            hasLightWindow.forEach(item => {
              if (item.zIndex === indexMin) {
                isGay.push(item.num);
              }
            });
          }

          // 如果当前区域的亮窗数量大于2或者等于2 则需要进行灰窗
          // if (hasLightWindow.length === outCardPortCount) {
          //   // 找出哪些需要灰窗 不包括当前窗体
          //   if (!hasLightWindowID.includes(Item.num)) {
          //     let zIndexList = [];
          //     hasLightWindow.forEach(item => {
          //       zIndexList.push(item.zIndex);
          //     });
          //     let min = Math.min(...zIndexList);
          //     let minItm = hasLightWindow.filter(item => item.zIndex === min);
          //     if (Item.flag === 0) {
          //     } else {
          //       if (minItm[0].flag) {
          //         // 保证不是灰窗 如果是灰窗就没必要再灰窗
          //         isGay.push(minItm[0].num);
          //       }
          //     }
          //   }
          // }
          // if (hasLightWindow.length > outCardPortCount) {
          //   // 找出哪些需要灰窗 不包括当前窗体
          //   let zIndexList = [];
          //   let notHaveMeLightWindow = hasLightWindow.filter(
          //     item => item.num !== Item.num
          //   );
          //   notHaveMeLightWindow.forEach(item => {
          //     zIndexList.push(item.zIndex);
          //   });
          //   let min = Math.min(...zIndexList);
          //   let minItm = notHaveMeLightWindow.filter(
          //     item => item.zIndex === min
          //   );
          //   if (Item.flag === 0) {
          //     // 如果拖动的窗体已经是灰窗就没必要 再灰其他窗了
          //   } else {
          //     if (minItm[0].flag) {
          //       // 保证不是灰窗 如果是灰窗就没必要再灰窗
          //       isGay.push(minItm[0].num);
          //     }
          //   }
          // }
          // let { type: ItemType } = incardListData.find(
          //   i => i.cID === Item.Vsrc_CH
          // );
          // if ((ItemType >= 17 && ItemType <= 48) || ItemType === 23) {
          //   // Item输入卡是4k的话
          //   let notHaveMeLightWindow = hasLightWindow.filter(
          //     item => item.num !== Item.num
          //   );
          //   notHaveMeLightWindow.forEach(item => {
          //     isGay.push(item.num);
          //   });
          // }
        });

        resolve({
          isGay
        });
      });
    },
    // 置顶时哪些窗体需要灰窗
    computedGayNumUp(ItemOmap, Item) {
      let _this = this;
      return new Promise((resolve, reject) => {
        let isGay = [];
        ItemOmap.forEach(a => {
          // 找出当前映射区域有哪些窗体
          let ItemOmapWindow = _this.getOmapHaveWindow(a);
          console.log(ItemOmapWindow, "computedGayNumUp：当前映射区域的已开窗");
          // 判断当前映射区域的窗体里面有没有两个亮窗
          let hasLightWindow = ItemOmapWindow.filter(item => item.flag);
          let hasLightWindowID = [];
          hasLightWindow.forEach(item => hasLightWindowID.push(item.num));
          // 如果当前区域的亮窗数量大于2或者等于2 则需要进行灰窗
          if (hasLightWindow.length === 2) {
            console.log("当前亮窗有两个");
            // 找出哪些需要灰窗 不包括当前窗体
            if (!hasLightWindowID.includes(Item.num)) {
              let zIndexList = [];
              hasLightWindow.forEach(item => {
                zIndexList.push(item.zIndex);
              });
              let min = Math.min(...zIndexList);
              let minItm = hasLightWindow.filter(item => item.zIndex === min);
              if (minItm[0].flag) {
                // 保证不是灰窗 如果是灰窗就没必要再灰窗
                isGay.push(minItm[0].num);
              }
            }
          }
          if (hasLightWindow.length > 2) {
            console.log("当前亮窗大于两个");
            // 找出哪些需要灰窗 不包括当前窗体
            let zIndexList = [];
            let notHaveMeLightWindow = hasLightWindow.filter(
              item => item.num !== Item.num
            );
            notHaveMeLightWindow.forEach(item => {
              zIndexList.push(item.zIndex);
            });
            let min = Math.min(...zIndexList);
            let minItm = notHaveMeLightWindow.filter(
              item => item.zIndex === min
            );
            if (minItm[0].flag) {
              // 保证不是灰窗 如果是灰窗就没必要再灰窗
              isGay.push(minItm[0].num);
            }
          }
          if (hasLightWindow.length === 1) {
          }
        });

        resolve({
          isGay
        });
      });
    },
    // 找出所有映射区域哪些需要亮窗
    computedLightNum(ItemOmap, Item) {
      let _this = this;
      return new Promise((resolve, reject) => {
        let isLight = [];
        ItemOmap.forEach(a => {
          // 找出当前映射区域有哪些窗体
          let ItemOmapWindow = _this.getOmapHaveWindow(a);
          console.log(ItemOmapWindow, "当前映射区域的已开窗");
          // 判断当前映射区域的窗体里面有没有两个亮窗
          let hasLightWindow = ItemOmapWindow.filter(item => item.flag === 1);
          let hasGayWindow = ItemOmapWindow.filter(item => item.flag === 0);
          console.log(hasLightWindow, "hasLightWindow");
          console.log(hasGayWindow, "hasGayWindow");

          if (hasLightWindow.length < 2) {
            let zIndexList = [];
            hasGayWindow.forEach(item => {
              zIndexList.push(item.zIndex);
            });
            if (hasLightWindow.length === 0) {
              let zIndexItem = zIndexList.sort((a, b) => a - b).slice(-2);
              zIndexItem.forEach(itemZindex => {
                if (itemZindex) {
                  let z = hasGayWindow.filter(
                    item => item.zIndex == itemZindex
                  );
                  // 如果这个窗与多个映射相交  则需要判断这个窗在其他映射位置能否弹起
                  let ItemOmap = this.getWindowIntersectOmap(z[0]);
                  console.log(
                    ItemOmap,
                    "弹起2:找出与当前窗体相交的映射区域有哪些"
                  );
                  if (this.windowIsLight(z[0])) {
                    isLight.push(z[0].num);
                  }
                }
              });
            }
            if (hasLightWindow.length === 1) {
              let max = Math.max(...zIndexList);
              let maxItem = hasGayWindow.filter(item => item.zIndex === max);
              if (maxItem[0]) {
                // 如果这个窗与多个映射相交  则需要判断这个窗在其他映射位置能否弹起
                let ItemOmap = this.getWindowIntersectOmap(maxItem[0]);
                console.log(
                  ItemOmap,
                  "弹起1:找出与当前窗体相交的映射区域有哪些"
                );
                console.log(a, "当前映射区域");
                if (ItemOmap.length > 1) {
                  // 当此窗相交两个映射区域时
                  console.log(maxItem[0], "computedLightNum这是相交的窗");
                  let hasGayWindowNotME = hasGayWindow.filter(
                    item => item.num !== maxItem[0].num
                  );
                  if (hasGayWindowNotME.length === 0) {
                    if (this.windowIsLight(maxItem[0])) {
                      _this.Layers.forEach(i => {
                        if (i.num === maxItem[0].num) {
                          i.flag = 1;
                        }
                      });
                      isLight.push(maxItem[0].num);
                    }
                  }
                  console.log(hasGayWindowNotME, "hasGayWindowNotME");
                  let zIndexListNotME = [];
                  hasGayWindowNotME.forEach(item => {
                    zIndexListNotME.push(item.zIndex);
                  });
                  console.log(zIndexListNotME, "zIndexListNotME");
                  let maxNotME = Math.max(...zIndexListNotME);
                  let maxNotMEItem = hasGayWindowNotME.filter(
                    item => item.zIndex === maxNotME
                  );
                  console.log(maxNotMEItem, "maxNotMEItem");
                  console.log(maxNotMEItem[0], "maxNotMEItem[0]");
                  if (maxNotMEItem[0]) {
                    console.log(
                      `${maxNotMEItem[0].num}是否能弹起：`,
                      this.windowIsLight(maxNotMEItem[0])
                    );
                    if (this.windowIsLight(maxNotMEItem[0])) {
                      _this.Layers.forEach(i => {
                        if (i.num === maxItem[0].num) {
                          i.flag = 1;
                        }
                      });

                      isLight.push(maxNotMEItem[0].num);
                    } else {
                      console.log("maxNotMEItem[0]不能弹起");
                      // 找到当前的灰窗 排除和多个映射相交的窗
                      let zIndexListNotMECopy = [];
                      hasGayWindowNotME.forEach(item => {
                        if (zIndexListNotME.includes(item.zIndex)) {
                          let ItemOmap1 = _this.getWindowIntersectOmap(item);
                          if (ItemOmap1.length === 1) {
                            zIndexListNotMECopy.push(item.zIndex);
                          }
                        }
                      });
                      let maxNotMECopy = Math.max(...zIndexListNotMECopy);
                      let maxNotMEItemCopy = hasGayWindowNotME.filter(
                        item => item.zIndex === maxNotMECopy
                      );
                      if (maxNotMEItemCopy[0]) {
                        if (this.windowIsLight(maxNotMEItemCopy[0])) {
                          _this.Layers.forEach(i => {
                            if (i.num === maxNotMEItemCopy[0].num) {
                              i.flag = 1;
                            }
                          });
                          isLight.push(maxNotMEItemCopy[0].num);
                        }
                      }
                    }
                  }
                } else {
                  console.log("没有相交");
                  if (this.windowIsLight(maxItem[0])) {
                    this.Layers.forEach(i => {
                      if (i.num === maxItem[0].num) {
                        i.flag = 1;
                      }
                    });
                    isLight.push(maxItem[0].num);
                  }
                }
              }
            }
          }
          // if (Item.flag===0){
          //   isLight.push(Item.num)
          // }
        });

        resolve({
          isLight
        });
      });
    },
    // 置顶时哪些需要亮窗
    computedLightNumUp(ItemOmap, Item) {
      let _this = this;
      return new Promise((resolve, reject) => {
        let isLight = [];
        ItemOmap.forEach(a => {
          // 找出当前映射区域有哪些窗体
          let ItemOmapWindow = _this.getOmapHaveWindow(a);
          console.log(ItemOmapWindow, "当前映射区域的已开窗");
          // 判断当前映射区域的窗体里面有没有两个亮窗
          let hasLightWindow = ItemOmapWindow.filter(item => item.flag);
          let hasGayWindow = ItemOmapWindow.filter(item => !item.flag);
          if (hasLightWindow.length < 2) {
            let zIndexList = [];
            hasGayWindow.forEach(item => {
              zIndexList.push(item.zIndex);
            });
            if (hasLightWindow.length === 0) {
              let zIndexItem = zIndexList.sort((a, b) => a - b).slice(-2);
              zIndexItem.forEach(itemZindex => {
                if (itemZindex) {
                  let z = hasGayWindow.filter(
                    item => item.zIndex == itemZindex
                  );
                  let ItemOmap = this.getWindowIntersectOmap(z[0]);
                  console.log(
                    ItemOmap,
                    "弹起4:找出与当前窗体相交的映射区域有哪些"
                  );
                  isLight.push(z[0].num);
                }
              });
            }
            if (hasLightWindow.length === 1) {
              let max = Math.max(...zIndexList);
              let maxItem = hasGayWindow.filter(item => item.zIndex === max);
              if (maxItem[0]) {
                isLight.push(maxItem[0].num);
              }
            }
          }
          // if (Item.flag===0){
          //   isLight.push(Item.num)
          // }
        });

        resolve({
          isLight
        });
      });
    },
    // 置底时哪些窗需要亮起
    computedLightNumBottom(ItemOmap, Item) {
      let _this = this;
      return new Promise((resolve, reject) => {
        let isLight = [];
        ItemOmap.forEach(a => {
          // 找出当前映射区域有哪些窗体
          let ItemOmapWindow = _this.getOmapHaveWindow(a);
          console.log(ItemOmapWindow, "当前映射区域的已开窗");
          // 判断当前映射区域的窗体里面有没有两个亮窗
          let hasLightWindow = ItemOmapWindow.filter(item => item.flag);
          let hasGayWindow = ItemOmapWindow.filter(item => !item.flag);
          if (hasLightWindow.length < 2) {
            console.log("当前映射区域亮窗数量小于两个");
            let zIndexList = [];
            hasGayWindow.forEach(item => {
              zIndexList.push(item.zIndex);
            });
            if (hasLightWindow.length === 0) {
              let zIndexItem = zIndexList.sort((a, b) => a - b).slice(-2);
              zIndexItem.forEach(itemZindex => {
                if (itemZindex) {
                  let z = hasGayWindow.filter(
                    item => item.zIndex == itemZindex
                  );
                  let ItemOmap = this.getWindowIntersectOmap(z[0]);
                  console.log(
                    ItemOmap,
                    "弹起5:找出与当前窗体相交的映射区域有哪些"
                  );
                  if (this.windowIsLight(z[0])) {
                    isLight.push(z[0].num);
                  }
                }
              });
            }
            if (hasLightWindow.length === 1) {
              let max = Math.max(...zIndexList);
              let maxItem = hasGayWindow.filter(item => item.zIndex === max);
              if (maxItem[0]) {
                // 如果这个窗与多个映射相交  则需要判断这个窗在其他映射位置能否弹起
                let ItemOmap = this.getWindowIntersectOmap(maxItem[0]);
                console.log(
                  ItemOmap,
                  "Bottom弹起1:找出与当前窗体相交的映射区域有哪些"
                );

                if (ItemOmap.length > 1) {
                  // 当此窗相交两个映射区域时
                  console.log(a, "当前映射区域");
                  console.log(maxItem[0], "置底：这是相交的窗");
                  let hasGayWindowNotME = hasGayWindow.filter(
                    item => item.num !== maxItem[0].num
                  );
                  let zIndexListNotME = [];
                  hasGayWindowNotME.forEach(item => {
                    zIndexListNotME.push(item.zIndex);
                  });
                  let maxNotME = Math.max(...zIndexListNotME);
                  let maxNotMEItem = hasGayWindowNotME.filter(
                    item => item.zIndex === maxNotME
                  );
                  console.log(maxNotMEItem[0], "maxNotMEItem[0]");
                  if (maxNotMEItem[0]) {
                    console.log(
                      `${maxItem[0].num}是否能弹起maxItem：`,
                      _this.windowIsLight(maxItem[0])
                    );
                    if (_this.windowIsLight(maxItem[0])) {
                      console.log(maxItem[0].num, "maxItem[0].num");
                      _this.Layers.forEach(i => {
                        if (i.num === maxItem[0].num) {
                          i.flag = 1;
                        }
                      });
                      isLight.push(maxItem[0].num);
                    }

                    console.log(
                      `${maxNotMEItem[0].num}是否能弹起maxNotMEItem：`,
                      _this.windowIsLight(maxNotMEItem[0])
                    );
                    if (_this.windowIsLight(maxNotMEItem[0])) {
                      console.log(maxNotMEItem[0].num, "maxNotMEItem[0].num");
                      _this.Layers.forEach(i => {
                        if (i.num === maxNotMEItem[0].num) {
                          i.flag = 1;
                        }
                      });
                      isLight.push(maxNotMEItem[0].num);
                    }
                  } else {
                    console.log(
                      `${maxItem[0].num}是否能弹起maxItem：`,
                      _this.windowIsLight(maxItem[0])
                    );
                    if (_this.windowIsLight(maxItem[0])) {
                      _this.Layers.forEach(i => {
                        if (i.num === maxItem[0].num) {
                          i.flag = 1;
                        }
                      });
                      isLight.push(maxItem[0].num);
                    }
                  }
                } else {
                  console.log("没有相交的");
                  console.log(
                    `${maxItem[0].num}是否能弹起：`,
                    this.windowIsLight(maxItem[0])
                  );
                  if (this.windowIsLight(maxItem[0])) {
                    this.Layers.forEach(i => {
                      if (i.num === maxItem[0].num) {
                        let dom = window.document.querySelector(
                          `#mouseWarp0${maxItem[0].num}`
                        );
                        // dom.style.zIndex=
                        i.flag = 1;
                      }
                    });
                    isLight.push(maxItem[0].num);
                  }
                }
              }
            }
          }
          // if (Item.flag===0){
          //   isLight.push(Item.num)
          // }
        });

        resolve({
          isLight
        });
      });
    },
    // 判断当前窗能否亮起 输入当前窗 输出布尔值
    windowIsLight(item) {
      let _this = this;
      // 找到相交的映射
      let ItemOmap = this.getWindowIntersectOmap(item);
      // 找到每个映射上的屏幕
      let scenceWindowNum = [];
      ItemOmap.forEach(a => {
        let omapWindowNum = [];
        let ItemOmapWindow = _this.getOmapHaveWindow(a);
        ItemOmapWindow.filter(item => {
          if (item.flag === 1) {
            omapWindowNum.push(item);
          }
        });
        scenceWindowNum.push(omapWindowNum);
      });
      console.log(scenceWindowNum, `item.num:${item.num}:scenceWindowNum`);
      return scenceWindowNum.every(i => i.length <= 1);
    },
    // 找出与当前窗体相交的映射区域有哪些
    getWindowIntersectOmap(ite) {
      let omap = [];
      let item = {
        ...ite
      };
      let n = 4;
      item.inpW -= n;
      item.inpH -= n;
      item.inpX += n / 2;
      item.inpY += n / 2;
      this.omap
        .filter(i => i.gid === this.gid)
        .forEach(a => {
          // a是映射 x y w h
          // item是窗口 inpX inpY inpW inpH
          if (
            Math.abs(a.x + a.w - (item.inpW + item.inpX)) +
              Math.abs(a.x - item.inpX) <
              item.inpW + a.w &&
            Math.abs(a.y + a.h - (item.inpH + item.inpY)) +
              Math.abs(a.y - item.inpY) <
              item.inpH + a.h
          ) {
            omap.push(a);
          }

          // if (
          //   a.x - item.inpX < item.inpW &&
          //   a.x + a.w > item.inpX &&
          //   a.y - item.inpY < item.inpH &&
          //   a.y + a.h > item.inpY
          // ) {
          //   omap.push(a);
          // }
        });
      return uniqBy(omap, "Logic_ch");
    },
    // 找出当前映射区域有哪些窗   a是映射区域
    getOmapHaveWindow(a) {
      let omapHaveWindow = [];
      // .filter(i => !(i.mark & 0x08))
      this.Layers.forEach((item, index) => {
        // a是映射 x y w h
        // item是窗口 inpX inpY inpW inpH

        // let item = {
        //   ...ite
        // };
        // let n = 4;
        // item.inpW -= n;
        // item.inpH -= n;
        // item.inpX += n / 2;
        // item.inpY += n / 2;
        let whdiff = item.mark & 0x08 ? 10 : 4;
        let xydiff = item.mark & 0x08 ? 5 : 2;

        if (
          Math.abs(a.x + a.w - (item.inpW - whdiff + item.inpX - xydiff)) +
            Math.abs(a.x - item.inpX - xydiff) <
            item.inpW - whdiff + a.w &&
          Math.abs(a.y + a.h - (item.inpH - whdiff + item.inpY - xydiff)) +
            Math.abs(a.y - item.inpY - xydiff) <
            item.inpH - whdiff + a.h
        ) {
          omapHaveWindow.push(item);
        }

        // if (
        //   a.x - item.inpX < item.inpW &&
        //   a.x + a.w > item.inpX &&
        //   a.y - item.inpY < item.inpH &&
        //   a.y + a.h > item.inpY
        // ) {
        //   omapHaveWindow.push(item);
        // }
      });
      return omapHaveWindow;
    },
    // 贴边处理
    WindowWelt(item) {
      let _this = this;
      return new Promise((resolve, reject) => {
        // 是否相交 相交多个屏幕才需要贴边处理
        let ItemOmap = this.getWindowIntersectOmap(item);
        if (ItemOmap.length >= 2) {
          console.log("当前拖动的窗需要贴边处理");
          console.log("WindowWelt:ItemOmap", ItemOmap);
          let MaxOmapX = Math.max.apply(Math, ItemOmap.map(I => I.x));
          let MinOmapX = Math.min.apply(Math, ItemOmap.map(I => I.x));
          let rightOmap = ItemOmap.reduce((p, v) => (p.x < v.x ? v : p)); // 最大
          let leftOmap = ItemOmap.reduce((p, v) => (p.x > v.x ? v : p)); // 最小
          console.log("WindowWelt:MaxOmapX", MaxOmapX);
          console.log("WindowWelt:MinOmapX", MinOmapX);
          console.log("WindowWelt:rightOmap", rightOmap);
          console.log("WindowWelt:leftOmap", leftOmap);
          // 窗体右边缘的中间线
          let windowX = item.inpX + item.inpW;
          console.log("当前拖动窗体的右边缘x", windowX);
          let CentreRightOmapX = MaxOmapX + 50; // 最右映射区域的相交线的右阈值
          let CentreLeftOmapX = MaxOmapX - 50; // 最右映射区域的相交线的左阈值
          if (item.inpX > CentreLeftOmapX && item.inpX < MaxOmapX) {
            console.log("到达中间线的左阈值，这时候要右移动");
            // 窗体的x坐标加上偏移的量
            // 偏移量
            let offset = MaxOmapX - item.inpX + 10;
            console.log("往右偏移：", offset);
            let dom = window.document.querySelector(`#mouseWarp0${item.num}`);
            item.inpX = item.inpX + offset;
            let itemLeft = parseFloat(dom.style.left) + this.Wrate * offset;
            dom.style.left = `${itemLeft}px`;
            // 还要减宽度
            item.inpW = item.inpW - offset;
            let itemWidth = parseFloat(dom.style.width) - this.Wrate * offset;
            dom.style.width = `${itemWidth}px`;
          }
          if (windowX > MaxOmapX && windowX < CentreRightOmapX) {
            console.log("到达中间线的右阈值，这时候要左移动");
            // 偏移量
            let offset = windowX - MaxOmapX + 10;
            console.log("往左偏移：", offset);
            console.log("偏移像素：", this.Wrate * offset);
            let dom = window.document.querySelector(`#mouseWarp0${item.num}`);
            // 减位置X
            // item.inpX=item.inpX-offset
            // let itemLeft=parseFloat(dom.style.left)-this.Wrate*offset
            // dom.style.left=`${itemLeft}px`
            // 减宽度
            item.inpW = item.inpW - offset;
            let itemWidth = parseFloat(dom.style.width) - this.Wrate * offset;
            dom.style.width = `${itemWidth}px`;

            // item.inpX=item.inpX-offset
            // dom.style.left=`${parseFloat(dom.style.left)+this.Wrate*offset}px`
          }

          //窗体左边缘的中间线

          resolve(true);
        } else {
          resolve(true);
          console.log("当前拖动的窗不需要贴边处理");
        }
      });
    },
    // 同步窗口
    getSyncWindow() {
      this.Layers = [];
      let _this = this;
      return new Promise(resolve => {
        websocketsend(`(sync,wnd)\r\n`, res => {
          console.log("查询同步窗口的数据：", res);
          const dataArray = res.filter(item => item["winfo sync"]);
          // const { "winfo sync": winfo_sync } = dataArray[0];
          const winfo_sync = dataArray.reduce((arr, item) => {
            if (item["winfo sync"]) {
              arr.push(...item["winfo sync"]);
            }
            return arr;
          }, []);
          console.log("dataArray", dataArray);
          console.log("winfo_sync", winfo_sync);
          // localStorage.setItem("wndData", JSON.stringify(winfo_sync));
          let dom = document.getElementById("ptngridwarp0");
          console.log(dom.firstElementChild, "dom.firstElementChild");
          console.log(dom.firstChild, "dom.firstChild");
          let { width, height } = dom.firstElementChild.style;
          let layouts = [...winfo_sync]
            .filter(i => i.gID == _this.gid)
            .map(item => {
              // let w = item.w ? item.w - _this.hgap : item.w;
              // let h = item.h ? item.h - _this.vgap : item.h;
              // let l = item.x ? item.x - _this.hgap / 2 : item.x;
              // let t = item.y ? item.y - _this.vgap / 2 : item.y;
              // let Wr = parseFloat(width) / item.w;
              // let Hr = parseFloat(height) / item.h;
              return {
                styleObj: {
                  width: `${item.w * this.Wrate}px`,
                  height: `${item.h * this.Hrate}px`,
                  position: "absolute",
                  background: item.flag
                    ? _this.CreateColor(item.wID % 36, 36)
                    : "#909399",
                  left: `${item.x * this.Wrate}px`,
                  top: `${item.y * this.Hrate}px`,
                  zIndex: item.order,
                  "min-width": `${201 * this.Wrate}px`,
                  "min-height": `${201 * this.Hrate}px`
                },
                inpW: item.w,
                inpH: item.h,
                inpX: item.x,
                inpY: item.y,
                zIndex: item.order, // 叠放序号
                num: item.wID, // 窗口标志
                // name: _this.CardINOUTList[item.in_ch],
                name: item.in_ch,
                singal_flag: 0, // 有无信号
                // haState: _this.haStateList[item.flag], // 窗体是否有效 0 无效 1有效 默认0
                haState: 1, // 窗体是否有效 0 无效 1有效 默认0
                isM: false, // 是否最大化满屏 默认false
                isW: false, // 是否无效窗口 默认false
                isF: false, // 是否放大 默认false
                contextMenuVisible: false, // 是否显示右键菜单
                Vsrc_CH: item.in_ch,
                Vsrc_clip_style: item.clip_style,
                lock: 0, // 是否锁定窗口 0无效 1锁定
                isTitle: 1, // 是否显示标题 0不显示 1显示 默认1显示
                x: 0, // 放大之后存储x轴
                y: 0, // 放大之后存储y轴
                w: 0, // 放大之后存储w宽
                h: 0, // 放大之后存储h高
                mark: item.mark,
                flag: item.flag // 灰窗还是亮窗
              };
            });
          layouts.forEach(item => {
            for (let j in _this.inList) {
              if (j == item.Vsrc_CH) {
                // console.log(_this.inList[j].singal_flag,'_this.inList[j].singal_flag')
                item.singal_flag = _this.inList[j].singal_flag;
                if (_this.inList[j].rename) {
                  item.name = _this.inList[j].rename;
                } else {
                  item.name = `${_this.NameList[_this.inList[j].card_type] +
                    _this.inList[j].ch}`;
                }
              }
            }
            switch (item.mark) {
              // 0,非全屏，非锁屏，标题开
              case 0: {
                break;
              }
              // 1，全屏，非锁屏，标题开
              case 1: {
                item.isM = true;
                break;
              }
              // 2，非全屏，锁屏，标题开
              case 2: {
                item.lock = 1;
                break;
              }
              // 3，全屏，锁屏，标题开
              case 3: {
                item.isM = true;
                item.lock = 1;
                break;
              }
              // 4，非全屏，非锁屏，标题关
              case 4: {
                item.isTitle = 0;
                break;
              }
              // 5，全屏，非锁屏，标题关
              case 5: {
                item.isM = true;
                item.isTitle = 0;
                break;
              }
              // 6，非全屏，锁屏，标题关
              case 6: {
                item.lock = 1;
                item.isTitle = 0;
                break;
              }
              // 7，全屏，锁屏，标题关
              case 7: {
                item.isM = true;
                item.lock = 1;
                item.isTitle = 0;
                break;
              }
            }
          });

          this.Layers.push(...layouts);
          setTimeout(resolve, 200);
          console.log(this.Layers, "this.Layers");
          console.log(res.winfo_sync, "窗口同步的信息");
          this.handleClickLoading.close();
        });
      });
    },
    // 根据行列计算矩阵
    computedGrid(rows, columns) {
      const _this = this;
      // let a = []
      // for (let i = 1; i < rows * columns + 1; i++) {
      //   a.push({
      //     import: '',
      //     importCh: '',
      //     output: '',
      //     outputCh: '',
      //     handleClass: '',
      //     singal_flagClass: '',
      //     hpd_link: '',
      //     card_type: ''
      //   })
      // }
      // return a  // 生成一维数组
      // let WarpWidth = getStyle(this.$refs["ptngridwarp0"][0], "width");
      // let WarpHeight = getStyle(this.$refs["ptngridwarp0"][0], "height");
      let WarpWidth = _this.WarpWidth;
      let WarpHeight = _this.WarpHeight;
      let a = [];
      let GridTwoArray = [];
      for (let i = 1; i < rows * columns + 1; i++) {
        a.push({
          Logic_ch: i,
          import: "",
          importCh: "",
          output: "",
          outputCh: "",
          handleClass: "",
          singal_flagClass: "",
          hpd_link: "",
          card_type: ""
        });
      }
      for (let i = 0; i < a.length; i += columns) {
        GridTwoArray.push(a.slice(i, i + columns));
      }

      for (let i = 0; i < GridTwoArray.length; i++) {
        for (let j = 0; j < GridTwoArray[i].length; j++) {
          GridTwoArray[i][j]["X"] = j * (parseFloat(WarpWidth) / this.Cols);
          GridTwoArray[i][j]["Y"] = i * (parseFloat(WarpHeight) / this.Rows);
          // GridTwoArray[i][j]["W"] = parseFloat(WarpWidth) / this.Cols;
          // GridTwoArray[i][j]["H"] = parseFloat(WarpHeight) / this.Rows;
          if (_this.$root.GroupType === 2) {
            GridTwoArray[i][j]["W"] = this.H_ACTIVE * this.Wrate;
            GridTwoArray[i][j]["H"] = this.V_ACTIVE * this.Hrate;
          } else {
            GridTwoArray[i][j]["W"] = this.H_ACTIVE * this.Wrate;
            GridTwoArray[i][j]["H"] = this.V_ACTIVE * this.Hrate;
          }

          // GridTwoArray[i][j]["W"] = this.H_ACTIVE * 0.1;
          // GridTwoArray[i][j]["H"] = this.V_ACTIVE * 0.1;
          GridTwoArray[i][j]["oX"] = j * this.H_ACTIVE;
          GridTwoArray[i][j]["oY"] = i * this.V_ACTIVE;
        }
      }

      return [...GridTwoArray.flat()];
    },
    // 计算宫格坐标
    computedXYArray(rows, columns) {
      let a = [];
      this.GridTwoArray = [];
      for (let i = 1; i < rows * columns + 1; i++) {
        a.push({ Logic_ch: i });
      }
      for (let i = 0; i < a.length; i += columns) {
        this.GridTwoArray.push(a.slice(i, i + columns));
      }
      for (let i = 0; i < this.GridTwoArray.length; i++) {
        for (let j = 0; j < this.GridTwoArray[i].length; j++) {
          this.GridTwoArray[i][j]["X"] = j * this.H_ACTIVE;
          this.GridTwoArray[i][j]["Y"] = i * this.V_ACTIVE;
        }
      }
      this.GridTwoArray = [...this.GridTwoArray.flat()];
      console.log(this.GridTwoArray, "this.GridTwoArray");
      console.log(this.omap, "this.omap");
    },
    // 计算逻辑子屏幕的坐标
    computedLJArray(rows, columns, lr, lc) {
      let a = [];
      this.GridLJArray = [];
      for (let i = 1; i < rows * columns + 1; i++) {
        a.push({});
      }
      for (let i = 0; i < a.length; i += columns) {
        this.GridLJArray.push(a.slice(i, i + columns));
      }
      for (let i = 0; i < this.GridLJArray.length; i++) {
        for (let j = 0; j < this.GridLJArray[i].length; j++) {
          if (j === 0) {
            this.GridLJArray[i][j]["x"] = j * (this.H_ACTIVE / lc);
          } else {
            if (j % 2 === 0) {
              this.GridLJArray[i][j]["x"] =
                j * (this.H_ACTIVE / lc) + this.hgap * (j / 2);
            } else {
              this.GridLJArray[i][j]["x"] =
                this.GridLJArray[i][j - 1]["x"] + this.H_ACTIVE / lc;
            }
          }

          if (i === 0) {
            this.GridLJArray[i][j]["y"] = i * (this.V_ACTIVE / lr);
          } else {
            if (i % 2 === 0) {
              this.GridLJArray[i][j]["y"] =
                i * (this.V_ACTIVE / lr) + this.vgap * (i / 2);
            } else {
              this.GridLJArray[i][j]["y"] =
                this.GridLJArray[i - 1][j]["y"] + this.V_ACTIVE / lr;
            }
          }

          this.GridLJArray[i][j]["w"] = this.H_ACTIVE / lc;
          this.GridLJArray[i][j]["h"] = this.V_ACTIVE / lr;
        }
      }
      console.log(this.GridLJArray, "this.GridLJArray");
      this.GridLJArray = [...this.GridLJArray.flat()];
      console.log(this.GridLJArray, "this.GridLJArray");
    },
    // 获取分组列表
    getGinfo_sync(iSend) {
      let _this = this;
      // ginfo_syncApi({
      //   cmd: "ginfo_sync"
      // }).then(res => {
      //   this.GroupContext = res.ginfo_sync.context; // 分组列表
      //   this.gid = res.ginfo_sync.curr_grp; // 当前的分组ID
      //   this.getscene_polling();
      //   let activeItem = this.GroupContext.filter(
      //     item => item.gID === this.gid
      //   );
      //   // console.log(activeItem,'activeItemactiveItemactiveItemactiveItem')
      //   this.omap = [...res.omap];
      //   console.log(activeItem, "activeItemactiveItemactiveItem");
      //   this.handleClick(activeItem[0]);
      // });
      ginfo_syncApi({ cmd: "ginfo_sync" }, true).then(res => {
        const dataArray = res;
        // localStorage.setItem("omapData", JSON.stringify(dataArray));
        const GroupContext = dataArray
          .map(item => {
            if (item["ginfo sync"]) {
              _this.gid = item["ginfo sync"]["curr grp"];
              return item["ginfo sync"].context;
            }
            // if (item["omap"]) {
            //   _this.omap = item["omap"];
            // }
          })
          .filter(Boolean);

        _this.omap = dataArray.reduce((arr, item) => {
          if (item["omap"]) {
            // let { hgap, vgap } = GroupContext.find(i => i.gID === _this.gid);
            // let gidOmap = item["omap"].filter(i => i.gid === _this.gid);
            // gidOmap.forEach(i => {
            // i.w -= Math.ceil(hgap / 2);
            // i.h -= Math.ceil(vgap / 2);
            // });
            arr.push(...item["omap"]);
          }
          return arr;
        }, []);

        console.log("dataArray", dataArray);
        console.log("GroupContext", GroupContext);
        localStorage.setItem("GroupContext", JSON.stringify(GroupContext));
        _this.GroupContext = GroupContext;
        let activeItem = _this.GroupContext.filter(
          item => item.gID === _this.gid
        );
        // 设置场景轮询参数
        this.dialog.poll.form.en = activeItem[0].scene_polling.status;

        this.dialog.poll.form.period = activeItem[0].scene_polling.interval;
        if (activeItem[0].scene_polling.interval <= 0) {
          this.dialog.poll.form.period = 5;
        }
        if (activeItem[0].scene_polling.interval >= 120) {
          this.dialog.poll.form.period = 120;
        }
        // this.dialog.poll.form.Id_group = activeItem[0].scene_polling.list || [];
        // 模拟点击分组按钮
        _this.handleClick(activeItem[0]);
      });
    },
    // 上位机算法生成36个颜色
    CreateColor(i, count) {
      let h = (((i + 1) * 2560) / count) % 256;
      let s = (((i + 1) * 1780) / count) % 256;
      let v = 200;
      return `rgb(${parseInt(h)},${parseInt(s)},${v})`;
    },
    sortByKey(array, key) {
      return array.sort(function(a, b) {
        var x = a[key];
        var y = b[key];
        return x < y ? -1 : x > y ? 1 : 0;
      });
    },
    GridArrayDrop(ev, item) {
      console.log("GridArrayDrop.............................");
      console.log(item, "item");
      let _this = this;
      // console.log(ev, 'warpDropevvvvvvvvvvvvvvvvvv')

      // let layerX = ev.layerX;
      // let layerY = ev.layerY;
      // console.log(layerX, "layerX");
      // console.log(layerY, "layerY");
      console.log(this.omap, "有多少个黑块");
      //TODO: 开窗数量不能超过 输出卡数量的4倍
      let itemGidOmapList = _this.omap.filter(
        item =>
          item.gid === _this.gid &&
          _this.cardOutputChList.includes(parseInt(item.Phy_ch))
      );
      console.log(itemGidOmapList, "itemGidOmapList");
      let windowsOpenNum =
        _this.Layers.length - _this.Layers.filter(i => i.mark & 0x08).length;
      if (
        windowsOpenNum > itemGidOmapList.length * 4 ||
        windowsOpenNum === itemGidOmapList.length * 4
      ) {
        return false;
      }
      console.log(ev.target, "warpDropevvvvvvvvvvvvvvvvvvevtarget");
      console.log(_this.$refs[`ptngridwarp${_this.initial_index}`][0]);
      // if (ev.target !== _this.$refs[`ptngridwarp${_this.initial_index}`][0]) {
      //   return false;
      // }
      console.log("执行到了这里");
      let evData = ev.dataTransfer.getData("abcd");
      let JsonEvData = JSON.parse(evData);
      let num = 0;
      let LayersLengthArray = [];
      let indexList = [];
      if (_this.Layers.length) {
        _this.Layers.forEach((i, index) => {
          LayersLengthArray.push(
            Math.abs(i.num - _this.gidRangList[_this.gid])
          );
        });
        LayersLengthArray.forEach((item, index) => {
          if (!LayersLengthArray.includes(item - 4) && item !== 1) {
            indexList.push(item - 4);
          }
        });

        if (indexList.length) {
          num = Math.max(...indexList);
        } else {
          num = Math.max(...LayersLengthArray) + 4;
        }
        // console.log(_this.Layers, "_this.Layers");
        // console.log(indexList, "indexList");
        // console.log(LayersLengthArray, "LayersLengthArray");
      } else {
        num = 1;
      }
      console.log(num, "nummmmmmmmmmmmmmmmmm");

      /* 解决原元素消失的问题  克隆节点而不是直接追加节点 */
      // let ref = this.$refs[data][0]
      // console.log(ref,'dommmmmm')
      // let dom = ref.cloneNode(true)
      // console.log(dom,'dommmmmm')

      // dom.style.left=`${ev.layerX-50}px`
      // dom.style.top=`${ev.layerY-50}px`
      // dom.style.zIndex=index

      // let dom=document.createElement('div')
      // dom.style.width=`100px`
      // dom.style.height=`100px`
      // dom.style.backgroundImage=`linear-gradient(45deg, #93a5cf 0%, #e4efe9 100%)`
      // dom.style.position=`absolute`
      // dom.setAttribute('inpW', 100)
      // dom.setAttribute('inpH', 100)
      // dom.setAttribute('inpX', this.num*50)
      // dom.setAttribute('inpY', this.num*50)
      // dom.style.left=`${this.num*50}px`
      // dom.style.top=`${this.num*50}px`
      // dom.style.zIndex=this.index

      // console.log('ev.layerX:',ev.layerX)
      // console.log('ev.layerY:',ev.layerY)

      // let inpW = parseInt(200 / _this.Wrate);
      // let inpH = parseInt(200 / _this.Hrate);
      // let inpX = parseInt(layerX / _this.Wrate);
      // let inpY = parseInt(layerY / _this.Hrate);

      // console.log(inpX, 'inpX')
      // console.log(inpY, 'inpY')
      // let i = this.GridTwoArray.find(
      //   i =>
      //     inpX > i.X &&
      //     inpX < i.X + _this.H_ACTIVE &&
      //     inpY > i.Y &&
      //     inpY < i.Y + _this.V_ACTIVE
      // );
      let haStateItem = _this.omap.find(
        ite => ite.gid === _this.gid && ite.Logic_ch === item.Logic_ch
      );

      // console.log(i, "GridTwoArrayItem");
      let GridArrayItem = this.GridArray.find(j => j.Logic_ch == item.Logic_ch);
      // console.log(this.GridTwoArray, 'this.GridTwoArray')
      // console.log(this.omap, 'this.omap')
      // console.log(_this.H_ACTIVE, '_this.H_ACTIVE')
      // console.log(_this.V_ACTIVE, '_this.V_ACTIVE')

      if (haStateItem && GridArrayItem.handleClass === "out") {
        // 这个屏幕上的块要已经映射才可以开窗
        console.log("相交了");
        console.log(haStateItem, "haStateItem");

        _this.isWebSwitch = true;

        // let haStateItem = this.omap.filter(
        //   item =>
        //     item.gid === _this.gid &&
        //     _this.cardOutputChList.includes(parseInt(item.Phy_ch)) &&
        //     item.x === i.X &&
        //     item.y === i.Y
        // );

        // console.log(haStateItem, "haStateItem");
        // console.log(_this.Layers.map(item=>parseInt(item.zIndex)),'_this.Layers.map(item=>parseInt(item.zIndex)')
        let zIndexmax = _this.Layers.length
          ? Math.max(..._this.Layers.map(item => parseInt(item.zIndex)))
          : 0;
        let zIndexmaxWindow = _this.Layers.find(
          item => item.zIndex === zIndexmax
        );
        let chleft = zIndexmaxWindow ? zIndexmaxWindow.Vsrc_CH : 0;
        let incardListData = JSON.parse(localStorage.getItem("incardListData"));
        let chleftType;
        let inCard = incardListData.find(i => i.cID === chleft);

        if (inCard) {
          chleftType = inCard.type;
        } else {
          chleftType = 0;
        }
        let chleftCount =
          (chleftType >= 17 && chleftType <= 48) || chleftType === 23 ? 2 : 1;
        // console.log(zIndexmax,'zIndexmax')

        // item.styleObj.background='rgba(0,0,0,0.2)'
        // item.styleObj.zIndex=0
        // item.zIndex=0
        let bkdom = document.getElementById(`${GridArrayItem.outputCh}ref`);
        let { left, top, width, height } = bkdom.style;
        console.log(bkdom, "bkdom");
        let ite = {
          styleObj: {
            width: width,
            height: height,
            position: "absolute",
            background: haStateItem
              ? _this.CreateColor((num + _this.gidRangList[_this.gid]) % 36, 36)
              : "rgba(0,0,0,0.2)",
            left: left,
            top: top,
            // zIndex:haStateItem.length ? zIndexmax + 1 : 0 ,
            zIndex: haStateItem ? zIndexmax + chleftCount : 0,
            "min-width": `${201 * this.Wrate}px`,
            "min-height": `${201 * this.Hrate}px`
          },
          // inpW: haStateItem.w + Math.ceil(_this.hgap / 2),
          // inpH: haStateItem.h + Math.ceil(_this.vgap / 2),
          inpW: haStateItem.w,
          inpH: haStateItem.h,
          inpX: haStateItem.x,
          inpY: haStateItem.y,
          // zIndex: haStateItem.length ? zIndexmax + 1 : 0, // 叠放序号
          zIndex: haStateItem ? zIndexmax + chleftCount : 0, // 叠放序号
          num: num + _this.gidRangList[_this.gid], // 窗口标志
          name: JsonEvData.name.split("_")[0],
          singal_flag: JsonEvData.singal_flag, // 有无信号
          haState: haStateItem ? 1 : 0, // 窗体是否有效 0 无效 1有效 默认0
          isM: false, // 是否最大化满屏 默认false
          isW: false, // 是否无效窗口 默认false
          isF: false, // 是否放大 默认false
          contextMenuVisible: false, // 是否显示右键菜单
          Vsrc_CH: JsonEvData.ch, // 输入源通道
          Vsrc_clip_style: JsonEvData.Vsrc_clip_style, // 信号裁剪方案
          lock: 0, // 是否锁定窗口 0无效 1锁定
          isTitle: 1, // 是否显示标题 0不显示 1显示 默认1显示
          x: 0, // 放大之后存储x轴
          y: 0, // 放大之后存储y轴
          w: 0, // 放大之后存储w宽
          h: 0, // 放大之后存储h高
          mark: item.mark,
          flag: 1
        };

        _this.moveOropenWindow(ite, "open");
        // 注释掉和后台同步
        // this.syncWindowOrder().then(res => {
        //   if (res) {
        //     _this.moveOropenWindow(ite, "open");
        //   }
        // });
      }
      console.log(JsonEvData, "JsonEvData");

      this.index++;
      this.num++;
    },
    GridArrayDragOver(ev, item) {
      ev.preventDefault();
    },
    GridArrayItemClick(item) {
      const _this = this;
      console.log("宫格的点击事件");

      //TODO: 开窗数量不能超过 输出卡数量的4倍
      let itemGidOmapList = _this.omap.filter(
        item =>
          item.gid === _this.gid &&
          _this.cardOutputChList.includes(parseInt(item.Phy_ch))
      );
      // console.log(itemGidOmapList, "itemGidOmapList");
      let windowsOpenNum =
        _this.Layers.length - _this.Layers.filter(i => i.mark & 0x08).length;
      if (
        windowsOpenNum > itemGidOmapList.length * 4 ||
        windowsOpenNum === itemGidOmapList.length * 4
      ) {
        return false;
      }

      if (!this.handleChCopy) {
        return false;
      }

      _this.isWebSwitch = true;

      let num = 0;
      let LayersLengthArray = [];
      let indexList = [];
      if (_this.Layers.length) {
        _this.Layers.forEach((i, index) => {
          LayersLengthArray.push(
            Math.abs(i.num - _this.gidRangList[_this.gid])
          );
        });
        LayersLengthArray.forEach((item, index) => {
          if (!LayersLengthArray.includes(item - 4) && item !== 1) {
            indexList.push(item - 4);
          }
        });

        if (indexList.length) {
          num = Math.max(...indexList);
        } else {
          num = Math.max(...LayersLengthArray) + 4;
        }
        // console.log(_this.Layers, '_this.Layers')
        // console.log(indexList, 'indexList')
        // console.log(LayersLengthArray, 'LayersLengthArray')
      } else {
        num = 1;
      }
      console.log(num, "nummmmmmmmmmmmmmmmmm");

      let haStateItem = _this.omap.find(
        ite => ite.gid === _this.gid && ite.Logic_ch === item.Logic_ch
      );
      console.log(haStateItem, "haStateItem");
      let GridArrayItem = this.GridArray.find(j => j.Logic_ch == item.Logic_ch);
      let zIndexmax = _this.Layers.length
        ? Math.max(..._this.Layers.map(item => parseInt(item.zIndex)))
        : 0;
      let zIndexmaxWindow = _this.Layers.find(
        item => item.zIndex === zIndexmax
      );
      let chleft = zIndexmaxWindow ? zIndexmaxWindow.Vsrc_CH : 0;
      let incardListData = JSON.parse(localStorage.getItem("incardListData"));
      let chleftType;
      let inCard = incardListData.find(i => i.cID === chleft);

      if (inCard) {
        chleftType = inCard.type;
      } else {
        chleftType = 0;
      }
      let chleftCount =
        (chleftType >= 17 && chleftType <= 48) || chleftType === 23 ? 2 : 1;
      console.log(this.handleChCopy, " => this.handleChCopy");
      console.log(this.handleChName, " => this.handleChName");
      console.log(this.handleSingal_flag, " => this.handleSingal_flag");
      let bkdom = document.getElementById(`${GridArrayItem.outputCh}ref`);
      if (bkdom) {
        let { left, top, width, height } = bkdom.style;
        let ite = {
          styleObj: {
            width: width,
            height: height,
            position: "absolute",
            background: haStateItem
              ? _this.CreateColor((num + _this.gidRangList[_this.gid]) % 36, 36)
              : "rgba(0,0,0,0.2)",
            left: left,
            top: top,
            zIndex: haStateItem ? zIndexmax + chleftCount : 0,
            "min-width": `${201 * this.Wrate}px`,
            "min-height": `${201 * this.Hrate}px`
          },
          // inpW: haStateItem.w + Math.ceil(_this.hgap / 2),
          // inpH: haStateItem.h + Math.ceil(_this.vgap / 2),
          inpW: haStateItem.w,
          inpH: haStateItem.h,
          inpX: haStateItem.x,
          inpY: haStateItem.y,
          zIndex: haStateItem ? zIndexmax + chleftCount : 0, // 叠放序号
          num: num + _this.gidRangList[_this.gid], // 窗口标志
          name: _this.handleChName.split("_")[0],
          singal_flag: parseInt(_this.handleSingal_flag), // 有无信号
          haState: haStateItem ? 1 : 0, // 窗体是否有效 0 无效 1有效 默认0
          isM: false, // 是否最大化满屏 默认false
          isW: false, // 是否无效窗口 默认false
          isF: false, // 是否放大 默认false
          contextMenuVisible: false, // 是否显示右键菜单
          Vsrc_CH: parseInt(_this.handleChCopy.split("_")[0]), // 输入源通道
          Vsrc_clip_style: this.handleVsrc_clip_style, // 信号裁剪方案
          lock: 0, // 是否锁定窗口 0无效 1锁定
          isTitle: 1, // 是否显示标题 0不显示 1显示 默认1显示
          x: 0, // 放大之后存储x轴
          y: 0, // 放大之后存储y轴
          w: 0, // 放大之后存储w宽
          h: 0, // 放大之后存储h高
          mark: 0,
          flag: 1
        };

        _this.moveOropenWindow(ite, "open");
        this.index++;
        this.num++;
      }
    },
    closeWindow(item, evv) {
      const _this = this;
      console.log(item, "item关闭窗口");
      console.log("closeWindow");
      // console.log(evv, "evv关闭窗口");
      // 场景轮询的时候，lockAll为true时禁用关闭窗口
      if (item.lockAll) {
        return false;
      }
      let num = item.num;
      // let index=this.Layers.indexOf(item)
      // console.log(index,'当前窗口的索引')
      this.Layers.forEach((i, index) => {
        if (i.num === num) {
          this.Layers.splice(index, 1);
        }
      });
      let chright = item.Vsrc_CH;
      let incardListData = JSON.parse(localStorage.getItem("incardListData"));
      let { type: chrightType } = incardListData.find(i => i.cID === chright);
      this.Layers.forEach(i => {
        if (i.zIndex > item.zIndex && item.zIndex !== 0) {
          if ((chrightType >= 17 && chrightType <= 48) || chrightType === 23) {
            i.styleObj.zIndex -= 2;
            i.zIndex -= 2;
          } else {
            i.styleObj.zIndex--;
            i.zIndex--;
          }
        }
      });

      websocketsend(`(wnd,close,1,${num})\r\n`, res => {
        // 关闭窗口后清掉中转
        _this.contextItem = {};
        _this.windowTarget = null;
        if (_this.closeWindowID.length) {
          windowNewChangeApi({
            cmd: "windowNewChange",
            Group: _this.gid,
            value: 1,
            ID: _this.closeWindowID
          });
          _this.closeWindowID = [];
        }
        console.log("关闭单个窗口的响应数据：", res);
        _this.autoOpenWindow();
      });
      this.index--;
      this.num--;
    },
    switchWindow(item) {
      console.log(item, "item");
      if (item.lock) {
        return false;
      }
      let inpW = parseFloat(item.inpW * this.Wrate) + "px";
      let inpH = parseFloat(item.inpH * this.Hrate) + "px";
      let inpX = item.inpX ? parseFloat(item.inpX * this.Wrate) + "px" : 0;
      let inpY = item.inpY ? parseFloat(item.inpY * this.Hrate) + "px" : 0;
      if (item.isM) {
        console.log("缩小的时候");
        item.styleObj.width = inpW;
        item.styleObj.height = inpH;
        item.styleObj.left = inpX;
        item.styleObj.top = inpY;
        item.isM = false;
        windowMoveApi({
          cmd: "windowMove",
          gid: this.gid,
          value: 1, // 0 灰色 1正常 2wu无效
          ID: item.num, // 窗口ID （0-65535）
          x: parseInt(item.inpX), // 起点x
          y: parseInt(item.inpY), // 起点y
          w: parseInt(item.inpW), // 结束x 或者 窗体宽
          h: parseInt(item.inpH) // 结束y 或者 窗体高
        });
        windowAttriConfigApi({
          cmd: "windowAttriConfig",
          gid: this.gid,
          ID: this.contextItem.num,
          type: "full",
          en: 0
        });

        if (this.closeWindowID.length) {
          windowNewChangeApi({
            cmd: "windowNewChange",
            Group: this.gid,
            value: 1,
            ID: this.closeWindowID
          });
          this.closeWindowID = [];
        }
      } else {
        // websocketsend(`wnd,sync,${this.gid},0`, () => {});
        let arrID = [];
        this.Layers.forEach(i => {
          if (!(i.mark & 0x08)) {
            if (i.num !== this.contextItem.num && i.flag === 1) {
              arrID.push(i.num);
            }
          }
        });
        this.closeWindowID = [...arrID];
        windowNewChangeApi({
          cmd: "windowNewChange",
          Group: this.gid,
          value: 0,
          ID: arrID
        });

        // windowLayerControlApi({
        //   cmd: "windowLayerControl",
        //   ID: this.contextItem.num,
        //   layer: "top"
        // });

        this.contextHandler("置顶");
        windowMoveApi({
          cmd: "windowMove",
          gid: this.gid,
          value: 1, // 0 灰色 1正常 2wu无效
          ID: this.contextItem.num, // 窗口ID （0-65535）
          x: 0, // 起点x
          y: 0, // 起点y
          w: this.W, // 结束x 或者 窗体宽
          h: this.H // 结束y 或者 窗体高
        });

        windowAttriConfigApi({
          cmd: "windowAttriConfig",
          ID: this.contextItem.num,
          gid: this.gid,
          type: "full",
          en: 1
        });
        let outWarpDom = document.querySelector("#centerTop");
        item.styleObj.left = "0px";
        item.styleObj.top = "0px";
        item.styleObj.width = `${outWarpDom.scrollWidth}px`; // 100%
        item.styleObj.height = `${outWarpDom.scrollHeight}px`; // 100%
        item.isM = true;
        let dom = document.querySelector(`#mouseWarp0${item.num}`);
        dom.style.left = "0px";
        dom.style.top = "0px";
        dom.style.width = `${outWarpDom.scrollWidth}px`; // 100%
        dom.style.height = `${outWarpDom.scrollHeight}px`; // 100%
        // websocketsend(`wnd,sync,${this.gid},1`, () => {});
      }
      this.$forceUpdate();
    },
    dbWindowClick: _.throttle(function(ev, item, isF) {
      let _this = this;

      console.log(isF, "isF");
      if (item.lock) {
        return false;
      }
      let itemDom = document.getElementById(
        `${"mouseWarp" + this.initial_index + item.num}`
      );
      if (isF) {
        // 已经放大 要缩小

        item.styleObj.left = `${item.x * _this.Wrate}px`;
        item.styleObj.top = `${item.y * _this.Hrate}px`;
        item.styleObj.width = `${item.w * _this.Wrate}px`;
        item.styleObj.height = `${item.h * _this.Hrate}px`;

        // ev.target
        itemDom.style.left = `${item.x * _this.Wrate}px`;
        itemDom.style.top = `${item.y * _this.Hrate}px`;
        itemDom.style.width = `${item.w * _this.Wrate}px`;
        itemDom.style.height = `${item.h * _this.Hrate}px`;

        item.inpW = item.w;
        item.inpH = item.h;
        item.inpX = item.x;
        item.inpY = item.y;

        item.isF = false;
        _this.contextItem.isF = false;

        windowMoveApi({
          cmd: "windowMove",
          gid: this.gid,
          value: 1, // 0 灰色 1正常 2wu无效
          ID: item.num, // 窗口ID （0-65535）
          x: item.x, // 起点x
          y: item.y, // 起点y
          w: item.w, // 结束x 或者 窗体宽
          h: item.h // 结束y 或者 窗体高
        });
      } else {
        // 目前缩小 要放大
        this.Layers = [...this.Layers];

        item.x = item.inpX;
        item.y = item.inpY;
        item.w = item.inpW;
        item.h = item.inpH;

        let haveOUTArray = [];
        let xList = [];
        let yList = [];
        // console.log(this.GridLJArray,'this.GridLJArray')
        let currentOmap = _this.omap.filter(i => i.gid === _this.gid);
        let currentLJOmap = [];
        let Wlist = [];
        let Hlist = [];
        /* {"gid":2,"Logic_ch":1,"Phy_ch":1,"x":0,"y":0,"w":500,"h":500,"pixel_space":100} */
        for (let i = 0; i < currentOmap.length; i++) {
          let { x, y, w, h } = currentOmap[i];
          let o1 = { x, y, w: w / 2, h: h / 2 };
          let o2 = { x: x + w / 2, y, w: w / 2, h: h / 2 };
          let o3 = { x, y: y + h / 2, w: w / 2, h: h / 2 };
          let o4 = { x: x + w / 2, y: y + h / 2, w: w / 2, h: h / 2 };
          currentLJOmap.push(o1, o2, o3, o4);
          // Wlist.push(o1.x + o1.w, o2.x + o2.w, o3.x + o3.w, o4.x + o4.w);
          // Hlist.push(o1.y + o1.h, o2.y + o2.h, o3.y + o3.h, o4.y + o4.h);
        }
        let gridarray;
        if (_this.$root.GroupType === 1) {
          gridarray = _this.GridLJArray;
        }
        if (_this.$root.GroupType === 2) {
          gridarray = currentLJOmap;
        }
        gridarray.forEach(a => {
          if (
            a.x - item.inpX < item.inpW &&
            a.x + a.w > item.inpX &&
            a.y - item.inpY < item.inpH &&
            a.y + a.h > item.inpY
          ) {
            haveOUTArray.push(a);
            Wlist.push(a.x + a.w);
            Hlist.push(a.y + a.h);
            xList.push(a.x);
            yList.push(a.y);
          }
        });
        console.log(haveOUTArray, "haveOUTArray");
        let x_min = Math.min(...xList);
        let x_max = Math.max(...xList);

        let y_min = Math.min(...yList);
        let y_max = Math.max(...yList);

        // 这里的2 表示逻辑子屏幕的几行几列 先固定
        let w = haveOUTArray[0].w || this.H_ACTIVE / this.Cols / 2;
        let h = haveOUTArray[0].h || this.V_ACTIVE / this.Rows / 2;

        let w_min = Math.min(...Wlist);
        let w_max = Math.max(...Wlist);
        let h_min = Math.min(...Hlist);
        let h_max = Math.max(...Hlist);
        // item.x=x_min*this.Wrate
        // item.y=y_min*this.Hrate
        // item.w=(x_max+w)*this.Wrate
        // item.h=(y_max+h)*this.Hrate
        // console.log(haveOUTArray,'haveOUTArray')
        // console.log(xList,'xList')
        // console.log(yList,'yList')
        // console.log(x_min,'x')
        // console.log(y_min,'y')
        // console.log(x_max,'x_max')
        // console.log(y_max,'y_max')

        // let a = x_max - x_min + w;
        // let b = y_max - y_min + h;
        let a = w_max - x_min;
        let b = h_max - y_min;
        if (a < item.inpW) {
          // 如果计算出来的宽小于窗口原来的宽
        }
        if (b < item.inpH) {
          // 如果计算出来的高小于窗口原来的高
        }
        // if (!(a&&b)){
        //   return false
        // }

        item.styleObj.left = `${x_min * _this.Wrate}px`;
        item.styleObj.top = `${y_min * _this.Hrate}px`;
        item.styleObj.width = `${a * _this.Wrate}px`;
        item.styleObj.height = `${b * _this.Hrate}px`;

        item.isF = true;
        _this.contextItem.isF = true;

        itemDom.style.left = `${x_min * _this.Wrate}px`;
        itemDom.style.top = `${y_min * _this.Hrate}px`;
        itemDom.style.width = `${a * _this.Wrate}px`;
        itemDom.style.height = `${b * _this.Hrate}px`;

        // console.log(ev.target,'target')

        // _this.$set(item.styleObj,'width',`${(a)*_this.Wrate}px`)
        // _this.$set(item.styleObj,'height',`${(b)*_this.Hrate}px`)
        // _this.$set(item.styleObj,'left',`${x_min*_this.Wrate}px`)
        // _this.$set(item.styleObj,'top',`${y_min*_this.Hrate}px`)

        // _this.$set(item,'inpW',x_max)
        // _this.$set(item,'inpH',y_max)
        // _this.$set(item,'inpX',x_min)
        // _this.$set(item,'inpY',y_min)

        item.inpW = a;
        item.inpH = b;
        item.inpX = x_min;
        item.inpY = y_min;

        windowMoveApi({
          cmd: "windowMove",
          gid: this.gid,
          value: 1, // 0 灰色 1正常 2wu无效
          ID: item.num, // 窗口ID （0-65535）
          x: item.inpX, // 起点x
          y: item.inpY, // 起点y
          w: item.inpW, // 结束x 或者 窗体宽
          h: item.inpH // 结束y 或者 窗体高
        });
      }
      // this.$forceUpdate();
    }),
    toggleClass(ev, item) {
      console.log("toggleClass");
      let _this = this;

      let caller = ev.target || event.srcElement;
      ev.stopPropagation();
      _this.flag = item.num;
      if (caller.classList.contains("tem") && !item.isM) {
        // if (_this.flag === false) {
        _this.acitveDom = caller;
        // let tems = document.querySelectorAll(".tem")
        // for (var i = 0; i < tems.length; i++) {
        //   tems[i].style.cursor = 'auto'
        //   if (tems[i] === caller) {
        //     continue;
        //   }
        //   tems[i].classList.remove("border")
        // }
        // caller.classList.toggle("border")
        // caller.classList.add("border")
        if (caller.classList.contains("border")) {
          // if (getStyle(nav, "right") !== "0px") {
          //   btn.click()
          // }
          // inpName.value = dom.getAttribute("id")
          console.log(item, "toggleClass的item");
          _this.inpX = getStyle(caller, "left");
          _this.inpY = getStyle(caller, "top");
          _this.inpW = getStyle(caller, "width");
          _this.inpH = getStyle(caller, "height");
          // inpData.value = dom.getAttribute("data")
        }
        // }
      }
      console.log("点击了窗体");
    },
    touchstartWindow(ev, item, type) {
      // console.log("type:=>", type);
      // console.log(ev, "touchstart-event");

      let $ev = ev;
      let _this = this;
      // let dom = ev.touches[0].target;
      let dom = document.querySelector(`#mouseWarp0${item.num}`);
      var ev = ev.touches[0];
      if (_this.handleChCopy) {
        _this.windowDrop($ev, item);
        // _this.handleChCopy = null;
        // return false;
      }

      _this.flag = item.num;
      _this.contextItem = item;
      _this.windowTarget = ev;
      // if (_this.istouchstartWindow) {
      //   return false;
      // }
      // _this.istouchstartWindow = true;

      console.log(dom, "dom");
      let { offsetLeft, offsetTop } = dom;
      // console.log(offsetLeft, "offsetLeft");
      // console.log(offsetTop, "offsetTop");

      // console.log("down");

      // console.log(ev, "这是down的ev");

      if (item.lock) {
        return false;
      }
      if (_this.contextMenuVisible) {
        _this.contextMenuVisible = false;
        return false;
      }
      _this.isMove = true; // 正在移动
      // ev.stopPropagation();

      // var that = ev.target || event.srcElement
      // var that =
      //   _this.$refs[`${item.num + "mouseWarp" + _this.initial_index}`][0];
      // console.log(that, "移动的方块");
      var that = dom;

      // console.log(that.classList.contains("tem"));
      // console.log(!item.isM);
      if (that.classList.contains("tem") && !item.isM) {
        // _this.flag = false
        // var timeout = setTimeout(function () {
        //   _this.flag = true
        // }, 150)
        // console.log(_this.flag,'_this.flag')
        // that.style.zIndex = 9001
        // that.style.cursor='move'
        var disW = that.offsetWidth; //元素  的宽度
        var disH = that.offsetHeight; //元素  的高度
        var disL = that.offsetLeft; //元素  左侧距离 父级 左侧 的距离
        var disT = that.offsetTop; //元素  顶部距离 父级 顶部 的距离

        var disX = ev.clientX; //鼠标  距离 屏幕 左侧 的距离
        var disY = ev.clientY; //鼠标  距离 屏幕 顶部 的距离
        var mouseElX = ev.clientX - that.offsetLeft; //鼠标  距离 元素 左侧 的距离
        var mouseElY = ev.clientY - that.offsetTop; //鼠标  距离 元素 顶部 的距离

        var eidtW = _this.boxEdit.offsetWidth; // 父元素 的宽度
        var eidtH = _this.boxEdit.offsetHeight; // 父元素 的高度

        var oLeft = disX - disL; // 算出鼠标距离元素左侧的距离
        var oTop = disY - disT; // 算出鼠标距离元素顶部的距离

        let padding = 30;
        _this.boxEdit.ontouchmove = function(ev) {
          // console.log(ev, "_this.boxEdit.ontouchmove的ev");
          var ev = ev.touches[0];
          // 鼠标移动的x轴和Y轴
          var setX = ev.clientX - oLeft;
          var setY = ev.clientY - oTop;
          // 利用 mouseElX  mouseElY  进行判断是否在范围内
          // 如果在放大缩小的范围之内
          if (type === 1) {
            // 移动
            if (setX <= -1) {
              setX = 0;
            }
            if (setY <= -1) {
              setY = 0;
            }
            // 这里先注释掉 限制窗体活动范围 的代码
            // if (setX >= eidtW - disW - 1) {
            //   setX = eidtW - disW;
            // }
            // if (setY >= eidtH - disH - 1) {
            //   setY = eidtH - disH;
            // }
            that.style.left = setX + "px";

            that.style.top = setY + "px";
          }
          if (type === 2) {
            // 缩放
            let width = parseFloat(getStyle(that, "width")) / _this.Wrate;
            let height = parseFloat(getStyle(that, "height")) / _this.Hrate;
            item.inpW = parseInt(width);
            that.style.width = disW + setX - disL + "px";
            item.inpH = parseInt(height);
            that.style.height = disH + setY - disT + "px";

            // if (parseInt(width) >= 200) {
            //   item.inpW = parseInt(width);
            //   that.style.width = disW + setX - disL + "px";
            // } else {
            //   item.inpW = 200;
            //   that.style.width = 200 * _this.Wrate + "px";
            // }
            // if (parseInt(height) >= 200) {
            //   item.inpH = parseInt(height);
            //   that.style.height = disH + setY - disT + "px";
            // } else {
            //   item.inpH = 200;
            //   that.style.height = 200 * _this.Hrate + "px";
            // }
          }

          let letf = parseFloat(getStyle(that, "left")) / _this.Wrate;
          let top = parseFloat(getStyle(that, "top")) / _this.Hrate;

          if (!setX) {
            item.inpX = 0;
          } else {
            item.inpX = parseInt(letf) || item.inpX;
          }

          if (!setY) {
            item.inpY = 0;
          } else {
            item.inpY = parseInt(top) || item.inpY;
          }
        };
        _this.contextItem = item;
        this.windowTarget = ev;
        // console.log(_this.boxEdit, "执行到了这里");

        _this.boxEdit.ontouchend = function(ev) {
          // console.log("_this.boxEdit.ontouchend事件执行了");
        };
      }
      if (item.styleObj.background === "rgba(0,0,0,0.2)") {
        let dom = window.document.querySelector(`#mouseWarp0${item.num}`);
        dom.style.zIndex = 1000;
        // item.styleObj.zIndex=1000
        // item.zIndex=1000
      }
    },
    touchmoveWindow(ev, item) {
      // console.log(ev, "touchmove-event");
      // this.isMove = true;
      const _this = this;
      if (_this.isMove) {
        console.log("正在移动中1");
        _this.isNewMove = true;
        if (item.isF) {
          item.isF = false;
        }
      } else {
        _this.isNewMove = false;
        console.log("正在移动中2");
      }
    },
    touchendWindow(ev, it) {
      // this.istouchstartWindow = false;
      // this.loading = this.$loading({
      //   lock: true,
      //   text: "Loading",
      //   spinner: "el-icon-loading",
      //   background: "rgba(0, 0, 0, 0.7)"
      // });
      this.boxEdit.ontouchmove = null;

      let _this = this;
      let item = this.contextItem;

      // console.log("up");
      // console.log(_this.isNewMove, "_this.isNewMove");
      // console.log(item.num, "当前移动的窗口ID");
      // console.log(ev, "当前移动的窗口ev");
      if (!_this.isNewMove) {
        _this.boxEdit.onmousemove = _this.boxEdit.onmouseup = null;
        _this.isNewMove = false;
        _this.isMove = false;
        return false;
      }
      // 移动无效窗户的时候不用发送move指令
      if (item.styleObj.background !== "rgba(0,0,0,0.2)") {
        let value = item.styleObj.background == "#909399" ? 0 : 1;
      }

      _this.isMove = false;
      _this.flag = null;

      _this.WindowWelt(item).then(res => {
        _this.moveOropenWindow(item, "move");
      });

      // _this.boxEdit.onmousemove = _this.boxEdit.onmouseup = null;
      console.log("touchend-event");
      // this.isMove = true;
    },
    down(ev, item) {
      console.log("down");
      let _this = this;
      console.log(ev, "这是down的ev");
      if (ev.target.dataset.colse === "closeWindow") {
        return false;
      }
      // 右键时
      if (ev.buttons === 2) {
        return false;
      }
      if (item.lock) {
        return false;
      }
      if (this.contextMenuVisible) {
        this.contextMenuVisible = false;
        return false;
      }
      _this.isMove = true; // 正在移动
      ev.stopPropagation();
      // var that = ev.target || event.srcElement
      var that =
        _this.$refs[`${item.num + "mouseWarp" + _this.initial_index}`][0];
      console.log(that, "移动的方块");
      var ev = ev || event;
      if (that.classList.contains("tem") && !item.isM) {
        // _this.flag = false
        // var timeout = setTimeout(function () {
        //   _this.flag = true
        // }, 150)
        // console.log(_this.flag,'_this.flag')
        // that.style.zIndex = 9001
        // that.style.cursor='move'
        var disW = that.offsetWidth; //元素  的宽度
        var disH = that.offsetHeight; //元素  的高度
        var disL = that.offsetLeft; //元素  左侧距离 父级 左侧 的距离
        var disT = that.offsetTop; //元素  顶部距离 父级 顶部 的距离

        var disX = ev.clientX; //鼠标  距离 屏幕 左侧 的距离
        var disY = ev.clientY; //鼠标  距离 屏幕 顶部 的距离
        var mouseElX = ev.offsetX; //鼠标  距离 元素 左侧 的距离
        var mouseElY = ev.offsetY; //鼠标  距离 元素 顶部 的距离

        var eidtW = _this.boxEdit.offsetWidth; // 父元素 的宽度
        var eidtH = _this.boxEdit.offsetHeight; // 父元素 的高度

        var oLeft = disX - disL; // 算出鼠标距离元素左侧的距离
        var oTop = disY - disT; // 算出鼠标距离元素顶部的距离

        _this.boxEdit.onmousemove = function(ev) {
          var ev = ev || event;
          // 鼠标移动的x轴和Y轴
          var setX = ev.clientX - oLeft;
          var setY = ev.clientY - oTop;
          // 利用 mouseElX  mouseElY  进行判断是否在范围内
          // 如果在放大缩小的范围之内

          if (
            mouseElX >= disW - 15 &&
            mouseElY >= disH - 15 &&
            that.classList.contains("border")
          ) {
            // 这时候等比例放大
            // 拖拽右下角

            that.style.width = disW + setX - disL + "px";
            that.style.height = disH + setY - disT + "px";
            let width = parseFloat(getStyle(that, "width")) / _this.Wrate;
            let height = parseFloat(getStyle(that, "height")) / _this.Hrate;
            item.inpW = parseInt(width);
            item.inpH = parseInt(height);
            // _this.inpW = getStyle(that, 'width')
            // _this.inpH = getStyle(that, 'height')
          } else if (
            mouseElX <= 15 &&
            mouseElY <= 15 &&
            that.classList.contains("border")
          ) {
            // 拖拽左上角
            // 这时候 等比例放大
            // x轴加多少,left减多少
            // y轴加多少,top减多少
            that.style.width = disW - setX + disL + "px";
            that.style.height = disH - setY + disT + "px";
            that.style.top = disT + setY - disT + "px";
            that.style.left = disL + setX - disL + "px";
            let width = parseFloat(getStyle(that, "width")) / _this.Wrate;
            let height = parseFloat(getStyle(that, "height")) / _this.Hrate;
            item.inpW = parseInt(width);
            item.inpH = parseInt(height);
            // _this.inpW = getStyle(that, 'width')
            // _this.inpH = getStyle(that, 'height')
            // _this.inpX = getStyle(that, 'left')
            // _this.inpY = getStyle(that, 'top')
          } else if (
            mouseElY <= 15 &&
            mouseElX >= disW - 15 &&
            that.classList.contains("border")
          ) {
            // 拖拽右上角  鼠标样式: ne-resize
            // 左下角不变
            // 这时候 等比例放大
            that.style.width = disW + setX - disL + "px";
            that.style.height = disH - setY + disT + "px";
            that.style.top = disT + setY - disT + "px";
            let width = parseFloat(getStyle(that, "width")) / _this.Wrate;
            let height = parseFloat(getStyle(that, "height")) / _this.Hrate;
            item.inpW = parseInt(width);
            item.inpH = parseInt(height);
            // _this.inpW = getStyle(that, 'width')
            // _this.inpH = getStyle(that, 'height')
            // _this.inpX = getStyle(that, 'left')
            // _this.inpY = getStyle(that, 'top')
          } else if (
            mouseElX <= 15 &&
            mouseElY >= disH - 15 &&
            that.classList.contains("border")
          ) {
            // 拖拽左下角  鼠标样式: ne-resize
            // 右上角不变
            // 这时候 等比例放大
            that.style.width = disW - setX + disL + "px";
            that.style.height = disH + setY - disT + "px";
            that.style.left = disL + setX - disL + "px";
            let width = parseFloat(getStyle(that, "width")) / _this.Wrate;
            let height = parseFloat(getStyle(that, "height")) / _this.Hrate;
            item.inpW = parseInt(width);
            item.inpH = parseInt(height);
            // _this.inpW = getStyle(that, 'width')
            // _this.inpH = getStyle(that, 'height')
            // _this.inpX = getStyle(that, 'left')
            // _this.inpY = getStyle(that, 'top')
          } else if (mouseElX <= 15 && that.classList.contains("border")) {
            that.style.width = disW - setX + disL + "px";
            that.style.left = disL + setX - disL + "px";
            let width = parseFloat(getStyle(that, "width")) / _this.Wrate;
            item.inpW = parseInt(width);
            // _this.inpW = getStyle(that, 'width')
            // _this.inpH = getStyle(that, 'height')
            // _this.inpX = getStyle(that, 'left')
            // _this.inpY = getStyle(that, 'top')
          } else if (
            mouseElX >= disW - 15 &&
            that.classList.contains("border")
          ) {
            // 这时候放大缩小x轴
            console.log(setX, setY, "---", disW, disH, "---", disL, disT);
            console.log(setX - disL);
            that.style.width = disW + setX - disL + "px";
            let width = parseFloat(getStyle(that, "width")) / _this.Wrate;
            item.inpW = parseInt(width);
            // _this.inpW = getStyle(that, 'width')
            // _this.inpH = getStyle(that, 'height')
          } else if (mouseElY <= 15 && that.classList.contains("border")) {
            console.log(setY, disT);
            that.style.height = disH - setY + disT + "px";
            that.style.top = disT + setY - disT + "px";
            let height = parseFloat(getStyle(that, "height")) / _this.Hrate;
            item.inpH = parseInt(height);
            // _this.inpW = getStyle(that, 'width')
            // _this.inpH = getStyle(that, 'height')
            // _this.inpX = getStyle(that, 'left')
            // _this.inpY = getStyle(that, 'top')
          } else if (
            mouseElY >= disH - 15 &&
            that.classList.contains("border")
          ) {
            // 这时候放大缩小Y轴
            that.style.height = disH + setY - disT + "px";
            let height = parseFloat(getStyle(that, "height")) / _this.Hrate;
            item.inpH = parseInt(height);
            // _this.inpW = getStyle(that, 'width')
            // _this.inpH = getStyle(that, 'height')
          } else {
            // 如果不在放大缩小的范围之内 就认为是移动

            if (setX <= -1) {
              setX = 0;
            }
            if (setY <= -1) {
              setY = 0;
            }

            // 这里先注释掉 限制窗体活动范围 的代码
            // if (setX >= eidtW - disW - 1) {
            //   setX = eidtW - disW;
            // }
            // if (setY >= eidtH - disH - 1) {
            //   setY = eidtH - disH;
            // }

            that.style.left = setX + "px";
            that.style.top = setY + "px";
            // _this.inpX = getStyle(that, 'left')
            // _this.inpY = getStyle(that, 'top')
          }

          // that.setAttribute('inpW', _this.inpW||'100px')
          // that.setAttribute('inpH', _this.inpH||'100px')
          // that.setAttribute('inpX', _this.inpX)
          // that.setAttribute('inpY', _this.inpY)

          // let X = parseInt(_this.inpX) // letf
          // let Y = parseInt(_this.inpY) // top
          // let W = parseInt(_this.inpW) // width
          // let H = parseInt(_this.inpH) // height

          // 等比放大之后
          // let Sw = parseInt(W / _this.Wrate)
          // let Sh = parseInt(H / _this.Hrate)
          // let Sx = parseInt(X / _this.Wrate)
          // let Sy = parseInt(Y / _this.Hrate)
          // console.log(X,'X')
          // console.log(Y,'Y')
          // console.log(setX,'setX')
          // console.log(setY,'setY')
          // console.log(Sx,'Sx')
          // console.log(Sy,'Sy')
          // console.log(Sw,'Sw')
          // console.log(Sh,'Sh')
          // console.log(W,'W')
          // console.log(H,'H')
          // console.log(_this.Wrate,'_this.Wrate')
          // console.log(_this.Hrate,'_this.Hrate')
          // console.log(ev.target,'ev.target')

          // let target = ev.target.hasAttribute('data-sid') ? ev.target : ev.target.parentNode
          // console.log(target,'target');
          // console.log(that,'that');

          // let width = parseInt(getStyle(that, "width")) / _this.Wrate;
          // let height = parseInt(getStyle(that, "height")) / _this.Hrate;
          // item.inpW = parseInt(width);
          // item.inpH = parseInt(height);

          let letf = parseFloat(getStyle(that, "left")) / _this.Wrate;
          let top = parseFloat(getStyle(that, "top")) / _this.Hrate;
          // console.log(width,'width')
          // console.log(height,'height')
          // console.log(getStyle(ev.target,'width'),'width')
          // 拖动改变窗体参数
          // item.inpX = parseInt(letf)|| item.inpX
          // item.inpY = parseInt(top)|| item.inpY

          // item.inpW = Sw || _this.H_ACTIVE
          // item.inpH = Sh || _this.V_ACTIVE

          if (!setX) {
            item.inpX = 0;
          } else {
            item.inpX = parseInt(letf) || item.inpX;
          }

          if (!setY) {
            item.inpY = 0;
          } else {
            item.inpY = parseInt(top) || item.inpY;
          }

          // item.inpX = Sx
          // item.inpY = Sy

          // item.inpX = setX?Sx:0
          // item.inpY = setY?Sy:0
        };
        this.contextItem = item;
        console.log(_this.boxEdit, "执行到了这里");

        _this.boxEdit.onmouseup = function(ev) {
          console.log("move事件执行了");
        };
      }
      if (item.styleObj.background === "rgba(0,0,0,0.2)") {
        let dom = window.document.querySelector(`#mouseWarp0${item.num}`);
        dom.style.zIndex = 1000;
        // item.styleObj.zIndex=1000
        // item.zIndex=1000
      }
    },
    up(ev, it) {
      console.log("up");

      let isTouchDevice = "ontouchstart" in document.documentElement;
      // 移动端禁止执行此事件
      if (isTouchDevice) {
        return false;
      }
      let _this = this;
      let item = this.contextItem;

      console.log(_this.isNewMove, "_this.isNewMove");
      console.log(item.num, "当前移动的窗口ID");
      // console.log(ev, "当前移动的窗口ev");
      if (!_this.isNewMove) {
        _this.boxEdit.onmousemove = _this.boxEdit.onmouseup = null;
        _this.isNewMove = false;
        _this.isMove = false;
        return false;
      }
      // 移动无效窗户的时候不用发送move指令
      if (item.styleObj.background !== "rgba(0,0,0,0.2)") {
        console.log("up事件的move指令");
        console.log(item.styleObj.background, "item.styleObj.background");
        let value = item.styleObj.background == "#909399" ? 0 : 1;
      }

      _this.isNewMove = false;
      _this.isMove = false;
      _this.flag = null;

      _this.WindowWelt(item).then(res => {
        _this.moveOropenWindow(item, "move");
      });
      // 注释掉和后台同步
      // _this.syncWindowOrder().then(res => {
      //   _this.WindowWelt(item).then(res => {
      //     _this.moveOropenWindow(item, "move");
      //   });
      // });

      _this.boxEdit.onmousemove = _this.boxEdit.onmouseup = null;
    },
    WarpUp(ev, item) {
      let _this = this;
      console.log("容器up事件");
      _this.boxEdit.onmousemove = _this.boxEdit.onmouseup = null;
    },
    leave(ev, item) {
      // console.log('leave')
      // this.isNewMove = false;
    },
    windowContext(ev, item) {
      console.log("windowContext");
      this.contextItem = item;
      this.windowTarget = null;
      this.windowTarget = ev;
      console.log(this.contextItem, "this.contextItem");
    },
    fetchWindowLayerControl(item, type) {
      windowLayerControlApi({
        cmd: "windowLayerControl",
        ID: item.num,
        layer: type
      });
    },
    is4kInput(window) {
      // 判断是否是4k输入源的窗
      const inCardListStorage = JSON.parse(
        localStorage.getItem("incardListData")
      );
      const inCardInfo = inCardListStorage.find(i => i.cID === window.Vsrc_CH);

      if (inCardInfo) {
        if (
          (inCardInfo.type >= 17 && inCardInfo.type <= 48) ||
          inCardInfo.type === 23
        ) {
          return true;
        }
      }
      return false;
    },
    contextHandler(type, en, bottomMap) {
      let _this = this;
      if (JSON.stringify(this.contextItem) !== "{}") {
        switch (type) {
          case "置顶": {
            let zIndexList = [];
            this.Layers.forEach(item => {
              zIndexList.push(parseInt(item.zIndex));
            });
            console.log(zIndexList, "zIndexList");
            let max = Math.max(...zIndexList);
            if (this.contextItem.zIndex < max) {
              console.log("开始置顶");
              console.log("发送置顶指令");
              this.fetchWindowLayerControl(this.contextItem, "top");
              if (this.contextItem.flag === 0) {
                // 当前置顶的是灰窗
                // 找出与当前需要置顶的窗相交的映射区域有哪些
                let ItemOmap = this.getWindowIntersectOmap(this.contextItem);
                console.log(
                  ItemOmap,
                  "找出与当前需要置顶窗体相交的映射区域有哪些"
                );
                if (ItemOmap.length) {
                  function searchGay() {
                    return new Promise(resolve => {
                      _this
                        .computedGayNum(ItemOmap, {
                          Vsrc_CH: _this.contextItem.Vsrc_CH,
                          num: _this.contextItem.num,
                          flag: 1
                        })
                        .then(res => {
                          if (res.isGay.length) {
                            let ID0 = Array.from(new Set([...res.isGay]));
                            resolve(ID0);
                          }
                        });
                    });
                  }

                  // function searchGay() {
                  //   return new Promise(resolve => {
                  //     let isGay = [];
                  //     ItemOmap.forEach(a => {
                  //       // 找出当前映射区域有哪些窗体
                  //       let ItemOmapWindow = _this.getOmapHaveWindow(a);
                  //       // 找亮窗集
                  //       let hasLightWindow = ItemOmapWindow.filter(
                  //         item => item.flag === 1
                  //       );
                  //       console.log(hasLightWindow, "hasLightWindow");
                  //       if (hasLightWindow.length) {
                  //         let zIndexList = [];
                  //         hasLightWindow.forEach(item => {
                  //           zIndexList.push(item.zIndex);
                  //         });
                  //         let zIndexmin = Math.min(...zIndexList);
                  //         let hasLightWindowzIndexMax = hasLightWindow.find(
                  //           item => item.zIndex === zIndexmin
                  //         );
                  //         isGay.push(hasLightWindowzIndexMax.num);
                  //       }
                  //     });
                  //     setTimeout(resolve(isGay), 0);
                  //   });
                  // }
                  function changeOrder() {
                    return new Promise(resolve => {
                      // 按层叠序号升序
                      let LayersAscOrder = orderBy(
                        _this.Layers,
                        ["zIndex"],
                        ["asc"]
                      ); // asc升序 desc降序
                      // 先删掉需要置顶的窗
                      let notHaveContextItem = remove(LayersAscOrder, i => {
                        return i.num !== _this.contextItem.num;
                      });

                      notHaveContextItem.push(_this.contextItem);
                      notHaveContextItem.forEach((item, index) => {
                        let order = index + 1;
                        if (order === 1) {
                          item.styleObj.zIndex = 1;
                          item.zIndex = 1;
                        } else {
                          let leftItem = notHaveContextItem[index - 1];
                          let leftItemzIndex = leftItem.zIndex;
                          let marginspace = _this.is4kInput(leftItem) ? 2 : 1;
                          item.styleObj.zIndex = leftItemzIndex + marginspace;
                          item.zIndex = leftItemzIndex + marginspace;
                        }
                      });
                      // _this.Layers.forEach(i => {
                      //   if (i.zIndex > _this.contextItem.zIndex) {
                      //     i.styleObj.zIndex -= 1;
                      //     i.zIndex -= 1;
                      //   }
                      // });

                      setTimeout(resolve, 0);
                    });
                  }
                  function sendGay(GayIDList) {
                    return new Promise(resolve => {
                      let IDlist = Array.from(new Set([...GayIDList]));
                      if (GayIDList.length) {
                        windowNewChangeApi({
                          cmd: "windowNewChange",
                          Group: _this.gid,
                          value: 0,
                          ID: IDlist
                        });
                      }
                      _this.Layers.forEach(i => {
                        if (IDlist.includes(i.num)) {
                          if (GayIDList.length) {
                            i.flag = 0;
                            let dom = window.document.querySelector(
                              `#mouseWarp0${i.num}`
                            );
                            i.styleObj.background = 0
                              ? _this.CreateColor(i.num % 36, 36)
                              : "#909399";
                            if (dom) {
                              dom.style.background = 0
                                ? _this.CreateColor(i.num % 36, 36)
                                : "#909399";
                            }
                          }
                        }
                      });

                      setTimeout(resolve, 1000);
                    });
                  }
                  function sendLight(GayIDList) {
                    return new Promise(resolve => {
                      // 亮窗逻辑
                      _this.Layers.forEach(i => {
                        if (i.num === _this.contextItem.num) {
                          // i.styleObj.zIndex = _this.Layers.length;
                          // i.zIndex = _this.Layers.length;

                          if (GayIDList.length) {
                            i.flag = 1;
                            let dom = window.document.querySelector(
                              `#mouseWarp0${i.num}`
                            );
                            i.styleObj.background = 1
                              ? _this.CreateColor(i.num % 36, 36)
                              : "#909399";
                            dom.style.background = 1
                              ? _this.CreateColor(i.num % 36, 36)
                              : "#909399";
                          }
                        }
                      });
                      if (GayIDList.length) {
                        windowNewChangeApi({
                          cmd: "windowNewChange",
                          Group: _this.gid,
                          value: 1,
                          ID: [parseInt(_this.contextItem.num)]
                        });
                      }

                      setTimeout(resolve, 0);
                    });
                  }
                  async function run3() {
                    const GayIDList = await searchGay();
                    await changeOrder();
                    await sendGay(GayIDList);
                    await sendLight(GayIDList);
                  }
                  run3().then(() => {
                    _this.autoOpenWindow();
                  });
                  // _this.computedGayNumUp(ItemOmap, this.contextItem).then(res => {
                  //   console.log(res.isGay, "置顶:res.isGay");
                  //   if (res.isGay.length) {
                  //     // 发送灰窗指令
                  //     let ID0 = res.isGay;
                  //     windowNewChangeApi({
                  //       cmd: "windowNewChange",
                  //       Group: _this.gid,
                  //       value: 0,
                  //       ID: Array.from(new Set([...ID0]))
                  //     }).then($ => {
                  //       let a = setTimeout(function() {
                  //         _this.syncWindowOrder().then(res => {
                  //           // 发送亮窗逻辑
                  //           _this.Layers.forEach(i => {
                  //             if (i.num === _this.contextItem.num) {
                  //               i.flag = 1;
                  //             }
                  //           });
                  //
                  //           let ItemOmap = _this.omap.filter(
                  //             i => i.gid === _this.gid
                  //           );
                  //           let ID2 = [];
                  //           _this
                  //             .computedLightNum(ItemOmap, _this.contextItem)
                  //             .then(res => {
                  //               res.isLight.push(_this.contextItem.num);
                  //               if (res.isLight.length) {
                  //                 console.log(res.isLight, "1置顶:res.isLight");
                  //                 let ID1 = res.isLight;
                  //                 ID2 = res.isLight;
                  //                 windowNewChangeApi({
                  //                   cmd: "windowNewChange",
                  //                   Group: _this.gid,
                  //                   value: 1,
                  //                   ID: Array.from(new Set([...ID1]))
                  //                 });
                  //               }
                  //             })
                  //             .then(_ => {
                  //               let b = setTimeout(function() {
                  //                 _this.syncWindowOrder();
                  //                 clearTimeout(b);
                  //               }, 1000);
                  //             });
                  //         });
                  //         clearTimeout(a);
                  //       }, 1000);
                  //     });
                  //   } else {
                  //     console.log("置顶时没有需要灰窗的时候");
                  //     // 没有需要灰窗的时候
                  //     let a = setTimeout(function() {
                  //       _this.syncWindowOrder().then(res => {
                  //         // 发送亮窗逻辑
                  //         _this.Layers.forEach(i => {
                  //           if (i.num === _this.contextItem.num) {
                  //             i.flag = 1;
                  //           }
                  //         });
                  //
                  //         let ItemOmap = _this.omap.filter(
                  //           i => i.gid === _this.gid
                  //         );
                  //         let ID2 = [];
                  //         _this
                  //           .computedLightNum(ItemOmap, _this.contextItem)
                  //           .then(res => {
                  //             res.isLight.push(_this.contextItem.num);
                  //             if (res.isLight.length) {
                  //               console.log(res.isLight, "2置顶:res.isLight");
                  //               let ID1 = res.isLight;
                  //               ID2 = res.isLight;
                  //               windowNewChangeApi({
                  //                 cmd: "windowNewChange",
                  //                 Group: _this.gid,
                  //                 value: 1,
                  //                 ID: Array.from(new Set([...ID1]))
                  //               });
                  //             }
                  //           })
                  //           .then(_ => {
                  //             let b = setTimeout(function() {
                  //               _this.syncWindowOrder();
                  //               clearTimeout(b);
                  //             }, 1000);
                  //           });
                  //       });
                  //       clearTimeout(a);
                  //     }, 1000);
                  //   }
                  // });
                }
              } else {
                // 按层叠序号升序
                let LayersAscOrder = orderBy(_this.Layers, ["zIndex"], ["asc"]); // asc升序 desc降序
                // 先删掉需要置顶的窗
                let notHaveContextItem = remove(LayersAscOrder, i => {
                  return i.num !== _this.contextItem.num;
                });

                notHaveContextItem.push(_this.contextItem);
                notHaveContextItem.forEach((item, index) => {
                  let order = index + 1;
                  if (order === 1) {
                    item.styleObj.zIndex = 1;
                    item.zIndex = 1;
                  } else {
                    let leftItem = notHaveContextItem[index - 1];
                    let leftItemzIndex = leftItem.zIndex;
                    let marginspace = _this.is4kInput(leftItem) ? 2 : 1;
                    item.styleObj.zIndex = leftItemzIndex + marginspace;
                    item.zIndex = leftItemzIndex + marginspace;
                  }
                });
                console.log(notHaveContextItem, "notHaveContextItem");
                // 置顶的亮窗
                _this.Layers.forEach(i => {
                  if (i.num === _this.contextItem.num) {
                    i.flag = 1;
                  }
                  // if (i.zIndex > _this.contextItem.zIndex) {
                  //   let marginspace = _this.is4kInput(i) ? 2 : 1;
                  //   i.styleObj.zIndex -= marginspace;
                  //   i.zIndex -= marginspace;
                  // }
                });

                _this.Layers.forEach(i => {
                  if (i.num === _this.contextItem.num) {
                    // i.styleObj.zIndex = max;
                    // i.zIndex = max;
                  }
                });

                windowNewChangeApi({
                  cmd: "windowNewChange",
                  Group: _this.gid,
                  value: 1,
                  ID: [parseInt(this.contextItem.num)]
                });

                // 当前置顶的是亮窗
                // 是亮窗直接同步窗体
                // let a = setTimeout(function() {
                //   _this.syncWindowOrder();
                //   clearTimeout(a);
                // }, 1000);
              }
            }
            break;
          }
          case "置底": {
            console.log(".....................置底..........................");
            // 置底的窗口叠层序号不能为1
            if (this.contextItem.zIndex !== 1) {
              this.fetchWindowLayerControl(this.contextItem, "bottom");
              let ItemOmap = this.getWindowIntersectOmap(this.contextItem);
              if (this.contextItem.flag === 0) {
                // 当前置底的是灰窗
                // 置底灰窗时，
                _this.Layers.forEach(i => {
                  if (i.num === _this.contextItem.num) {
                    i.flag = 0;
                  }
                  // if (i.zIndex < _this.contextItem.zIndex) {
                  //   i.styleObj.zIndex += 1;
                  //   i.zIndex += 1;
                  // }
                });

                // _this.Layers.forEach(i => {
                //   if (i.num === _this.contextItem.num) {
                //     i.styleObj.zIndex = 1;
                //     i.zIndex = 1;
                //   }
                // });

                let LayersAscOrder = orderBy(
                  _this.Layers,
                  ["zIndex"],
                  ["desc"]
                ); // asc升序 desc降序
                // 先删掉需要置顶的窗
                let notHaveContextItem = remove(LayersAscOrder, i => {
                  return i.num !== _this.contextItem.num;
                });

                notHaveContextItem.push(_this.contextItem);
                notHaveContextItem.reverse();
                notHaveContextItem.forEach((item, index) => {
                  let order = index + 1;
                  if (order === 1) {
                    item.styleObj.zIndex = 1;
                    item.zIndex = 1;
                  } else {
                    let leftItem = notHaveContextItem[index - 1];
                    let leftItemzIndex = leftItem.zIndex;
                    let marginspace = _this.is4kInput(leftItem) ? 2 : 1;
                    item.styleObj.zIndex = leftItemzIndex + marginspace;
                    item.zIndex = leftItemzIndex + marginspace;
                  }
                });

                windowNewChangeApi({
                  cmd: "windowNewChange",
                  Group: _this.gid,
                  value: 0,
                  ID: [parseInt(this.contextItem.num)]
                });

                // 注释掉和后台同步
                // let a = setTimeout(function() {
                //   _this.syncWindowOrder();
                //   clearTimeout(a);
                // }, 1000);
              } else {
                // 置底的是亮窗
                let ItemOmap = this.getWindowIntersectOmap(this.contextItem);
                console.log(
                  ItemOmap,
                  "bottom:找出与当前需要置底窗体相交的映射区域有哪些"
                );
                if (ItemOmap.length) {
                  function searchLight() {
                    return new Promise(resolve => {
                      let isLight = [];
                      ItemOmap.forEach(a => {
                        // 找出当前映射区域有哪些窗体
                        let ItemOmapWindow = _this.getOmapHaveWindow(a);
                        // 找灰窗集
                        let hasGayWindow = ItemOmapWindow.filter(
                          item => item.flag === 0
                        );
                        let hasLightWindow = ItemOmapWindow.filter(
                          item => item.flag === 1
                        );
                        console.log(hasGayWindow, "hasGayWindow");
                        if (hasGayWindow.length) {
                          let zIndexList = [];
                          hasGayWindow.forEach(item => {
                            // 找出当前灰窗有几个亮窗

                            // 判断这个灰窗能不能亮起
                            if (_this.isWindowGayToLight(item, ItemOmap)) {
                              console.log("灰窗中可亮的窗ID：", item.num);
                              if (item.mark & 0x08) {
                                // 如果这个是底图窗
                              } else {
                                zIndexList.push(item.zIndex);
                              }
                            }
                          });
                          let zIndexMax = Math.max(...zIndexList);

                          let hasGayWindowzIndexMax = hasGayWindow.find(
                            item => item.zIndex === zIndexMax
                          );
                          if (hasGayWindowzIndexMax) {
                            isLight.push(hasGayWindowzIndexMax.num);
                          }
                        }
                      });
                      setTimeout(resolve(isLight), 0);
                    });
                  }
                  function changeOrder() {
                    return new Promise(resolve => {
                      let LayersAscOrder = orderBy(
                        _this.Layers,
                        ["zIndex"],
                        ["desc"]
                      ); // asc升序 desc降序
                      // 先删掉需要置顶的窗
                      let notHaveContextItem = remove(LayersAscOrder, i => {
                        return i.num !== _this.contextItem.num;
                      });

                      notHaveContextItem.push(_this.contextItem);
                      notHaveContextItem.reverse();
                      notHaveContextItem.forEach((item, index) => {
                        let order = index + 1;
                        if (order === 1) {
                          item.styleObj.zIndex = 1;
                          item.zIndex = 1;
                        } else {
                          let leftItem = notHaveContextItem[index - 1];
                          let leftItemzIndex = leftItem.zIndex;
                          let marginspace = _this.is4kInput(leftItem) ? 2 : 1;
                          item.styleObj.zIndex = leftItemzIndex + marginspace;
                          item.zIndex = leftItemzIndex + marginspace;
                        }
                      });

                      // _this.Layers.forEach(i => {
                      //   if (i.zIndex < _this.contextItem.zIndex) {
                      //     i.styleObj.zIndex += 1;
                      //     i.zIndex += 1;
                      //   }
                      // });

                      setTimeout(resolve, 0);
                    });
                  }
                  function sendGay(LightIDList) {
                    return new Promise(resolve => {
                      _this.Layers.forEach(i => {
                        if (i.num === _this.contextItem.num) {
                          // i.styleObj.zIndex = 1;
                          // i.zIndex = 1;

                          if (LightIDList.length) {
                            i.flag = 0;
                            let dom = window.document.querySelector(
                              `#mouseWarp0${i.num}`
                            );
                            i.styleObj.background = 0
                              ? _this.CreateColor(i.num % 36, 36)
                              : "#909399";
                            if (dom) {
                              dom.style.background = 0
                                ? _this.CreateColor(i.num % 36, 36)
                                : "#909399";
                            }
                          } else {
                            console.log("没有需要亮的窗！！！");
                          }
                        }
                      });
                      if (LightIDList.length) {
                        console.log(_this.contextItem.num, "灰掉的窗ID");
                        windowNewChangeApi({
                          cmd: "windowNewChange",
                          Group: _this.gid,
                          value: 0,
                          ID: [parseInt(_this.contextItem.num)]
                        });
                      }

                      // 从1000改成0
                      setTimeout(resolve, 0);
                    });
                  }
                  function sendLight(LightIDList) {
                    return new Promise(resolve => {
                      // 亮窗逻辑
                      _this.autoOpenWindow();
                      setTimeout(resolve, 1000);
                    });
                  }
                  async function run2() {
                    const LightIDList = await searchLight();
                    console.log(LightIDList, "需要亮的窗ID");
                    await changeOrder();
                    await sendGay(LightIDList);
                    await sendLight(LightIDList);
                    await new Promise(async resolve => {
                      console.log("执行到了run2().then");
                      if (!bottomMap) {
                        let mapWindows = _this.Layers.filter(
                          item => item.mark & 0x08
                        );
                        if (mapWindows.length) {
                          // console.log(mapWindows, "mapWindows");
                          let mapWindowsOrder = orderBy(
                            mapWindows,
                            ["zIndex"],
                            ["asc"]
                          ); // asc升序 desc降序
                          for (const item of mapWindowsOrder) {
                            _this.contextItem = item;
                            await _this.contextHandler("置底", 0, true);
                          }
                        }
                      }
                    });
                  }
                  run2();
                }
              }
            }
            break;
          }
          case "锁定": {
            windowAttriConfigApi({
              cmd: "windowAttriConfig",
              ID: this.contextItem.num,
              type: "lock",
              en: en
            });
            this.contextItem.lock = en;
            break;
          }
          case "放大": {
            this.dbWindowClick(
              this.windowTarget,
              this.contextItem,
              this.contextItem.isF
            );
            break;
          }
          case "缩小": {
            this.dbWindowClick(
              this.windowTarget,
              this.contextItem,
              this.contextItem.isF
            );
            break;
          }
          case "全屏": {
            this.contextItem.isM = !en;
            windowAttriConfigApi({
              cmd: "windowAttriConfig",
              ID: this.contextItem.num,
              type: "full",
              en: en
            });
            this.switchWindow(this.contextItem);
            break;
          }
          case "属性": {
            console.log(this.contextItem, "this.contextItem");
            this.dialogWindow.visible = true;
            this.dialogWindow.form.isTitle = this.contextItem.isTitle;
            this.dialogWindow.form.X = this.contextItem.inpX;
            this.dialogWindow.form.Y = this.contextItem.inpY;
            this.dialogWindow.form.W = this.contextItem.inpW;
            this.dialogWindow.form.H = this.contextItem.inpH;
            // return false
            break;
          }
          case "关闭": {
            this.closeWindow(this.contextItem);
            break;
          }
          default: {
            break;
          }
        }
        this.contextMenuVisible = false;
      }
    },
    windowDrop(ev, item) {
      let _this = this;
      // _this.handleChCopy = null;
      let portTwo = [23, 17];
      console.log(item, "windowDrop这是窗体的drop事件");
      // if (_this.$root.GroupType !== 1){
      //   return false;
      // }
      // let evData = ev.dataTransfer.getData("abcd");
      // let JsonEvData = JSON.parse(evData);
      let JsonEvData = _this.evData;
      console.log(JsonEvData, "JsonEvData");
      let chleft = JsonEvData.ch;
      let chright = item.Vsrc_CH;
      let incardListData = JSON.parse(localStorage.getItem("incardListData"));
      let { type: chleftType } = incardListData.find(i => i.cID === chleft);
      let { type: chrightType } = incardListData.find(i => i.cID === chright);

      if (portTwo.includes(chleftType) && portTwo.includes(chrightType)) {
        windowInChangeApi({
          cmd: "windowInChange",
          // value: 1, // 0 灰色 1正常 2wu无效
          ID: item.num, // 窗口ID （0-65535）
          // Group: _this.gid,
          Vsrc_CH: JsonEvData.ch, //信号源通道
          Vsrc_clip_style: JsonEvData.Vsrc_clip_style // 信号源裁剪方案
          // x: item.inpX,// 起点x
          // y: item.inpY,// 起点y
          // w: item.inpW,// 结束x 或者 窗体宽
          // h: item.inpH // 结束y 或者 窗体高
        });
      } else {
        if (portTwo.includes(chleftType) || portTwo.includes(chrightType)) {
          websocketsend(`(wnd,sync,${_this.gid},0)\r\n`, () => {});
          websocketsend(`(wnd,close,1,${item.num})\r\n`, res => {
            console.log("如果输出卡图层数不足需要灰窗");

            let chleftCount =
              (chleftType >= 17 && chleftType <= 48) || chleftType === 23
                ? 2
                : 1;
            let rightCount =
              (chrightType >= 17 && chrightType <= 48) || chrightType === 23
                ? 2
                : 1;
            if (chleftCount === 2) {
              console.log("4k输入源 >>> 2k输入源");
              let itemOmap = _this.getWindowIntersectOmap(item);
              if (itemOmap.length) {
                async function mian3() {
                  await _this
                    .computedGayNum(itemOmap, {
                      Vsrc_CH: chleft,
                      num: item.num,
                      flag: 1
                    })
                    .then(res => {
                      if (res.isGay.length) {
                        let ID0 = Array.from(new Set([...res.isGay]));
                        _this.Layers.forEach(i => {
                          if (ID0.includes(i.num) && i.haState) {
                            // i.styleObj.zIndex = Item.order;
                            // i.zIndex = Item.order;
                            i.flag = 0;
                            let dom = window.document.querySelector(
                              `#mouseWarp0${i.num}`
                            );
                            i.styleObj.background = 0
                              ? _this.CreateColor(i.num % 36, 36)
                              : "#909399";
                            if (dom) {
                              dom.style.background = 0
                                ? _this.CreateColor(i.num % 36, 36)
                                : "#909399";
                            }
                          }
                        });
                        windowNewChangeApi({
                          cmd: "windowNewChange",
                          Group: _this.gid,
                          value: 0,
                          ID: ID0
                        });
                      }
                    });
                  await windowOpenApi({
                    cmd: "windowOpen",
                    Group: _this.gid,
                    value: 1, // 0 灰色 1正常 2wu无效
                    ID: item.num, // 窗口ID （0-65535）
                    Vsrc_CH: chleft, //信号源通道
                    Vsrc_clip_style: JsonEvData.Vsrc_clip_style, // 信号源裁剪方案
                    x: item.isM ? 0 : item.inpX, // 起点x
                    y: item.isM ? 0 : item.inpY, // 起点y
                    w: item.isM ? _this.W : item.inpW, // 结束x 或者 窗体宽
                    h: item.isM ? _this.H : item.inpH // 结束y 或者 窗体高
                  }).then(() => {
                    websocketsend(`(wnd,sync,${_this.gid},1)\r\n`, () => {});
                    console.log("这里需要置顶");
                  });
                }
                mian3();
              }
            } else {
              console.log("2k输入源 >>> 4k输入源");
              windowOpenApi({
                cmd: "windowOpen",
                Group: _this.gid,
                value: 1, // 0 灰色 1正常 2wu无效
                ID: item.num, // 窗口ID （0-65535）
                Vsrc_CH: chleft, //信号源通道
                Vsrc_clip_style: JsonEvData.Vsrc_clip_style, // 信号源裁剪方案
                x: item.isM ? 0 : item.inpX, // 起点x
                y: item.isM ? 0 : item.inpY, // 起点y
                w: item.isM ? _this.W : item.inpW, // 结束x 或者 窗体宽
                h: item.isM ? _this.H : item.inpH // 结束y 或者 窗体高
              }).then(() => {
                websocketsend(`(wnd,sync,${_this.gid},1)\r\n`, () => {});
                console.log("这里需要置顶");
              });
            }
            if (chleftCount === 2 && rightCount === 1) {
              item.flag = 1;
              let dom = window.document.querySelector(`#mouseWarp0${item.num}`);
              item.styleObj.background = 1
                ? _this.CreateColor(item.num % 36, 36)
                : "#909399";
              dom.style.background = 1
                ? _this.CreateColor(item.num % 36, 36)
                : "#909399";
            }
            if (chleftCount === 1 && rightCount === 2) {
              // 左边2k右边4k卡，需要走自动开窗逻辑
              _this.autoOpenWindow();
            }
            _this.topChangeOrder(item);
          });
        } else {
          windowInChangeApi({
            cmd: "windowInChange",
            // value: 1, // 0 灰色 1正常 2wu无效
            ID: item.num, // 窗口ID （0-65535）
            // Group: _this.gid,
            Vsrc_CH: JsonEvData.ch, //信号源通道
            Vsrc_clip_style: JsonEvData.Vsrc_clip_style // 信号源裁剪方案
            // x: item.inpX,// 起点x
            // y: item.inpY,// 起点y
            // w: item.inpW,// 结束x 或者 窗体宽
            // h: item.inpH // 结束y 或者 窗体高
          });
        }
      }

      item.name = JsonEvData.name.split("_")[0];
      item.singal_flag = JsonEvData.singal_flag;
      item.Vsrc_CH = chleft;
    },
    windowAllowDrop(ev, item) {
      // console.log(item,'windowAllowDrop这是窗体的dropover事件')
      ev.preventDefault();
    },
    move(ev, item) {
      // console.log(ev, "这是move的ev");
      let _this = this;
      if (item.lock) {
        return false;
      }

      // if (!_this.isMove) {
      //   // 固定右键
      //   return false
      // }

      // if (this.contextMenuVisible){
      //   this.contextMenuVisible=false
      //   return false
      // }

      // 此处阻止事件流会卡顿
      // ev.stopPropagation()
      // var that = ev.target || event.srcElement
      var that =
        _this.$refs[`${item.num + "mouseWarp" + _this.initial_index}`][0];
      if (that.classList.contains("border")) {
        var disW = that.offsetWidth; //元素  的宽度
        var disH = that.offsetHeight; //元素  的高度
        var mouseElX = ev.offsetX; //鼠标  距离 元素 左侧 的距离
        var mouseElY = ev.offsetY; //鼠标  距离 元素 顶部 的距离
        if (
          (mouseElX >= disW - 15 && mouseElY >= disH - 15) ||
          (mouseElX <= 15 && mouseElY <= 15)
        ) {
          // 这时候改变鼠标样式为 \ 的
          that.style.cursor = "se-resize ";
        } else if (
          (mouseElX <= 15 && mouseElY >= disH - 15) ||
          (mouseElY <= 15 && mouseElX >= disW - 15)
        ) {
          // 这时候改变鼠标样式为  / 的
          that.style.cursor = "ne-resize ";
        } else if (mouseElX >= disW - 15 || mouseElX <= 15) {
          // 这时候改变鼠标样式为  - 的
          that.style.cursor = "w-resize ";
        } else if (mouseElY >= disH - 15 || mouseElY <= 15) {
          // 这时候改变鼠标样式为 |
          that.style.cursor = "s-resize ";
        } else {
          // 这时候让鼠标样式还原
          that.style.cursor = "auto";
        }
      } else {
        that.style.cursor = "auto";
      }

      if (_this.isMove) {
        // console.log("正在移动中1");
        _this.isNewMove = true;
        if (item.isF) {
          item.isF = false;
        }
      } else {
        _this.isNewMove = false;
        // console.log("正在移动中2");
      }
    },
    closeVideo(item) {
      item.in = null;
    },
    videoDrop(ev, item) {
      const _this = this;
      if (!this.handleCh) {
        return false;
      }
      item.in = parseInt(this.handleCh);
      console.log(item);
    },
    videoDragover(ev, item) {
      ev.preventDefault();
    },
    // 搜索输入卡事件
    searchInCard() {
      if (!this.searchInCardInput.trim()) {
        return false;
      }
      // console.log(this.cardImportListDetails,'this.cardImportListDetails')
      // this.cardImportListDetailsCopy=[...this.cardImportListDetails]
      // this.cardImportListDetailsCopy={...this.inList}
      let cardImportListDetailsHas = {};
      for (let i in this.inList) {
        if (this.inList[i].rename) {
          if (
            this.inList[i].rename
              .toLowerCase()
              .search(this.searchInCardInput.toLowerCase()) !== -1
          ) {
            cardImportListDetailsHas[i] = this.inList[i];
          }
        } else {
          if (
            `HDMI${this.inList[i].ch}`
              .toLowerCase()
              .search(this.searchInCardInput.toLowerCase()) !== -1
          ) {
            cardImportListDetailsHas[i] = this.inList[i];
          }
        }
      }
      // let cardImportListDetailsHas = this.cardImportListDetails.filter(item=>{
      //   if (item.rename){
      //     // return  item.rename===this.searchInCardInput
      //     return  item.rename.toLowerCase().search(this.searchInCardInput.toLowerCase())!==-1
      //   }else {
      //     // return `HDMI${item.ch}`===this.searchInCardInput
      //     return `HDMI${item.ch}`.toLowerCase().search(this.searchInCardInput.toLowerCase())!==-1
      //   }
      // })
      if (cardImportListDetailsHas) {
        this.inList = { ...cardImportListDetailsHas };
      } else {
        this.$message.error(i18n.t("home.thereIsNoInputCardYouWant"));
      }

      console.log(this.searchInCardInput, "this.searchInCardInput");
    },
    // 搜索框监听为空时出现列表事件
    searchInCardInputChange(val) {
      console.log(val, "val输入框的监听事件");
      if (val === "") {
        // if (this.cardImportListDetailsCopy!=='无'){
        this.inList = { ...this.cardImportListDetailsCopy };
        // }
      }
    },
    // 搜索输入框的清除事件
    searchInCardInputClear() {
      console.log(
        this.cardImportListDetailsCopy,
        "this.cardImportListDetailsCopy"
      );
      // if (this.cardImportListDetailsCopy!=='无'){
      this.inList = { ...this.cardImportListDetailsCopy };
      // }
    },
    imgfalse(e) {
      return false;
    },
    // 点击弹窗窗体预览场景
    selectSceneULiDialog(item) {
      if (this.dialog.poll.form.en) {
        this.$message.info(i18n.t("home.Scenepollingstatuscannot"));
      } else {
        console.log("点击的当前场景是", item);
        this.dialog.scene.visible = true;
        this.dialog.scene.title = `${i18n.t("home.number") +
          ":" +
          item.sID +
          " " +
          i18n.t("home.name") +
          ":" +
          item.name}`;
        this.dialog.scene.form.sid = item.sID;
        this.dialog.scene.form.name = item.name;
        // this.dialog.scene.form.dataurl = item.dataurl + `?h=${Math.random()}`;
        this.dialog.scene.form.dataurl = `/sence_pic/sence_${
          item.sID
        }.jpg?h=${Math.random()}`;
      }
      // this.dialog.scene.form.sw=item.sw
    },
    // 清空窗窗体预览场景并关闭
    ClearSceneULiDialog() {
      this.dialog.scene.title = ``;
      this.dialog.scene.form.sid = "";
      this.dialog.scene.form.dataurl = "";
      this.dialog.scene.visible = false;
    },
    // 调用场景
    dialogSceneUse() {
      let _this = this;
      // 第一步清空屏幕蓝色部分，不清空输出卡
      this.clearOnlyBlue();
      const loading2 = this.$loading({
        lock: true,
        text: i18n.t("spl.Processing"),
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.isScene_call = true;
      // promise数组
      let promiseList = [];
      scene_callApi({
        cmd: "scene_call",
        gid: _this.gid,
        Id: parseInt(this.dialog.scene.form.sid)
      }).then(res => {
        this.activeSID = this.dialog.scene.form.sid;
        this.getSyncWindow().then(() => {
          _this.isWebSwitch = true; // web调用
          // 截图上传
          _this.setImage().then(r => {
            if (r) {
              const sceneItem = _this.sceneList.find(
                i => i.sID == _this.dialog.scene.form.sid
              );
              // 用原来的接口
              scene_saveApi({
                cmd: "scene_save",
                Group: _this.gid,
                Id: parseInt(_this.dialog.scene.form.sid),
                dataurl: _this.dataurl,
                Scene_name: sceneItem.name
              }).then(() => {
                _this.sceneList = [..._this.sceneList];
                loading2.close();
              });
            }
          }); // 截图
          // let img = new Image();
          // img.src = this.dialog.scene.form.dataurl;
          // img.onload = () => {
          //   loading2.close();
          // };
          // img.onerror = err => {
          //   console.log("图片加载失败,经此判断无场景图，开始截图。。。");
          // };
        });

        _this.dialog.scene.visible = false;
      });
    },
    // 删除单个场景
    dialogSceneDell() {
      scene_delApi({
        cmd: "scene_del",
        Id: this.dialog.scene.form.sid,
        Group: this.gid
      }).then(res => {
        this.$message.success(i18n.t("home.deleted"));
        // 获取场景列表
        this.getSyncScene(true);
        // 关闭弹窗 清空弹窗数据
        this.ClearSceneULiDialog();
      });
    },
    // 重命名
    dialogSceneRename() {
      const _this = this;
      // this.dialog.scene.form.sid = item.sID;
      // this.dialog.scene.form.name = item.name;
      this.$prompt(i18n.t("home.SceneRename"), i18n.t("home.NewSceneRename"), {
        confirmButtonText: i18n.t("home.enter"),
        cancelButtonText: i18n.t("home.cancel"),
        inputValue: this.dialog.scene.form.name,
        inputValidator: inputValidatorGroupRename,
        inputErrorMessage: i18n.t("home.rSceneRename")
      }).then(({ value }) => {
        websocketsend(
          `(rename,scene,${this.dialog.scene.form.sid},${value})\r\n`,
          () => {
            _this.sceneList.forEach(i => {
              if (i.sID == _this.dialog.scene.form.sid) {
                i.name = value;
              }
            });
          }
        );
      });
    },
    // 清空屏幕 所有
    clearScene() {
      let _this = this;
      const loading2 = this.$loading({
        lock: true,
        text: i18n.t("spl.Processing"),
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      _this.isWebSwitch = true;
      websocketsend(`(out,mapflag,${this.gid},0,0)\r\n`, () => {});
      windowClearApi({
        cmd: "windowClear",
        Group: this.gid
      }).then(res => {
        // open
        let mapWidows = this.Layers.filter(i => i.mark & 0x08);
        console.log(mapWidows, "mapWidows");
        async function open() {
          for (const i of mapWidows) {
            await new Promise(resolve => {
              i.flag = 1;
              websocketsend(
                `(wnd,open,${_this.gid},1,${i.num},${i.Vsrc_CH + 1},${
                  i.Vsrc_clip_style
                },${i.inpX},${i.inpY},${i.inpW},${i.inpH})\r\n`,
                res => {
                  websocketsend(
                    `(wnd,attri,${i.num},basemapflag,1)\r\n`,
                    () => {
                      websocketsend(`(wnd,attri,${i.num},lock,1)\r\n`, () => {
                        resolve(true);
                      });
                    }
                  );
                }
              );

              // setTimeout(() => {
              //   return resolve(true);
              // }, 1000);
            });
          }
        }
        open().then(() => {
          _this.Layers = [];
          _this.contextItem = {};
          _this.windowTarget = null;
          websocketsend(`(out,mapflag,${_this.gid},1,0)\r\n`, () => {
            websocketsend(`(sw,0)\r\n`, () => {
              _this.Layers.push(...mapWidows);
              _this.$forceUpdate();
              loading2.close();
            });
          });
        });
      });
    },
    // 只是清空
    clearOnlyBlue() {
      for (const i in this.GridArray) {
        if (this.GridArray[i].outputCh) {
          // 有输出卡  只清空蓝色部分
          this.GridArray[i].import = "";
          this.GridArray[i].importCh = "";
          this.GridArray[i].handleClass = "out";
          this.GridArray[i].singal_flagClass = "";
        }
      }
    },
    // 获取首屏数据
    getList() {
      let _this = this;
      const loading1 = this.$loading({
        lock: true,
        text: i18n.t("home.dataLoading") + "...",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      //TODO: LMP-D: 获取输入通道列表
      // getInputCardListApi({
      //   cmd: "incard_info_sync"
      // })
      //   .then(res => {
      //     let incardList = res.incard_info_sync;
      //     incardList.forEach(item => {
      //       _this.inListInsert(item.cID, {
      //         rename: item.name,
      //         ch: item.cID,
      //         card_type: item.type,
      //         singal_flag: item.signal
      //       });
      //     });
      //   })
      //   .then(_ => {
      //     const a = setTimeout(function() {
      //       loading1.close();
      //       clearTimeout(a);
      //     }, 2000);
      //   })
      //   .catch(err => {
      //     loading1.close();
      //   });
      let port2Type = [23, 17, 81, 82]; // 只有两个端口
      let port1Type = [24]; //只有一个端口
      if (localStorage.getItem("incardListData") && false) {
        const incard_info_sync = JSON.parse(
          localStorage.getItem("incardListData")
        );
        const inputData = JSON.parse(localStorage.getItem("istaData"));
        incard_info_sync.forEach((item, index) => {
          const ch = Math.ceil(item.cID / 4); // 板卡ID
          const signalList = inputData[ch - 1]["signal"];
          const signal = signalList[Math.abs(item.cID - ch * 4 + 3)];
          console.log(signal, "signal");
          _this.inListInsert(item.cID, {
            rename: item.name,
            ch: item.cID, // 端口ID
            card_type: item.type,
            singal_flag: signal,
            clip: item.clip
          });
        });
      } else {
        websocketsend(`(sync,incard)\r\n`, res => {
          console.log("查询输入端口的数据：", res);
          const incard_info_sync = res.reduce((arr, item) => {
            if (item.incard_info_sync) {
              arr.push(...item.incard_info_sync);
            }
            return arr;
          }, []);
          console.log("incard_info_sync: ", incard_info_sync);
          localStorage.setItem(
            "incardListData",
            JSON.stringify(incard_info_sync)
          );
          websocketsend(`(info,ista)\r\n`, res => {
            console.log("查询输入端口信号：", res);
            const inputData = res.reduce((arr, item) => {
              if (item["input status"]) {
                arr.push(...item["input status"]);
              }
              return arr;
            }, []);
            console.log("inputData: ", inputData);
            localStorage.setItem("istaData", JSON.stringify(inputData));
            incard_info_sync.forEach((item, index) => {
              const ch = Math.ceil(item.cID / 4); // 板卡ID
              const signalList = inputData[ch - 1]["signal"];
              const signal = signalList[Math.abs(item.cID - ch * 4 + 3)];
              console.log(signalList, "signalList");
              console.log(item, "item");
              console.log(item.cID, "item.cID");
              console.log(
                Math.abs(item.cID - ch * 4),
                "Math.abs(item.cID - ch * 4)"
              );
              console.log(signal, "signal");
              console.log(
                item.clip.every(item => JSON.stringify(item) !== "{}"),
                'item.clip.every(item => JSON.stringify(item) !== "{}")'
              );
              if (port2Type.includes(item.type)) {
                // 奇数端口 两个端口
                if (item.cID % 2 !== 0) {
                  _this.inListInsert(item.cID, {
                    rename: item.name,
                    ch: item.cID, // 端口ID
                    card_type: item.type,
                    singal_flag: signal,
                    clip: item.clip.every(item => JSON.stringify(item) == "{}")
                      ? []
                      : item.clip
                  });
                }
              } else if (port1Type.includes(item.type)) {
                // 一个端口
              } else {
                // 四个端口
                _this.inListInsert(item.cID, {
                  rename: item.name,
                  ch: item.cID, // 端口ID
                  card_type: item.type,
                  singal_flag: signal,
                  clip: item.clip.every(item => JSON.stringify(item) == "{}")
                    ? []
                    : item.clip
                });
              }
            });
            let protOneList = incard_info_sync.filter(i =>
              port1Type.includes(i.type)
            );
            for (let i = 0; i < protOneList.length; i += 4) {
              let item = protOneList[i];
              const ch = Math.ceil(item.cID / 4); // 板卡ID
              const signalList = inputData[ch - 1]["signal"];
              const signal = signalList[Math.abs(item.cID - ch * 4 + 3)];
              _this.inListInsert(item.cID, {
                rename: item.name,
                ch: item.cID, // 端口ID
                card_type: item.type,
                singal_flag: signal,
                clip: item.clip.every(item => JSON.stringify(item) == "{}")
                  ? []
                  : item.clip
              });
            }
          });
          _this.getGinfo_sync(true);
        });
      }
    },
    // 输入列表插入逻辑
    inListInsert(index, item) {
      console.log(item, "输入列表插入逻辑item");
      let i = index;
      let _this = this;
      if (_this.inList[i]) {
        let i_port =
          _this.inList[i].ch +
          "_" +
          `${
            _this.inList[i].port_index === undefined
              ? 0
              : _this.inList[i].port_index
          }`;
        let item_port =
          item.ch +
          "_" +
          `${item.port_index === undefined ? 0 : item.port_index}`;
        if (i_port === item_port) {
          // 如果 通道_端口 一样 则替换
          // console.log(i_port,'i_port')
          // console.log(item_port,'item_port')
          _this.inList[i] = item;
        } else {
          _this.inListInsert(i + 1, item);
        }
        console.log(i_port, "i_port");
        console.log(item_port, "item_port");
      } else {
        _this.inList[i] = item;
        _this.cardImportListDetailsCopy[i] = item;
      }
    },
    // 获取场景
    getSyncScene(iSend) {
      let _this = this;
      _this.isWebSwitch = true; // web调用
      // TODO: 查询场景列表时要加分组ID
      // SyncSceneApi({ cmd: "syncScene", gid: _this.gid }).then(res => {
      //   console.log(res, "获取的场景列表数据");
      //   // 先根据当前分组的ID进行初步筛选
      //   const items = res.scene_info_sync.filter(i => i.gID === this.gid);
      //   // 再根据 当前分组的分辨率 几行几列 间隙
      //   this.sceneList = [...items];
      //   this.sceneIDList = res.scene_info_sync.map(item => item.sID);
      //
      //   // 获取单个场景的数据
      //   //   _this.sceneList.forEach(item => {
      //   //     getScenceDataApi({ cmd: 'getScenceData', sId: item.sID, type: 0 }).then(d => {
      //   //      item.dataurl = d.dataurl
      //   //     })
      //   //   })
      // });
      if (localStorage.getItem("sceneData") && !iSend && false) {
        const scene_info_sync = JSON.parse(localStorage.getItem("sceneData"));
        const items = scene_info_sync.filter(i => i.gID === this.gid);
        //   // 再根据 当前分组的分辨率 几行几列 间隙
        this.sceneList = [...items];
        this.sceneIDList = scene_info_sync.map(item => item.sID);
      } else {
        websocketsend("(sync,scene)\r\n", res => {
          console.log("查询场景列表数据：", res);
          // const itemData = res.filter(i => i.scene_info_sync);
          const itemData = res.reduce((arr, item) => {
            if (item.scene_info_sync) {
              arr.push(item.scene_info_sync);
            }
            return arr;
          }, []);

          console.log("itemData:", itemData);
          // const { scene_info_sync } = itemData[0];
          const scene_info_sync = itemData.flat();
          // 目前缓存不放本地
          // localStorage.setItem("sceneData", JSON.stringify(scene_info_sync));
          //   // 先根据当前分组的ID进行初步筛选
          const items = scene_info_sync.filter(i => i.gID === this.gid);
          items.forEach(i =>
            Object.assign(i, {
              localImg: `/sence_pic/sence_${parseInt(
                i.sID
              )}.jpg?h=${Math.random()}`
            })
          );
          //   // 再根据 当前分组的分辨率 几行几列 间隙
          this.sceneList = [...items];
          this.sceneIDList = scene_info_sync.map(item => item.sID);
        });
      }
    },
    dbLineHeight() {
      return false;
    },
    LineHeight(ch, name, singal_flag, item, Vsrc_clip_style) {
      console.log("LineHeight");
      if (this.dialog.poll.form.en) {
        this.$message.info(i18n.t("home.Cannotclicktheinput"));
        return false;
      }
      // this.handleChCopy = ch
      // if (this.handleChName !== name) {
      //   // lidom.classList.add("light");
      //   // lidom.style.background = "#ededf0";
      //   // lidom.style.color = "#1890ff";
      //   console.log("点击赋值了");
      //   this.handleChCopy =
      //     item.port_index === undefined
      //       ? `${item.ch}_0`
      //       : `${item.ch}_${item.port_index}`;
      //   console.log(this.handleChCopy, "this.handleChCopy");
      //   console.log(`${item.ch}_${item.port_index}`);
      //   this.handleChName = name;
      //   this.handleSingal_flag = singal_flag;
      //   this.handleVsrc_clip_style = Vsrc_clip_style;
      //
      //   let evData = {
      //     name: name,
      //     singal_flag: singal_flag,
      //     // ch: parseInt(j),
      //     ch: parseInt(item.ch),
      //     Vsrc_clip_style: parseInt(Vsrc_clip_style)
      //   };
      //   this.evData = evData;
      // } else {
      //   console.log("LineHeight取消输入源选择");
      //   // lidom.classList.remove("light");
      //   // lidom.style.background = "transparent";
      //   // lidom.style.color = "#ffffff";
      //   this.handleChCopy = "";
      //   this.handleChName = "";
      //   this.handleSingal_flag = "";
      //   this.handleVsrc_clip_style = 0;
      //   this.evData = null;
      // }
      for (let key in this.inList) {
        let inListElement = this.inList[key];
        console.log(inListElement, "inListElement");
        if (inListElement.ch == ch && inListElement) {
          let lidom = document.getElementById(`in${ch}`);
          console.log(lidom);
          if (this.handleChName !== name) {
            lidom.classList.add("light");
            lidom.style.background = "#ededf0";
            lidom.style.color = "#1890ff";
            this.handleChCopy =
              item.port_index === undefined
                ? `${item.ch}_0`
                : `${item.ch}_${item.port_index}`;
            this.handleChName = name;
            this.handleSingal_flag = singal_flag;
            this.handleVsrc_clip_style = Vsrc_clip_style;

            let evData = {
              name: name,
              singal_flag: singal_flag,
              // ch: parseInt(j),
              ch: parseInt(item.ch),
              Vsrc_clip_style: parseInt(Vsrc_clip_style)
            };
            this.evData = evData;
          } else {
            lidom.classList.remove("light");
            lidom.style.background = "transparent";
            lidom.style.color = "#ffffff";
            this.handleChCopy = "";
            this.handleChName = "";
            this.handleSingal_flag = "";
            this.handleVsrc_clip_style = 0;
            this.evData = null;
          }
        } else {
          let lidom = document.getElementById(`in${inListElement.ch}`);
          if (lidom) {
            lidom.classList.remove("light");
            lidom.style.background = "transparent";
            lidom.style.color = "#ffffff";
          }
        }
      }

      // this.handleChCopy =
      //   item.port_index === undefined
      //     ? `${item.ch}_0`
      //     : `${item.ch}_${item.port_index}`;
      // console.log(this.handleChCopy, "this.handleChCopy");
      // console.log(`${item.ch}_${item.port_index}`);
      // this.handleChName = name;
      // this.handleSingal_flag = singal_flag;
      // this.handleVsrc_clip_style = Vsrc_clip_style;
      //
      // let evData = {
      //   name: name,
      //   singal_flag: singal_flag,
      //   // ch: parseInt(j),
      //   ch: parseInt(item.ch),
      //   Vsrc_clip_style: parseInt(Vsrc_clip_style)
      // };
      // this.evData = evData;
    },
    drag(ev, name, singal_flag, item, Vsrc_clip_style) {
      // console.log('拖动ev.target', ev.target)
      // console.log('拖动name', name)
      // console.log('拖动ev.target.dataset.ch', ev.target.dataset.ch)
      // ev.target.classList.add('heightBk');
      if (this.dialog.poll.form.en) {
        this.$message.info(i18n.t("home.Cannotdraggedtheinput"));
        return false;
      }
      this.handleCh = ev.target.dataset.ch;
      console.log(this.handleCh, "this.handleCh");
      // this.handleChCopy = ev.target.dataset.ch
      this.handleChCopy =
        item.port_index === undefined
          ? `${item.ch}_0`
          : `${item.ch}_${item.port_index}`;
      this.handleChName = name;
      this.handleSingal_flag = singal_flag;
      // let j;
      // for (let i in this.CardINOUTList) {
      //   if (this.CardINOUTList[i] === this.handleChCopy) {
      //     j = i;
      //   }
      // }

      let evData = {
        name: name,
        singal_flag: singal_flag,
        // ch: parseInt(j),
        ch: parseInt(item.ch),
        Vsrc_clip_style: parseInt(Vsrc_clip_style)
      };
      this.evData = evData;
      console.log(ev, "ev");
      ev.dataTransfer.setData("abcd", JSON.stringify(evData));
      // ev.dataTransfer.setData("text", JSON.stringify(evData));
      // ev.dataTransfer.effectAllowed = "move";
    },
    // 关闭输入卡
    closeIN(ii, card_type, Grid_i) {
      console.log(ii, "关闭的out");
      let i = parseInt(ii.split("_")[0]);
      let j = parseInt(ii.split("_")[1]);
      let index;
      console.log(card_type, "card_type");
      console.log(i, "i");
      // if (card_type===102){
      //   index=i+j
      // }else {
      //   index=parseInt(Grid_i)
      // }
      index = parseInt(Grid_i);
      this.GridArray[index].import = "";
      this.GridArray[index].importCh = "";
      this.GridArray[index].handleClass = "out";
      this.GridArray[index].singal_flagClass = "";
      let data = {
        cmd: "videoSwitch",
        in: 0,
        out: i,
        in_port_index: 0,
        out_port_index: Number(ii.split("_")[1])
      };
      SendInOutSeatApi(data)
        .then(res => {
          if (res.msg === "ok") {
          }
        })
        .catch(err => {});
    },
    async toLogin() {
      if (WS) {
        WS.close();
      }
      WSNULL();
      await this.$store.dispatch("user/logout");
      this.$router.push(`/login`);

      localStorage.removeItem("sceneData");
      localStorage.removeItem("omapData");
      localStorage.removeItem("incardListData");
      localStorage.removeItem("timingData");
      localStorage.removeItem("wndData");
      localStorage.removeItem("outListData");
      localStorage.removeItem("istaData");
      localStorage.removeItem("systemType");
      localStorage.removeItem("ipInfoData");
      localStorage.removeItem("verData");
      localStorage.removeItem("permit");

      // window.open("/#/login", "_self");
    },
    toSetting() {
      this.$router.push({ path: "/layout/SplicingSettings" });
    },
    // 窗体的属性弹窗的确定事件
    dialogWindowEnter() {
      this.contextItem.isTitle = this.dialogWindow.form.isTitle;
      this.contextItem.inpX = this.dialogWindow.form.X;
      this.contextItem.inpY = this.dialogWindow.form.Y;
      this.contextItem.inpW = this.dialogWindow.form.W;
      this.contextItem.inpH = this.dialogWindow.form.H;

      console.log(this.windowTarget, "this.windowTarget");

      // this.windowTarget.target.style.width = `${this.dialogWindow.form.W *
      //   this.Wrate}px`;
      // this.windowTarget.target.style.height = `${this.dialogWindow.form.H *
      //   this.Hrate}px`;
      // this.windowTarget.target.style.left = `${this.dialogWindow.form.X *
      //   this.Wrate}px`;
      // this.windowTarget.target.style.top = `${this.dialogWindow.form.Y *
      //   this.Hrate}px`;

      let dom = document.querySelector(`#mouseWarp0${this.contextItem.num}`);
      dom.style.width = `${this.dialogWindow.form.W * this.Wrate}px`;
      dom.style.height = `${this.dialogWindow.form.H * this.Hrate}px`;
      dom.style.left = `${this.dialogWindow.form.X * this.Wrate}px`;
      dom.style.top = `${this.dialogWindow.form.Y * this.Hrate}px`;

      windowAttriConfigApi({
        cmd: "windowAttriConfig",
        ID: this.contextItem.num,
        gid: this.gid,
        type: "title",
        en: this.dialogWindow.form.isTitle ? 0 : 1
      });
      windowMoveApi({
        cmd: "windowMove",
        gid: this.gid,
        value: 1, // 0 灰色 1正常 2wu无效
        ID: this.contextItem.num, // 窗口ID （0-65535）
        x: parseInt(this.contextItem.inpX), // 起点x
        y: parseInt(this.contextItem.inpY), // 起点y
        w: parseInt(this.contextItem.inpW), // 结束x 或者 窗体宽
        h: parseInt(this.contextItem.inpH) // 结束y 或者 窗体高
      });

      this.dialogWindow.visible = false;
    },
    // 保存场景的确认弹框
    dialogAddpollEnter() {
      let _this = this;

      const loading4 = this.$loading({
        lock: true,
        text: i18n.t("home.Saving") + "...",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.$refs.addpollform.validateField("Scene_name");
      if (
        this.dialog.addpoll.form.Scene_name.length < 11 &&
        this.dialog.addpoll.form.Scene_name.length > 2
      ) {
        _this.setImage().then(r => {
          if (r) {
            console.log("保存结束");
            _this.isWebSwitch = true; // web调用
            // 用原来的接口
            scene_saveApi({
              cmd: "scene_save",
              Group: _this.gid,
              Id: parseInt(_this.dialog.addpoll.form.Id),
              dataurl: _this.dataurl,
              Scene_name: _this.dialog.addpoll.form.Scene_name,
              Cols: 4, // 几行
              Rows: 4, // 几列
              w: 1920, // 水平
              h: 1080, // 垂直
              vgap: 0, // 水平间隙
              hgap: 0 // 垂直间隙
            })
              .then(res => {
                // for (let i in _this.pollNumList){
                //   _this.pollNumList[i]=null
                // }
                // _this.getSyncScene(true);
                _this.dialog.addpoll.visible = false;

                // {"sID":1,"gID":1,"name":"场景1","H":1920,"V":1080,"Rows":4,"Cols":4,"hgap":2,"vgap":2}

                if (_this.sceneIDList.length !== 128) {
                  _this.sceneList.push({
                    sID: parseInt(_this.dialog.addpoll.form.Id),
                    gID: _this.gid,
                    name: _this.dialog.addpoll.form.Scene_name,
                    localImg: `/sence_pic/sence_${parseInt(
                      _this.dialog.addpoll.form.Id
                    )}.jpg?h=${Math.random()}`
                  });
                  _this.sceneIDList.push(
                    parseInt(_this.dialog.addpoll.form.Id)
                  );
                }

                // 场景数据太大不放本地
                // const sceneData = JSON.parse(localStorage.getItem("sceneData"));
                // sceneData.push({
                //   sID: parseInt(_this.dialog.addpoll.form.Id),
                //   gID: _this.gid,
                //   name: _this.dialog.addpoll.form.Scene_name
                // });
                // localStorage.setItem("sceneData", JSON.stringify(sceneData));
                // 成功做一些操作
                // _this.sceneList.push({
                //   sID: parseInt(_this.dialog.addpoll.form.Id),
                //   gID: 1,
                //   name: _this.dialog.addpoll.form.Scene_name,
                //   sw: [],
                //   dataurl: _this.dataurl
                // })
                loading4.close();

                _this.$message({
                  type: "success",
                  showClose: true,
                  message:
                    i18n.t("home.saveIngTip") +
                    ": " +
                    `${_this.dialog.addpoll.form.Scene_name}`,
                  duration: 2000
                });
              })
              .catch(err => {
                loading4.close();
                _this.$message({
                  type: "error",
                  message: i18n.t("home.SaveFailed")
                });
              });
          }
        }); // 截图
      }
    },
    // 保存场景弹出弹窗
    saveSceneDialog() {
      if (!this.Layers.length) {
        this.$message.error(i18n.t("home.saveTip"));
        return false;
      }
      for (let i = 1; i < 129; i++) {
        this.pollNumList[i] = null;
      }

      // for (let i in this.pollNumList) {
      //   this.pollNumList[i] = null;
      // }
      console.log(this.pollNumList, "this.pollNumList");
      console.log(this.sceneIDList, "this.sceneIDList");

      const sceneLength = [];
      this.sceneIDList.forEach(item => {
        this.pollNumList[item] = item;
        sceneLength.push(item);
      });
      let sceneNameDefault;
      if (sceneLength.length) {
        // sceneNameDefault = Math.max(...sceneLength) + 1
        let arr = [];
        for (let i in this.pollNumList) {
          console.log(this.pollNumList[2], "this.pollNumList[2]");
          if (!this.pollNumList[i]) {
            arr.push(i);
          }
        }
        console.log(arr, "arrrrrr");
        if (parseInt(arr[0])) {
          sceneNameDefault = parseInt(arr[0]);
          this.dialog.addpoll.form.Id = parseInt(arr[0]);
          this.dialog.addpoll.form.Scene_name = `${i18n.t("home.scenes") +
            sceneNameDefault}`;
        } else {
          this.dialog.addpoll.form.Scene_name = `${i18n.t("home.scenes") +
            128}`;
          this.dialog.addpoll.form.Id = 128;
        }
      } else {
        sceneNameDefault = 1;
        this.dialog.addpoll.form.Scene_name = `${i18n.t("home.scenes") + 1}`;
        this.dialog.addpoll.form.Id = 1;
      }
      console.log(sceneNameDefault, "sceneNameDefault");

      this.dialog.addpoll.visible = true;
    },
    // 删除所有场景
    delSceneAll() {
      const _this = this;
      this.$confirm(
        i18n.t("home.deleteAllTipStatement"),
        i18n.t("home.deleteAllTip"),
        {
          confirmButtonText: i18n.t("home.enter"),
          cancelButtonText: i18n.t("home.cancel"),
          type: "warning",
          closeOnClickModal: false,
          beforeClose(action, instance, done) {
            if (action == "confirm") {
              instance.$refs["confirm"].$el.onclick = a();

              function a(e) {
                console.log(2);
                e = e || window.event;
                if (e.detail != 0) {
                  done();
                }
              }
            } else {
              done();
            }
          }
        }
      )
        .then(() => {
          const loading5 = this.$loading({
            lock: true,
            text: "正在删除...",
            spinner: "el-icon-loading",
            background: "rgba(0, 0, 0, 0.7)"
          });

          websocketsend(`(scene,del,${this.gid},0)\r\n`, res => {
            console.log("删除所有场景的响应数据：", res);
            loading5.close();
            _this.$message.success(i18n.t("home.successdeleted"));
            _this.getSyncScene(true);
          });
          // scene_delApi({ cmd: "scene_del", Id: 0, Group: this.gid })
          //   .then(res => {
          //     this.$message({
          //       type: "success",
          //       message: "删除成功!"
          //     });
          //   })
          //   .then(_ => {
          //     // 获取场景列表
          //     this.getSyncScene(true);
          //   });
        })
        .catch(() => {
          // this.$message({
          //   type: 'info',
          //   message: '已取消删除'
          // });
        });
    },
    // 截图
    setImage() {
      console.log("开始保存");
      const that = this;
      return new Promise((resolve, reject) => {
        const outWarp = document.getElementById("centerTop");
        outWarp.style.backgroundColor = "#181818";
        let inWarp = document.querySelector("#ptngridwarp0");
        html2canvas(inWarp, {
          width: outWarp.scrollWidth,
          height: outWarp.scrollHeight,
          scale: 0.5
        }).then(function(canvas) {
          that.dataurl = canvas.toDataURL("image/jpeg", 0.5);
          if (that.dataurl) {
            resolve(true);
          } else {
            reject(false);
          }
        });
      });
    },
    // 轮询设置弹出弹窗
    pollDialog() {
      if (this.sceneList.length) {
        this.getscene_polling();
        let GroupContext = JSON.parse(localStorage.getItem("GroupContext"));
        GroupContext.forEach(i => {
          if (i.gID === this.gid) {
            this.dialog.poll.form.en = i.scene_polling.status;
            this.dialog.poll.form.Id_group = i.scene_polling.list
              ? i.scene_polling.list
              : [];
          }
        });

        this.dialog.poll.visible = true;
      } else {
        this.$message.error(i18n.t("home.scenePollingTip"));
      }
    },
    // 场景轮询开关事件
    enChange(val) {
      console.log(val, "场景开关值");
      scene_rotateApi({ cmd: "scene_rotate", Group: this.gid, en: val }).then(
        res => {}
      );
    },
    // 场景开关
    sceneSwitch(val) {
      console.log(val, "场景开关");
      // scene_rotateApi({
      //   Group: this.gid,
      //   en: val
      // });
    },
    // 场景轮询参数确定
    dialogPollEnter() {
      let _this = this;
      let state = false;
      this.$refs["pollform"].validate(valid => {
        if (valid) {
          state = true;
        }
      });
      if (!state) {
        return false;
      }

      const loading3 = this.$loading({
        lock: true,
        text: "正在设置轮询参数...",
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      this.isWebSwitch = true;

      // 无论当前是开关状态 ，都是先关
      // scene_rotateApi({ cmd: "scene_rotate", Group: this.gid, en: 0 }).then(
      //   res => {
      //     scene_rotate_argsApi({
      //       cmd: "scene_rotate_args",
      //       Group: this.gid,
      //       period: this.dialog.poll.form.period,
      //       Id_group: this.dialog.poll.form.Id_group
      //     }).then(r => {
      //       if (this.dialog.poll.form.en) {
      //         // 判断之前的状态  如果是开  重新开启
      //         scene_rotateApi({
      //           cmd: "scene_rotate",
      //           Group: this.gid,
      //           en: 1
      //         }).then(re => {});
      //       } else {
      //         // 如果是关 则不用管
      //       }
      //     });
      //     this.dialog.poll.visible = false;
      //     // this.dialog.poll.form.Id_group=[]
      //     // this.dialog.poll.form.period=10
      //     // this.dialog.poll.form.en=0
      //   }
      // );

      let en = this.dialog.poll.form.en ? 1 : 0;
      let GroupContext = JSON.parse(localStorage.getItem("GroupContext"));
      GroupContext.forEach(i => {
        if (i.gID === this.gid) {
          console.log(en, "ennnnnnnnnnnnnnnnnnnnnn");
          i.scene_polling.status = en;
          i.scene_polling.list = _this.dialog.poll.form.Id_group;
        }
      });
      localStorage.setItem("GroupContext", JSON.stringify(GroupContext));
      // 新逻辑 发ws
      scene_rotate_argsApi({
        cmd: "scene_rotate_args",
        Group: this.gid,
        period: this.dialog.poll.form.period,
        Id_group: this.dialog.poll.form.Id_group
      }).then(r => {
        // 判断之前的状态  如果是开  重新开启

        scene_rotateApi({
          cmd: "scene_rotate",
          Group: this.gid,
          en
        });

        loading3.close();

        _this.allCheckStae = false;
        _this.dialog.poll.form.Id_group = [];

        this.dialog.poll.visible = false;
      });
    },
    // 获取场景轮询参数设置
    getscene_polling() {
      // scene_pollingApi({ cmd: "scene_polling", Group: this.gid }).then(res => {
      //   this.dialog.poll.form.en = res.scene_polling.status;
      //   this.dialog.poll.form.period = res.scene_polling.interval;
      //   if (res.scene_polling.interval <= 0) {
      //     this.dialog.poll.form.period = 5;
      //   }
      //   if (res.scene_polling.interval >= 120) {
      //     this.dialog.poll.form.period = 120;
      //   }
      //
      //   this.dialog.poll.form.Id_group = res.scene_polling.scene_list || [];
      // });
    }
  }
};
</script>
<style>
.el-dialog__wrapper,
.el-message-box__wrapper,
.el-loading-mask,
.el-select-dropdown,
.el-color-dropdown {
  z-index: 99999 !important;
}

.el-tooltip__popper[aria-hidden="false"] {
  z-index: 99999 !important;
}

.v-modal {
  z-index: 99998 !important;
}

.el-icon-circle-close {
  color: #ffffff;
}

.el-carousel__container {
  height: 720px;
}

.wuxiao {
  background-image: linear-gradient(
    to bottom,
    #d5d4d0 0%,
    #d5d4d0 1%,
    #eeeeec 31%,
    #efeeec 75%,
    #e9e9e7 100%
  ) !important;
}

.pointer_events_none {
  pointer-events: none;
}

.not_allowed {
  background: #aaa;
  cursor: not-allowed !important;
}

.tem {
  width: 100px;
  height: 100px;
  overflow: hidden;
  /*padding: 5px;*/
  box-sizing: border-box;
  /*border: transparent 2px dashed;*/
}

.border {
  border: #ffffff 0 dashed !important;
}
</style>
<style lang="scss" scoped>
/*右键菜单*/
.right-menu {
  position: fixed;
  background: #fff;
  border: solid 1px rgba(0, 0, 0, 0.2);
  border-radius: 3px;
  z-index: 99999;
}

.right-menu a {
  width: 75px;
  height: 28px;
  line-height: 28px;
  padding: 2px;
  text-align: center;
  display: block;
  color: #1a1a1a;
}

.right-menu a:hover {
  background: rgb(39, 61, 79);
  color: #fff;
}

/*头部*/
.header {
  /*display: flex;*/
  /*justify-content: space-between;*/
  /*align-items: center;*/
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  align-items: center;

  height: 57px;
  padding-left: 52px;
  padding-right: 45px;
  background: linear-gradient(to top, #1b1b1b, #3f3f3f);
  box-shadow: 0 0 12px 0 rgba(190, 118, 66, 0.24);
  border-bottom: 2px solid #000000;

  & > .center-top-buttonGroup {
    display: flex;
    justify-content: center;
    //width: 635px;
  }

  .header_title {
    width: 180px;
    height: 28px;
    margin: 0;
    font-size: 18px;
    color: #ffffff;
  }
}

/*中间部分*/
.content {
  color: #ffffff;
  display: flex;

  .left {
    position: relative;
    width: 262px;
    height: calc(100vh - 60px);
    overflow-y: hidden;
    border-right: 2px solid #000000;

    .left-header {
      width: 100%;
      height: 50px;
      line-height: 50px;
      text-align: center;
      font-size: 19px;
      border-bottom: 2px solid #000000;
    }

    .left-list {
      height: calc(100vh - 106px);
      overflow-y: auto;
    }

    /*修改滚动条样式*/
    .left-list::-webkit-scrollbar {
      width: 24px;
      height: 10px;
      /**/
    }

    .left-list::-webkit-scrollbar-track {
      background: linear-gradient(to top, #1b1b1b, #3f3f3f);
    }

    .left-list::-webkit-scrollbar-thumb {
      background: linear-gradient(-90deg, #323232, #030303);
      border-radius: 10px;
    }

    .left-list::-webkit-scrollbar-thumb:hover {
      /*background: #030303;*/
    }

    .left-list::-webkit-scrollbar-button:start {
      width: 24px;
      background: #3f3f3f url("../../assets/home/web1x_start.png") 7px 7px
        no-repeat;
    }

    .left-list::-webkit-scrollbar-button:end {
      width: 24px;
      background: #1b1b1b url("../../assets/home/web1x_end.png") 7px 7px
        no-repeat;
    }

    .left-list > .left-list-ul {
      padding-left: 56px;
    }

    .left-list > .left-list-input-warp {
      position: sticky;
      top: 0;
      width: 180px;
      margin-left: 49px;
      margin-top: 22px;
      background: #181818;

      & .el-input > .el-input__inner {
        border-top-left-radius: 25px;
        border-bottom-left-radius: 25px;
      }

      & .el-input > .el-input-group__append {
        border-top-right-radius: 25px;
        border-bottom-right-radius: 25px;
      }

      .input {
        width: 156px;
        height: 36px;
        padding-left: 5px;
        padding-right: 52px;
        border-radius: 25px;
        border: none;
        outline: none;
      }

      .img-warp {
        width: 51px;
        height: 36px;
        position: absolute;
        right: 0;
        bottom: 0;
        border: none;
        background: linear-gradient(to right, #474747, #a3a3a3);
        border-top-right-radius: 25px;
        border-bottom-right-radius: 25px;
        text-align: center;
      }

      img {
        margin-top: 3px;
      }
    }

    .left-list > .left-list-ul .left-list-ul-li {
      display: flex;
      align-items: center;
      width: 140px;
      height: 36px;
      border-radius: 18px;
      line-height: 36px;
      margin-top: 17px;
      user-select: none;
      vertical-align: center;
      font-size: 17px;
      font-weight: 400;
      list-style: none;
    }

    .left-list > .left-list-ul .left-list-ul-li:hover {
      /*display: flex;*/
      /*align-items: center;*/
      /*width: 140px;*/
      /*height: 36px;*/
      /*border-radius: 18px;*/
      /*line-height: 36px;*/
      /*margin-top: 17px;*/
      /*user-select: none;*/
      /*vertical-align: center;*/
      /*font-size: 17px;*/
      /*font-weight: 400;*/
      /*list-style: none;*/
      background: #ededf0;
      color: #1890ff;
    }

    .left-list > .left-list-ul .left-list-ul-li.light {
      background: #ededf0;
      color: #1890ff;
    }

    .left-list > .left-list-ul .left-list-ul-li > img {
      width: 19px;
      height: 27px;
      margin-right: 17px;
      margin-left: 13px;
    }
  }

  .center {
    width: 1460px;
    height: fit-content;
    /*height: 777px;*/
    /*background-color: #000000;*/

    display: flex;
    flex-direction: column;
    justify-content: flex-start;

    .center-top {
      /*& > .center-top-buttonGroup {*/
      /*  display: flex;*/
      /*  justify-content: space-between;*/
      /*  width: 435px;*/
      /*  margin-top: 12px;*/
      /*  margin-left: 117px;*/
      /*}*/

      & > .ptn-grid-warp {
        position: relative;
        min-width: 1263px;
        flex-basis: 1263px;
        display: flex;
        flex-wrap: wrap;
        width: 1263px;
        height: 710px;
        /*margin-top: 7px;*/
        /*margin-left: 117px;*/
        margin: 0 auto;
        background-color: #292929;
      }

      .ptn-grid-warp > .ptn-grid-item {
        position: relative;
        display: flex;
        flex-wrap: wrap;
        box-sizing: border-box;
        width: 315px;
        height: 177px;
        max-width: 315px;
        max-height: 177px;
        border: 1px solid #ffffff;
      }

      .ptn-grid-warp > .ptn-grid-item.show {
        background: #5a5e66;
      }

      .ptn-grid-warp > .ptn-grid-item > .ptn-grid-item-i {
        width: 156px;
        height: 87px;
        max-width: 156px;
        max-height: 87px;
        /*background: #5a5e66;*/
      }

      .ptn-grid-warp > .ptn-grid-item > .ptn-grid-item-i.show {
        /*background: #bbbbbb;*/
      }

      .ptn-grid-warp > .ptn-grid-item > .ptn-grid-item-i:nth-child(2n-1) {
        border-right: 1px dashed #f0f0f0;
      }

      .ptn-grid-warp > .ptn-grid-item > .ptn-grid-item-i:first-child {
        border-bottom: 1px dashed #f0f0f0;
      }

      .ptn-grid-warp > .ptn-grid-item > .ptn-grid-item-i:nth-child(2) {
        border-bottom: 1px dashed #f0f0f0;
      }
    }

    .left-header {
      width: 100%;
      height: 50px;
      line-height: 50px;
      text-align: center;
      font-size: 19px;
      border-bottom: 2px solid #000000;
    }

    .center-bottom {
      margin-top: 10px;
      width: 1460px;
      /*height: calc(100vh - 840px);*/
      flex: 1;
      /*margin-top: 44px;*/
      display: flex;
      justify-content: space-around;
      align-items: stretch;
      background-color: #181818;

      .center-bottom-item {
        position: relative;
        display: flex;
        justify-content: center;
        align-items: center;
        width: 200px;
        /*height: 200px;*/
        /*line-height: 100%;*/
        background: #434343;
        border: 2px solid #cacaca;
        border-radius: 10px;
        text-align: center;
        font-size: 28px;
        font-weight: 400;
        color: #fffefe;
        padding: 2px;

        .videoCloseClass {
          position: absolute;
          top: 0;
          right: 0;
          z-index: 9999;
        }
      }

      /* 平板 */
      @media all and (max-width: 1024px) {
        .center-bottom-item {
          height: 200px;
        }
      }
    }
  }
}

/*右侧场景列表*/
.right {
  position: relative;
  width: calc(100vw - 1720px);
  text-align: center;
  border-left: 2px solid #000000;

  .scene-button {
    width: 122px;
    height: 40px;
    margin: 5px auto 0 auto;
    line-height: 40px;
    border-radius: 25px;
    text-align: center;
    //background: linear-gradient(#474747, #a3a3a3);
    //box-shadow: 0 1px 0 0 #ffffff inset;
    font-size: 17px;
    font-weight: 400;
    color: #ffffff;
  }

  .scene-ul {
    height: calc(100vh - 400px);
    overflow-y: auto;
    padding: 0;
    scroll-behavior: smooth;
    .elimg {
      width: 100%;
      height: 100%;
      border-radius: 10px;
    }

    .scene-ul-li {
      margin: 25px 25px 0 25px;
      list-style: none;
      border-radius: 10px;
      display: block;
      cursor: pointer;
      color: #fff;
      position: relative;
      width: 157px;
      height: 92px;
      background: #434343;
      border: 2px solid #cacaca;

      &:before {
        display: inline-block;
        content: "";
        height: 100%;
        vertical-align: middle;
      }

      &.active {
        /*background: -webkit-gradient(linear, 0 0, 0 100%, from(#007acc), to(#81aff3));*/
        border: 2px solid #007acc;
      }

      /*span {*/
      /*  display: inline-block;*/
      /*  width: 60%;*/
      /*  height: 50px;*/
      /*  line-height: 50px;*/
      /*  border-radius: 10px;*/
      /*  background-color: #007acc;*/

      /*  &:active {*/
      /*    user-select: none;*/
      /*    background-color: #fff;*/
      /*    color: #007acc;*/
      /*  }*/
      /*}*/
    }
  }

  .span {
    font-size: 16px;
    display: inline-block;
    width: 80px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .button-list {
    /*position: absolute;*/
    /*left: 0;*/
    /*right: 0;*/
    /*bottom: 0;*/
    display: flex;
    flex-direction: column;

    .button-list-item {
      border-radius: 5px;
      //width: auto;
      width: 110px;
      background-color: #a0a0a0;
      color: #fff;
      cursor: default;
      margin: 7px auto;
      outline: none;
      font-size: 16px;
    }
  }
}
/*左侧输入列表 剪裁功能*/
.clipWarp {
  overflow: hidden;
  height: 60px;
  transition: height 0.3s ease-in-out;
}
.clipWarpNoHover:hover {
  // TODO: 暂时去掉背景
  //background: #303133;
}
.clipWarp:hover {
  // TODO: 暂时去掉背景
  //background: #303133;
  height: auto;
}
.clipLi {
  display: flex;
  align-items: center;
  width: 140px;
  height: 36px;
  border-radius: 18px;
  line-height: 36px;
  margin-top: 17px;
  user-select: none;
  vertical-align: center;
  font-size: 15px;
  font-weight: 400;
  list-style: none;
  padding-left: 47px;
}
.clipLi:hover {
  background: #303133;
  color: #1890ff;
}
</style>
