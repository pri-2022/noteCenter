<template>
  <div class="padding30">
    <div class="filter-container">
      <!--      <div class="filter-item">-->
      <!--        <el-select v-model="query.permit" placeholder="请选择权限">-->
      <!--          <el-option label="低" :value="0"></el-option>-->
      <!--          <el-option label="中" :value="1"></el-option>-->
      <!--          <el-option label="高" :value="2"></el-option>-->
      <!--        </el-select>-->
      <!--      </div>-->
      <!--      <div class="filter-item">-->
      <!--        <el-button type="primary"  size="mini" @click="getList">查询</el-button>-->
      <!--      </div>-->
      <div class="filter-item">
        <el-button type="primary" size="mini" @click="addUserDialog">{{
          $t("user.add")
        }}</el-button>
      </div>
    </div>
    <div>
      <el-table :data="tableData" style="width: 100%" border stripe>
        <!--      <el-table-column-->
        <!--        align="center"-->
        <!--        prop="date"-->
        <!--        label="日期"-->
        <!--      >-->
        <!--      </el-table-column>-->
        <el-table-column align="center" prop="name" :label="$t('user.account')">
        </el-table-column>
        <!--      <el-table-column-->
        <!--        align="center"-->
        <!--        prop="mobile"-->
        <!--        label="电话">-->
        <!--      </el-table-column>-->
        <el-table-column align="center" prop="permit" :label="$t('user.type')">
          <template slot-scope="{ row }">
            <span v-if="row.permit === 1">{{ $t("user.administrator") }}</span>
            <span v-else-if="row.permit === 2">{{ $t("user.Super") }}</span>
            <span v-else>{{ $t("user.Ordinary") }}</span>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          prop="columnProp"
          :label="$t('user.actionBar')"
        >
          <template slot-scope="{ row }">
            <el-button type="primary" size="mini" @click="editUser(row)">{{
              $t("user.edit")
            }}</el-button>
            <el-button
              v-if="row.permit !== 2"
              type="danger"
              size="mini"
              @click="delUser(row)"
              >{{ $t("user.delete") }}</el-button
            >
          </template>
        </el-table-column>
      </el-table>
    </div>

    <!--添加账号的弹窗-->
    <el-dialog
      :title="dialog.addUser.title"
      :visible.sync="dialog.addUser.visible"
      :close-on-click-modal="false"
      :before-close="beforeClose"
      width="30%"
    >
      <el-form
        ref="addUserForm"
        :model="dialog.addUser.form"
        :rules="rules"
        label-width="110px"
      >
        <el-form-item :label="$t('login.username') + '：'" prop="name">
          <el-input
            v-model="dialog.addUser.form.name"
            :disabled="dialog.addUser.form.permit === 2"
          ></el-input>
        </el-form-item>
        <el-form-item :label="$t('login.password') + '：'" prop="password">
          <el-input v-model="dialog.addUser.form.password"></el-input>
        </el-form-item>
        <!--        <el-form-item label="角色：" prop="permit">-->
        <!--          <el-select v-model="dialog.addUser.form.permit" placeholder="请选择角色">-->
        <!--            <el-option label="普通账号" :value="0"></el-option>-->
        <!--&lt;!&ndash;            <el-option label="管理员" :value="1"></el-option>&ndash;&gt;-->
        <!--&lt;!&ndash;            <el-option label="超级管理员" :value="2"></el-option>&ndash;&gt;-->
        <!--          </el-select>-->
        <!--        </el-form-item>-->
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="beforeClose">{{ $t("set.Cancel") }}</el-button>
        <el-button type="primary" @click="dialogAddUserEnter">{{
          $t("set.Enter")
        }}</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import {
  userListApi,
  newUserApi,
  editUserApi,
  delUserApi
} from "@/api/usermanage";
import i18n from "@/lang";

export default {
  name: "index",
  data() {
    const validatePassword = (rule, value, callback) => {
      if (!value) {
        callback(new Error(i18n.t("tip.PasswordThan")));
      } else {
        callback();
      }
    };
    return {
      query: {
        permit: ""
      },
      dialog: {
        addUser: {
          visible: false,
          title: "",
          t: "",
          form: {
            userId: "",
            name: "",
            password: "",
            permit: 0
          }
        }
      },
      tableData: [],
      rules: {
        name: [
          {
            required: true,
            message: i18n.t("tip.PleaseInputUsername"),
            trigger: "change"
          }
        ],
        password: [
          { required: true, validator: validatePassword, trigger: "change" }
        ],
        permit: [
          {
            required: true,
            message: i18n.t("tip.PleasePermissions"),
            trigger: "change"
          }
        ]
      }
    };
  },
  mounted() {
    this.getList();
  },
  methods: {
    // 获取数据
    getList() {
      userListApi({
        cmd: "userList",
        permit: this.query.permit
      })
        .then(res => {
          this.tableData = res.list;
        })
        .catch(err => {
          this.$message.error(i18n.t("tip.FailedAccountList"));
        });
    },
    // 点击添加账号按钮弹出窗体
    addUserDialog() {
      this.dialog.addUser.title = i18n.t("user.add");
      this.dialog.addUser.t = "添加账号";
      this.dialog.addUser.visible = true;
    },
    // 添加账号确认事件
    dialogAddUserEnter() {
      if (this.dialog.addUser.t === "添加账号") {
        this.$refs["addUserForm"].validate(valid => {
          if (valid) {
            newUserApi({
              cmd: "newUser",
              name: this.dialog.addUser.form.name,
              password: this.dialog.addUser.form.password,
              permit: this.dialog.addUser.form.permit
            })
              .then(res => {
                this.dialog.addUser.visible = false;
                this.$message.success(i18n.t("tip.AddSuccessTip"));

                this.dialog.addUser.form.userId = "";
                this.dialog.addUser.form.name = "";
                this.dialog.addUser.form.password = "";
                this.dialog.addUser.form.permit = 0;

                this.getList();
              })
              .catch(err => {
                this.$message.error(i18n.t("tip.AddFailedTip"));
              });
          } else {
            console.log("error submit!!");
            return false;
          }
        });
      } else {
        editUserApi({
          cmd: "editUser",
          userId: this.dialog.addUser.form.userId,
          name: this.dialog.addUser.form.name,
          password: this.dialog.addUser.form.password,
          permit: this.dialog.addUser.form.permit
        })
          .then(res => {
            this.dialog.addUser.visible = false;
            this.$message.success(i18n.t("tip.EditSuccessTip"));

            this.dialog.addUser.form.userId = "";
            this.dialog.addUser.form.name = "";
            this.dialog.addUser.form.password = "";
            this.dialog.addUser.form.permit = 0;

            this.getList();
          })
          .catch(err => {
            this.dialog.addUser.visible = false;
            this.$message.error(i18n.t("tip.EditFailedTip"));
          });
      }
    },
    // 添加/编辑弹窗关闭前的回调
    beforeClose(done) {
      this.$refs["addUserForm"].resetFields();
      console.log(done, "doneeeee");

      this.dialog.addUser.form.userId = "";
      this.dialog.addUser.form.name = "";
      this.dialog.addUser.form.password = "";
      this.dialog.addUser.form.permit = 0;

      if (done.button === 0) {
        this.dialog.addUser.visible = false;
      } else {
        done();
      }
    },
    // 编辑账号
    editUser(row) {
      this.dialog.addUser.title = i18n.t("user.edit");
      this.dialog.addUser.t = "编辑账号";
      this.dialog.addUser.form.userId = row.userId;
      this.dialog.addUser.form.name = row.name;
      this.dialog.addUser.form.password = row.password;
      this.dialog.addUser.form.permit = row.permit;
      this.dialog.addUser.visible = true;
    },
    //删除账号
    delUser(row) {
      this.$confirm(
        i18n.t("tip.deleteAccountTip"),
        i18n.t("home.deleteAllTip"),
        {
          confirmButtonText: i18n.t("home.enter"),
          cancelButtonText: i18n.t("home.cancel"),
          type: "warning"
        }
      )
        .then(() => {
          delUserApi({
            cmd: "delUser",
            userId: row.userId
          })
            .then(res => {
              this.getList();
              this.$message.success(i18n.t("home.successdeleted"));
            })
            .catch(err => {
              this.$message.error(i18n.t("tip.deleteFiled"));
            });
        })
        .catch(() => {
          // this.$message({
          //   type: 'info',
          //   message: '已取消删除'
          // });
        });
    }
  }
};
</script>

<style scoped></style>
