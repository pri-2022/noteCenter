<template>
  <div class="navbar">
    <hamburger
      id="hamburger-container"
      :is-active="sidebar.opened"
      class="hamburger-container"
      @toggleClick="toggleSideBar"
    />

    <!--    <breadcrumb id="breadcrumb-container" class="breadcrumb-container" />-->

    <div class="right-menu">
      <template v-if="device !== 'mobile'">
        <!--        <search id="header-search" class="right-menu-item" />-->

        <error-log class="errLog-container right-menu-item hover-effect" />

        <!--        <screenfull id="screenfull" class="right-menu-item hover-effect" />-->

        <!--        <el-tooltip :content="$t('navbar.size')" effect="dark" placement="bottom">-->
        <!--          <size-select id="size-select" class="right-menu-item hover-effect" />-->
        <!--        </el-tooltip>-->

        <!--        <lang-select class="right-menu-item hover-effect" />-->
      </template>

      <lang-select class="right-menu-item hover-effect" />

      <div class="right-menu-item">
        <router-link to="/">
          <!--        <i class="backHome-container right-menu-item el-icon-s-home"></i>-->
          <svg-icon class-name="homesvgicon" icon-class="home"></svg-icon>
        </router-link>
      </div>

      <!--      <el-dropdown class="avatar-container right-menu-item hover-effect" trigger="click">-->
      <!--        <div class="avatar-wrapper">-->
      <!--          <svg-icon icon-class="user"  class-name='user-avatar' />-->
      <!--&lt;!&ndash;          <img :src="avatar+'?imageView2/1/w/80/h/80'" class="user-avatar">&ndash;&gt;-->
      <!--&lt;!&ndash;          <i class="el-icon-caret-bottom" />&ndash;&gt;-->
      <!--        </div>-->
      <!--        <el-dropdown-menu slot="dropdown">-->
      <!--&lt;!&ndash;          <router-link to="/profile/index">&ndash;&gt;-->
      <!--&lt;!&ndash;            <el-dropdown-item>&ndash;&gt;-->
      <!--&lt;!&ndash;              {{ $t('navbar.profile') }}&ndash;&gt;-->
      <!--&lt;!&ndash;            </el-dropdown-item>&ndash;&gt;-->
      <!--&lt;!&ndash;          </router-link>&ndash;&gt;-->
      <!--          <router-link to="/">-->
      <!--            <el-dropdown-item>-->
      <!--              {{ $t('navbar.dashboard') }}-->
      <!--            </el-dropdown-item>-->
      <!--          </router-link>-->
      <!--&lt;!&ndash;          <a target="_blank" href="https://github.com/PanJiaChen/vue-element-admin/">&ndash;&gt;-->
      <!--&lt;!&ndash;            <el-dropdown-item>&ndash;&gt;-->
      <!--&lt;!&ndash;              {{ $t('navbar.github') }}&ndash;&gt;-->
      <!--&lt;!&ndash;            </el-dropdown-item>&ndash;&gt;-->
      <!--&lt;!&ndash;          </a>&ndash;&gt;-->
      <!--&lt;!&ndash;          <a target="_blank" href="https://panjiachen.github.io/vue-element-admin-site/#/">&ndash;&gt;-->
      <!--&lt;!&ndash;            <el-dropdown-item>Docs</el-dropdown-item>&ndash;&gt;-->
      <!--&lt;!&ndash;          </a>&ndash;&gt;-->
      <!--          <el-dropdown-item divided @click.native="logout">-->
      <!--            <span style="display:block;">{{ $t('navbar.logOut') }}</span>-->
      <!--          </el-dropdown-item>-->
      <!--        </el-dropdown-menu>-->
      <!--      </el-dropdown>-->
    </div>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import Breadcrumb from "@/components/Breadcrumb";
import Hamburger from "@/components/Hamburger";
import ErrorLog from "@/components/ErrorLog";
import Screenfull from "@/components/Screenfull";
import SizeSelect from "@/components/SizeSelect";
import LangSelect from "@/components/LangSelect";
import Search from "@/components/HeaderSearch";

export default {
  components: {
    Breadcrumb,
    Hamburger,
    ErrorLog,
    Screenfull,
    SizeSelect,
    LangSelect,
    Search
  },
  computed: {
    ...mapGetters(["sidebar", "avatar", "device"])
  },
  data() {
    return {
      // 是否为移动端
      isMobile: window.navigator.userAgent.match(
        /(Intel Mac|phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|IEMobile|MQQBrowser|JUC|Fennec|wOSBrowser|BrowserNG|WebOS|Symbian|Windows Phone)/i
      )
    };
  },
  methods: {
    toggleSideBar() {
      this.$store.dispatch("app/toggleSideBar");
    },
    async logout() {
      await this.$store.dispatch("user/logout");
      // this.$router.push(`/login?redirect=${this.$route.fullPath}`)
      this.$router.push(`/login`);
    }
  }
};
</script>

<style lang="scss" scoped>
.homesvgicon {
  font-size: 25px;
  margin-right: 50px;
}
.navbar {
  height: 50px;
  overflow: hidden;
  position: relative;
  /*background: #181818;*/
  background: linear-gradient(to bottom, #1b1b1b, #3f3f3f);
  box-shadow: 0 0 12px 0 rgba(190, 118, 66, 0.24);
  border-bottom: #000000 2px solid;
  border-left: #000000 2px solid;

  .hamburger-container {
    line-height: 46px;
    height: 100%;
    float: left;
    cursor: pointer;
    transition: background 0.3s;
    -webkit-tap-highlight-color: transparent;

    &:hover {
      background: rgba(0, 0, 0, 0.025);
    }
  }

  .breadcrumb-container {
    float: left;
  }

  .errLog-container {
    display: inline-block;
    vertical-align: top;
  }

  .right-menu {
    float: right;
    height: 100%;
    line-height: 50px;

    &:focus {
      outline: none;
    }

    .right-menu-item {
      display: inline-block;
      padding: 0 8px;
      height: 100%;
      font-size: 18px;
      color: #ffffff;
      vertical-align: text-bottom;

      &.hover-effect {
        cursor: pointer;
        transition: background 0.3s;

        &:hover {
          background: rgba(0, 0, 0, 0.025);
        }
      }
    }
    .backHome-container {
      font-size: 20px;
      line-height: 50px;
    }
    .avatar-container {
      margin-right: 30px;

      .avatar-wrapper {
        margin-top: 5px;
        position: relative;

        .user-avatar {
          cursor: pointer;
          width: 20px;
          height: 40px;
          border-radius: 10px;
        }

        .el-icon-caret-bottom {
          cursor: pointer;
          position: absolute;
          right: -20px;
          top: 25px;
          font-size: 12px;
        }
      }
    }
  }
}
</style>
