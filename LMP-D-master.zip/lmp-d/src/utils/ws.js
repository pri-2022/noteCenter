import { MessageBox, Message, Notification } from "element-ui";

var WS = null;
var globalCallback = null;
var offerCallback = null;
var setIntervalID = null;
var agentDataStr = null; // 单次发送数据
var str = ""; // 单次响应数据
var agentList = [
  "(sync,scene)\r\n",
  "(sync,incard)\r\n",
  "(sync,outcard)\r\n",
  "(sync,omap)\r\n"
];
var blobList = []; // 单次响应的blob列表 // 解决接收包解码后中文乱码情况
var offerstr = ""; // 单次响应数据
var flagS = false; // 发送状态
var offerflagS = false; // 发送状态
var flagSCount = 0; // 记录flags为true的次数 当次数大于3的时候把flags设置为false
var closeStatus = false; // 连接失败状态
// const sendDataType = process.env.NODE_ENV === "development";
const sendDataType = false;
const timing = 200;
const limitCont = 20;
import store from "@/store";
import i18n from "@/lang";
function initWebSocket() {
  if (!WS) {
    var ws =
      process.env.NODE_ENV === "development"
        ? "ws://192.168.0.178:8082"
        : `ws://${window.document.location.hostname}:8082`;
    console.log("websocket的连接地址: ", ws);
    // WS = new WebSocket(ws, "chat");
    WS = new WebSocket(ws);
    // WS.binaryType = "arraybuffer";
    WS.onmessage = function(e) {
      websocketonmessage(e);
    };
    WS.onclose = function(e) {
      websocketclose(e);
    };
    WS.onopen = function() {
      websocketOpen();
    };

    // 连接发生错误的回调方法
    WS.onerror = function() {
      store.dispatch("app/setOpenstate", false);
      console.log("WebSocket连接发生错误");
    };
  }
}

// 暂时不用的方法
function sendSock(agentData, callback) {
  globalCallback = callback;
  if (WS.readyState === WS.OPEN) {
    // 若是ws开启状态
    WS.send(agentData);
  } else if (WS.readyState === WS.CONNECTING) {
    // 若是 正在开启状态，则等待1s后重新调用
    setTimeout(function() {
      sendSock(agentData, callback);
    }, timing);
  } else {
    // 若未开启 ，则等待1s后重新调用
    setTimeout(function() {
      sendSock(agentData, callback);
    }, timing);
  }
}
// arraybuffer转字符串
const arrayBufferToString = ev => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsText(ev.data, "utf-8");
    reader.onload = function() {
      resolve(reader.result);
    };
  });
};
// 数据接收
function websocketonmessage(ev) {
  if (sendDataType) {
    deData(ev.data);
    offerDeData(ev.data);
  } else {
    // console.log(ev.data);
    const reader = new FileReader();
    reader.readAsText(ev.data, "utf-8");
    reader.onload = function() {
      const data = reader.result;
      if (data.indexOf("ip_info") < 0) {
        blobList.push(ev.data);
      }
      deData(data);
      offerDeData(data);
    };
  }
}
// 主动监听接收
function onOffer(callback) {
  offerCallback = callback;
}
// 主动监听接收的数据处理函数
function offerDeData(data) {
  if (data.indexOf("ip_info") < 0) {
    // flagSCount = 0;
    offerstr += data;
    if (offerstr.indexOf("finish") < 0) {
      if (
        // offerstr.indexOf(JSON.stringify(agentDataStr)) !== -1
        // offerstr.indexOf(JSON.stringify(agentDataStr)) !== -1 ||
        offerstr.indexOf(`\"ok\"`) !== -1
      ) {
        offerflagS = false;
        if (offerCallback) {
          const dataArray = offerstr
            .split("\r\n")
            .map(item => {
              if (item) {
                // console.log("json字符串：", item);
                // return JSON.parse(item);
                return item;
              }
            })
            .filter(Boolean);
          offerCallback(dataArray);
        }
        offerstr = "";
      } else {
        if (offerstr.indexOf(`\"err\"`) !== -1) {
          offerflagS = false;
        }
        if (offerstr === '{\n\t"msg":\t"err"\n}\r\n') {
          offerflagS = false;
          offerCallback(offerstr);
          offerstr = "";
        }
      }
    } else {
      offerflagS = false;
      if (offerCallback) {
        offerCallback(offerstr);
      }
    }
  }
}
// 处理接收的数据
function deData(data) {
  if (data.indexOf("ip_info") < 0) {
    flagSCount = 0;
    str += data;
    if (str.indexOf("finish") < 0) {
      // console.log("这是json数据");
      // console.log(str);
      // if (str.indexOf(`\"ok\"`) > 0) {
      // console.log("agentDataStr", agentDataStr);
      // console.log("JSON.stringify(agentDataStr)", JSON.stringify(agentDataStr));
      if (
        str.indexOf(JSON.stringify(agentDataStr)) !== -1
        // str.indexOf(JSON.stringify(agentDataStr)) !== -1 ||
        // str.indexOf(`\"ok\"`) !== -1
      ) {
        flagS = false;
        if (globalCallback) {
          const dataArray = str
            .split("\r\n")
            .map(item => {
              if (item) {
                // console.log("json字符串：", item);
                return JSON.parse(item);
              }
            })
            .filter(Boolean);
          if (agentList.includes(agentDataStr)) {
            const b = new Blob([...blobList], { type: "text/plain" });
            const r = new FileReader();
            r.readAsText(b, "utf-8");
            r.onload = function() {
              // console.log(r.result.split("\r\n"));
              const dataArray = r.result
                .split("\r\n")
                .map(item => {
                  if (item) {
                    // console.log("json字符串：", item);
                    return JSON.parse(item);
                  }
                })
                .filter(Boolean);
              globalCallback(dataArray);
            };
          } else {
            globalCallback(dataArray);
          }
        }
        str = "";
        blobList = [];
      } else {
        if (str.indexOf(`\"err\"`) !== -1) {
          flagS = false;
        }
        if (str === '{\n\t"msg":\t"err"\n}\r\n') {
          flagS = false;
          globalCallback(str);
          str = "";
          blobList = [];
        }
        console.log("err");
      }
    } else {
      flagS = false;
      if (globalCallback) {
        globalCallback(str);
        str = "";
      }
      if (offerCallback) {
        offerCallback(str);
        str = "";
      }
      console.log("这是裸数据");
    }
  } else {
    let { ip_info } = JSON.parse(data.split("\r\n")[0]);
    // console.log("ip_info:=>", ip_info);
    // const dataArray = data
    //   .split("\r\n")
    //   .map(item => {
    //     if (item) {
    //       // console.log("json字符串：", JSON.parse(item));
    //       try {
    //         let obj = JSON.parse(item);
    //         return obj;
    //       } catch (e) {
    //         console.log(e);
    //       }
    //     }
    //   })
    //   .filter(Boolean);
    // const ipInfo = dataArray.reduce((arr, item) => {
    //   if (item.ip_info) {
    //     arr.push(item.ip_info);
    //   }
    //   return arr;
    // }, []);
    localStorage.setItem("ipInfoData", JSON.stringify(ip_info));
  }
}

// 字符串转arraybuffer
export const stringToArrayBuffer = s => {
  return new Promise((resolve, reject) => {
    const b = new Blob([s], { type: "text/plain" });
    const r = new FileReader();
    r.readAsArrayBuffer(b);
    r.onload = function() {
      resolve(r.result);
    };
  });
};

// 数据发送
function websocketsend(agentData, callback, isArrayBuffer) {
  console.log("进入websocketsend函数");
  if (WS.readyState === WS.OPEN) {
    // 若是ws开启状态
    if (!flagS) {
      // 若是没有处于接收消息状态的ws
      // clearInterval(setIntervalID); // 先停止定时器
      flagS = true;
      globalCallback = callback;
      agentDataStr = agentData;
      if (sendDataType && !isArrayBuffer) {
        console.log("发送的文本数据");
        WS.send(agentData);
      } else {
        console.log("发送的二进制数据");
        stringToArrayBuffer(agentData).then(res => {
          WS.send(res);
        });
      }
    } else {
      const s3 = setTimeout(function() {
        if (flagSCount < limitCont) {
          flagSCount++;
        } else {
          console.log(`flagSCount大于${limitCont - 1}次`);
          flagS = false;
        }

        console.log(
          "进入了WS.readyState === WS.OPEN控制流，flagS为true,这是有数据正在发送"
        );
        websocketsend(agentData, callback, isArrayBuffer);
        clearTimeout(s3);
      }, timing);
    }
  } else if (WS.readyState === WS.CONNECTING) {
    // 若是 正在开启状态，则等待1s后重新调用
    const s1 = setTimeout(function() {
      websocketsend(agentData, callback, isArrayBuffer);
      clearTimeout(s1);
    }, timing);
  } else {
    // 若未开启 ，则等待1s后重新调用
    const s2 = setTimeout(function() {
      websocketsend(agentData, callback, isArrayBuffer);
      clearTimeout(s2);
    }, timing);
  }
}

// 关闭
function websocketclose(e) {
  WS.close();
  WSNULL();
  clearInterval(setIntervalID);
  initWebSocket();
  // alert('设备已断开连接，请稍后重试')
  console.log(e);
  console.log("connection closed (" + e.code + ")");
  console.log("connection closed (" + e.reason + ")");
  // Message.error("设备已断开");
  if (!closeStatus) {
    Notification({
      title: i18n.t("set.error"),
      type: "error",
      message: i18n.t("set.DeviceDisconnected"),
      duration: 3500,
      onClose: () => {
        // window.location.reload()
      }
    });
  }

  closeStatus = true;
}

// 创建 websocket 连接
function websocketOpen(e) {
  store.dispatch("app/setOpenstate", true);
  console.log("连接成功");
  closeStatus = false;
  Notification({
    title: i18n.t("home.deleteAllTip"),
    type: "success",
    message: i18n.t("set.DeviceConnected"),
    duration: 3500
  });
  // setIntervalID = setInterval(function() {
  //   if (sendDataType) {
  //     WS.send("(ip)\r\n");
  //   } else {
  //     stringToArrayBuffer("(ip)\r\n").then(res => {
  //       WS.send(res);
  //     });
  //   }
  // }, 5000);
}
function WSNULL() {
  WS = null;
}

// 将方法暴露出去
export {
  initWebSocket,
  sendSock,
  websocketsend,
  WS,
  WSNULL,
  onOffer,
  globalCallback
};
