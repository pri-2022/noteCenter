let transferIndex = 0; //传输分包序号
const getFileArr = e => {
  let file = e.target.files[0],
    filename = file.name,
    fileSize = file.size,
    transferSize = 8096, //分包大小
    fileArr = [];

  //重置包指针
  transferIndex = 0;

  let reader = new FileReader();

  reader.readAsArrayBuffer(file);

  reader.onload = function(e) {
    let r = this.result,
      len = r.byteLength;

    for (let i = 0; i < len; i += transferSize) {
      let length = i + transferSize <= len ? transferSize : len % transferSize;

      fileArr.push({
        start: i,
        len: length,
        data: new Uint8Array(r.slice(i, i + length))
      });
    }
  };
  console.log("fileArr", fileArr);
  return {
    fileArr,
    fileSize,
    filename
  };
};

// 开始传输
const doTransfer = fileObj => {
  setTimeout(() => {
    // console.log("fileObj", fileObj, fileObj.fileArr.length)
    // console.log("transferIndex", transferIndex)
    if (fileObj.fileArr.length == 0) {
      Vue.prototype.$message.success(i18n.t("lan.UploadFailed"));
    }
    if (transferIndex >= fileObj.fileArr.length) {
      let finishCmd = ipcCmd.finishTransferCmd(fileObj.fileSize);
      // 发送文件传输结束命令
      store.dispatch("crtlWorkerSend", finishCmd);
      Vue.prototype.$message.success(i18n.t("lan.postSuccess"));
      transferIndex = 0; //传输分包序号
      // fileArr = [] //二进制文件分包数组
      store.commit("updataButtonLoading", false);
      store.commit("upDataPostfileLoading", false);
      store.state.CrtlV2.transferReady = false;
      return false;
    }
    let i = transferIndex,
      pack = fileObj.fileArr[i].data,
      body = {
        //分包信息
        POS: {
          //起始位置
          StartPos: fileObj.fileArr[i].start,
          //数据长度
          DataLen: fileObj.fileArr[i].len
        }
      };

    //数据传输命令
    let upgradeCmd = {
      type: "upgrade",
      cmd: strTool.strToUint8Array(
        JSON.stringify(
          ipcCmd.commonPacker("MEDIA_DATA_MESSAGE", 1, "0", body)
        ) + "\0"
      ),
      package: pack
    };

    store.dispatch("crtlWorkerSend", upgradeCmd);
    //还有数据待发送
    if (transferIndex < fileObj.fileArr.length) {
      //移动到下一包
      transferIndex++;
      //间隔30
      setTimeout(() => {
        //递归调用
        doTransfer(fileObj);
      }, 15);
    }
  }, 2);

  // 发送完成
};
