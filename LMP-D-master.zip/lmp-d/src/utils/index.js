/**
 * Created by PanJiaChen on 16/11/18.
 */

/*
 * sw切换指令
 * 例如：'(sw,9,5,3,4)' '(sw,1,close)'  '(sw,1,all)'
 * */
import i18n from "@/lang";

export function sw(str) {
  const aar = str.replace(/\(|\)\s*/g, "").split(",");
  const bb = {};
  // 输入卡X 切换到 对应的输出卡
  if (aar.includes("sw")) {
    // 如果是 sw指令
    bb["input"] = aar[1];
    bb["type"] = "input_switch_output";
    bb["output"] = aar.slice(2);
  }
  //  关掉所有输入卡X
  if (aar.includes("sw") && aar.includes("c")) {
    bb["input"] = aar[1];
    bb["type"] = "c";
  }
  // 所有已经插入的输出卡切换到输入卡X
  if (aar.includes("sw") && aar.includes("a")) {
    bb["input"] = aar[1];
    bb["type"] = "a";
  }
  // 关闭输出卡指令 （sw,0,1,2）
  if (aar.includes("sw") && aar.includes("0-a")) {
    bb["type"] = "close_output";
    bb["output"] = aar.slice(2);
  }
  if (aar.includes("sw") && aar.includes("0")) {
    bb["type"] = "close_output";
    bb["output"] = aar.slice(2);
  }
  // 清空屏幕
  if (aar.includes("sw") && aar.includes("0") && aar.includes("a")) {
    bb["type"] = "close_all";
  }
  return bb;
}
/*
 * in_audio_choose 输入卡音频切换解析指令
 * */
export function in_audio_choose(str) {
  const aar = str.replace(/\(|\)\s*/g, "").split(",");
  const bb = {};
  if (aar.includes("in") && aar.includes("audio") && aar.includes("choose")) {
    // 如果是 sw指令
    bb["in"] = aar[3];
    bb["choose"] = aar[4];
  }
  return bb;
}
/*
(edid,choose,4,2)
(edid,learn,4,15)   // 15 要是双通道的 得区分端口
* edid_choose 输入卡选择EDID解析指令
* */
export function edid_choose(str) {
  const aar = str.replace(/\(|\)\s*/g, "").split(",");
  const bb = {};
  if (aar.includes("edid") && aar.includes("choose")) {
    // 解析前六个
    bb["in"] = aar[2];
    bb["type"] = "choose";
    bb["choose"] = aar[3];
  }
  if (aar.includes("edid") && aar.includes("learn")) {
    // 解析后六个
    bb["in"] = aar[2];
    bb["type"] = "learn";
    bb["choose"] = aar[3];
  }
  return bb;
}
/*
Cmd: "rename_incard"
data: "(rename,incard,4,HDMI04)
↵"
msg: "ok"
同步输入卡命名
* */
export function rename_incard(str) {
  const aar = str.replace(/\(|\)\s*/g, "").split(",");
  const bb = {};
  if (aar.includes("rename") && aar.includes("incard")) {
    bb["in"] = aar[2];
    bb["name"] = aar[3];
  }
  return bb;
}
/*
 * 同步输出卡重命名
 * */
export function rename_outcard(str) {
  const aar = str.replace(/\(|\)\s*/g, "").split(",");
  const bb = {};
  if (aar.includes("rename") && aar.includes("outcard")) {
    bb["in"] = aar[2];
    bb["name"] = aar[3];
  }
  return bb;
}
/*首页场景保存同步
Cmd: "scene_save"
data: "(scene,save,1,3,场景3)
↵"
*
* */
export function scene_save(str) {
  const aar = str.replace(/\(|\)\s*/g, "").split(",");
  const bb = {};
  if (aar.includes("scene") && aar.includes("save")) {
    bb["group"] = aar[2];
    bb["sceneId"] = aar[3];
    bb["sceneName"] = aar[4];
  }
  return bb;
}
/*
* 首页场景删除同步
* Cmd: "scene_del"
data: "(scene,del,5) //删除单个场景
* data: "(scene,del,1,0) // 清空组1的所有场景
↵"
↵"
*
* */
export function scene_del(str) {
  const aar = str.replace(/\(|\)\s*/g, "").split(",");
  const bb = {};
  if (aar.includes("scene") && aar.includes("del")) {
    bb["sceneId"] = aar[2];
    bb["type"] = "clearOne";
  }
  if (aar.includes("scene") && aar.includes("del") && aar.includes("0")) {
    bb["group"] = aar[2];
    bb["type"] = "clearAll";
  }
  return bb;
}
/*
* Cmd: "rename_scene"
data: "(rename,scene,1,自定义1)
↵"
* 场景重命名
*
* */
export function rename_scene(str) {
  const aar = str.replace(/\(|\)\s*/g, "").split(",");
  const bb = {};
  if (aar.includes("rename") && aar.includes("scene")) {
    bb["sceneId"] = aar[2];
    bb["sceneName"] = aar[3];
  }
  return bb;
}
/*
(scene,rotate,group,en)
* Cmd: "scene_rotate"
data: "(scene,rotate,1,0)"
msg: "ok"
* 场景开关
* */
export function scene_rotate(str) {
  const aar = str.replace(/\(|\)\s*/g, "").split(",");
  const bb = {};
  if (aar.includes("scene") && aar.includes("rotate")) {
    bb["groupId"] = aar[2];
    bb["switchState"] = aar[3];
  }
  return bb;
}
/*
* {msg: "ok", data: "(setting,timing,1,11,1920x1080@50,1920,2640,148,528,44,1,1080,1125,36,4,5,1,50,50,297)
* (setting,timing,)
↵", Cmd: "setting_timing"}
* 输出卡分辨率指令解析
* */
export function setting_timing(str) {
  const aar = str.replace(/\(|\)\s*/g, "").split(",");
  console.log(aar, "aar");
  console.log(aar[aar.length], "aar[aar.length]");
  console.log(aar[aar.length - 1], "aar[aar.length-1]M分辨率ID");
  console.log(aar[aar.length - 2], "aar[aar.length-2]D类型");
  const bb = {};
  if (aar.includes("setting") && aar.includes("timing")) {
    bb["out"] = aar[3];
    bb["name"] = aar[4];
    bb["M"] = aar[aar.length - 1];
    bb["D"] = aar[aar.length - 2];
  }
  return bb;
}
/*
* Cmd: "out_brightness"
data: "(out,brightness,14,215)
↵"
msg: "ok"
* 输出卡亮度同步指令解析
* */
export function out_brightness(str) {
  const aar = str.replace(/\(|\)\s*/g, "").split(",");
  const bb = {};
  if (aar.includes("out") && aar.includes("brightness")) {
    bb["out"] = aar[2];
    bb["brightbess"] = aar[3];
  }
  return bb;
}
/*
* out_res_auto
* 分辨率模式切换同步
*Cmd: "out_res_auto"
data: "(out,res_auto,8,0)
↵"
* */
export function out_res_auto(str) {
  const aar = str.replace(/\(|\)\s*/g, "").split(",");
  const bb = {};
  if (aar.includes("out") && aar.includes("res_auto")) {
    bb["out"] = aar[2];
    bb["sta"] = aar[3];
  }
  return bb;
}
/*
* {msg: "ok", data: "(out,mode,13,2)
↵", Cmd: "out_mode"}
* 信号格式同步指令解析
* */
export function out_mode(str) {
  const aar = str.replace(/\(|\)\s*/g, "").split(",");
  const bb = {};
  if (aar.includes("out") && aar.includes("mode")) {
    bb["out"] = aar[2];
    bb["mode"] = aar[3];
  }
  return bb;
}

/*
* {msg: "ok", data: "(out,freed,13,1)
↵", Cmd: "out_freed"}
* 输出卡画面选择切换指令同步
* */
export function out_freed(str) {
  const aar = str.replace(/\(|\)\s*/g, "").split(",");
  const bb = {};
  if (aar.includes("out") && aar.includes("freed")) {
    bb["out"] = aar[2];
    bb["mode"] = aar[3];
  }
  return bb;
}

/*
* {msg: "ok", data: "(out,audio,analog,13,1)
↵", Cmd: "out_audio_analog"}
* 输出卡模拟音频切换指令同步
* */
export function out_audio_analog(str) {
  const aar = str.replace(/\(|\)\s*/g, "").split(",");
  const bb = {};
  if (aar.includes("out") && aar.includes("audio") && aar.includes("analog")) {
    bb["out"] = aar[3];
    bb["mode"] = aar[4];
  }
  return bb;
}

/*
* {msg: "ok", data: "(out,audio,embedded,13,1)
↵", Cmd: "out_audio_embedded"}
* 输出卡内嵌音频切换指令同步
* */
export function out_audio_embedded(str) {
  const aar = str.replace(/\(|\)\s*/g, "").split(",");
  const bb = {};
  if (
    aar.includes("out") &&
    aar.includes("audio") &&
    aar.includes("embedded")
  ) {
    bb["out"] = aar[3];
    bb["mode"] = aar[4];
  }
  return bb;
}
/*
* Cmd: "in_subtitle"
data: "(in,subtitle,3,0)"
msg: "ok"
* 输入卡字幕开关
* */
export function in_subtitle(str) {
  const aar = str.replace(/\(|\)\s*/g, "").split(",");
  const bb = {};
  if (aar.includes("in") && aar.includes("subtitle")) {
    bb["in"] = aar[2];
    bb["mode"] = aar[3];
  }
  return bb;
}
/*
* Cmd: "edid_init"
data: "(edid,init,5)"
* 默认EDID同步
* */
export function edid_init(str) {
  const aar = str.replace(/\(|\)\s*/g, "").split(",");
  const bb = {};
  if (aar.includes("edid") && aar.includes("init")) {
    bb["in"] = aar[2];
  }
  return bb;
}
/*
*Cmd: "fan_setting"
data: "(fan,2)
↵"
msg: "ok"
* */
export function fan_setting(str) {
  const aar = str.replace(/\(|\)\s*/g, "").split(",");
  const bb = {};
  if (aar.includes("fan")) {
    bb["step"] = aar[1];
  }
  return bb;
}
/*
* Cmd: "CLEAR_SUB"
data: "(CLEAR,3)"
msg: "ok"
* 单卡恢复默认同步
* */
export function CLEAR_SUB(str) {
  const aar = str.replace(/\(|\)\s*/g, "").split(",");
  const bb = {};
  if (aar.includes("CLEAR")) {
    bb["in"] = aar[1];
  }
  return bb;
}
/*
* Cmd: "set_insubcard"
data: "(in,color,choose,6,2)"
msg: "ok"
* */
export function set_insubcard(str) {
  const aar = str.replace(/\(|\)\s*/g, "").split(",");
  const bb = {};
  if (aar.includes("in") && aar.includes("color") && aar.includes("choose")) {
    bb["in"] = aar[3];
    bb["step"] = aar[4];
  }
  return bb;
}
/*
* Cmd: "set_poe"
data: "(poe,9,0)"
msg: "ok"
* */
export function set_poe(str) {
  const aar = str.replace(/\(|\)\s*/g, "").split(",");
  const bb = {};
  if (aar.includes("poe")) {
    bb["in"] = aar[1];
    bb["poe"] = aar[2];
  }
  return bb;
}
/*
 * (in,sub,disp,3,1)
 * cmd: in_sub_disp
 * 输入卡字幕开关
 * */
export function in_sub_disp(str) {
  const aar = str.replace(/\(|\)\s*/g, "").split(",");
  const bb = {};
  if (aar.includes("in") && aar.includes("sub") && aar.includes("disp")) {
    bb["in"] = aar[3];
    bb["mode"] = aar[4];
  }
  return bb;
}
/*
 * 获取dom的css属性
 *
 * */
export function getStyle(obj, attr) {
  return obj.currentStyle !== undefined
    ? obj.currentStyle[attr]
    : getComputedStyle(obj)[attr];
}
/*
 * 调用win10通知
 *
 * */
export function Notification(str) {
  if (undefined !== window.Notification) {
    window.Notification.requestPermission().then(function(result) {
      if (result === "denied") {
        console.log("Permission wasn't granted. Allow a retry.");
        return;
      }
      if (result === "default") {
        console.log("The permission request was dismissed.");
        return;
      }
      // 在获得许可的情况下做某事。
      const notify = new window.Notification(i18n.t("login.title"), {
        // icon: './img/logo.png',
        body: str
      });

      // 桌面消息显示时
      notify.onshow = () => {
        // const audio = new Audio('./mp3/test2.mp3')
        // audio.play()
      };

      // 点击时桌面消息时触发
      notify.onclick = () => {
        // 跳转到当前通知的tab,如果浏览器最小化，会将浏览器显示出来
        window.focus();
      };
    });
  }
}
/*
 * 转rgba为数组
 * */
export function rgbOrRgbaToArray(colorString) {
  var rgbOrgbaJudgeTag = /^([^\(]+)\([^\)]+\)$/i;

  var aaa = rgbOrgbaJudgeTag.exec(colorString);

  if (aaa !== null) {
    if (aaa[1].trim() === "rgb") {
      var str = colorString;

      var strTag = /^rgb[a]*\s*\(([^,]+),([^,]+),([^\)]+)\)$/i;

      var result = strTag.exec(str);

      if (
        result === null ||
        result[1].trim() === "" ||
        result[2].trim() === "" ||
        result[3].trim() === ""
      ) {
        return null;
      }

      var returnArray = [];

      for (var i = 1; i <= result.length - 1; i++) {
        returnArray[i - 1] = Number(result[i].trim());
      }

      return returnArray;
    } else if (aaa[1].trim() === "rgba") {
      var str = colorString;

      var strTag = /^rgb[a]*\s*\(([^,]+),([^,]+),([^,]+),([^\)]+)\)$/i;

      var result = strTag.exec(str);

      if (
        result === null ||
        result[1].trim() === "" ||
        result[2].trim() === "" ||
        result[3].trim() === ""
      ) {
        return null;
      }

      var returnArray = [];

      for (var i = 1; i <= result.length - 1; i++) {
        returnArray[i - 1] = Number(result[i].trim());
      }

      return returnArray;
    } else {
      return null;
    }
  } else {
    return null;
  }
}

/**
 * Parse the time to string
 * @param {(Object|string|number)} time
 * @param {string} cFormat
 * @returns {string | null}
 */
export function parseTime(time, cFormat) {
  if (arguments.length === 0) {
    return null;
  }
  const format = cFormat || "{y}-{m}-{d} {h}:{i}:{s}";
  let date;
  if (typeof time === "object") {
    date = time;
  } else {
    if (typeof time === "string" && /^[0-9]+$/.test(time)) {
      time = parseInt(time);
    }
    if (typeof time === "number" && time.toString().length === 10) {
      time = time * 1000;
    }
    date = new Date(time);
  }
  const formatObj = {
    y: date.getFullYear(),
    m: date.getMonth() + 1,
    d: date.getDate(),
    h: date.getHours(),
    i: date.getMinutes(),
    s: date.getSeconds(),
    a: date.getDay()
  };
  const time_str = format.replace(/{([ymdhisa])+}/g, (result, key) => {
    const value = formatObj[key];
    // Note: getDay() returns 0 on Sunday
    if (key === "a") {
      return ["日", "一", "二", "三", "四", "五", "六"][value];
    }
    return value.toString().padStart(2, "0");
  });
  return time_str;
}

/**
 * @param {number} time
 * @param {string} option
 * @returns {string}
 */
export function formatTime(time, option) {
  if (("" + time).length === 10) {
    time = parseInt(time) * 1000;
  } else {
    time = +time;
  }
  const d = new Date(time);
  const now = Date.now();

  const diff = (now - d) / 1000;

  if (diff < 30) {
    return "刚刚";
  } else if (diff < 3600) {
    // less 1 hour
    return Math.ceil(diff / 60) + "分钟前";
  } else if (diff < 3600 * 24) {
    return Math.ceil(diff / 3600) + "小时前";
  } else if (diff < 3600 * 24 * 2) {
    return "1天前";
  }
  if (option) {
    return parseTime(time, option);
  } else {
    return (
      d.getMonth() +
      1 +
      "月" +
      d.getDate() +
      "日" +
      d.getHours() +
      "时" +
      d.getMinutes() +
      "分"
    );
  }
}

/**
 * @param {string} url
 * @returns {Object}
 */
export function getQueryObject(url) {
  url = url == null ? window.location.href : url;
  const search = url.substring(url.lastIndexOf("?") + 1);
  const obj = {};
  const reg = /([^?&=]+)=([^?&=]*)/g;
  search.replace(reg, (rs, $1, $2) => {
    const name = decodeURIComponent($1);
    let val = decodeURIComponent($2);
    val = String(val);
    obj[name] = val;
    return rs;
  });
  return obj;
}

/**
 * @param {string} input value
 * @returns {number} output value
 */
export function byteLength(str) {
  // returns the byte length of an utf8 string
  let s = str.length;
  for (var i = str.length - 1; i >= 0; i--) {
    const code = str.charCodeAt(i);
    if (code > 0x7f && code <= 0x7ff) s++;
    else if (code > 0x7ff && code <= 0xffff) s += 2;
    if (code >= 0xdc00 && code <= 0xdfff) i--;
  }
  return s;
}

/**
 * @param {Array} actual
 * @returns {Array}
 */
export function cleanArray(actual) {
  const newArray = [];
  for (let i = 0; i < actual.length; i++) {
    if (actual[i]) {
      newArray.push(actual[i]);
    }
  }
  return newArray;
}

/**
 * @param {Object} json
 * @returns {Array}
 */
export function param(json) {
  if (!json) return "";
  return cleanArray(
    Object.keys(json).map(key => {
      if (json[key] === undefined) return "";
      return encodeURIComponent(key) + "=" + encodeURIComponent(json[key]);
    })
  ).join("&");
}

/**
 * @param {string} url
 * @returns {Object}
 */
export function param2Obj(url) {
  const search = url.split("?")[1];
  if (!search) {
    return {};
  }
  return JSON.parse(
    '{"' +
      decodeURIComponent(search)
        .replace(/"/g, '\\"')
        .replace(/&/g, '","')
        .replace(/=/g, '":"')
        .replace(/\+/g, " ") +
      '"}'
  );
}

/**
 * @param {string} val
 * @returns {string}
 */
export function html2Text(val) {
  const div = document.createElement("div");
  div.innerHTML = val;
  return div.textContent || div.innerText;
}

/**
 * Merges two objects, giving the last one precedence
 * @param {Object} target
 * @param {(Object|Array)} source
 * @returns {Object}
 */
export function objectMerge(target, source) {
  if (typeof target !== "object") {
    target = {};
  }
  if (Array.isArray(source)) {
    return source.slice();
  }
  Object.keys(source).forEach(property => {
    const sourceProperty = source[property];
    if (typeof sourceProperty === "object") {
      target[property] = objectMerge(target[property], sourceProperty);
    } else {
      target[property] = sourceProperty;
    }
  });
  return target;
}

/**
 * @param {HTMLElement} element
 * @param {string} className
 */
export function toggleClass(element, className) {
  if (!element || !className) {
    return;
  }
  let classString = element.className;
  const nameIndex = classString.indexOf(className);
  if (nameIndex === -1) {
    classString += "" + className;
  } else {
    classString =
      classString.substr(0, nameIndex) +
      classString.substr(nameIndex + className.length);
  }
  element.className = classString;
}

/**
 * @param {string} type
 * @returns {Date}
 */
export function getTime(type) {
  if (type === "start") {
    return new Date().getTime() - 3600 * 1000 * 24 * 90;
  } else {
    return new Date(new Date().toDateString());
  }
}

/**
 * @param {Function} func
 * @param {number} wait
 * @param {boolean} immediate
 * @return {*}
 */
export function debounce(func, wait, immediate) {
  let timeout, args, context, timestamp, result;

  const later = function() {
    // 据上一次触发时间间隔
    const last = +new Date() - timestamp;

    // 上次被包装函数被调用时间间隔 last 小于设定时间间隔 wait
    if (last < wait && last > 0) {
      timeout = setTimeout(later, wait - last);
    } else {
      timeout = null;
      // 如果设定为immediate===true，因为开始边界已经调用过了此处无需调用
      if (!immediate) {
        result = func.apply(context, args);
        if (!timeout) context = args = null;
      }
    }
  };

  return function(...args) {
    context = this;
    timestamp = +new Date();
    const callNow = immediate && !timeout;
    // 如果延时不存在，重新设定延时
    if (!timeout) timeout = setTimeout(later, wait);
    if (callNow) {
      result = func.apply(context, args);
      context = args = null;
    }

    return result;
  };
}

/**
 * 这只是deep copy的一个简单版本
 * 有很多边盒缺陷
 * 如果你想用一个完美的深拷贝， use lodash's _.cloneDeep
 * @param {Object} source
 * @returns {Object}
 */
export function deepClone(source) {
  if (!source && typeof source !== "object") {
    throw new Error("error arguments", "deepClone");
  }
  const targetObj = source.constructor === Array ? [] : {};
  Object.keys(source).forEach(keys => {
    if (source[keys] && typeof source[keys] === "object") {
      targetObj[keys] = deepClone(source[keys]);
    } else {
      targetObj[keys] = source[keys];
    }
  });
  return targetObj;
}

/**
 * @param {Array} arr
 * @returns {Array}
 */
export function uniqueArr(arr) {
  return Array.from(new Set(arr));
}

/**
 * @returns {string}
 */
export function createUniqueString() {
  const timestamp = +new Date() + "";
  const randomNum = parseInt((1 + Math.random()) * 65536) + "";
  return (+(randomNum + timestamp)).toString(32);
}

/**
 * Check if an element has a class
 * @param {HTMLElement} elm
 * @param {string} cls
 * @returns {boolean}
 */
export function hasClass(ele, cls) {
  return !!ele.className.match(new RegExp("(\\s|^)" + cls + "(\\s|$)"));
}

/**
 * Add class to element
 * @param {HTMLElement} elm
 * @param {string} cls
 */
export function addClass(ele, cls) {
  if (!hasClass(ele, cls)) ele.className += " " + cls;
}

/**
 * Remove class from element
 * @param {HTMLElement} elm
 * @param {string} cls
 */
export function removeClass(ele, cls) {
  if (hasClass(ele, cls)) {
    const reg = new RegExp("(\\s|^)" + cls + "(\\s|$)");
    ele.className = ele.className.replace(reg, " ");
  }
}
