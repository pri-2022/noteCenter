var WS = null;
var globalCallback = null;
var setIntervalID = null;
var str = ""; // 单次响应数据
var flagS = false; // 发送状态
import store from "@/store";
// 初始化weosocket
function initWebSocket() {
  if (!WS) {
    var ws =
      process.env.NODE_ENV === "development"
        ? "ws://127.0.0.1"
        : `ws://${window.document.location.hostname}:8082`;
    // console.log('websocket的连接地址: ',ws)
    // WS = new WebSocket(ws, "chat");
    WS = new WebSocket(ws);
    // WS.binaryType = "arraybuffer";
    WS.onmessage = function(e) {
      websocketonmessage(e);
    };
    WS.onclose = function(e) {
      websocketclose(e);
    };
    WS.onopen = function() {
      websocketOpen();
    };

    // 连接发生错误的回调方法
    WS.onerror = function() {
      store.dispatch("app/setOpenstate", false);
      console.log("WebSocket连接发生错误");
    };
  }
}

// 实际调用的方法
function sendSock(agentData, callback) {
  globalCallback = callback;
  if (WS.readyState === WS.OPEN) {
    // 若是ws开启状态
    WS.send(agentData);
  } else if (WS.readyState === WS.CONNECTING) {
    // 若是 正在开启状态，则等待1s后重新调用
    setTimeout(function() {
      sendSock(agentData, callback);
    }, 1000);
  } else {
    // 若未开启 ，则等待1s后重新调用
    setTimeout(function() {
      sendSock(agentData, callback);
    }, 1000);
  }
}

// 数据接收
function websocketonmessage(ev) {
  const _this = this;
  // const reader = new FileReader(); // 创建读取文件对象
  // reader.readAsText(e.data, "utf-8"); // 设置读取的数据以及返回的数据类型为utf-8
  // reader.onload = function() {
  //   const data = JSON.parse(reader.result);
  //   globalCallback(data);
  // };
  if (ev.data.indexOf("ip_info") < 0) {
    str += ev.data;
  }
}

// 数据发送
function websocketsend(agentData, callback, delay = 2500) {
  console.log("delay:string:", delay);
  console.log("delay:parse:", parseInt(delay));
  return new Promise((resolve, reject) => {
    if (WS.readyState === WS.OPEN) {
      // 若是ws开启状态
      if (!flagS) {
        // 若是没有处于接收消息状态的ws
        flagS = true;
        globalCallback = callback;
        WS.send(agentData);
      } else {
        const s3 = setTimeout(function() {
          websocketsend(agentData, callback, delay);
          clearTimeout(s3);
        }, delay * 2);
      }
    } else if (WS.readyState === WS.CONNECTING) {
      // 若是 正在开启状态，则等待1s后重新调用
      const s1 = setTimeout(function() {
        websocketsend(agentData, callback, delay);
        clearTimeout(s1);
      }, 1000);
    } else {
      // 若未开启 ，则等待1s后重新调用
      const s2 = setTimeout(function() {
        websocketsend(agentData, callback, delay);
        clearTimeout(s2);
      }, 1000);
    }

    const s = setTimeout(function() {
      if (str) {
        if (str.indexOf("finish") < 0) {
          console.log("这是json数据");
          // console.log(str);
          if (str.indexOf(`\"ok\"`) > 0) {
            resolve(str);
            // console.log("globalCallback:", globalCallback);
            if (globalCallback) {
              const dataArray = str
                .split("\r\n")
                .map(item => {
                  if (item) {
                    return JSON.parse(item);
                  }
                })
                .filter(Boolean);
              globalCallback(dataArray);
            }
          } else {
            console.log("err");
            reject("err");
          }
        } else {
          console.log("这是裸数据");
          resolve(str);
        }
      }

      str = "";
      flagS = false;
      clearTimeout(s);
    }, delay);
  });
}

// 关闭
function websocketclose(e) {
  WS.close();
  clearInterval(setIntervalID);
  initWebSocket();
  // alert('设备已断开连接，请稍后重试')
  console.log("connection closed (" + e.code + ")");
}

// 创建 websocket 连接
function websocketOpen(e) {
  store.dispatch("app/setOpenstate", true);
  console.log("连接成功");
  setIntervalID = setInterval(function() {
    WS.send("(ip)\r\n");
  }, 5000);
}

// 将方法暴露出去
export { initWebSocket, sendSock, websocketsend, WS };
