<template>
  <div id="app">
    <router-view />
    <vue-element-loading
      :active="loading.singe"
      is-full-screen
      spinner="bar-fade-scale"
      background-color="rgba(0, 0, 0, .7)"
      color="#1890ff"
      :text="loading.title"
    />
  </div>
</template>

<script>
import { mapGetters } from "vuex";
import VueElementLoading from "vue-element-loading";
import { CardListApi, TerminalApi } from "@/api/home";
// import router from "@/router";
import { websocketsend } from "@/utils/ws";
export default {
  name: "App",
  components: {
    VueElementLoading
  },
  computed: {
    ...mapGetters(["loading", "Openstate"])
  },
  mounted() {
    window.ws = websocketsend;
    window.addEventListener("beforeunload", this.beforeunloadHandler, false);
    // sscom串口调试功能
    window.sscom = dos => {
      TerminalApi({
        cmd: "Terminal",
        tans_msg: dos
      }).then(res => {
        console.log(
          `%c串口返回信息：`,
          "color: #43bb88;font-size: 24px;font-weight: bold;text-decoration: underline;"
        );
        console.log(
          `%c${JSON.stringify(res.tans_msg_ret)}`,
          "color: #43bb88;font-size: 24px;font-weight: bold;text-decoration: underline;"
        );
      });
    };

    // 断电提示
    // let _this=this
    // let b=null
    // let a=setInterval(function() {
    //   CardListApi({ cmd: 'LinkInfo' }).then(res=>{
    //
    //   }).catch(err=>{b=true})
    // },7000)
    //
    // let c=setInterval(function() {
    //   if (b){
    //     _this.$notify.error({
    //       title: '错误',
    //       message: '设备已断开连接,稍后将重新连接...',
    //       duration: 3500,
    //       onClose:()=>{
    //         // window.location.reload()
    //       }
    //     });
    //     clearInterval(a)
    //     clearInterval(c)
    //   }
    // },1000)

    // websocket监听
    // this.socketApi.sendSock({}, data => {
    //   console.log('websocket接收的数据APP：', data)
    //   if (data.Cmd==='CLEAR'){  // 恢复出厂设置 恢复默认
    //     window.location.href='http://192.168.0.178'
    //   }
    // })

    // 禁止使用右键
    document.oncontextmenu = function(event) {
      event.preventDefault();
    };

    // 监听回车按键
    function enterCallback(e) {
      if (e.keyCode === 32) {
        //阻止浏览器的默认行为
        if (e.preventDefault) {
          // w3c
          e.preventDefault();
        } else {
          // IE
          window.event.returnValue = false;
        }
        return false;
      }
    }

    window.addEventListener("keydown", enterCallback);
  },
  destroyed() {
    window.removeEventListener("beforeunload", this.beforeunloadHandler, false);
  },
  methods: {
    beforeunloadHandler(e) {
      localStorage.removeItem("sceneData");
      localStorage.removeItem("omapData");
      localStorage.removeItem("incardListData");
      localStorage.removeItem("timingData");
      localStorage.removeItem("wndData");
      localStorage.removeItem("outListData");
      localStorage.removeItem("istaData");
      localStorage.removeItem("systemType");
      localStorage.removeItem("ipInfoData");
      localStorage.removeItem("verData");
      localStorage.removeItem("tempOmapData");
      localStorage.removeItem("GroupContext");
    }
  }
};
</script>
<style>
.mButton {
  font-size: 20px !important;
}

@media (-webkit-min-device-pixel-ratio: 1.5), (min-resolution: 120dpi) {
}
@media (-webkit-min-device-pixel-ratio: 2), (min-resolution: 192dpi) {
  .el-menu-item {
    font-size: 12px !important;
  }
  .zidingyiclass .el-menu-item {
    padding-left: 5px !important;
    font-size: 8px !important;
  }

  .button-list-item {
    padding: 1px !important;
    width: 108px !important;
    font-size: 16px !important;
  }
  .left-header {
    height: 40px !important;
    line-height: 40px !important;
    font-size: 15px !important;
    border-bottom: 2px solid #000000 !important;
  }
  .scene-button {
    width: 100px !important;
    height: 40px !important;
    margin: 5px auto 0 auto !important;
    line-height: 40px !important;
    border-radius: 25px !important;
    font-size: 15px !important;
  }
  .header_title {
    font-size: 18px !important;
  }
  .sidebar-title {
    font-size: 16px !important;
  }
  .ptn-btn-124 {
    border-radius: 25px !important;
    width: 126px !important;
    height: 28px !important;
    line-height: 28px !important;
    font-size: 16px !important;
  }
  .header {
    height: 40px !important;
  }
  .ptn-grid-warp-grid {
    height: 70vh;
  }
  .scene-ul {
    height: calc(100vh - 350px) !important;
  }
  .navbar {
    height: 50px !important;
  }
  .hamburger-container {
    line-height: 46px !important;
  }
  .hamburger {
    width: 20px !important;
    height: 20px !important;
  }
  .right-menu {
    line-height: 50px !important;
  }
  .sidebar-logo-container {
    height: 50px !important;
    line-height: 50px !important;
  }
  .right-menu-item {
    padding: 0 8px !important;
    font-size: 18px !important;
  }
  .homesvgicon {
    font-size: 25px !important;
    margin-right: 25px !important;
  }
  .el-form-item__label {
    font-size: 12px !important;
  }
  .el-dialog__title {
    font-size: 16px !important;
  }
  .el-switch {
    font-size: 14px !important;
    line-height: 20px !important;
    height: 20px !important;
  }
  .el-switch__core {
    width: 40px !important;
    height: 20px !important;
    border-radius: 10px !important;
  }
  .el-switch__core:after {
    width: 16px !important;
    height: 16px !important;
  }
  .el-switch.is-checked .el-switch__core::after {
    margin-left: -17px !important;
  }
  .el-button {
    font-size: 10px !important;
  }
  .left-content-img-warp {
    width: 310px !important;
    height: 60px !important;
    margin: 15px 5px !important;
  }
  .el-form-item__label {
    width: 100px !important;
  }
  .el-form-item__content {
    margin-left: 100px !important;
  }
  .padding30 {
    padding: 30px !important;
  }
  .el-tabs__item {
    font-size: 12px !important;
  }
  .el-switch__label * {
    font-size: 10px !important;
  }
  .el-menu-item {
    height: 57px !important;
    line-height: 57px !important;
  }
  .fontsize16 {
    font-size: 16px !important;
  }
  aside {
    font-size: 14px !important;
  }
}
@media (-webkit-min-device-pixel-ratio: 3), (min-resolution: 288dpi) {
}
@media (-webkit-min-device-pixel-ratio: 4), (min-resolution: 384dpi) {
}
</style>
