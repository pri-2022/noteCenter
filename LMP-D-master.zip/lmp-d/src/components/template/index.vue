<template>
  <div class="app-container">
    <!--操作栏-->
    <div class="page-filter">
      <div class="filter-item">
        <el-button type="primary" @click="addTag" v-waves size="mini" >添加分类</el-button>
      </div>
    </div>
    <!--表格-->
    <el-table
      :data="tagTable"
      stripe
      border
    >
      <el-table-column
        prop="name"
        label="分类名称"
        align="center"
      />
      <el-table-column
        prop="order"
        label="排序"
        align="center"
      />
      <el-table-column
        header-align="center"
        align="center"
        label="操作"
      >
        <template slot-scope="{row}">
          <el-button type="primary" v-waves size="mini" @click="handleEvent('edit',row)">编辑</el-button>
          <el-button type="danger" v-waves size="mini" @click="handleEvent('del',row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <!--分页组件-->
    <el-row type="flex" justify="center" align="middle" style="padding-top: 30px;">
      <el-col>
        <el-pagination
          background
          :current-page.sync="tablePagination.query.curPage"
          :page-sizes="tablePagination.pagesizes"
          :page-size.sync="tablePagination.query.pagesize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="tablePagination.total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </el-col>
    </el-row>
    <!--添加标签的弹框-->
    <el-dialog  :title="dialog.title" :visible.sync="dialog.visible" :before-close="DialogBeforeClose">
      <el-form ref="form" :model="dialog.form"  :label-position="dialog.form.labelPosition" label-width="100px" >
        <el-form-item label="分类名称:" prop="name" :rules="[{required:true,message:'请输入分类名称',trigger:'blur'}]">
          <el-input v-model="dialog.form.name" type="text" />
        </el-form-item>
        <el-form-item label="排序:" prop="order" :rules="[{required:true,message:'请输入排序',trigger:'blur'}]">
          <el-input v-model="dialog.form.order" type="text" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button v-waves size="mini" @click="DialogBeforeClose">取消</el-button>
        <el-button v-if="dialog.title==='添加分类'" v-waves type="success" size="mini" @click="dialogEnter('add')">确定</el-button>
        <el-button v-else v-waves type="success" size="mini" @click="dialogEnter('edit')">确定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import  {findPageContentTypeAPI,insContentTypeAPI,upContentTypeAPI,delContentTypeAPI} from '@/api/template'
  export default {
    name: 'Index',
    data() {
      return {
        /* 表格数据*/
        tagTable: [],
        /* 添加弹窗相关*/
        dialog: {
          visible: false,
          loading: false,
          title:'',
          form: {
            labelPosition: 'right',
            name: '',
            id: '', // 编辑的时候需要用到的文章id
            order: '',
            isVisible:false
          }
        },
        /* 分页组件*/
        tablePagination: {
          pagesizes: [5, 10, 20, 50, 100], // 每页显示个数选择器的选项设置
          total: 100, // 总条目数
          loading: false, // 是否加载loading动画
          query: {
            curPage: 1, // 当前页数
            pagesize: 20 // 每页显示条目个数，支持 .sync 修饰符
          }
        }
      }
    },
    mounted(){
      this.getList()
    },
    methods: {
      /* 点击添加按钮弹窗*/
      addTag() {
        this.dialog.title = '添加分类'
        this.dialog.visible = true
      },
      /* 选择项改变时*/
      handleSizeChange(val) {
        const query = this.tablePagination.query
        query.pagesize = val // 每页条数
        query.curPage = 1 // 每页条数切换，重置当前页
        this.getList()
      },
      /* 当前页改变时*/
      handleCurrentChange(val) {
        this.tablePagination.query.curPage = val // 当前页
        this.getList()
      },
      /* 获取表格数据*/
      getList() {
        let data={
          pageNumber:this.tablePagination.query.curPage,
          pageSize:this.tablePagination.query.pagesize,
        }
        findPageContentTypeAPI(data).then(res=>{
          this.tagTable=res.data.list
          this.tablePagination.total=res.data.totalRow
          this.tablePagination.query.curPage=res.data.pageNumber
          this.tablePagination.query.pagesize=res.data.pageSize
        })
      },
      handleEvent(event,data){
        switch (event) {
          case 'edit':
            // 编辑
            this.dialog.form.id = data.id
            this.dialog.title = '编辑分类'
            this.dialog.visible = true
            Object.assign(this.dialog.form, data)
            break
          case 'del':
            // 删除
            this.$confirm('此操作将永久删除该标签, 是否继续?', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
            }).then(() => {
              delContentTypeAPI({id:data.id}).then(res=>{
                this.$message.success(res.msg)
              }).then(res=>{
                this.getList()
              })
            }).catch(() => {
              this.$message({
                type: 'info',
                message: '已取消删除'
              });
            });

            break
          default:

            break
        }
      },
      /*弹框的确定事件 分为添加和编辑*/
      dialogEnter(type){
        let state
        this.$refs.form.validate(val=>val?state=true:state=false)
        if (!state){return false}
        let data={
          name: this.dialog.form.name,
          order: this.dialog.form.order
        }
        let API
        if (type==='add'){
          API=insContentTypeAPI
        } else if (type==='edit'){
          API=upContentTypeAPI
          Object.assign(data,{id:this.dialog.form.id})
        }

        API(data).then(res=>{
          this.$message.success(res.msg)
        }).then(res=>{
          this.DialogBeforeClose('')
          this.getList()
        })
      },
      DialogBeforeClose(done){
        this.$refs.form.resetFields()
        if (typeof done==="function") {
          done()
        } else {
          this.dialog.visible = false
        }
      }
    }
  }
</script>

<style scoped>

</style>
