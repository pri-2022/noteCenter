<template>
  <div>
    <canvas v-show="false" ref="canvasFont" />
    <canvas v-show="false" ref="canvasFontCopy2" />
    <canvas style="height: 52px;" ref="canvasFontCopy" />
  </div>
</template>

<script>
import {
  inSubtitleTransApi,
  infoReportConfigApi,
  argsFontApi,
  inSubtitleArgsApi,
  inSubtitleApi
} from "@/api/InCard";
import { rgbOrRgbaToArray } from "@/utils";

export default {
  name: "Index",
  model: {
    prop: "value",
    event: "input"
  },
  props: {
    value: {
      type: String,
      default: ""
    },
    fontsize: {
      type: Number,
      default: 16
    },
    ch: Number,
    font: String,
    result: {
      type: Array,
      default: []
    },
    Bc: String,
    Fc: String,
    Y: Number,
    X: Number,
    bc_transparent: Number,
    isXY: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {};
  },
  mounted() {},
  methods: {
    font3() {
      const _this = this;
      const canvas = this.$refs.canvasFont;
      const ctx = canvas.getContext("2d");
      const fontSize = _this.fontsize;
      const font = _this.font;
      let chinaString = _this.value.match(/[\u4E00-\u9FA5]/g); //计算中文的个数
      let valueWidth;
      if (chinaString) {
        // 含有中文
        let len = chinaString.length; // 中文的长度
        let alen = _this.value.length - len; // 英文或数字的长度
        // valueWidth=parseInt(len*fontSize+(alen*fontSize/2)+(this.result.includes('Italic')?0.4*fontSize:5))
        valueWidth = parseInt(len * fontSize + (alen * fontSize) / 2);
      } else {
        // 无中文 纯英文或者纯数字
        // valueWidth=parseInt(_this.value.length*fontSize/2+(this.result.includes('Italic')?0.4*fontSize:5))
        valueWidth = parseInt((_this.value.length * fontSize) / 2);
      }
      console.log(chinaString, "chinaString");
      canvas.width = valueWidth;
      canvas.height = fontSize;
      ctx.textAlign = "left";
      ctx.textBaseline = "top";
      // ctx.font = fontSize + 'px \'' + font + '\''
      ctx.font = `${this.result.includes("Blod") ? "bold" : ""} ${
        this.result.includes("Italic") ? "italic" : ""
      } ${fontSize}px ${font}`;
      function getzm() {
        ctx.fillStyle = "rgb(0,0,0)"; // 背景
        ctx.fillRect(0, 0, valueWidth, fontSize);
        ctx.fillStyle = "rgb(255,255,255)"; // 字体颜色
        ctx.fillText(_this.value, 0, 0, valueWidth - 10);
        // ctx.fillText(_this.value, 0, 0, valueWidth);

        ctx.strokeStyle = "rgb(255,255,255)";
        ctx.lineWidth = 1;
        if (_this.result.includes("Strickout")) {
          // 删除线
          ctx.moveTo(0, fontSize / 2);
          ctx.lineTo(valueWidth, fontSize / 2);
          ctx.stroke();
        }
        if (_this.result.includes("Underline")) {
          // 下划线
          ctx.moveTo(0, fontSize - 5);
          ctx.lineTo(valueWidth, fontSize - 5);
          ctx.stroke();
        }

        ctx.stroke();

        const data = ctx.getImageData(0, 0, valueWidth, fontSize);
        // console.log(data, '图片数据')
        // console.log(data.width, 'data.width图片宽')
        // console.log(valueWidth, 'valueWidth宽')
        // console.log(data.height, 'data.height图片高')
        // console.log(fontSize, 'fontSize高')
        // _this.$parent.isXY({width:data.width,height:data.height})
        _this.$emit("isXYHandle", {
          width: data.width,
          height: data.height,
          imgData: data.data
        });

        // if (!_this.isXY){
        //   return false
        // }

        // let a=''
        // let b=''
        //
        //
        // for (let i = 0; i < data.data.length; i+=4) {
        //   if (data.data[i] > 127) {
        //     // a.push(1)
        //     a+='1'
        //   } else {
        //     // a.push(0)
        //     a+='0'
        //   }
        // }
        // console.log(a,'a')
        // for (let j=0;j<a.length;j+=8){
        //   let ite=a.substr(j,8)
        //   // b+=str2hex(ite)
        //   // console.log(ite,'itemmmm')
        //   b+=parseInt(ite,2)+','
        // }
        //
        // let bArray=b.split(',')
        // let cArray=bArray.slice(0,bArray.length-1).map(i=>parseInt(i).toString(16))
        //
        // inSubtitleApi({
        //   cmd: 'inSubtitle',
        //   ch: _this.ch,
        //   en: 0
        // }).then(res=>{
        //   infoReportConfigApi({cmd:'infoReportConfig',en: 0}).then(res=>{
        //     inSubtitleTransApi({
        //       cmd:'inSubtitleTrans',
        //       ch:_this.ch,
        //       packsize:cArray.length,
        //       pic_w:data.width,
        //       pic_h:data.height,
        //       data: cArray
        //     }).then(res=>{
        //       argsFontApi({
        //         cmd:'argsFont',
        //         ch:_this.ch,
        //         FontAttri: {
        //           Blod:_this.result.includes('Blod')?1:0,
        //           Italic:_this.result.includes('Italic')?1:0,
        //           Strickout:_this.result.includes('Strickout')?1:0,
        //           Underline:_this.result.includes('Underline')?1:0,
        //         },
        //         Size: fontSize,
        //         Text:_this.value,
        //         FontName: font
        //       }).then(res=>{
        //         inSubtitleArgsApi({
        //           cmd:'inSubtitleArgs',
        //           ch:_this.ch,
        //           bc_transparent:_this.bc_transparent,
        //           Flag: '',
        //           Fc: rgbOrRgbaToArray(_this.Fc),
        //           Bc: rgbOrRgbaToArray(_this.Bc),
        //           X:_this.X,
        //           Y:_this.Y,
        //           W: data.width,
        //           H: data.height
        //         }).then(res=>{
        //           inSubtitleApi({
        //             cmd: 'inSubtitle',
        //             ch: _this.ch,
        //             en: 1
        //           }).then(res=>{
        //             infoReportConfigApi({cmd:'infoReportConfig',en:1}).then(()=>{
        //               _this.$message.success('字幕设置成功')
        //             })
        //           })
        //         })
        //       })
        //     })
        //   })
        // })
      }
      getzm();
    },
    fontCopy2() {
      let _this = this;
      const canvas = this.$refs.canvasFontCopy2;
      const ctx = canvas.getContext("2d");
      const fontSize = _this.fontsize;
      const font = _this.font;
      let chinaString = _this.value.match(/[\u4E00-\u9FA5]/g); //计算中文的个数
      let valueWidth;
      if (chinaString) {
        // 含有中文
        let len = chinaString.length; // 中文的长度
        let alen = _this.value.length - len; // 英文或数字的长度
        // valueWidth=len*fontSize+(alen*fontSize/2)+(this.result.includes('Italic')?0.4*fontSize:5)
        valueWidth = len * fontSize + (alen * fontSize) / 2;
      } else {
        // 无中文 纯英文或者纯数字
        // valueWidth=_this.value.length*fontSize/2+(this.result.includes('Italic')?0.4*fontSize:5)
        valueWidth = (_this.value.length * fontSize) / 2;
      }
      canvas.width = valueWidth;
      canvas.height = fontSize;
      ctx.textAlign = "left";
      ctx.textBaseline = "top";
      // ctx.font = 'italic\''+ '\'' + fontSize + 'px \'' + font + '\''
      ctx.font = `${this.result.includes("Blod") ? "bold" : ""} ${
        this.result.includes("Italic") ? "italic" : ""
      } ${fontSize}px ${font}`;
      console.log(this.result, "this.result");

      function getzm() {
        ctx.fillStyle = _this.Bc; // 背景
        ctx.fillRect(0, 0, valueWidth, fontSize);
        ctx.fillStyle = _this.Fc; // 字体颜色
        ctx.fillText(_this.value, 0, 0, valueWidth - 10);

        ctx.strokeStyle = _this.Fc;
        ctx.lineWidth = 1;
        if (_this.result.includes("Strickout")) {
          // 删除线
          ctx.moveTo(0, fontSize / 2);
          ctx.lineTo(valueWidth, fontSize / 2);
          ctx.stroke();
        }
        if (_this.result.includes("Underline")) {
          // 下划线
          ctx.moveTo(0, fontSize - 5);
          ctx.lineTo(valueWidth, fontSize - 5);
          ctx.stroke();
        }

        ctx.stroke();

        const data = ctx.getImageData(0, 0, valueWidth, fontSize);
        // _this.$emit('isXYHandle',{width:data.width,height:data.height})
        let a = "";
        for (let i = 0; i < data.data.length; i += 4) {
          if (data.data[i] > 127) {
            a += "1";
          } else {
            a += "0";
          }
        }
        // console.log(a, "a");
        if (a.length > 65536) {
          _this.$message.error("字幕总数据超过了预定值(长*宽<=65536)");
        } else {
          _this.fontCopy();
        }
      }
      getzm();
    },
    fontCopy() {
      let _this = this;
      const canvas = this.$refs.canvasFontCopy;
      const ctx = canvas.getContext("2d");
      const fontSize = _this.fontsize;
      const font = _this.font;
      let chinaString = _this.value.match(/[\u4E00-\u9FA5]/g); //计算中文的个数
      let valueWidth;
      if (chinaString) {
        // 含有中文
        let len = chinaString.length; // 中文的长度
        let alen = _this.value.length - len; // 英文或数字的长度
        // valueWidth=len*fontSize+(alen*fontSize/2)+(this.result.includes('Italic')?0.4*fontSize:5)
        valueWidth = len * fontSize + (alen * fontSize) / 2;
      } else {
        // 无中文 纯英文或者纯数字
        // valueWidth=_this.value.length*fontSize/2+(this.result.includes('Italic')?0.4*fontSize:5)
        valueWidth = (_this.value.length * fontSize) / 2;
      }
      canvas.width = valueWidth;
      canvas.height = fontSize;
      ctx.textAlign = "left";
      ctx.textBaseline = "top";
      // ctx.font = 'italic\''+ '\'' + fontSize + 'px \'' + font + '\''
      ctx.font = `${this.result.includes("Blod") ? "bold" : ""} ${
        this.result.includes("Italic") ? "italic" : ""
      } ${fontSize}px ${font}`;
      console.log(this.result, "this.result");

      function getzm() {
        ctx.fillStyle = _this.bc_transparent === 1 ? "rgba(0,0,0,0)" : _this.Bc; // 背景
        ctx.fillRect(0, 0, valueWidth, fontSize);
        ctx.fillStyle = _this.Fc; // 字体颜色
        ctx.fillText(_this.value, 0, 0, valueWidth - 10);

        ctx.strokeStyle = _this.Fc;
        ctx.lineWidth = 1;
        if (_this.result.includes("Strickout")) {
          // 删除线
          ctx.moveTo(0, fontSize / 2);
          ctx.lineTo(valueWidth, fontSize / 2);
          ctx.stroke();
        }
        if (_this.result.includes("Underline")) {
          // 下划线
          ctx.moveTo(0, fontSize - 5);
          ctx.lineTo(valueWidth, fontSize - 5);
          ctx.stroke();
        }

        ctx.stroke();

        const data = ctx.getImageData(0, 0, valueWidth, fontSize);
        // _this.$emit('isXYHandle',{width:data.width,height:data.height})
      }
      getzm();
    }
  }
};
</script>

<style scoped></style>
