<template>
  <el-popover
    placement="top"
    trigger="manual"
    style="margin: 5px;"
    v-model="open"
  >
    <div
      id="outMap"
      style="width: 200px;height:200px;touch-action: none;position: relative;"
      @mouseout="touchendInMap"
    >
      <div
        id="inMap"
        style="width: 50px;height: 50px;position: absolute;top: 0;left: 0;background: #414246;opacity:0.5;touch-action: auto;"
        @touchstart.stop.prevent="touchstartInMap($event)"
        @touchmove="touchmoveInMap($event)"
        @touchend.stop.prevent="touchendInMap($event)"
        @mousedown.stop.prevent="touchstartInMap"
        @mousemove="touchmoveInMap"
        @mouseup="touchendInMap"
      ></div>
    </div>
    <el-button type="info" slot="reference" @click="init">
      <i v-if="loading" class="el-icon-loading"></i>
      <svg-icon v-else :icon-class="open ? 'eye' : 'eye-open'"></svg-icon>
    </el-button>
  </el-popover>
</template>

<script>
import html2canvas from "html2canvas";

export default {
  name: "index",
  props: {
    outWarp: String,
    inWarp: String
  },
  data() {
    return {
      open: false,
      loading: false
    };
  },
  mounted() {
    let outWarpDom = document.querySelector(this.outWarp);
    let inMapDom = document.querySelector("#inMap");
    outWarpDom.onscroll = function(e) {
      // console.log("let", e.target.scrollLeft);
      // console.log("top", e.target.scrollTop);
      inMapDom.style.left = `${e.target.scrollLeft * 0.1}px`;
      inMapDom.style.top = `${e.target.scrollTop * 0.1}px`;
    };
  },
  methods: {
    init() {
      let _this = this;
      if (this.loading) {
        return false;
      }
      if (this.open) {
        this.open = false;
      } else {
        let outMapDom = document.querySelector("#outMap");
        let outWarpDom = document.querySelector(this.outWarp);
        outMapDom.style.width = `${outWarpDom.scrollWidth * 0.1}px`;
        outMapDom.style.height = `${outWarpDom.scrollHeight * 0.1}px`;
        let inMapDom = document.querySelector("#inMap");
        let inWarpDom = document.querySelector(this.inWarp);
        inMapDom.style.width = `${outWarpDom.clientWidth * 0.1}px`;
        inMapDom.style.height = `${outWarpDom.clientHeight * 0.1}px`;

        if (outMapDom.style.background && false) {
          this.open = true;
        } else {
          this.loading = true;
          html2canvas(inWarpDom, {
            width: outWarpDom.scrollWidth,
            height: outWarpDom.scrollHeight,
            scale: 0.5
          }).then(canvas => {
            // let dataUrl = canvas.toDataURL("image/jpeg", 0.1);
            // outMapDom.style.background = `url(${dataUrl})`;
            // outMapDom.style.backgroundSize = "cover";
            // this.open = true;
            // this.loading = false;

            canvas.toBlob(
              function(blob) {
                console.log(blob, "blob");
                console.log(blob.size / 1024, "blob.size");
                let url = window.URL.createObjectURL(blob);
                outMapDom.style.background = `url(${url})`;
                outMapDom.style.backgroundSize = "cover";
                _this.open = true;
                _this.loading = false;
              },
              "image/jpeg",
              1
            );
          });
        }
      }
    },
    touchstartInMap(e) {
      console.log(e);
      let boxEdit = document.querySelector(`#outMap`);
      let that = document.querySelector(`#inMap`);
      let ev = (e.touches && e.touches[0]) || e;
      console.log(ev);

      var disW = that.offsetWidth; //元素  的宽度
      var disH = that.offsetHeight; //元素  的高度
      var disL = that.offsetLeft; //元素  左侧距离 父级 左侧 的距离
      var disT = that.offsetTop; //元素  顶部距离 父级 顶部 的距离

      var disX = ev.clientX; //鼠标  距离 屏幕 左侧 的距离
      var disY = ev.clientY; //鼠标  距离 屏幕 顶部 的距离
      var mouseElX = ev.clientX - that.offsetLeft; //鼠标  距离 元素 左侧 的距离
      var mouseElY = ev.clientY - that.offsetTop; //鼠标  距离 元素 顶部 的距离
      var eidtW = boxEdit.offsetWidth; // 父元素 的宽度
      var eidtH = boxEdit.offsetHeight; // 父元素 的高度
      var oLeft = disX - disL; // 算出鼠标距离元素左侧的距离
      var oTop = disY - disT; // 算出鼠标距离元素顶部的距离
      let outWarpDom = document.querySelector(this.outWarp);
      let isMobile = e.touches && e.touches[0];
      let eventBox = isMobile ? "ontouchmove" : "onmousemove";
      console.log(isMobile);
      boxEdit[eventBox] = function(boxEditev) {
        var ev = (boxEditev.touches && boxEditev.touches[0]) || boxEditev;
        // 鼠标移动的x轴和Y轴
        var setX = ev.clientX - oLeft;
        var setY = ev.clientY - oTop;
        // 利用 mouseElX  mouseElY  进行判断是否在范围内
        // 如果在放大缩小的范围之内

        // 移动
        if (setX <= -1) {
          setX = 0;
        }
        if (setY <= -1) {
          setY = 0;
        }
        // 这里先注释掉 限制窗体活动范围 的代码
        if (setX >= eidtW - disW - 1) {
          setX = eidtW - disW;
        }
        if (setY >= eidtH - disH - 1) {
          setY = eidtH - disH;
        }
        that.style.left = setX + "px";
        that.style.top = setY + "px";
        outWarpDom.scrollTo(setX * 10, setY * 10);
      };
    },
    touchmoveInMap(ev) {},
    touchendInMap(ev) {
      let boxEdit = document.querySelector(`#outMap`);
      boxEdit.ontouchmove = null;
      boxEdit.onmousemove = null;
    }
  }
};
</script>

<style lang="scss" scoped></style>
