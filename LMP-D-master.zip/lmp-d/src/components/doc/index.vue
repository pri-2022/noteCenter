<template>
    <el-card id="card" class="box-card" style="background:black;color:white;max-height:27.2em;overflow:auto"
             @click="autoFocus()">
        <div id="text" style="background:black;color:white;" @click="autoFocus()">
            <ul id="ul">
                <li v-for="(i,b) in total" :key="b">{{i}}<br/></li>
            </ul>
            <el-input
                    v-loading="loading"
                    type="text"
                    id="in"
                    class="input_text"
                    v-model="command"
                    resize="none"
                    @keyup.enter.native="enter()"
                    autofocus="autofocus">
                <span slot="prepend" style="font-size:18px">></span>
            </el-input>
        </div>
    </el-card>
</template>

<style>
    ul {
        margin: 0px;
        padding: 0px;
        list-style: none;
    }

    .input_text .el-input__inner:focus {
        border: 1px solid black;
    }

    .input_text .el-input__inner:hover {
        border: 1px solid black;
    }

    .input_text .el-input__inner {
        color: green;
        border: 1px solid black;
        background-color: black;
    }

    .input_text .el-input-group__prepend {
        padding: 0px;
        color: white;
        border: 1px solid black;
        background-color: black;
    }
</style>

<script>
    export default {
        data() {
            return {
                command: '',
                loading: false,
                total: ['Welcome！You can enter：ping 192.168.1.1', ' ']
            }
        },
        created() {
        },
        directives: {
            focus: {
                inserted: function (el, {value}) {
                    console.log(el, {value})
                    if (value) {
                        el.focus()
                    }
                }
            }
        },
        watch: {
            loading: {
                handler(newVal, oldVal) {
                    if (newVal == false) {
                        this.scoll()
                    }
                },
                deep: true
            }
        },
        methods: {
            enter() {
                var _this = this
                var ip = $('#in').val()
                this.loading = true
                if (ip.indexOf('ping ') >= 0 || ip === 'ipconfig' || ip === 'ipconfig /all') {
                    _this.total.push('>' + ip)
                    this.$axios.get("/command", {
                        params: {
                            ip: ip,
                        }
                    }).then(response => {
                        if (response.data.err == true) {
                            // 所有指令
                            var db = response.data.db
                            var array = []
                            array.push(db.split('&'))
                            for (var i in array[0]) {
                                _this.total.push(array[0][i])
                            }
                            $('#in').val('') // 清空输入框
                            $('#text').scrollTop($('#text').scrollTop() + 32)// 滚动条拉到最下面，显示出输入框
                            _this.total.push(' ')
                            _this.loading = false
                        } else {
                            _this.total.push(response.data.message)
                            $('#in').val('') // 清空输入框
                            $('#text').scrollTop($('#text').scrollTop() + 32)// 滚动条拉到最下面，显示出输入框
                            _this.total.push(' ')
                            _this.loading = false
                        }
                    }).catch(error => {
                        $('#in').val('') // 清空输入框
                        _this.total.push('再次出错')
                        _this.total.push(error)
                        _this.total.push(' ')
                        _this.loading = false
                    })
                } else if (ip.indexOf('clear') >= 0) {
                    this.total = ['Welcome！You can enter：ping 192.168.1.1', ' ']
                    $('#in').val('') // 清空输入框
                    _this.loading = false
                } else {
                    if (ip === '' || ip === null) {
                        this.total.push('>' + ip)
                        $('#in').val('') // 清空输入框
                        _this.loading = false
                    } else {
                        this.total.push('>' + ip)
                        var start = ip.split(' ')[0]
                        this.total.push("’" + start + "’" + '  不是内部或外部命令，也不是可运行的程序或批处理文件。')
                        $('#in').val('') // 清空输入框
                        this.total.push(' ')
                        this.loading = false
                    }
                }
            },
            autoFocus() {
                $('#in').focus()
            },
            scoll() {
                var _this = this
                this.positionTimer = setTimeout(() => {
                    var card = $('#card')
                    clearTimeout(_this.positionTimer)
                    _this.positionTimer = null
                }, 100, function () {
                })
            }
        }
    }
</script>