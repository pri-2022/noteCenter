<template>
  <video
    :ref="`video${ch}`"
    autoplay
    muted
    style="width: 100%;height: 100%;object-fit: fill;position: absolute;left: 0;top: 0;"
  >
    Your browser is too old which doesn't support HTML5 video.
  </video>
</template>

<script>
import ZLMRTCClient from "./ZLMRTCClient.js";

export default {
  props: {
    ch: Number,
    w: Number,
    h: Number
  },
  data() {
    return {
      player: null
    };
  },
  mounted() {
    if (this.player) {
      this.player.close();
      this.player = null;
      this.init();
    } else {
      this.init();
    }
  },
  destroyed() {
    this.player.close();
    this.player = null;
  },
  methods: {
    init() {
      const _this = this;
      this.player = new ZLMRTCClient.Endpoint({
        // element: document.getElementById(`video${_this.ch}`),// video 标签
        element: _this.$refs[`video${_this.ch}`], // video 标签
        debug: true, // 是否打印日志
        zlmsdpUrl:
          "http://192.168.20.200:8080/index/api/webrtc?app=live&stream=test&type=play", //流地址
        simulcast: false,
        useCamera: false,
        audioEnable: false,
        videoEnable: true,
        recvOnly: true,
        resolution: { w: 1280, h: 720 }
      });

      this.player.on(ZLMRTCClient.Events.WEBRTC_ICE_CANDIDATE_ERROR, function(
        e
      ) {
        // ICE 协商出错
        console.log("ICE 协商出错");
      });

      this.player.on(ZLMRTCClient.Events.WEBRTC_ON_REMOTE_STREAMS, function(e) {
        //获取到了远端流，可以播放
        // document.getElementById(`video${_this.ch}`).play();
        let s = setTimeout(function() {
          _this.$refs[`video${_this.ch}`].play();
          clearTimeout(s);
        }, 1000);
        // _this.$refs[`video${_this.ch}`].play();
        console.log("播放成功", e.streams);
      });

      this.player.on(
        ZLMRTCClient.Events.WEBRTC_OFFER_ANSWER_EXCHANGE_FAILED,
        function(e) {
          // offer answer 交换失败
          console.log("offer answer 交换失败", e);
          stop();
        }
      );

      this.player.on(ZLMRTCClient.Events.WEBRTC_ON_LOCAL_STREAM, function(s) {
        // 获取到了本地流

        document.getElementById("selfVideo").srcObject = s;
        document.getElementById("selfVideo").muted = true;

        //console.log('offer answer 交换失败',e)
      });

      this.player.on(ZLMRTCClient.Events.CAPTURE_STREAM_FAILED, function(s) {
        // 获取本地流失败

        console.log("获取本地流失败");
      });
    }
  }
};
</script>

<style></style>
