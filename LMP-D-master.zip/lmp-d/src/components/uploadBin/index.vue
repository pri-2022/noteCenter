<template>
  <el-card class="box-card">
    <div slot="header" class="clearfix">
      <span>{{ title }}</span>
    </div>
    <!--          accept=".bin"-->
    <!--          :before-upload="beforeUploadFile"-->
    <el-upload
      class="upload-demo"
      :ref="name"
      :limit="1"
      action
      :on-change="fileChange"
      :on-exceed="uploadExceed"
      :http-request="httpRequest"
      :file-list="fileList"
      :auto-upload="false"
    >
      <el-button slot="trigger" size="mini">{{
        $t("upgrade.select")
      }}</el-button>
      <el-button
        style="margin-left: 10px;"
        size="mini"
        type="primary"
        @click="submitUpload"
        >{{ $t("upgrade.Upload") }}</el-button
      >
      <!--          <div slot="tip" class="el-upload__tip">只能上传bin文件</div>-->
    </el-upload>
  </el-card>
</template>

<script>
import { updateApi } from "@/api/uploadBin";
import { initWebSocket, onOffer, WS } from "@/utils/ws";
import { chunk } from "lodash";
import { sendData } from "@/api/InCard";
import i18n from "@/lang";

export default {
  name: "index",
  props: {
    url: {
      type: String,
      default: ""
    },
    title: {
      type: String,
      default: ""
    },
    name: {
      type: String,
      default: ""
    },
    packType: {
      type: String,
      default: ""
    },
    cardType: {
      type: String,
      default: ""
    },
    mode: {
      type: Number,
      default: 0
    },
    ch: {
      type: Number,
      default: 0
    }
  },
  data() {
    return {
      fileList: [],
      EDIDfile: null
    };
  },
  created() {
    if (!WS) {
      initWebSocket();
    }
  },
  mounted() {
    let _this = this;
    onOffer(offerData => {
      console.log(
        "............................onOffer...................................."
      );
      // console.log(JSON.stringify(offerData));
      // console.log(offerData);
      offerData.forEach(datai => {});
    });
    //       this.socketApi.sendSock({}, data => {
    //         console.log('websocket接收的数据uploadBin：', data)
    //
    //         /*Cmd: "upgradeNotice"   进度条升级
    // msg: "ok"
    // percent: 0
    // status: 255*/
    //
    //
    //         // 升级回复指令
    //         if (data.Cmd==='upgradeNotice'){
    //           if (data.status===255){
    //             // _this.$store.dispatch('app/setLoading', { title:`正在升级${data.percent}%...`,singe:true })
    //             _this.$parent.percentageValue({singe:true,percent:data.percent})
    //             console.log('开始升级了')
    //           }else if (data.status===0){
    //             _this.$parent.percentageValue({singe:false})
    //             console.log('升级成功了')
    //             _this.$store.dispatch('app/setLoading',{ title:'升级成功，请勿手动刷新页面，设备程序正在重启...',singe:true })
    //             // _this.$store.dispatch('app/setUploadTip', { uploadTip:'升级成功，请勿手动刷新页面，设备程序正在重启...',singe:true })
    //             // _this.$message.success('升级成功')
    //             setTimeout(function() {
    //               // window.location.href='/'
    //               // window.open(`${window.location.href}login`,'_self')
    //               _this.$store.dispatch('user/logout')
    //               // _this.$router.push(`/login`)
    //               window.location.href='/'
    //             },30000)
    //
    //           }else if (data.status===1){
    //             _this.$parent.percentageValue({singe:false})
    //             _this.$store.dispatch('app/setLoading',false)
    //             _this.$store.dispatch('app/setUploadTip', { uploadTip:'申请内存失败',singe:false })
    //             // _this.$message.error('申请内存失败')
    //           }else if (data.status===2){
    //             _this.$parent.percentageValue({singe:false})
    //             _this.$store.dispatch('app/setLoading',false)
    //             _this.$store.dispatch('app/setUploadTip', { uploadTip:'获得共享内存失败',singe:false })
    //             // _this.$message.error('获得共享内存失败')
    //           }else if (data.status===3){
    //             _this.$parent.percentageValue({singe:false})
    //              _this.$store.dispatch('app/setLoading',false)
    //             _this.$store.dispatch('app/setUploadTip', { uploadTip:'文件长度不正确',singe:false })
    //             // _this.$message.error('文件长度不正确')
    //           }else if (data.status===4){
    //             _this.$parent.percentageValue({singe:false})
    //              _this.$store.dispatch('app/setLoading',false)
    //             _this.$store.dispatch('app/setUploadTip', { uploadTip:'文件校验不正确',singe:false })
    //             // _this.$message.error('文件校验不正确')
    //           }else if (data.status===5){
    //             _this.$parent.percentageValue({singe:false})
    //              _this.$store.dispatch('app/setLoading',false)
    //             _this.$store.dispatch('app/setUploadTip', { uploadTip:'文件版本相同',singe:false })
    //             // _this.$message.error('文件版本相同')
    //           }else if (data.status===6){
    //             _this.$parent.percentageValue({singe:false})
    //             // _this.$store.dispatch('app/setLoading',false)
    //             // _this.$store.dispatch('app/setUploadTip', { uploadTip:'升级失败',singe:false })
    //             _this.$store.dispatch('app/setLoading',{ title:'升级失败，请稍候重试...',singe:true })
    //             setTimeout(function() {
    //               _this.$store.dispatch('app/setLoading',false)
    //             },7000)
    //             // _this.$message.error('文件版本相同')
    //           }
    //         }
    //       })
  },
  methods: {
    clearFiles() {
      this.$refs[this.name].clearFiles(); //清除文件
    },
    uploadExceed(files, fileList) {
      this.$set(fileList[0], "raw", files[0]);
      this.$set(fileList[0], "name", files[0].name);
      this.$refs[this.name].clearFiles(); //清除文件
      this.$refs[this.name].handleStart(files[0]); //选择文件后的赋值方法
      console.log(this.fileList);
    },
    fileChange(file, fileList) {
      const _this = this;
      this.fileList = [];
      this.fileList.push(file);
      this.EDIDfile = file.raw;
      // console.log(this.fileList, "this.fileList");
      console.log(this.EDIDfile, "this.EDIDfile");
    },
    // 覆盖上传行为
    httpRequest() {
      const _this = this;
      const loading = _this.$loading({
        lock: true,
        text: i18n.t("upgrade.notLeave"),
        spinner: "el-icon-loading",
        background: "rgba(0, 0, 0, 0.7)"
      });
      let webHi = ["web", "hi"];
      if (webHi.includes(this.packType)) {
        // 海思和web的升级方式
        const formData = new FormData();
        formData.append(this.name, this.EDIDfile);
        const loadinghttpRequest = this.$loading({
          lock: true,
          text: i18n.t("upgrade.UploadingFile"),
          spinner: "el-icon-loading",
          background: "rgba(0, 0, 0, 0.7)"
        });
        console.log(this.url, "this.url");
        updateApi(formData, this.url)
          .then(res => {
            loadinghttpRequest.close();
            _this.$parent.percentageValue({ singe: false });
            _this.$store.dispatch("app/setLoading", {
              title: i18n.t("upgrade.upgradeSuccessful"),
              singe: true
            });
            let s = setTimeout(function() {
              if (_this.cardType === "ctrl") {
                _this.$store.dispatch("user/logout");
                window.location.href = "/";
              } else {
                window.location.reload();
              }

              clearTimeout(s);
            }, 3000);
          })
          .catch(err => {
            loadinghttpRequest.close();
            this.$message.error("文件上传失败");
          });
      } else {
        // mcu和fpga的升级方式
        const r = new FileReader();
        r.readAsArrayBuffer(this.EDIDfile);
        r.onload = function() {
          console.log(r.result, "r.result");
          const filesDataV = new DataView(
            r.result,
            0,
            r.result.byteLength - 76
          );
          const infoDataV = new DataView(r.result, r.result.byteLength - 76);
          console.log(filesDataV, "filesDataV");
          console.log(infoDataV, "infoDataV");

          console.log(infoDataV.getUint32(0)); //parseInt('1196446798').toString(16) 4750544e
          console.log(parseInt(`${infoDataV.getUint32(0)}`).toString(16));
          console.log(
            parseInt(`${infoDataV.getUint32(0)}`).toString(16) === "4750544e"
          );

          if (
            parseInt(`${infoDataV.getUint32(0)}`).toString(16) === "4750544e"
          ) {
            const filesDataVLIST = [];
            for (let i = 0; i <= filesDataV.byteLength; i += 1024) {
              let a = new ArrayBuffer(1024);
              let b = new DataView(a);
              for (let j = 0; j <= 1024; j++) {
                try {
                  let index = i + j;
                  if (index > filesDataV.byteLength) {
                    // console.log(index);
                    b.setUint8(j, parseInt("FF", 16));
                  } else {
                    b.setUint8(j, filesDataV.getUint8(index));
                  }
                } catch (e) {}
              }
              filesDataVLIST.push(b);
            }

            async function mian() {
              filesDataVLIST.push(infoDataV);
              // console.log(filesDataVLIST, "filesDataVLIST数组");
              // console.log(filesDataVLIST.length, "filesDataVLIST数组.length");
              await sendData(`(info,report,0)\r\n`, false, 500);
              // 按卡号升级时，第四个参数为0，第五个参数是卡号
              // 按类型升级时，第四个参数为255，第五个参数是卡类型 卡类型大于6时要加3
              // 第二个参数，mcu、fpga、fpga2、Hisilicon
              // 第三个参数，ctrl、in、out
              await sendData(
                `(updata,${_this.packType},${_this.cardType},${_this.mode},${
                  _this.ch
                },0)\r\n`,
                false,
                3000
              );
              await loading.close();
              for (let index = 0; index < filesDataVLIST.length; index++) {
                let progressRate = parseInt(
                  (index / filesDataVLIST.length) * 100
                );
                _this.$parent.percentageValue({
                  singe: true,
                  percent: progressRate
                });
                await sendData(filesDataVLIST[index], true, 250);
              }
            }

            let s1 = setTimeout(function() {
              mian().then(() => {
                sendData(`(info,report,1)\r\n`, false, 1000);
                _this.$parent.percentageValue({ singe: false });
                _this.$store.dispatch("app/setLoading", {
                  title: i18n.t("upgrade.upgradeSuccessful"),
                  singe: true
                });
                let s = setTimeout(function() {
                  if (_this.cardType === "ctrl") {
                    _this.$store.dispatch("user/logout");
                    window.location.href = "/";
                  } else {
                    window.location.reload();
                  }
                  clearTimeout(s);
                }, 10000);
                clearTimeout(s1);
              });
            }, 5000);

            console.log("执行了提交事件");
          } else {
            _this.$message.error(i18n.t("upgrade.FileVerFailed"));
          }
        };
      }
    },
    submitUpload() {
      if (this.cardType === "ctrl") {
        if (!this.fileList.length) {
          this.$message.info(i18n.t("upgrade.selectFileTip"));
        } else {
          this.$refs[this.name].submit();
        }
      } else {
        let webHi = ["web", "hi"];
        if (webHi.includes(this.packType)) {
          if (!this.fileList.length) {
            this.$message.info(i18n.t("upgrade.selectFileTip"));
          } else {
            this.$refs[this.name].submit();
          }
        } else {
          if (!this.ch) {
            this.$message.info(i18n.t("upgrade.selectTip"));
          } else {
            if (!this.fileList.length) {
              this.$message.info(i18n.t("upgrade.selectFileTip"));
            } else {
              this.$refs[this.name].submit();
            }
          }
        }
      }
    }
  }
};
</script>

<style lang="scss" scoped></style>
