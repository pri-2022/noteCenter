<template>
  <canvas
    ref="canvasVideo"
    width="352"
    height="288"
    style="width: 100%;height:100%;border:1px #000000 solid;"
  ></canvas>
</template>

<script>
export default {
  name: "Test",
  data() {
    return {
      websock: null
    };
  },
  props: {
    in: {
      type: Number,
      default: 1
    }
  },
  created() {
    this.initWebSocket();
  },
  mounted() {
    let canvas = this.$refs.canvasVideo;
    this.ctx = canvas.getContext("2d");
  },
  destroyed() {
    this.websock.close(); // 离开路由之后断开websocket连接
  },
  methods: {
    initWebSocket() {
      // 初始化weosocket   pic_1 链接   pic_data_1 二进制数据
      // var wsuri = process.env.NODE_ENV === 'development' ? 'ws://192.168.0.178:8082' : `ws://${window.document.location.hostname}:8082`
      const wsuri = "ws://192.168.3.106:8082";
      this.websock = new WebSocket(wsuri, `pic_${this.in}`);
      this.websock.binaryType = "blob"; // 'blob' 'arraybuffer'
      this.websock.onmessage = this.websocketonmessage;
      this.websock.onopen = this.websocketonopen;
      this.websock.onerror = this.websocketonerror;
      this.websock.onclose = this.websocketclose;
    },
    websocketonopen() {
      // 连接建立之后执行send方法发送数据
      const actions = { test: "12345" };
      this.websocketsend(JSON.stringify(actions));
    },
    websocketonerror() {
      // 连接建立失败重连
      this.initWebSocket();
    },
    websocketonmessage(e) {
      // 数据接收
      const _this = this;
      // let reader = new FileReader(); // 创建读取文件对象
      // reader.readAsText(e.data, 'utf-8'); // 设置读取的数据以及返回的数据类型为utf-8
      // reader.onload = function () {
      //   let  data = JSON.parse(reader.result);
      //   console.log(data)
      // }

      /*canvas*/
      // let reader = new FileReader();
      // reader.onload = function(evt){
      //   if(evt.target.readyState === FileReader.DONE){
      //     var image = new Image();
      //     image.width = 352;
      //     image.height = 288;
      //     image.src=evt.target.result
      //     // _this.ctx.clearRect(0,0,352,288)
      //     // 352*288
      //     image.onload=function (e) {
      //       _this.ctx.drawImage(image,0,0,352,288)
      //     }
      //   }
      // }
      // reader.readAsDataURL(e.data);

      let image = new Image();
      image.width = 352;
      image.height = 288;
      let reader = new FileReader();
      reader.onload = function(evt) {
        if (evt.target.readyState === FileReader.DONE) {
          let data = JSON.parse(evt.target.result);
          image.src =
            "http://192.168.3.106/" + data.url + `?ha=${Math.random()}`;
          image.onload = function(e) {
            _this.ctx.drawImage(image, 0, 0, 352, 288);
            image.remove();
          };
        }
      };
      reader.readAsText(e.data, "utf-8");

      // let image = new Image();
      // image.width = 352;
      // image.height = 288;
      // let url=window.URL.createObjectURL(e.data)
      // image.src=url
      // // 352*288
      // image.onload=function (e) {
      //   _this.ctx.drawImage(image,0,0,352,288)
      //   window.URL.revokeObjectURL(url)
      // }

      // let dataView=new DataView(e.data)
      // console.log(dataView,'dataView')
    },
    websocketsend(Data) {
      // 数据发送
      this.websock.send(Data);
    },
    websocketclose(e) {
      // 关闭
      console.log("断开连接", e);
    }
  }
};
</script>
<style></style>
