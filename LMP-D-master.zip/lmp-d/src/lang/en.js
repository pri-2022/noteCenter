export default {
  home: {
    inlist: "InputList",
    outList: "SceneList",
    saveSceneButton: "SaveScene",
    scenePollingButton: "ScenePolling",
    deleteAllButton: "DeleteAll",
    clearScreenButton: "ClearScreen",
    screen: "Screen",
    saveTip: "No window in this group", // 本组无窗口
    scenePollingTip: "Please Save The Scene First", // 请先保存场景
    deleteAllTip: "Prompt", // 提示
    deleteAllTipStatement:
      "This operation will delete all scenes, do you want to continue?", // 此操作将删除所有场景, 是否继续?
    cancel: "Cancel", // 取消
    enter: "Enter", // 确定
    dataLoading: "Getting data", //正在获取数据
    saveSceneDialogTip: "Save scene", //保存场景
    saveSceneDialogName: "SceneName", // 场景名称
    saveSceneDialogID: "SceneNumber", // 场景编号
    Saving: "Saving", // 正在保存
    scenes: "Scenes", //场景
    scenePollingSettings: "Scene polling settings", // 场景轮询设置
    pleaseSelectAPollingScene: "Please select a polling scene", //请选择轮询场景
    pollingInterval: "Polling interval", // 轮询时间间隔
    scenePollingSwitch: "Scene polling switch", // 场景轮询开关
    number: "Number", // 编号
    name: "Name", // 名称
    transfer: "Transfer", // 调 用
    delete: "Delete", // 删 除
    rename: "Rename", // 重命名
    SceneRename: "Scene rename", // 场景重命名
    NewSceneRename: "Please enter a new scene name", // 请输入新的场景名称
    rSceneRename: "Please enter a scene name", // 请输入场景名称
    noSignal: "NoSignal", // 无信号
    invalidWindow: "InvalidWindow", // 无效窗
    windowSign: "WindowSign", // 窗口标志
    stackingNumber: "StackingNumber", // 叠放序号
    windowPosition: "WindowPosition", // 窗口位置
    windowSize: "WindowSize", // 窗口大小
    Top: "Top", // 置顶
    setAtTheEnd: "Bottom", // 置底
    enlarge: "Enlarge", // 放大
    narrow: "Narrow", // 缩小
    lock: "Lock", // 锁定
    unlock: "Unlock", // 取消锁定
    fullScreen: "FullScreen", // 全屏
    cancelFullScreen: "CFScreen", // 取消全屏
    property: "Property", // 属性
    close: "Close", // 关闭
    formProperties: "FormProperties", // 窗体属性
    titleSwitch: "TitleSwitch", // 标题开关
    windowCoordinates: "WindowCoordinates", // 窗口坐标
    wide: "Wide", // 宽
    high: "High", // 高
    saveIngTip: "The scene is saved successfully, the scene is named", // 场景保存成功，场景名为
    group: "Group", // 分组
    thereIsNoInputCardYouWant: "There is no input card you want", // 没有您想要的输入卡
    Scenepollingstatuscannot: "Scene polling status cannot operate scene alone", // 场景轮询状态不能单独操作场景
    deleted: "Deleted", // 已删除
    Cannotclicktheinput: "Cannot click the input card when the scene is polled", // 正在场景轮询时不能点击输入卡
    Cannotdraggedtheinput:
      "The input card cannot be dragged during scene polling", // 正在场景轮询时不能拖拽输入卡
    SaveFailed: "Save failed", // 保存失败
    successdeleted: "Successfully deleted!" // 删除成功!
  },
  set: {
    InputCard: "InputCard", // 输入卡
    outputCard: "OutputCard", // 输出卡
    port: "Port", // 端口
    osdSettings: "OsdSettings", // OSD设置
    osdSwitch: "OsdSwitch", // OSD开关
    DetailedSettings: "DetailedSettings", // 详细设置
    portNameModification: "Name", // 名称修改
    poeControlSwitch: "PoeControlSwitch", // POE控制开关
    on: "On", // 开
    off: "Off", // 关
    dviUpgrade: "DviUpgrade", // DVI升级
    resolution: "Resolution", // 分辨率
    softwareVersion: "Software", // 软件版本
    hardwareVersion: "Hardware", // 硬件版本
    fpgaVersion: "FpgaVersion", // FPGA版本
    Font: "Font", // 字体
    FontHolder: "Please select font", // 请选择字体
    boldFace: "BoldFace", // 黑体
    italics: "Italics", // 楷体
    newSong: "NewSong", // 新宋体
    songTi: "SongTi", // 宋体
    imitateSong: "ImitateSong", // 仿宋
    fontSize: "FontSize", // 字体大小
    fontSizeHolder: "Please select font size", // 请选择字体大小
    Effect: "Effect", // 效果
    pleaseSelectTheEffect: "Please select the effect", // 请选择效果
    Bold: "Bold", // 粗体
    Italic: "Italic", // 斜体
    Strikethrough: "Strikethrough", // 删除线
    Underscore: "Underscore", // 下划线
    subtitleContent: "Content", // 字幕内容
    currentResolution: "Resolution", // 当前分辨率
    transparentBackground: "Transparent", // 背景透明
    opaque: "Off", // 不透明
    transparent: "On", // 透明
    displayPositionX: "PositionX", // 显示位置X
    displayPositionY: "PositionY", // 显示位置Y
    fontColor: "FontColor", // 字体颜色
    backgroundColor: "Background", // 背景颜色
    previewEffect: "Preview", // 预览效果
    Cancel: "Cancel", // 取 消
    Enter: "Enter", // 确 定
    preview: "Preview", // 预 览
    maxX: "The maximum value of display position X is", // 显示位置X最大值为
    maxY: "The maximum value of display position Y is", // 显示位置Y最大值为
    TheTotalData:
      "The total data of subtitles exceeds the predetermined value (length and width<=65536)", // 字幕总数据超过了预定值(长*宽<=65536)
    fontDataSuccess: "Subtitles set successfully", // 字幕设置成功
    QueryFailed: "Query resolution failed", // 查询分辨率失败
    InputSuccessfully: "Input card audio switch successfully", // 输入卡音频切换成功
    InputFailed: "Input card audio switching failed", // 输入卡音频切换失败
    SuccessModified: "Successfully modified", // 修改成功
    EDIDFailed: "EDID selection failed", // EDID选择失败
    EDIDInitSuccessfully: "EDID restored to default successfully", // EDID恢复默认成功
    EDIDInitFailed: "EDID recovery failed", // EDID恢复失败
    UploadedSuccessfully: "Uploaded successfully", // 上传成功
    EDIDUploadFailed: "EDID upload failed", // EDID上传失败
    selectEDID: "Please select an EDID file", // 请选择EDID文件
    SwitchSuccessfully: "Switch successfully", // 切换成功
    SubtitleSwitchFailed: "Subtitle switch failed", // 字幕开关切换失败
    PleaseOSDFirst: "Please set up OSD first", // 请先设置OSD
    TheLengthName: "The length of the name cannot be greater than 10", // 名称长度不能大于10
    failEdit: "fail to edit", // 修改失败
    ChooseSuccess: "Choose success", // 选择成功
    SuccessfulOperation: "Successful operation", // 操作成功
    RestoreSuccess: "Restore the default success", // 恢复默认成功
    FailedResolutionList: "Failed to get custom resolution list", // 获取自定义分辨率列表失败
    FailedSelectResolution: "Failed to select resolution", // 选择分辨率失败
    BrightnessSuccessfully: "Brightness adjusted successfully", // 调节亮度成功
    BrightnessFailed: "Failed to adjust brightness", // 调节亮度失败
    controlCard: "ControlCard", // 控制卡
    changIp: "AlterIp", // 修改IP
    mask: "Mask", // 掩码
    gateway: "Gateway", // 网关
    PortNumber: "PortNumber", // 端口号
    reset: "Reset", // 恢复出厂设置
    fanAdjustment: "FanAdjustment", // 风扇调节
    PleaseSpeed: "Please select the speed", // 请选择转速
    lowSpeed: "LowSpeed", // 低速
    mediumSpeed: "MediumSpeed", // 中速
    highSpeed: "HighSpeed", // 高速
    brightness: "Brightness", // 亮度
    webVersion: "WebVersion", // web版本
    ThisRestoreContinue:
      "This operation will restore the factory settings, do you want to continue?", // 此操作将恢复出厂设置, 是否继续?
    factoryResetSuccessful:
      "The factory reset is successful, and I am going to the login page...", // 恢复出厂设置成功,正在前往登录页...
    FailedRestore: "Failed to restore factory settings", // 恢复出厂设置失败
    error: "Error", // 错误
    DeviceDisconnected: "Device disconnected", // 设备已断开连接
    DeviceConnected: "Device connected", // 设备已连接
    NoSignal: "No signal source at current input port", // 当前输入端口无信号源
    crossBorder: "Horizontal or vertical cross-border", // 横向或纵向越界
    cuttingPlan: "cuttingPlan" // 裁剪方案
  },
  upgrade: {
    pressCard: "ByCard", // 按卡升级
    byType: "ByType", // 按类型升级
    MCUUpgradeInputCard: "MCU upgrade input card", // MCU升级输入卡
    FPGAUpgradeInputCard: "FPGA upgrade input card(Need to restart the device)", // FPGA升级输入卡(需要重启设备)
    MCUUpgradeOutputCard: "MCU upgrade output card", // MCU升级输出卡
    FPGAUpgradeOutputCard:
      "FPGA upgrade output card(Need to restart the device)", // FPGA升级输出卡(需要重启设备)
    webUpgrade: "Web upgrade", // web升级
    SOCUpgrade: "Hisilicon", // SOC升级
    MCUControlUpgrade: "MCU upgrade of control card", // 控制卡MCU升级
    FPGAControlUpgrade:
      "FPGA upgrade of control card(Need to restart the device)", // 控制卡FPGA升级(需要重启设备)
    select: "Select", // 选择文件
    Upload: "Upload", // 立即上传
    selectTip: "Please select card or type", // 请选择卡或类型
    selectFileTip: "Please select file", // 请选择文件
    upgradeSuccessful:
      "The upgrade is successful, the program is restarting...", // 升级成功，程序正在重启...
    FileVerFailed: "File verification failed", // 文件检验失败
    UploadingFile: "Uploading file...", // 正在上传文件...
    notLeave: "Do not leave or refresh the current page..." // 请勿离开或刷新当前页面...
  },
  user: {
    add: "Add", // 添加账号
    edit: "Edit", // 编辑账号
    account: "Account", // 账号
    type: "Type", // 账号类型
    actionBar: "ActionBar", // 操作栏
    administrator: "Administrator", // 管理员
    Super: "Super", // 超级管理员
    Ordinary: "Ordinary", // 普通账号
    delete: "Delete" // 删除账号
  },
  tip: {
    PasswordThan: "Password can not be blank", // 密码不能为空
    PleaseInputUsername: "Please input Username", // 请输入账号
    PleasePermissions: "Please select account permissions", // 请选择账号权限
    FailedAccountList: "Failed to get account list", // 获取账号列表失败
    AddSuccessTip: "Add account successfully", // 添加账号成功
    AddFailedTip: "Failed to add account", // 添加账号失败
    EditSuccessTip: "Edit account successfully", // 编辑账号成功
    EditFailedTip: "Failed to edit account", // 编辑账号失败
    deleteAccountTip:
      "This operation will permanently delete the account, do you want to continue?", // 此操作将永久删除该账号, 是否继续?
    deleteFiled: "Failed to delete", // 删除失败
    PortTip:
      "Tips: Click port to display operation bar (odd ports of 4K input card and four layer output card are valid)"
  },
  res: {
    add: "Add", // 添加
    edit: "Edit", // 编辑
    delete: "Delete", // 删除
    Name: "Name", // 名称
    H_ACTIVE: "H_ACTIVE", // 水平有效像素
    V_ACTIVE: "V_ACTIVE", // 垂直有效像素
    H_FP: "H_FP", // 水平前沿
    V_FP: "V_FP", // 垂直前沿
    H_SYNC: "H_SYNC", // 水平同步宽度
    V_SYNC: "V_SYNC", // 垂直同步宽度
    H_POL: "H_POL", // 水平同步极性
    V_POL: "V_POL", // 垂直同步极性
    H_BP: "H_BP", // 水平后沿
    V_BP: "V_BP", // 垂直后沿
    H_TOTAL: "H_TOTAL", // 水平总数
    V_TOTAL: "V_TOTAL", // 垂直总数
    Fps: "Fps", // 刷新率
    Rate: "Rate", // 点时钟
    PleaseName: "Please enter the resolution name", // 请输入分辨率名称
    nameAlready: "Resolution name is already in use", // 分辨率名称已占用
    PleaseHorizontal: "Please enter a valid horizontal pixel", // 请输入水平有效像素
    PleaseVertical: "Please enter a valid vertical pixel", // 请输入垂直有效像素
    PleaseFrontier: "Please enter horizontal frontier", // 请输入水平前沿
    PleaseFront: "Please enter the vertical front", // 请输入垂直前沿
    Pleasehorizontalsyncwidth: "Please enter the horizontal sync width", // 请输入水平同步宽度
    Pleaseverticalsyncwidth: "Please enter the vertical sync width", // 请输入垂直同步宽度
    Pleasehorizontalsyncpolarity: "Please enter the horizontal sync polarity", // 请输入水平同步极性
    Pleaseverticalsyncpolarity: "Please enter the vertical sync polarity", // 请输入垂直同步极性
    Pleasehorizontaltrailingedge: "Please enter the horizontal trailing edge", // 请输入水平后沿
    Pleaseverticaltrailingedge: "Please enter the vertical trailing edge", // 请输入垂直后沿
    Pleasetotalnumberlevels: "Please enter the total number of levels", // 请输入水平总数
    Pleasetotalnumberverticals: "Please enter the total number of verticals", // 请输入垂直总数
    Pleaserefreshrate: "Please enter the refresh rate", // 请输入刷新率
    deleteResolutionTip:
      "This operation will delete the resolution, do you want to continue?", // 此操作将删除该分辨率, 是否继续?
    Undeleted: "Undeleted" // 已取消删除
  },
  spl: {
    belongingToTheGroup: "CurrentGroup", // 所属分组
    Rename: "Rename", // 重命名
    addGroup: "AddGroup", // 添加分组
    deleteGroup: "DeleteGroup", // 删除分组
    GroupType: "GroupType", // 分组类型
    PanelGap: "MarginWidth", // 边缘宽度
    HS: "HorizontalSpacing", // 水平间距
    VI: "VerticalInterval", // 垂直间距
    rowAndColumnSettings: "RowAndColumnSettings", // 行列设置
    row: "R", // 行
    col: "C", // 列
    outputFormat: "OutputFormat", // 输出格式
    screenSettings: "ScreenSettings", // 屏幕设置
    Screen: "Screen", // 屏幕
    setUp: "SetUp", // 设置
    x: "X", // 水平起点
    y: "Y", // 垂直起点
    w: "W", // 屏幕宽
    h: "H", // 屏幕高
    open: "Open", // 开窗
    cancelCurrentMap: "CancelCurrentMap", // 取消当前映射
    enterMap: "EnterMap", // 提交映射
    outCardList: "OutCardList", // 输出卡列表
    PleaseName: "Please enter a group name", // 请输入分组名称
    PleaseGroupType: "Please select group type", // 请选择分组类型
    charactersLength: "1 to 6 characters in length", // 长度在 1 到 6 个字符
    PleaseResolution: "Please select resolution", // 请选择分辨率
    PleaseMapFirst: "Please submit the mapping first", // 请先提交映射
    WindowOpened: "Window opened", // 已开窗
    Processing: "Processing...", // 正在处理...
    PleaseGroupName: "Please enter a group name", // 请输入分组名称
    CancelRename: "Cancel rename", // 取消重命名
    OnlyFourGroups: "Only four groups can be added", // 只能添加四个分组
    ScreenGrouping: "Group", // 屏幕分组
    OnlyOneGroup: "Only one group cannot be deleted", // 仅有一个分组不能删除
    SettingUp: "Setting up..." // 正在设置...
  },
  route: {
    facilityset: "DeviceSettings",
    upgrademanage: "UpgradeManagement",
    usermanage: "AccountManagement",
    CustomResolution: "CustomResolution",
    SplicingSettings: "MosaicSettings"
  },
  navbar: {
    logOut: "SignOut"
  },
  login: {
    title: "SplicingProcessor",
    logIn: "LogIn",
    username: "Account",
    password: "Password",
    pleaseName: "Please enter user name", // 请输入用户名
    PleasePassword: "Please enter the password", // 请输入密码
    RememberPassword: "Remember password", // 记住密码
    IncorrectAccountPassword: "Incorrect account name or password", // 账户名或密码错误
    ServerConnectionFailed: "Server connection failed" // 服务器连接失败
  }
};
