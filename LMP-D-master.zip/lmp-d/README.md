# LMP-D

> lmp-d

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report
```
```textmate
更新记录
V1.0.2:
1.新增断电通知功能 
2.升级管理界面新增输出卡连接屏幕提示(已连接屏幕的输出卡序号为绿色) 
3.修复已知bug

V1.0.3:
1.SDI输出卡新增I系分辨率
2.一入一出卡输入信号输出信号标识可同时显示


海思打包步骤：
1.把前端资源包上传至/home/luke/3520DV400/LMP-D/APP/AppRelease/dist
2.cd /home/luke/3520DV400/LMP-D/APP
3.执行./mkAppUpgrade.sh



```