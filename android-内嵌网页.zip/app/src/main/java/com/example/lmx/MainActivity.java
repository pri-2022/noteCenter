package com.example.lmx;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.view.Window;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 设置 标题栏不显示
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (getSupportActionBar() != null){
            getSupportActionBar().hide();
        }

        setContentView(R.layout.activity_main);
        WebView webView = (WebView) findViewById(R.id.web_view);


        // 设置本地存储
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAppCacheEnabled(true);
        String appCachepath = getApplication().getCacheDir().getAbsolutePath();
        webView.getSettings().setAppCachePath(appCachepath);
        webView.getSettings().setDatabaseEnabled(true);


        // 设置 url 地址
        webView.loadUrl("http://192.168.0.178:80");
        webView.setWebViewClient(new WebViewClient());
    }
}