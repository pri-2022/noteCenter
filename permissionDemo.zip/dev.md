1. vue create demo , 可以选择 自定义配置
2. 安装 element UI , 可以使用 vue add element