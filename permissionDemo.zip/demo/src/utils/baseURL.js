const baseUrl = 'http://localhost:3300'
export default baseUrl