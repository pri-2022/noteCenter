<template>
  <div class="clearfix" id="login_warp">
    <h2 class="title">登录页</h2>
    <div id="login">
      <div class="login--account">
        <span>账号:</span>
        <input type="text" name="account" v-model.trim="account" />
      </div>
      <div class="login--password">
        <span>密码:</span>
        <input
          type="password"
          name="password"
          v-model.trim="password"
          @keyup.enter="login"
        />
      </div>
      <p class="login--btn">
        <button id="loginBtn" @click="login">登录</button>
      </p>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      account: "",
      password: "",
    };
  },
  methods: {
      login(){
          
      }
  },
};
</script>

<style>
</style>