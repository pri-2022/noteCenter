# 简介

- SVG 表示可缩放矢量图
- SVG 用XML格式定义矢量图
- SVG 文件里的所有元素和属性都可以运用动画效果
- SVG 图片可以使用文本编辑器创建和编辑
- SVG 图片能够实现内容搜索，索引，脚本控制和压缩
- SVG 图片可以以任意高分辨率打印
- SVG 图片的缩放显示是无损的



SVG标签

- SVG图片用<svg>标记定义

- <svg>元素里提供了“width”和“height”两个属性来定义SVG图片的高度和宽度

- <circle>元素的功能是画出一个圆

- `cx`和`cy`两个属性分别定义了圆心的x坐标和y坐标。如果没有提供`cx`和`cy`的值，那么，缺省圆心是(0, 0)

- `r`属性定义了圆的半径长度

- `stroke`和`stroke-width`两个属性用来定义图像的边框样子。上面例子中定义圆的边框颜色为`green`，边框粗细为`4px`

- `fill`属性定义了圆内部填充的颜色。我们可以看出，例子中填充了黄色。



# 形状

- 矩形 <rect>
- 圆形 <circle>
- 椭圆 <ellipse>
- 直线 <line>
- 折线 <polyline>
- 多边形 <polygon>
- 路径 <path>





## SVG画矩形 

![](img/rect2.png)

```javascript
<svg width="400" height="180">
 
<rect x="50" y="20" width="150" height="150" rx="20" ry="20"
 
style="fill:blue;stroke:pink;stroke-width:5;fill-opacity:0.1;stroke-opacity:0.9;opacity:0.5"
	/>
</svg>
```

- `<rect>`元素里的`width`和`width`属性定义了矩形的高度和宽度
- `style`属性里的`fill`属性定义了这个矩形填充的颜色
- `style`属性里的`stroke-width`属性定义了矩形边线的宽度
- `style`属性里的`stroke`属性定义了矩形的边线的颜色
- `x`属性定义矩形距离左边的距离，比如，`x="50"`相对于CSS里的`margin-left: 50px`
- `y`属性定义了矩形距离上边的距离，比如`y="20"`相当于CSS里的`margin-top: 20px`
- CSS `fill-opacity`属性定义了填充颜色的透明度，值范围为 0 到 1
- CSS `stroke-opacity`属性定义了边线颜色的透明度，值范围为 0 到 1
- CSS `opacity`属性定义了整个图形元素的透明度
- `rx`和`ry`定义了矩形四个角的圆角效果





## SVG圆形

```javascript
<svg height="100" width="100">
 
<circle cx="50" cy="50" r="40" stroke="black"
stroke-width="3" fill="red" />
</svg>
```

- `cx`和`cy`属性是用来定义圆心的坐标。如果没有提供`cx`和`cy`的值，则缺省圆心是`(0,0)`
- `r`属性定义了圆的半径长度



## SVG椭圆

<ellipse>元素的作用是绘制一个椭圆。

椭圆跟圆形很相似。不同之处在于椭圆有两个半径，并且这两个值不同，而圆形也可以说有两个半径，但两个值是相同的：

例子1

![](img/ellipse.png)

```javascript
<svg height="150" width="500">
 
<ellipse cx="240" cy="100" rx="220" ry="30"
style="fill:purple" />
 
<ellipse cx="220" cy="70" rx="190" ry="20"
style="fill:lime" />
 
<ellipse cx="210" cy="45" rx="170" ry="15"
style="fill:yellow" />
</svg>
```

- `cx`属性定义了椭圆的`x`坐标
- `cy`属性定义了椭圆的`y`坐标
- `rx`属性定义了椭圆的横向半径
- `ry`属性定义了椭圆的纵向半径



例子2

![](img/ellipse2.png)

```javascript
<svg height="100" width="500">
 
<ellipse cx="240" cy="50" rx="220" ry="30"
style="fill:yellow" />
 
<ellipse cx="220" cy="50" rx="190" ry="20"
style="fill:white" />
</svg>
```



## SVG直线

```svg
<svg height="210" width="500">
 
<line x1="0" y1="0" x2="200" y2="200"
style="stroke:rgb(255,0,0);stroke-width:2" />
</svg>
```

- `x1`属性定义了直线的x轴起始坐标
- `y1`属性定义了直线的y轴起始坐标
- `x2`属性定义了直线的x轴终止坐标
- `y2`属性定义了直线的y轴终止坐标



## SVG折线

![](img/line.png)

```svg
<svg height="180" width="500">
 
<polyline points="0,40 40,40 40,80 80,80 80,120 120,120 120,160"
 
style="fill:white;stroke:red;stroke-width:4" />
</svg>
```

- `points`属性里定义了各个点的坐标，`x`和`y`坐标之间用逗号分别，多个坐标之间用空格分割





## SVG多边形

<polygon>元素用来绘制多边形图形，比如三角形，四边形，五边形等。

多边形是直线围成的图形。

![](img/polygon.png)

```svg
<svg height="210" width="500">
  <polygon points="100,10 40,198 190,78 10,78 160,198"
 
style="fill:lime;stroke:purple;stroke-width:5;fill-rule:evenodd;" />
</svg>
```

- `fill-rule`属性的取值可以是`nonzero | evenodd | inherit`





## SVG路径

<path>元素可以用来定义一个路径。

| 指令 | 参数                                               | 名称                             | 描述                                                         |
| :--- | :------------------------------------------------- | :------------------------------- | :----------------------------------------------------------- |
| M    | x,y                                                | moveto 移动到                    | 移动虚拟画笔到指定的（x,y）坐标，仅移动不绘制                |
| m    | x,y                                                | moveto                           | 同M，但使用相对坐标                                          |
| L    | x,y                                                | lineto 连直线到                  | 从当前画笔所在位置绘制一条直线到指定的（x,y）坐标            |
| l    | x,y                                                | lineto                           | 同L，但使用相对坐标                                          |
| H    | x                                                  | horizontal lineto 水平连线到     | 绘制一条水平直线到参数指定的x坐标点，y坐标为画笔的y坐标      |
| h    | x                                                  | horizontal lineto                | 同H，但使用相对坐标                                          |
| V    | y                                                  | vertical lineto 垂直连线到       | 从当前位置绘制一条垂直直线到参数指定的y坐标                  |
| v    | y                                                  | vertical lineto                  | 同V，但使用相对坐标                                          |
| C    | x1,y1 x2,y2 x,y                                    | curveto 三次方贝塞尔曲线         | 从当前画笔位置绘制一条三次贝兹曲线到参数（x,y）指定的坐标。x1，y1和x2,y2是曲线的开始和结束控制点，用于控制曲线的弧度 |
| c    | x1,y1 x2,y2 x,y                                    | curveto                          | 同C，但使用相对坐标                                          |
| S    | x2,y2 x,y                                          | shorthand / 平滑三次方贝塞尔曲线 | 从当前画笔位置绘制一条三次贝塞尔曲线到参数（x,y）指定的坐标。x2,y2是结束控制点。开始控制点和前一条曲线的结束控制点相同 |
| s    | x2,y2 x,y                                          | shorthand / 平滑三次方贝塞尔曲线 | 同S，但使用相对坐标                                          |
| Q    | x1,y1 x,y                                          | 二次方贝塞尔曲线                 | 从当前画笔位置绘制一条二次方贝塞尔曲线到参数（x,y）指定的坐标。x1,y1是控制点，用于控制曲线的弧度 |
| q    | x1,y1 x,y                                          | 二次方贝塞尔曲线                 | 同Q，但使用相对坐标                                          |
| T    | x,y                                                | 平滑的二次贝塞尔曲线             | 从当前画笔位置绘制一条二次贝塞尔曲线到参数（x,y）指定的坐标。控制点被假定为最后一次使用的控制点 |
| t    | x,y                                                | 平滑的二次贝塞尔曲线             | 同T，但使用相对坐标                                          |
| A    | rx,ry x-axis-rotation large-arc-flag,sweepflag x,y | 椭圆弧线                         | 从当前画笔位置开始绘制一条椭圆弧线到（x,y）指定的坐标。rx和ry分别为椭圆弧线水平和垂直方向上的半径。x-axis-rotation指定弧线绕x轴旋转的度数。它只在rx和ry的值不相同是有效果。large-arc-flag是大弧标志位，取值0或1，用于决定绘制大弧还是小弧。sweep-flag用于决定弧线绘制的方向 |
| a    | rx,ry x-axis-rotation large-arc-flag,sweepflag x,y | 椭圆弧线                         | 同A，但使用相对坐标                                          |
| Z    | 无                                                 | 闭合路径                         | 从结束点绘制一条直线到开始点，闭合路径                       |
| z    | 无                                                 | 闭合路径                         | 同Z                                                          |

![](img/path.png)

```svg
<svg height="400" width="450">
	  <path id="lineAB" d="M 100 350 l 150 -300" stroke="red"
	  stroke-width="3" fill="none" />
	  <path id="lineBC" d="M 250 50 l 150 300" stroke="red"
	  stroke-width="3" fill="none" />
	  <path d="M 175 200 l 150 0" stroke="green" stroke-width="3"
	  fill="none" />
	  <path d="M 100 350 q 150 -300 300 0" stroke="blue"
	  stroke-width="5" fill="none" />
	  <!-- Mark relevant points -->
	  <g stroke="black" stroke-width="3" fill="black">
	    <circle id="pointA" cx="100" cy="350" r="3" />
	    <circle id="pointB" cx="250" cy="50" r="3" />
	    <circle id="pointC" cx="400" cy="350" r="3" />
	  </g>
	  <!-- Label the points -->
	  <g font-size="30" font-family="sans-serif" fill="black" stroke="none"
	  text-anchor="middle">
	    <text x="100" y="350" dx="-30">A</text>
	    <text x="250" y="50" dy="-10">B</text>
	    <text x="400" y="350" dx="30">C</text>
	  </g>
	</svg>
```





# SVG边线边框属性

- stroke
- stroke-width
- stroke-linecap
- stroke-dasharray

## SVG stroke 属性

```svg
<svg height="80" width="300">
  <g fill="none">
    <path stroke="red" stroke-width="2" d="M5 20 l215 0" />
    <path stroke="black" stroke-width="2" d="M5 40 l215 0" />
    <path stroke="blue" stroke-width="2" d="M5 60 l215 0" />
  </g>
</svg>
```

## SVG stroke-linecap 属性

`stroke-linecap`属性用来定义开放式路径的端点的样子

![](img/linecap.png)

```svg
<svg height="80" width="300">
  <g fill="none" stroke="black" stroke-width="20">
    <path stroke-linecap="butt" d="M5 20 l215 0" />
    <path stroke-linecap="round" d="M5 40 l215 0" />
    <path stroke-linecap="square" d="M5 60 l215 0" />
  </g>
</svg>
```

## SVG stroke-dasharray 属性

`stroke-dasharray`属性用来创建虚线

![](img/linecap.png)

```svg
<svg height="80" width="300">
  <g fill="none" stroke="black" stroke-width="4">
    <path stroke-dasharray="5,5" d="M5 20 l215 0" />
    <path stroke-dasharray="10,10" d="M5 40 l215 0" />
    <path stroke-dasharray="20,10,5,5,5,10" d="M5 60 l215 0" />
  </g>
</svg>
```

# 结构元素

# SVG <use>

<use>标记的作用是能从SVG文档内部取出一个节点，克隆它，并把它输出到别处。跟‘引用’很相似，但它是深度克隆

![](img/use.png)

```html
<svg width="100%" height="300" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox='0 0 50 100'>
  <style>
    .classA { fill:red }
  </style> 
  <defs>
    <g id="Port">
      <circle style="fill:inherit" r="10"/>
    </g>
  </defs>
 
  <text y="15">black</text>
  <use x="50" y="10" xlink:href="#Port" />
  <text y="35">red</text>
  <use x="50" y="30" xlink:href="#Port" class="classA"/>
  <text y="55">blue</text>
  <use x="50" y="50" xlink:href="#Port" style="fill:blue"/>
 </svg>
```

